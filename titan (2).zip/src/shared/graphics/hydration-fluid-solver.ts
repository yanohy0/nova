// SOTA 2D Vorticity-Confinement Fluid Solver, Analytic Teardrop Volume Integral,
// and Component-Aware Interfacial Card Droplet Simulation
// (Contact Angle Hysteresis, Stick-Slip Pinning, Lubrication Theory, Landau-Levich Trails,
//  Plateau-Rayleigh Breakup, Area-Conserving Coalescence, & DOM Collider Physics).

// ============================================================================
// 1. Analytic Volume Conservation for Teardrop Silhouette (Area Integral Inversion)
// ============================================================================
// Matches inner cavity sdRoundCone3D(p, (0,-0.155,0), (0,0.435,0), 0.305, 0.016) + 0.022 in DROPLET_FRAGMENT_300.
const DROPLET_Y_MIN = -0.438;
const DROPLET_Y_MAX = 0.422;
const AREA_LUT_SIZE = 129;

function dropletInnerRadiusAtY(y: number): number {
  const yBot = -0.155;
  const rBot = 0.283; // 0.305 - 0.022 cavity thickness
  const yTop = 0.435;
  const rTop = 0.006;

  if (y <= yBot) {
    const dy = y - yBot;
    return Math.sqrt(Math.max(0, rBot * rBot - dy * dy));
  }
  if (y >= yTop) {
    const dy = y - yTop;
    return Math.sqrt(Math.max(0, rTop * rTop - dy * dy));
  }
  const t = (y - yBot) / (yTop - yBot);
  const sinAlpha = (rBot - rTop) / (yTop - yBot);
  const cosAlpha = Math.sqrt(Math.max(0.01, 1 - sinAlpha * sinAlpha));
  return Math.max(0.002, (rBot + (rTop - rBot) * t) / cosAlpha);
}

const DROPLET_AREA_LUT = (() => {
  const lut = new Float32Array(AREA_LUT_SIZE);
  let accum = 0;
  const step = (DROPLET_Y_MAX - DROPLET_Y_MIN) / (AREA_LUT_SIZE - 1);
  let r0 = dropletInnerRadiusAtY(DROPLET_Y_MIN);
  let prevSection = Math.PI * r0 * r0;
  lut[0] = 0;
  for (let i = 1; i < AREA_LUT_SIZE; i++) {
    const y = DROPLET_Y_MIN + i * step;
    const r = dropletInnerRadiusAtY(y);
    // Frustum / 3D revolution slice cross-section pi * r^2
    const section = Math.PI * r * r;
    accum += 0.5 * (prevSection + section) * step;
    lut[i] = accum;
    prevSection = section;
  }
  const total = accum > 0 ? accum : 1;
  for (let i = 0; i < AREA_LUT_SIZE; i++) {
    lut[i] = (lut[i] ?? 0) / total;
  }
  return lut;
})();

export function volumeToDropletFillY(volumeRatio: number): number {
  const v = Math.min(1, Math.max(0, Number.isFinite(volumeRatio) ? volumeRatio : 0));
  if (v <= 0) return DROPLET_Y_MIN;
  if (v >= 1) return DROPLET_Y_MAX;

  let lo = 0;
  let hi = AREA_LUT_SIZE - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if ((DROPLET_AREA_LUT[mid] ?? 0) <= v) lo = mid;
    else hi = mid;
  }
  const a0 = DROPLET_AREA_LUT[lo] ?? 0;
  const a1 = DROPLET_AREA_LUT[hi] ?? 1;
  const frac = a1 > a0 ? (v - a0) / (a1 - a0) : 0;
  const t = (lo + frac) / (AREA_LUT_SIZE - 1);
  return DROPLET_Y_MIN + t * (DROPLET_Y_MAX - DROPLET_Y_MIN);
}

// ============================================================================
// 2. 2D Incompressible Navier-Stokes + Vorticity Confinement + CSF Curvature
// ============================================================================
// Lightweight 48x24 Eulerian grid packed into RGBA8 (u, v, vorticity, aeration)
// for real-time GPU advection of internal eddies, Stokes bubbles & surface shimmer.

export class FluidVorticityGrid {
  readonly width: number;
  readonly height: number;
  private readonly size: number;
  private u: Float32Array;
  private v: Float32Array;
  private uPrev: Float32Array;
  private vPrev: Float32Array;
  private curl: Float32Array;
  private absCurl: Float32Array;
  private p: Float32Array;
  private div: Float32Array;
  private aeration: Float32Array;
  private aerationPrev: Float32Array;
  readonly packedRgba: Uint8Array;
  private energy = 0;
  private _version = 0;

  get version(): number {
    return this._version;
  }

  constructor(width = 48, height = 24) {
    this.width = width;
    this.height = height;
    this.size = width * height;
    this.u = new Float32Array(this.size);
    this.v = new Float32Array(this.size);
    this.uPrev = new Float32Array(this.size);
    this.vPrev = new Float32Array(this.size);
    this.curl = new Float32Array(this.size);
    this.absCurl = new Float32Array(this.size);
    this.p = new Float32Array(this.size);
    this.div = new Float32Array(this.size);
    this.aeration = new Float32Array(this.size);
    this.aerationPrev = new Float32Array(this.size);
    this.packedRgba = new Uint8Array(this.size * 4);
    this.packToTexture();
  }

  private idx(x: number, y: number): number {
    const cx = x < 0 ? 0 : x >= this.width ? this.width - 1 : x;
    const cy = y < 0 ? 0 : y >= this.height ? this.height - 1 : y;
    return cy * this.width + cx;
  }

  isActive(): boolean {
    return this.energy > 0.002;
  }

  injectImpulse(normX: number, normY: number, vx: number, vy: number, aerationAmount = 0.75): void {
    const cx = Math.round(Math.min(1, Math.max(0, normX)) * (this.width - 1));
    const cy = Math.round(Math.min(1, Math.max(0, normY)) * (this.height - 1));
    const radius = 3;
    for (let dy = -radius; dy <= radius; dy++) {
      for (let dx = -radius; dx <= radius; dx++) {
        const d2 = dx * dx + dy * dy;
        if (d2 > radius * radius) continue;
        const w = Math.exp(-d2 * 0.45);
        const i = this.idx(cx + dx, cy + dy);
        const swirlU = -dy * 0.38 * (vx >= 0 ? 1 : -1);
        const swirlV = dx * 0.38 * (vx >= 0 ? 1 : -1);
        this.u[i] = Math.max(-4, Math.min(4, (this.u[i] ?? 0) + (vx + swirlU) * w));
        this.v[i] = Math.max(-4, Math.min(4, (this.v[i] ?? 0) + (vy + swirlV) * w));
        this.aeration[i] = Math.min(1, (this.aeration[i] ?? 0) + aerationAmount * w);
      }
    }
    this.energy = Math.min(1.5, this.energy + 0.65);
    this.packToTexture();
  }

  step(dt: number, tiltX = 0, tiltY = 0): void {
    const clampedDt = Math.min(0.033, Math.max(0.004, dt));
    const w = this.width;
    const h = this.height;

    if (Math.abs(tiltX) > 0.01 || Math.abs(tiltY) > 0.01) {
      this.energy = Math.min(1.5, this.energy + (Math.abs(tiltX) + Math.abs(tiltY)) * 0.08);
    }

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const aeL = this.aeration[i - 1] ?? 0;
        const aeR = this.aeration[i + 1] ?? 0;
        const aeD = this.aeration[i - w] ?? 0;
        const aeU = this.aeration[i + w] ?? 0;
        const aeC = this.aeration[i] ?? 0;
        const curvature = aeL + aeR + aeD + aeU - 4 * aeC;
        const gradX = 0.5 * (aeR - aeL);
        const gradY = 0.5 * (aeU - aeD);
        const csfScale = 0.0728 * 3.5;

        const buoyY = aeC * 0.42;
        this.u[i] = (this.u[i] ?? 0) + (tiltX * 0.85 + curvature * gradX * csfScale) * clampedDt;
        this.v[i] = (this.v[i] ?? 0) + (tiltY * 0.45 + buoyY + curvature * gradY * csfScale) * clampedDt;
      }
    }

    // Vorticity Confinement (Fedkiw et al.)
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const dvdx = 0.5 * ((this.v[i + 1] ?? 0) - (this.v[i - 1] ?? 0));
        const dudy = 0.5 * ((this.u[i + w] ?? 0) - (this.u[i - w] ?? 0));
        const c = dvdx - dudy;
        this.curl[i] = c;
        this.absCurl[i] = Math.abs(c);
      }
    }

    const vorticityStrength = 2.6;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const nx = 0.5 * ((this.absCurl[i + 1] ?? 0) - (this.absCurl[i - 1] ?? 0));
        const ny = 0.5 * ((this.absCurl[i + w] ?? 0) - (this.absCurl[i - w] ?? 0));
        const len = Math.hypot(nx, ny) + 1e-5;
        const dx = nx / len;
        const dy = ny / len;
        const c = this.curl[i] ?? 0;
        this.u[i] = (this.u[i] ?? 0) + dy * c * vorticityStrength * clampedDt;
        this.v[i] = (this.v[i] ?? 0) - dx * c * vorticityStrength * clampedDt;
      }
    }

    // Incompressible projection
    this.p.fill(0);
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        this.div[i] =
          -0.5 *
          ((this.u[i + 1] ?? 0) -
            (this.u[i - 1] ?? 0) +
            (this.v[i + w] ?? 0) -
            (this.v[i - w] ?? 0));
      }
    }
    for (let iter = 0; iter < 6; iter++) {
      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          const i = y * w + x;
          this.p[i] =
            0.25 *
            ((this.div[i] ?? 0) +
              (this.p[i - 1] ?? 0) +
              (this.p[i + 1] ?? 0) +
              (this.p[i - w] ?? 0) +
              (this.p[i + w] ?? 0));
        }
      }
    }
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        this.u[i] = (this.u[i] ?? 0) - 0.5 * ((this.p[i + 1] ?? 0) - (this.p[i - 1] ?? 0));
        this.v[i] = (this.v[i] ?? 0) - 0.5 * ((this.p[i + w] ?? 0) - (this.p[i - w] ?? 0));
      }
    }

    // Semi-Lagrangian Advection
    this.uPrev.set(this.u);
    this.vPrev.set(this.v);
    this.aerationPrev.set(this.aeration);

    const velDamp = Math.exp(-clampedDt * 1.15);
    const aerDamp = Math.exp(-clampedDt * 0.65);

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const sx = Math.max(0.5, Math.min(w - 1.5, x - (this.uPrev[i] ?? 0) * clampedDt * 14));
        const sy = Math.max(0.5, Math.min(h - 1.5, y - (this.vPrev[i] ?? 0) * clampedDt * 14));
        const x0 = Math.floor(sx);
        const y0 = Math.floor(sy);
        const tx = sx - x0;
        const ty = sy - y0;

        const i00 = y0 * w + x0;
        const i10 = i00 + 1;
        const i01 = i00 + w;
        const i11 = i01 + 1;

        const uSample =
          (1 - tx) * (1 - ty) * (this.uPrev[i00] ?? 0) +
          tx * (1 - ty) * (this.uPrev[i10] ?? 0) +
          (1 - tx) * ty * (this.uPrev[i01] ?? 0) +
          tx * ty * (this.uPrev[i11] ?? 0);
        const vSample =
          (1 - tx) * (1 - ty) * (this.vPrev[i00] ?? 0) +
          tx * (1 - ty) * (this.vPrev[i10] ?? 0) +
          (1 - tx) * ty * (this.vPrev[i01] ?? 0) +
          tx * ty * (this.vPrev[i11] ?? 0);
        const aSample =
          (1 - tx) * (1 - ty) * (this.aerationPrev[i00] ?? 0) +
          tx * (1 - ty) * (this.aerationPrev[i10] ?? 0) +
          (1 - tx) * ty * (this.aerationPrev[i01] ?? 0) +
          tx * ty * (this.aerationPrev[i11] ?? 0);

        this.u[i] = uSample * velDamp;
        this.v[i] = vSample * velDamp;
        this.aeration[i] = aSample * aerDamp;
      }
    }

    for (let x = 0; x < w; x++) {
      this.u[x] = 0;
      this.v[x] = 0;
      this.u[(h - 1) * w + x] = 0;
      this.v[(h - 1) * w + x] = 0;
    }
    for (let y = 0; y < h; y++) {
      this.u[y * w] = 0;
      this.v[y * w] = 0;
      this.u[y * w + (w - 1)] = 0;
      this.v[y * w + (w - 1)] = 0;
    }

    this.energy *= Math.exp(-clampedDt * 0.85);
    this.packToTexture();
  }

  private packToTexture(): void {
    const out = this.packedRgba;
    for (let i = 0; i < this.size; i++) {
      const o = i * 4;
      const uVal = Math.max(-1, Math.min(1, (this.u[i] ?? 0) * 0.5));
      const vVal = Math.max(-1, Math.min(1, (this.v[i] ?? 0) * 0.5));
      const cVal = Math.max(-1, Math.min(1, (this.curl[i] ?? 0) * 0.4));
      const aVal = Math.max(0, Math.min(1, this.aeration[i] ?? 0));
      out[o] = Math.round((uVal * 0.5 + 0.5) * 255);
      out[o + 1] = Math.round((vVal * 0.5 + 0.5) * 255);
      out[o + 2] = Math.round((cVal * 0.5 + 0.5) * 255);
      out[o + 3] = Math.round(aVal * 255);
    }
    this._version += 1;
  }
}

// ============================================================================
// 3. Component-Aware Interfacial Card Droplet Simulation
//    - Real DOM Collider Obstacles (Buttons, Droplet Gauge, Tank Rim, Labels)
//    - Contact Angle Hysteresis (CAH) + Stick-Slip + Lubrication Theory
//    - Curved Landau-Levich Wet Trails + Plateau-Rayleigh Breakup
//    - Smooth-Min Coalescence with Area Conservation (A_total = A1 + A2)
//    - Tactile Pointer/Touch Manipulation & Ambient Condensation Cycle
// ============================================================================

export const MAX_CARD_DROPLETS = 12;
export const MAX_CARD_OBSTACLES = 6;

export type CardColliderKind = 'ledge' | 'droplet-pool' | 'tank-pool' | 'label';

export interface CardColliderRect {
  id: string;
  kind: CardColliderKind;
  xMin: number;
  yMin: number;
  xMax: number;
  yMax: number;
}

export interface CardDropletImpactEvent {
  target: 'droplet' | 'tank';
  normX: number;
  strength: number;
}

export interface CardDropletBody {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  mass: number;
  pinned: boolean;
  pinThreshold: number;
  dwellTimer: number;
  maxDwell: number;
  creepRate: number;
  trailStartX: number;
  trailStartY: number;
  trailBendX: number;
  trailAlpha: number;
  stretch: number;
  onLedge: boolean;
  splashedTank: boolean;
  splashedDroplet: boolean;
}

export interface CardDropletGpuState {
  // [x, y, radius, stretch] * 12
  drops: Float32Array;
  // [vx, vy] * 12
  velocities: Float32Array;
  // [trailStartX, trailStartY, trailBendX, trailAlpha] * 12
  trails: Float32Array;
  // [xMin, yMin, xMax, yMax] * 6
  obstacles: Float32Array;
  // Wetness glow intensity on each obstacle [0..1]
  obstacleWetness: Float32Array;
}

export class CardDropletSim {
  readonly bodies: CardDropletBody[] = [];
  colliders: CardColliderRect[] = [];
  readonly gpu: CardDropletGpuState = {
    drops: new Float32Array(MAX_CARD_DROPLETS * 4),
    velocities: new Float32Array(MAX_CARD_DROPLETS * 2),
    trails: new Float32Array(MAX_CARD_DROPLETS * 4),
    obstacles: new Float32Array(MAX_CARD_OBSTACLES * 4),
    obstacleWetness: new Float32Array(MAX_CARD_OBSTACLES),
  };
  private seed = 1337;
  private activityEnergy = 0;
  private ambientEnabled = false;
  private ambientAccumulator = 0;

  constructor() {
    this.resetCalmDew();
  }

  private nextRand(): number {
    this.seed = (this.seed * 1664525 + 1013904223) >>> 0;
    return this.seed / 4294967296;
  }

  setColliders(nextColliders: CardColliderRect[]): void {
    this.colliders = nextColliders.slice(0, MAX_CARD_OBSTACLES);
    this.gpu.obstacles.fill(-2);
    for (let i = 0; i < this.colliders.length; i++) {
      const c = this.colliders[i];
      if (!c) continue;
      const o4 = i * 4;
      this.gpu.obstacles[o4] = c.xMin;
      this.gpu.obstacles[o4 + 1] = c.yMin;
      this.gpu.obstacles[o4 + 2] = c.xMax;
      this.gpu.obstacles[o4 + 3] = c.yMax;
    }
  }

  setAmbientCondensation(enabled: boolean): void {
    this.ambientEnabled = enabled;
    if (enabled && this.activityEnergy < 0.45) {
      this.activityEnergy = 0.72;
      // Launch staggered sliding droplets + short-dwell creeping beads so all droplets are visibly alive
      for (let i = 0; i < this.bodies.length; i++) {
        const b = this.bodies[i];
        if (!b) continue;
        const isImmediateSlide = i < 7;
        b.x = 0.06 + ((i + 0.35 + this.nextRand() * 0.55) / this.bodies.length) * 0.88;
        b.y = isImmediateSlide ? 0.04 + (i / 7) * 0.54 : 0.06 + this.nextRand() * 0.62;
        b.radius = isImmediateSlide
          ? 0.0042 + this.nextRand() * 0.0026
          : 0.0034 + this.nextRand() * 0.0018;
        b.mass = b.radius * b.radius;
        b.pinned = !isImmediateSlide;
        b.pinThreshold = b.mass * (isImmediateSlide ? 0.75 : 1.06 + this.nextRand() * 0.14);
        b.dwellTimer = 0;
        b.maxDwell = 0.25 + this.nextRand() * 0.95;
        b.creepRate = 0.005 + this.nextRand() * 0.007;
        b.vx = (this.nextRand() - 0.5) * 0.018;
        b.vy = isImmediateSlide ? 0.055 + this.nextRand() * 0.055 : b.creepRate;
        b.trailStartX = b.x;
        b.trailStartY = b.y;
        b.trailBendX = 0;
        b.trailAlpha = isImmediateSlide ? 0.82 : 0.15;
        b.stretch = isImmediateSlide ? 0.28 : 0.06;
        b.onLedge = false;
        b.splashedTank = false;
        b.splashedDroplet = false;
      }
      this.syncGpuBuffers();
    }
  }

  resetCalmDew(): void {
    this.ambientEnabled = false;
    this.bodies.length = 0;
    const anchors: ReadonlyArray<[number, number, number]> = [
      [0.10, 0.15, 0.0042],
      [0.24, 0.11, 0.0036],
      [0.39, 0.22, 0.0045],
      [0.54, 0.13, 0.0038],
      [0.69, 0.19, 0.0046],
      [0.86, 0.14, 0.0040],
      [0.17, 0.42, 0.0034],
      [0.34, 0.51, 0.0037],
      [0.52, 0.39, 0.0036],
      [0.68, 0.47, 0.0042],
      [0.84, 0.68, 0.0039],
      [0.22, 0.79, 0.0034],
    ];
    for (let i = 0; i < MAX_CARD_DROPLETS; i++) {
      const [x, y, r] = anchors[i] ?? [0.5, 0.3, 0.005];
      this.bodies.push({
        x,
        y,
        vx: 0,
        vy: 0,
        radius: r,
        mass: r * r,
        pinned: true,
        pinThreshold: r * r * (1.10 + this.nextRand() * 0.22),
        dwellTimer: 0,
        maxDwell: 0.35 + this.nextRand() * 0.90,
        creepRate: 0.005 + this.nextRand() * 0.006,
        trailStartX: x,
        trailStartY: y,
        trailBendX: 0,
        trailAlpha: 0,
        stretch: 0,
        onLedge: false,
        splashedTank: false,
        splashedDroplet: false,
      });
    }
    this.activityEnergy = 0;
    this.gpu.obstacleWetness.fill(0);
    this.syncGpuBuffers();
  }

  /** Spawns active condensation and stick-slip sliding droplets when water is added or card is touched. */
  triggerCondensationBurst(intensity = 1.0): void {
    const count = Math.min(MAX_CARD_DROPLETS, 7 + Math.round(intensity * 5));
    for (let i = 0; i < count; i++) {
      const body = this.bodies[i];
      if (!body) continue;
      body.x = 0.06 + this.nextRand() * 0.88;
      body.y = 0.03 + this.nextRand() * 0.24;
      body.radius = 0.0042 + this.nextRand() * 0.0028;
      body.mass = body.radius * body.radius;
      body.pinned = i % 5 === 4;
      body.pinThreshold = body.mass * (body.pinned ? 1.05 : 0.78);
      body.dwellTimer = 0;
      body.maxDwell = 0.20 + this.nextRand() * 0.65;
      body.creepRate = 0.006 + this.nextRand() * 0.007;
      body.vx = (this.nextRand() - 0.5) * 0.025;
      body.vy = body.pinned ? body.creepRate : 0.075 + this.nextRand() * 0.085;
      body.trailStartX = body.x;
      body.trailStartY = body.y;
      body.trailBendX = 0;
      body.trailAlpha = body.pinned ? 0.25 : 0.86;
      body.stretch = body.pinned ? 0.12 : 0.36;
      body.onLedge = false;
      body.splashedTank = false;
      body.splashedDroplet = false;
    }
    this.activityEnergy = Math.max(this.activityEnergy, 1.0);
    this.syncGpuBuffers();
  }

  /** Direct tactile pointer/touch interaction: sweeps droplets aside, breaks pinning, or spawns a bead at tap. */
  applyPointerSweep(normX: number, normY: number, vx: number, vy: number, isTap: boolean): void {
    const cx = Math.min(0.96, Math.max(0.04, normX));
    const cy = Math.min(0.94, Math.max(0.04, normY));
    const brushR = isTap ? 0.18 : 0.13;
    let touchedAny = false;

    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (!b) continue;
      const dx = b.x - cx;
      const dy = b.y - cy;
      const dist = Math.hypot(dx, dy);
      if (dist < brushR) {
        touchedAny = true;
        const falloff = 1 - dist / brushR;
        const pushAngleX = dist > 0.004 ? dx / dist : (i % 2 === 0 ? 1 : -1);
        b.pinned = false;
        b.dwellTimer = 0;
        b.onLedge = false;
        b.vx = Math.max(-0.45, Math.min(0.45, b.vx + (vx * 0.55 + pushAngleX * 0.14) * falloff));
        b.vy = Math.max(0.045, Math.min(0.48, b.vy + (Math.max(0, vy) * 0.45 + 0.11) * falloff));
        b.stretch = Math.min(1, b.stretch + 0.35 * falloff);
        b.trailAlpha = Math.max(b.trailAlpha, 0.82);
      }
    }

    if (isTap || !touchedAny) {
      let target = this.bodies[0];
      let minPriority = Infinity;
      for (let i = 0; i < this.bodies.length; i++) {
        const b = this.bodies[i];
        if (!b) continue;
        const score = (b.pinned ? 0 : 10) + b.radius * 100;
        if (score < minPriority) {
          minPriority = score;
          target = b;
        }
      }
      if (target) {
        target.x = cx;
        target.y = cy;
        target.radius = isTap ? 0.0056 + this.nextRand() * 0.0018 : 0.0044 + this.nextRand() * 0.0016;
        target.mass = target.radius * target.radius;
        target.pinned = false;
        target.dwellTimer = 0;
        target.pinThreshold = target.mass * 0.8;
        target.vx = Math.max(-0.22, Math.min(0.22, vx * 0.35 + (this.nextRand() - 0.5) * 0.035));
        target.vy = Math.max(0.08, Math.min(0.28, 0.10 + Math.max(0, vy) * 0.22));
        target.trailStartX = target.x;
        target.trailStartY = target.y;
        target.trailBendX = 0;
        target.trailAlpha = 0.84;
        target.stretch = 0.36;
        target.onLedge = false;
        target.splashedTank = false;
        target.splashedDroplet = false;
      }
    }

    this.activityEnergy = Math.max(this.activityEnergy, isTap ? 0.95 : 0.76);
    this.syncGpuBuffers();
  }

  /** Shakes droplets off a clicked/hovered button ledge so they cascade onto the tank below. */
  shakeCollider(colliderId: string): void {
    const colIndex = this.colliders.findIndex((c) => c.id === colliderId);
    const col = colIndex >= 0 ? this.colliders[colIndex] : undefined;
    if (!col) return;
    this.gpu.obstacleWetness[colIndex] = 1.0;

    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (!b) continue;
      if (
        b.x >= col.xMin - 0.07 &&
        b.x <= col.xMax + 0.07 &&
        b.y >= col.yMin - 0.07 &&
        b.y <= col.yMax + 0.09
      ) {
        b.pinned = false;
        b.dwellTimer = 0;
        b.onLedge = false;
        const center = (col.xMin + col.xMax) * 0.5;
        b.vx += (b.x >= center ? 1 : -1) * 0.15;
        b.vy = Math.max(b.vy, 0.18);
        b.stretch = 0.65;
        b.trailAlpha = 0.9;
      }
    }
    this.activityEnergy = Math.max(this.activityEnergy, 0.85);
    this.syncGpuBuffers();
  }

  isActive(): boolean {
    if (this.ambientEnabled) return true;
    if (this.activityEnergy > 0.01) return true;
    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (b && (!b.pinned || b.vy > 0.002 || b.trailAlpha > 0.02 || b.stretch > 0.02)) {
        return true;
      }
    }
    return false;
  }

  step(
    dt: number,
    tiltX = 0,
    onDropletImpact?: (event: CardDropletImpactEvent) => void,
  ): void {
    const clampedDt = Math.min(0.033, Math.max(0.002, dt));

    for (let k = 0; k < MAX_CARD_OBSTACLES; k++) {
      const w = this.gpu.obstacleWetness[k] ?? 0;
      if (w > 0) this.gpu.obstacleWetness[k] = Math.max(0, w - clampedDt * 0.55);
    }

    // Continuous ambient stick-slip flow: keep at least 6 droplets actively sliding, and wake resting ones quickly
    if (this.ambientEnabled) {
      this.ambientAccumulator += clampedDt;
      this.activityEnergy = Math.max(this.activityEnergy, 0.36);
      if (this.ambientAccumulator > 0.45) {
        this.ambientAccumulator = 0;
        let slidingCount = 0;
        for (let i = 0; i < this.bodies.length; i++) {
          if (this.bodies[i] && !this.bodies[i]!.pinned) slidingCount++;
        }
        if (slidingCount < 7) {
          for (let i = 0; i < this.bodies.length; i++) {
            const b = this.bodies[i];
            if (!b || !b.pinned) continue;
            b.pinned = false;
            b.dwellTimer = 0;
            b.vx = (this.nextRand() - 0.5) * 0.022;
            b.vy = 0.055 + this.nextRand() * 0.045;
            b.trailStartX = b.x;
            b.trailStartY = b.y;
            b.trailBendX = 0;
            b.trailAlpha = Math.max(b.trailAlpha, 0.78);
            b.stretch = 0.28;
            break;
          }
        }
      }
    }

    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (!b) continue;

      if (this.activityEnergy > 0.05 || this.ambientEnabled) {
        b.mass += 0.000048 * clampedDt * (0.55 + this.activityEnergy);
        b.radius = Math.min(0.0105, Math.sqrt(b.mass));
      }

      if (b.pinned) {
        b.dwellTimer += clampedDt;
        // Even resting droplets visibly micro-creep under gravity before breaking static CAH pinning!
        if (this.ambientEnabled || this.activityEnergy > 0.06) {
          b.y += b.creepRate * clampedDt;
          b.x = Math.max(0.035, Math.min(0.965, b.x + tiltX * 0.015 * clampedDt));
        }

        const readyToSlide =
          (b.dwellTimer >= b.maxDwell || b.mass >= b.pinThreshold) &&
          (this.activityEnergy > 0.05 || this.ambientEnabled);

        if (readyToSlide || b.y > 0.96) {
          b.pinned = false;
          b.dwellTimer = 0;
          b.vy = 0.058 + this.nextRand() * 0.045;
          b.trailStartX = b.x;
          b.trailStartY = b.y;
          b.trailBendX = 0;
          b.trailAlpha = Math.max(b.trailAlpha, 0.82);
        } else {
          b.vx *= Math.exp(-clampedDt * 6);
          b.vy = b.creepRate;
          b.stretch = 0.08 + 0.06 * Math.sin(b.dwellTimer * 7.0 + i);
          b.trailAlpha = Math.max(0, b.trailAlpha - clampedDt * 0.16);
          continue;
        }
      }

      // Stick-Slip lubrication velocity with organic hesitation pulses (never permanently stalls)
      const roughnessPin = 0.5 + 0.5 * Math.sin(b.y * 48.0 + i * 2.1);
      const gravityDrive = (0.40 + b.mass * 3200.0) * (0.58 + 0.56 * roughnessPin);
      const viscousDrag = 2.8;
      b.vy += (gravityDrive - b.vy * viscousDrag) * clampedDt;
      b.vy = Math.max(0.018, Math.min(0.36, b.vy));
      b.vx += (tiltX * 0.28 - b.vx * 4.2) * clampedDt;

      // Component Collider Interaction (Buttons, Water Droplet Gauge, Crystal Tank, Labels)
      b.onLedge = false;
      for (let cIdx = 0; cIdx < this.colliders.length; cIdx++) {
        const col = this.colliders[cIdx];
        if (!col) continue;
        const margin = Math.max(0.012, b.radius * 1.15);
        const inX = b.x >= col.xMin - margin && b.x <= col.xMax + margin;

        if (col.kind === 'ledge') {
          if (inX && b.y >= col.yMin - b.radius * 0.4 && b.y <= col.yMin + 0.048) {
            b.onLedge = true;
            b.y = Math.min(b.y, col.yMin + 0.012);
            b.vy = 0.016;
            const colCenter = (col.xMin + col.xMax) * 0.5;
            const sideDir = b.x >= colCenter ? 1 : -1;
            b.vx += (sideDir * 0.42 + tiltX * 0.25) * clampedDt * 3.8;
            b.trailBendX = (b.x - b.trailStartX) * 0.45;
            this.gpu.obstacleWetness[cIdx] = Math.min(1, (this.gpu.obstacleWetness[cIdx] ?? 0) + clampedDt * 2.5);
          } else if (
            b.x >= col.xMin &&
            b.x <= col.xMax &&
            b.y > col.yMin + 0.048 &&
            b.y <= col.yMax + b.radius * 0.3
          ) {
            const colCenter = (col.xMin + col.xMax) * 0.5;
            const sideDir = b.x >= colCenter ? 1 : -1;
            b.vx += sideDir * 0.48 * clampedDt * 4.2;
            b.vy = Math.max(0.03, b.vy * 0.90);
            this.gpu.obstacleWetness[cIdx] = Math.min(1, (this.gpu.obstacleWetness[cIdx] ?? 0) + clampedDt * 1.8);
          }
        } else if (col.kind === 'droplet-pool') {
          const inGaugeY = b.y >= col.yMin + 0.08 && b.y <= col.yMax - 0.04;
          if (inX && inGaugeY && !b.splashedDroplet) {
            b.splashedDroplet = true;
            const colCenter = (col.xMin + col.xMax) * 0.5;
            const localNormX = Math.min(
              1,
              Math.max(0, (b.x - col.xMin) / Math.max(0.02, col.xMax - col.xMin)),
            );
            this.gpu.obstacleWetness[cIdx] = 1.0;
            onDropletImpact?.({
              target: 'droplet',
              normX: localNormX,
              strength: Math.min(3.2, Math.max(1.1, b.mass * 12000 + b.vy * 4.2)),
            });
            b.vx += (b.x >= colCenter ? 0.14 : -0.14);
            b.mass *= 0.62;
            b.radius = Math.max(0.0058, Math.sqrt(b.mass));
          }
        } else if (col.kind === 'tank-pool') {
          const inTankTopRim = b.y >= col.yMin - b.radius * 0.6 && b.y <= col.yMin + 0.045;
          if (inX && inTankTopRim) {
            if (!b.splashedTank) {
              b.splashedTank = true;
              const localNormX = Math.min(
                1,
                Math.max(0, (b.x - col.xMin) / Math.max(0.04, col.xMax - col.xMin)),
              );
              this.gpu.obstacleWetness[cIdx] = 1.0;
              onDropletImpact?.({
                target: 'tank',
                normX: localNormX,
                strength: Math.min(3.0, Math.max(1.0, b.mass * 11000 + b.vy * 3.8)),
              });
            }
            b.onLedge = true;
            b.vy = Math.max(0.024, b.vy * 0.78);
            b.vx += tiltX * 0.18 * clampedDt;
          }
        } else if (col.kind === 'label') {
          if (inX && b.y >= col.yMin && b.y <= col.yMax) {
            const colCenter = (col.xMin + col.xMax) * 0.5;
            b.vx += (b.x >= colCenter ? 0.09 : -0.09) * clampedDt * 2.2;
            b.vy = Math.max(0.028, b.vy * 0.94);
          }
        }
      }

      b.x = Math.max(0.035, Math.min(0.965, b.x + b.vx * clampedDt));
      b.y += b.vy * clampedDt;

      // Contact Angle Hysteresis (CAH)
      const targetStretch = b.onLedge ? 0.08 : Math.min(0.68, b.vy * 2.2);
      b.stretch += (targetStretch - b.stretch) * Math.min(1, clampedDt * 12);
      b.trailAlpha = Math.min(1.0, b.trailAlpha + clampedDt * 0.45);
      b.trailBendX = (b.x - b.trailStartX) * 0.38;

      if (this.colliders.length === 0 && b.y >= 0.58 && b.y <= 0.64 && b.vy > 0.03 && !b.splashedTank) {
        b.splashedTank = true;
        onDropletImpact?.({
          target: b.x < 0.25 ? 'droplet' : 'tank',
          normX: b.x < 0.25 ? b.x * 4 : (b.x - 0.25) / 0.75,
          strength: Math.min(2.6, Math.max(1.0, b.mass * 10000 + b.vy * 4.0)),
        });
      }

      // Landau-Levich trail mass deposition
      b.mass = Math.max(0.000032, b.mass - b.vy * 0.000034 * clampedDt);
      b.radius = Math.sqrt(b.mass);

      // Brief stick-slip micro-pause when hitting rough spots (never long freeze)
      if (roughnessPin < 0.04 && b.vy < 0.085 && !b.onLedge && this.nextRand() > 0.55) {
        b.pinned = true;
        b.dwellTimer = 0;
        b.maxDwell = 0.22 + this.nextRand() * 0.55;
        b.pinThreshold = b.mass * 1.05;
      }

      // Recycle droplet smoothly at top edge once it exits the bottom squircle bevel
      if (b.y > 1.06) {
        if (this.activityEnergy > 0.14 || this.ambientEnabled) {
          b.x = 0.06 + this.nextRand() * 0.88;
          b.y = 0.02 + this.nextRand() * 0.09;
          b.radius = 0.0040 + this.nextRand() * 0.0024;
          b.mass = b.radius * b.radius;
          // 70% start sliding immediately; 30% brief dwell while creeping
          b.pinned = this.nextRand() > 0.70;
          b.dwellTimer = 0;
          b.maxDwell = 0.25 + this.nextRand() * 0.75;
          b.creepRate = 0.006 + this.nextRand() * 0.007;
          b.pinThreshold = b.mass * (1.03 + this.nextRand() * 0.14);
          b.vx = (this.nextRand() - 0.5) * 0.015;
          b.vy = b.pinned ? b.creepRate : 0.06 + this.nextRand() * 0.05;
          b.trailStartX = b.x;
          b.trailStartY = b.y;
          b.trailBendX = 0;
          b.trailAlpha = b.pinned ? 0.15 : 0.76;
          b.stretch = b.pinned ? 0.06 : 0.26;
          b.onLedge = false;
          b.splashedTank = false;
          b.splashedDroplet = false;
        } else {
          b.y = 0.16 + this.nextRand() * 0.68;
          b.radius = 0.0036 + this.nextRand() * 0.0014;
          b.mass = b.radius * b.radius;
          b.pinned = true;
          b.dwellTimer = 0;
          b.pinThreshold = b.mass * 1.25;
          b.vx = 0;
          b.vy = 0;
          b.trailStartX = b.x;
          b.trailStartY = b.y;
          b.trailBendX = 0;
          b.trailAlpha = 0;
          b.stretch = 0;
          b.onLedge = false;
          b.splashedTank = false;
          b.splashedDroplet = false;
        }
      }
    }

    // Coalescence with Area Conservation (A_total = A1 + A2)
    for (let i = 0; i < this.bodies.length; i++) {
      const a = this.bodies[i];
      if (!a || a.pinned) continue;
      for (let j = 0; j < this.bodies.length; j++) {
        if (i === j) continue;
        const other = this.bodies[j];
        if (!other) continue;
        const dist = Math.hypot(a.x - other.x, a.y - other.y);
        if (dist < (a.radius + other.radius) * 0.95 && a.mass >= other.mass) {
          a.mass = Math.min(0.000082, a.mass + other.mass * 0.85);
          a.radius = Math.sqrt(a.mass);
          a.vy = Math.min(0.38, a.vy + 0.045);
          other.x = 0.06 + this.nextRand() * 0.88;
          other.y = 0.04 + this.nextRand() * 0.16;
          other.radius = 0.0036 + this.nextRand() * 0.0016;
          other.mass = other.radius * other.radius;
          other.pinned = true;
          other.dwellTimer = 0;
          other.maxDwell = 0.30 + this.nextRand() * 0.80;
          other.creepRate = 0.006 + this.nextRand() * 0.006;
          other.pinThreshold = other.mass * (1.06 + this.nextRand() * 0.16);
          other.vx = 0;
          other.vy = other.creepRate;
          other.trailStartX = other.x;
          other.trailStartY = other.y;
          other.trailBendX = 0;
          other.trailAlpha = 0;
          other.stretch = 0;
          other.onLedge = false;
          other.splashedTank = false;
          other.splashedDroplet = false;
        }
      }
    }

    this.activityEnergy = Math.max(0, this.activityEnergy - clampedDt * 0.14);
    this.syncGpuBuffers();
  }

  private syncGpuBuffers(): void {
    for (let i = 0; i < MAX_CARD_DROPLETS; i++) {
      const b = this.bodies[i];
      const d4 = i * 4;
      const v2 = i * 2;
      if (!b) {
        this.gpu.drops[d4] = -2;
        this.gpu.drops[d4 + 1] = -2;
        this.gpu.drops[d4 + 2] = 0;
        this.gpu.drops[d4 + 3] = 0;
        this.gpu.velocities[v2] = 0;
        this.gpu.velocities[v2 + 1] = 0;
        this.gpu.trails[d4] = -2;
        this.gpu.trails[d4 + 1] = 0;
        this.gpu.trails[d4 + 2] = 0;
        this.gpu.trails[d4 + 3] = 0;
        continue;
      }
      this.gpu.drops[d4] = b.x;
      this.gpu.drops[d4 + 1] = b.y;
      this.gpu.drops[d4 + 2] = b.radius;
      this.gpu.drops[d4 + 3] = b.stretch;
      this.gpu.velocities[v2] = b.vx;
      this.gpu.velocities[v2 + 1] = b.vy;
      this.gpu.trails[d4] = b.trailStartX;
      this.gpu.trails[d4 + 1] = b.trailStartY;
      this.gpu.trails[d4 + 2] = b.trailBendX;
      this.gpu.trails[d4 + 3] = b.trailAlpha;
    }
  }
}
