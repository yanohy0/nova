// Shared single-context WebGL2 liquid renderer.
// Research references adapted in this implementation:
// - mrdoob/three.js physical shader chunks: anisotropic GGX visibility/distribution for satin metal.
// - evanw/webgl-water and HowdyKeith/swek-webgl2-water: Fresnel, refraction,
//   height-field ripples and differential-area caustics.
// - Aureliengmz/clearwater: compact WebGL2 optics, absorption and clean highlights.
// - pmndrs/drei MeshTransmissionMaterial: IOR, thickness and Beer-Lambert attenuation.
// - StarKnightt/liquid-glass and smirki/glasswork: SDF silhouettes, refraction normals
//   and bounded edge/rim optics.
// This is a small UI liquid volume, not an ocean/SPH simulation. Static water is
// rendered once; the shared RAF wakes only for a fill transition or a single impulse.

import type {
  CardDropletGpuState,
  FluidVorticityGrid,
} from './hydration-fluid-solver';

export interface SpringNode {
  height: number;
  velocity: number;
}

export interface WaterOpticalConfig {
  ior: number;
  fresnelR0: number;
  attenuationColor: [number, number, number];
  attenuationDistance: number;
  esrIntensity: number;
  causticIntensity: number;
  footprintFilter: boolean;
}

export const DEFAULT_WATER_OPTICAL_CONFIG: WaterOpticalConfig = {
  ior: 1.333,
  fresnelR0: 0.020,
  attenuationColor: [0.82, 0.975, 1.0],
  attenuationDistance: 2.65,
  esrIntensity: 1.18,
  causticIntensity: 1.08,
  footprintFilter: true,
};


let reducedMotionQueryCache: MediaQueryList | null = null;

export function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return false;
  reducedMotionQueryCache ??= window.matchMedia('(prefers-reduced-motion: reduce)');
  return reducedMotionQueryCache.matches;
}

export function createSpringArray(count: number): SpringNode[] {
  return Array.from({ length: count }, () => ({ height: 0, velocity: 0 }));
}

/** Exponential interpolation keeps progress transitions consistent at 30/60/120Hz. */
export function interpolateRatio(
  current: number,
  target: number,
  elapsedSeconds: number,
  timeConstantSeconds = 0.14,
): number {
  const delta = target - current;
  if (!Number.isFinite(delta) || Math.abs(delta) <= 0.0005) return target;
  const dt = Math.min(0.05, Math.max(0, Number.isFinite(elapsedSeconds) ? elapsedSeconds : 0));
  const timeConstant = Math.max(
    0.001,
    Number.isFinite(timeConstantSeconds) ? timeConstantSeconds : 0.14,
  );
  const next = current + delta * (1 - Math.exp(-dt / timeConstant));
  // Snap on the same frame that crosses the threshold so the final target is actually painted.
  return Math.abs(target - next) <= 0.0005 ? target : next;
}

const springScratch = new WeakMap<SpringNode[], { left: Float32Array; right: Float32Array }>();

export function stepSpringNodes(
  nodes: SpringNode[],
  tension: number,
  damping: number,
  spread: number,
): void {
  const n = nodes.length;
  for (let i = 0; i < n; i++) {
    const node = nodes[i];
    if (!node) continue;
    const force = -tension * node.height - node.velocity * damping;
    node.velocity += force;
    node.height += node.velocity;
  }

  let scratch = springScratch.get(nodes);
  if (!scratch || scratch.left.length !== n) {
    scratch = { left: new Float32Array(n), right: new Float32Array(n) };
    springScratch.set(nodes, scratch);
  }
  const { left: leftDeltas, right: rightDeltas } = scratch;

  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < n; i++) {
      const curr = nodes[i];
      if (!curr) continue;
      const prev = i > 0 ? nodes[i - 1] : undefined;
      const next = i < n - 1 ? nodes[i + 1] : undefined;

      if (prev) {
        const d = spread * (curr.height - prev.height);
        leftDeltas[i] = d;
        prev.velocity += d;
      }
      if (next) {
        const d = spread * (curr.height - next.height);
        rightDeltas[i] = d;
        next.velocity += d;
      }
    }

    for (let i = 0; i < n; i++) {
      const prev = i > 0 ? nodes[i - 1] : undefined;
      const next = i < n - 1 ? nodes[i + 1] : undefined;
      if (prev) prev.height += leftDeltas[i] ?? 0;
      if (next) next.height += rightDeltas[i] ?? 0;
    }
  }
}

export type FluidProgramKind = 'droplet' | 'tank' | 'card-droplets' | 'liquid-glass' | 'energy' | 'metal';

const MIN_FLUID_FRAME_INTERVAL_MS = 1000 / 60;

export interface FluidDrawJob {
  kind: FluidProgramKind;
  targetCanvas: HTMLCanvasElement;
  width: number;
  height: number;
  fill: number;
  fillY?: number;
  active?: boolean;
  isAnimating?: boolean;
  idleFrameIntervalMs?: number;
  wave?: SpringNode[];
  fluidGrid?: FluidVorticityGrid;
  textCanvas?: HTMLCanvasElement;
  textVersion?: number;
  textDims?: [number, number];
  cardDroplets?: CardDropletGpuState;
  cardPointer?: [number, number, number, number];
  cardRipples?: Float32Array;
  soliton?: [number, number, number, number];
  tilt?: [number, number];
  opticalConfig?: Partial<WaterOpticalConfig>;
  metalColor?: [number, number, number];
  metalHighlight?: [number, number, number];
  isVisible: boolean;
}

const VERTEX_SHADER_300 = `#version 300 es
in vec2 a_position;
out vec2 v_uv;
void main() {
  v_uv = a_position * 0.5 + 0.5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}
`;

// Utilitários ópticos em espaço linear HDR + ACES Filmic + derivadas hardware para projeção de cáusticas
const SHARED_OPTICS_GLSL = `
float sq(float x) {
  return x * x;
}

float pow5(float x) {
  float x2 = x * x;
  return x2 * x2 * x;
}

float safePow(float x, float y) {
  return pow(max(x, 1e-5), y);
}

float invSmooth(float lo, float hi, float x) {
  return 1.0 - smoothstep(lo, hi, x);
}

vec3 acesFilmic(vec3 x) {
  float a = 2.51;
  float b = 0.03;
  float c = 2.43;
  float d = 0.59;
  float e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Khronos PBR Neutral + suave desaturação AgX em highlights intensos (evita clipping plástico)
vec3 pbrNeutralAgx(vec3 color) {
  vec3 c = max(color, vec3(0.0));
  const float startCompression = 0.76;
  const float desaturation = 0.16;
  float x = min(c.r, min(c.g, c.b));
  float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
  c -= offset;
  float peak = max(c.r, max(c.g, c.b));
  if (peak >= startCompression) {
    float d = 1.0 - startCompression;
    float newPeak = 1.0 - (d * d) / (peak + d - startCompression);
    c *= newPeak / max(peak, 1e-5);
    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    c = mix(c, vec3(newPeak), g);
  }
  return clamp(c, 0.0, 1.0);
}

vec3 linearToSrgb(vec3 c) {
  vec3 linear = max(c, vec3(0.0));
  vec3 low = linear * 12.92;
  vec3 high = 1.055 * pow(max(linear, vec3(0.0031308)), vec3(1.0 / 2.4)) - 0.055;
  return mix(high, low, lessThanEqual(linear, vec3(0.0031308)));
}

float distributionGGX(float nDotH, float roughness) {
  float a = max(roughness * roughness, 0.0025);
  float a2 = a * a;
  float n2 = nDotH * nDotH;
  float denom = n2 * (a2 - 1.0) + 1.0;
  return a2 / max(3.14159265 * denom * denom, 1e-5);
}

float geometrySchlickGGX(float nDotV, float roughness) {
  float r = roughness + 1.0;
  float k = (r * r) * 0.125;
  return nDotV / max(nDotV * (1.0 - k) + k, 1e-5);
}

vec3 fresnelSchlick(float cosTheta, vec3 f0) {
  float f = pow5(clamp(1.0 - cosTheta, 0.0, 1.0));
  return f0 + (1.0 - f0) * f;
}

// Lazanyi & Szirmay-Kalos analytic complex-IOR (n + i*k) conductor Fresnel for molten metals
vec3 evalConductorFresnelLSK(vec3 nIor, vec3 kExt, float cosTheta) {
  float c = clamp(cosTheta, 0.0, 1.0);
  vec3 k2 = kExt * kExt;
  vec3 num = (nIor - 1.0) * (nIor - 1.0) + k2;
  vec3 den = (nIor + 1.0) * (nIor + 1.0) + k2;
  vec3 f0 = num / max(den, vec3(1e-4));
  float omc = 1.0 - c;
  float omc5 = pow5(omc);
  vec3 a = (1.0 - f0) * omc5;
  // Lazanyi-Szirmay-Kalos grazing edge absorption dip correction term
  vec3 edgeTerm = (k2 * 0.045) * omc * c * (1.0 - f0);
  return clamp(f0 + a - edgeTerm, vec3(0.0), vec3(1.0));
}

vec3 evaluateGGXSpecular(vec3 normal, vec3 viewDir, vec3 lightDir, vec3 f0, float roughness) {
  vec3 n = normalize(normal);
  vec3 v = normalize(viewDir);
  vec3 l = normalize(lightDir);
  vec3 h = normalize(v + l);
  float nDotV = max(dot(n, v), 1e-4);
  float nDotL = max(dot(n, l), 0.0);
  float nDotH = max(dot(n, h), 0.0);
  float vDotH = max(dot(v, h), 0.0);
  float d = distributionGGX(nDotH, roughness);
  float g = geometrySchlickGGX(nDotV, roughness) * geometrySchlickGGX(nDotL, roughness);
  vec3 f = fresnelSchlick(vDotH, f0);
  return (d * g * f * nDotL) / max(4.0 * nDotV * nDotL, 1e-4);
}

float softboxRect(vec3 direction, vec3 centerDirection, vec2 halfSize, float softness) {
  vec3 center = normalize(centerDirection);
  vec3 referenceUp = abs(center.y) > 0.94 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
  vec3 axisU = normalize(cross(referenceUp, center));
  vec3 axisV = normalize(cross(center, axisU));
  float forward = max(dot(direction, center), 1e-3);
  vec2 panelUv = vec2(dot(direction, axisU), dot(direction, axisV)) / forward;
  float edge = max(abs(panelUv.x) / max(halfSize.x, 1e-3), abs(panelUv.y) / max(halfSize.y, 1e-3));
  return 1.0 - smoothstep(1.0 - softness, 1.0 + softness, edge);
}

// Anisotropic GGX keeps the macro reflections stretched along the liquid-metal flow.
// The tangent follows the arc; the bitangent closes a stable local shading frame.
float visibilityGGXSmithAnisotropic(
  float alphaT,
  float alphaB,
  float dotTV,
  float dotBV,
  float dotTL,
  float dotBL,
  float dotNV,
  float dotNL
) {
  float gv = dotNL * length(vec3(alphaT * dotTV, alphaB * dotBV, dotNV));
  float gl = dotNV * length(vec3(alphaT * dotTL, alphaB * dotBL, dotNL));
  return 0.5 / max(gv + gl, 1e-5);
}

float distributionGGXAnisotropic(
  float alphaT,
  float alphaB,
  float nDotH,
  float tDotH,
  float bDotH
) {
  float a2 = alphaT * alphaB;
  vec3 v = vec3(alphaB * tDotH, alphaT * bDotH, a2 * nDotH);
  float v2 = max(dot(v, v), 1e-6);
  float w2 = a2 / v2;
  return (a2 * w2 * w2) / 3.14159265;
}

vec3 evaluateGGXAnisotropicSpecular(
  vec3 normal,
  vec3 tangent,
  vec3 viewDir,
  vec3 lightDir,
  vec3 f0,
  float roughness,
  float anisotropy
) {
  vec3 n = normalize(normal);
  vec3 t = normalize(tangent - n * dot(n, tangent));
  vec3 b = normalize(cross(n, t));
  vec3 v = normalize(viewDir);
  vec3 l = normalize(lightDir);
  vec3 h = normalize(v + l);

  float nDotV = max(dot(n, v), 1e-4);
  float nDotL = max(dot(n, l), 0.0);
  float nDotH = max(dot(n, h), 0.0);
  float vDotH = max(dot(v, h), 0.0);
  float alpha = max(roughness * roughness, 0.0025);
  float alphaT = max(alpha * (1.0 - clamp(anisotropy, 0.0, 0.7)), 0.0025);
  float alphaB = max(alpha * (1.0 + clamp(anisotropy, 0.0, 0.7)), 0.0025);

  float visibility = visibilityGGXSmithAnisotropic(
    alphaT, alphaB,
    dot(t, v), dot(b, v),
    dot(t, l), dot(b, l),
    nDotV, nDotL
  );
  float distribution = distributionGGXAnisotropic(
    alphaT, alphaB, nDotH, dot(t, h), dot(b, h)
  );
  vec3 fresnel = fresnelSchlick(vDotH, f0);
  return fresnel * (visibility * distribution) * nDotL;
}

float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}


float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float fbm3(vec2 st) {
  float val = 0.0;
  float amp = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 3; i++) {
    val += amp * valueNoise(st);
    st = rot * st * 2.02 + vec2(1.7, 3.1);
    amp *= 0.5;
  }
  return val;
}

// Cascata Gerstner com derivadas analíticas + micro-ondulação capilar
void evalGerstnerCascade(
  vec2 pos,
  float t,
  float footprintScale,
  out float heightOut,
  out vec2 gradOut,
  out float causticFocusOut
) {
  heightOut = 0.0;
  gradOut = vec2(0.0);
  float laplacian = 0.0;

  vec4 waves[4];
  waves[0] = vec4(1.25, 0.018, 0.89, 0.45);
  waves[1] = vec4(0.70, 0.011, -0.74, 0.67);
  waves[2] = vec4(0.36, 0.007, 0.48, -0.88);
  waves[3] = vec4(0.19, 0.0035, -0.92, -0.38);

  for (int i = 0; i < 4; i++) {
    float L = waves[i].x;
    float A = waves[i].y;
    vec2 dir = normalize(waves[i].zw);
    float fade = mix(1.0, smoothstep(0.04, 0.30, L), footprintScale);
    float k = 6.283185 / L;
    float c = sqrt(9.81 / k) * 0.48;
    float phase = k * dot(dir, pos) - c * t * 1.35;
    float amp = A * fade;
    float s = sin(phase);
    heightOut += amp * s;
    gradOut += dir * (amp * k * cos(phase));
    laplacian += amp * k * k * s;
  }

  causticFocusOut = clamp(0.5 + laplacian * 0.34, 0.0, 1.5);
}

// Ambiente analítico procedural de estúdio em espaço linear (não é uma textura HDRI).
vec3 sampleStudioEnvironment(vec3 dir, vec3 skyTint) {
  float dirLen = length(dir);
  vec3 d = dirLen > 1e-4 ? dir / dirLen : vec3(0.0, 0.0, 1.0);
  float elev = d.y;
  float az = atan(d.x, d.z);

  // Chão escuro obsidiana + horizonte neutro frio + cúpula celeste clara
  vec3 floorCol = vec3(0.012, 0.022, 0.028);
  vec3 wallCol = vec3(0.045, 0.078, 0.095);
  vec3 horizonCol = mix(wallCol, skyTint * 0.24, 0.45);
  vec3 skyCol = mix(horizonCol, vec3(0.76, 0.90, 0.98), smoothstep(0.0, 0.88, elev));

  vec3 env = elev < 0.0
    ? mix(floorCol, horizonCol * 0.65, smoothstep(-0.65, 0.0, elev))
    : skyCol;

  // Painéis retangulares de estúdio: highlights alongados, não pontos circulares artificiais.
  float stripLeft = softboxRect(d, vec3(-0.56, 0.66, 0.50), vec2(0.13, 0.48), 0.10);
  float stripRight = softboxRect(d, vec3(0.62, 0.38, 0.68), vec2(0.11, 0.40), 0.12);
  float overhead = softboxRect(d, vec3(-0.15, 0.95, 0.27), vec2(0.34, 0.12), 0.12);
  float rimArc = exp(-sq((elev - 0.14) * 11.0)) * (0.4 + 0.6 * cos(az * 2.0));

  env += vec3(2.40, 2.50, 2.60) * stripLeft;
  env += skyTint * 1.15 * stripRight;
  env += vec3(3.10, 3.20, 3.30) * overhead;
  env += vec3(0.90, 1.05, 1.15) * rimArc * 0.55;
  return env;
}

// Ambiente analítico iluminado para refração em água cristalina (Dual-Hemisphere Dark-Field Studio: Contraste fotográfico puro sem névoa azulada)
vec3 sampleWaterStudioEnvironment(vec3 dir, vec3 skyTint) {
  float dirLen = length(dir);
  vec3 d = dirLen > 1e-4 ? dir / dirLen : vec3(0.0, 0.0, 1.0);
  float elev = d.y;
  float az = atan(d.x, d.z);

  // Câmara escura obsidiana neutra (água real é perfeitamente incolor e revela forma pelo contraste entre faixas negras e reflexos prata)
  vec3 floorBounce = vec3(0.002, 0.0022, 0.0028);
  vec3 wallCol = vec3(0.004, 0.0048, 0.006);
  vec3 horizonCol = mix(wallCol, skyTint * 0.028, 0.12);
  vec3 skyCol = mix(horizonCol, vec3(0.088, 0.098, 0.112), smoothstep(0.08, 0.92, elev));

  vec3 env = elev < 0.0
    ? mix(floorBounce, horizonCol * 0.42, smoothstep(-0.84, 0.0, elev))
    : skyCol;

  // Bandeiras negras arquitetônicas (esculpem contraste de estúdio fotográfico em vidro e água pura)
  float darkContrastL = softboxRect(d, vec3(-0.90, 0.04, 0.36), vec2(0.16, 0.68), 0.012);
  float darkContrastR = softboxRect(d, vec3(0.90, -0.04, 0.36), vec2(0.16, 0.64), 0.012);
  float darkBackCore = softboxRect(d, vec3(0.0, -0.02, -0.99), vec2(0.46, 0.30), 0.05);
  float darkHorizonBar = exp(-sq((elev + 0.028) * 48.0));
  env *= 1.0 - clamp((darkContrastL + darkContrastR) * 0.95 + darkBackCore * 0.90 + darkHorizonBar * 0.88, 0.0, 0.97);

  // Hemisfério frontal (+Z): tiras retangulares prata-branco cirúrgicas para especular de cristal e superfície livre
  float stripLeft = softboxRect(d, vec3(-0.46, 0.72, 0.51), vec2(0.056, 0.64), 0.005);
  float stripRight = softboxRect(d, vec3(0.64, 0.42, 0.64), vec2(0.048, 0.54), 0.008);
  float overhead = softboxRect(d, vec3(-0.06, 0.96, 0.26), vec2(0.48, 0.058), 0.008);
  float tableBounce = softboxRect(d, vec3(0.04, -0.78, 0.58), vec2(0.58, 0.12), 0.06);

  // Hemisfério traseiro (-Z): difusores edge-lit neutros que a lente de água (IOR 1.333) inverte e amplia oticamente
  float backRimLeft = softboxRect(d, vec3(-0.62, 0.18, -0.76), vec2(0.078, 0.56), 0.008);
  float backRimRight = softboxRect(d, vec3(0.62, -0.14, -0.76), vec2(0.078, 0.54), 0.008);
  float backSkyBank = softboxRect(d, vec3(-0.08, 0.76, -0.64), vec2(0.48, 0.095), 0.020);
  float backCausticFloor = softboxRect(d, vec3(0.04, -0.72, -0.68), vec2(0.54, 0.11), 0.040);
  float backCoreGlow = softboxRect(d, vec3(0.02, 0.14, -0.98), vec2(0.32, 0.14), 0.12);

  float horizonBand = exp(-sq((elev - 0.042) * 56.0)) * (0.42 + 0.58 * cos(az * 2.0 + 0.4));
  float rimArc = exp(-sq((elev - 0.11) * 30.0)) * (0.40 + 0.60 * cos(az * 2.0));

  env += vec3(7.9, 7.95, 8.0) * stripLeft;
  env += mix(vec3(3.3, 3.35, 3.4), skyTint * 3.1, 0.12) * stripRight;
  env += vec3(7.5, 7.55, 7.6) * overhead;
  env += vec3(0.56, 0.60, 0.64) * tableBounce * 0.80;

  env += vec3(4.9, 4.98, 5.05) * backRimLeft * 0.96;
  env += vec3(3.4, 3.48, 3.55) * backRimRight * 0.86;
  env += vec3(4.6, 4.68, 4.75) * backSkyBank * 0.84;
  env += vec3(1.52, 1.58, 1.66) * backCausticFloor * 0.92;
  env += vec3(0.42, 0.45, 0.48) * backCoreGlow * 0.26;

  env += vec3(1.18, 1.22, 1.26) * horizonBand * 0.72;
  env += vec3(1.32, 1.36, 1.40) * rimArc * 0.78;
  return env;
}

// Estúdio Dark-Field curvilíneo dedicado para metal líquido / mercúrio (alternância de bandeiras negras e fitas HDR intensas)
vec3 sampleLiquidMetalStudioEnv(vec3 dir, vec3 metalColor, vec3 metalHighlight) {
  float dirLen = length(dir);
  vec3 d = dirLen > 1e-4 ? dir / dirLen : vec3(0.0, 0.0, 1.0);
  float elev = d.y;
  float az = atan(d.x, d.z);

  vec3 floorStudio = mix(vec3(0.008, 0.010, 0.012), metalColor * 0.10, 0.45);
  vec3 horizonBase = mix(vec3(0.032, 0.038, 0.044), metalColor * 0.24, 0.48);
  vec3 domeTop = mix(vec3(0.18, 0.20, 0.23), metalHighlight * 0.55, 0.42);
  vec3 env = elev < 0.0
    ? mix(floorStudio, horizonBase, smoothstep(-0.68, 0.0, elev))
    : mix(horizonBase, domeTop, smoothstep(0.0, 0.86, elev));

  // Faixas negativas pretas cirúrgicas no horizonte e laterais para criar reflexo de cromo líquido real
  float negHorizon = exp(-sq((elev + 0.035) * 32.0));
  float negFlagL = softboxRect(d, vec3(-0.84, 0.06, 0.52), vec2(0.15, 0.62), 0.018);
  float negFlagR = softboxRect(d, vec3(0.84, -0.06, 0.52), vec2(0.15, 0.62), 0.018);
  env *= 1.0 - clamp(negHorizon * 0.90 + (negFlagL + negFlagR) * 0.86, 0.0, 0.94);

  // Fitas retangulares HDR de alta energia deformadas pelo campo de ondas do mercúrio líquido
  float stripKey = softboxRect(d, vec3(-0.44, 0.68, 0.58), vec2(0.085, 0.60), 0.010);
  float stripRim = softboxRect(d, vec3(0.62, 0.36, 0.68), vec2(0.072, 0.52), 0.012);
  float bankOverhead = softboxRect(d, vec3(-0.04, 0.95, 0.30), vec2(0.52, 0.082), 0.014);
  float lowerBounce = softboxRect(d, vec3(0.06, -0.72, 0.68), vec2(0.56, 0.14), 0.05);
  float horizonRibbon = exp(-sq((elev - 0.095) * 42.0)) * (0.45 + 0.55 * cos(az * 3.0 + 0.3));

  env += mix(vec3(5.8), metalHighlight * 6.4, 0.42) * stripKey;
  env += mix(vec3(2.8), metalColor * 3.6 + metalHighlight * 1.4, 0.52) * stripRim;
  env += mix(vec3(6.2), metalHighlight * 6.8, 0.35) * bankOverhead;
  env += mix(vec3(0.45), metalColor * 1.15, 0.60) * lowerBounce;
  env += mix(vec3(1.15), metalHighlight * 1.65, 0.46) * horizonRibbon * 0.85;
  return env;
}

// Fundo óptico contínuo de estúdio através da parede traseira de quartzo (neutro cristalino para evidenciar ampliação IOR 1.333)
vec3 sampleOpticalCavityWall(vec2 refrPos, vec2 scaleGrid, float depthFade) {
  float softHorizon = 0.5 + 0.5 * sin(refrPos.y * 6.4 + sin(refrPos.x * 3.8) * 0.52);
  float studioSlit = exp(-sq((refrPos.y - 0.14 + sin(refrPos.x * 2.6) * 0.04) * 5.2));
  float bokehCaustic = exp(-sq((refrPos.y + 0.22) * 3.6)) * (0.5 + 0.5 * cos(refrPos.x * 4.6 + scaleGrid.x * 0.04));
  vec3 quartzBase = vec3(0.003, 0.0035, 0.0045) + vec3(0.020, 0.023, 0.026) * softHorizon;
  quartzBase += vec3(0.036, 0.040, 0.045) * studioSlit * 0.65;
  quartzBase += vec3(0.072, 0.080, 0.088) * bokehCaustic * 0.74;
  return quartzBase * mix(0.60, 1.44, clamp(depthFade, 0.0, 1.0));
}

// Micro-escala ótica gravada a laser na parede interna de quartzo do tubo (ampliação cilíndrica real sob IOR 1.333)
vec3 sampleCalibratedQuartzWall(vec2 rearUv, float inWater, vec2 rayShift, float depthFade) {
  vec2 lensUv = inWater > 0.02
    ? vec2(rearUv.x + rayShift.x * 0.105, 0.5 + (rearUv.y - 0.5) * 0.62 + rayShift.y * 0.078)
    : rearUv;
  vec3 wall = sampleOpticalCavityWall(lensUv, vec2(14.0, 2.5), depthFade);
  float tickCoord = lensUv.x * 20.0;
  float tickDist = abs(fract(tickCoord) - 0.5);
  float tickIdx = floor(tickCoord + 0.5);
  float isMajor = step(0.5, 1.0 - mod(tickIdx, 5.0));
  float tickVBand = smoothstep(0.10, 0.24, lensUv.y) * invSmooth(mix(0.28, 0.42, isMajor), mix(0.34, 0.48, isMajor), lensUv.y);
  float tickLine = invSmooth(0.018, mix(0.070, 0.090, isMajor), tickDist) * tickVBand;
  float edgeMask = smoothstep(0.05, 0.12, lensUv.x) * invSmooth(0.88, 0.95, lensUv.x);
  vec3 tickCol = mix(vec3(0.22, 0.24, 0.26), vec3(0.98, 1.02, 1.06), inWater);
  wall += tickCol * tickLine * edgeMask * mix(0.10, 0.36, inWater);
  return wall;
}

// Janela de Snell física (k = 1 - eta² * (1 - cos²i)) com banda cromática de ângulo crítico
float evalSnellsWindowAndCrit(vec3 raySubmerged, vec3 outwardNormal, float waterToAirEta, out vec3 refrDir, out float critRim) {
  vec3 nIn = dot(raySubmerged, outwardNormal) > 0.0 ? -outwardNormal : outwardNormal;
  float cosI = clamp(dot(-raySubmerged, nIn), 0.0, 1.0);
  float k = 1.0 - waterToAirEta * waterToAirEta * (1.0 - cosI * cosI);
  critRim = exp(-sq(k * 9.0)) * smoothstep(0.0, 0.85, 1.0 - cosI);
  if (k <= 0.0005) {
    refrDir = reflect(raySubmerged, nIn);
    return 0.0;
  }
  refrDir = normalize(waterToAirEta * raySubmerged + (waterToAirEta * cosI - sqrt(k)) * nIn);
  return smoothstep(0.0, 0.14, k);
}

// Cáustica por área diferencial projetada (evanw/webgl-water: dFdx / dFdy sobre ondas analíticas suaves)
float computeDifferentialCaustic(vec2 basePos, vec2 refrPos) {
  float detBase = abs(dFdx(basePos.x) * dFdy(basePos.y) - dFdx(basePos.y) * dFdy(basePos.x));
  float detRefr = abs(dFdx(refrPos.x) * dFdy(refrPos.y) - dFdx(refrPos.y) * dFdy(refrPos.x));
  float ratio = detBase / max(detRefr, max(detBase * 0.06, 1e-6));
  return clamp(safePow(ratio, 2.25) - 0.55, 0.0, 6.4);
}

// Malha de cáusticas subaquáticas por convergência Hessiana de ondas harmônicas suaves (dupla oitava sem aliasing)
float evalWaterCausticWeb(vec2 coord, float t, vec2 flow, float energy) {
  vec2 p = coord * 4.4 + flow * 0.45;
  float p1 = p.x * 1.42 + p.y * 0.94 - t * 1.15;
  float p2 = -p.x * 1.12 + p.y * 1.52 + t * 0.94;
  float p3 = p.x * 2.08 - p.y * 1.32 + t * 1.42;
  float w1 = sin(p1 + sin(p2 * 0.72) * 0.82);
  float w2 = sin(p2 + cos(p3 * 0.68) * 0.78);
  float w3 = cos(p3 * 0.84 + w1 * 0.62);
  float ridgeA = 1.0 - abs(w1 + w2) * 0.5;
  float ridgeB = 1.0 - abs(w2 - w3) * 0.5;
  float focus = safePow(max(ridgeA, 0.0), 7.4) * 1.05 + safePow(max(ridgeB, 0.0), 8.2) * 0.82;
  return clamp(focus * (0.76 + 0.65 * energy), 0.0, 2.8);
}

// Função de fase volumétrica de Henyey-Greenstein (espalhamento direcional em água pura)
float evalHenyeyGreenstein(float cosTheta, float g) {
  float g2 = g * g;
  float denom = max(1.0 + g2 - 2.0 * g * clamp(cosTheta, -1.0, 1.0), 1e-3);
  return (1.0 - g2) / (12.5663706 * denom * sqrt(denom));
}

// Perfil analítico de menisco capilar de Young-Laplace: h(d) = h0 * exp(-d / lambda_c)
float evalYoungLaplaceMeniscus(float wallDist, float capHeight, float capLength) {
  float d = max(wallDist, 0.0);
  return capHeight * exp(-d / max(capLength, 1e-4));
}

// Curvatura analítica normalizada do menisco côncavo (2ª derivada d²h/dd²) para foco cáustico capilar
float evalYoungLaplaceCurvature(float wallDist, float capLength) {
  float d = max(wallDist, 0.0);
  return exp(-d / max(capLength, 1e-4)) * (1.0 - smoothstep(capLength * 1.8, capLength * 3.6, d));
}

// Bolha de oxigênio 3D real (Ray-Sphere Intersection + TIR ar-em-água + anel prateado nítido + micro-specular)
vec4 traceBubbleSphere3D(vec3 ro, vec3 rd, vec3 center, float radius, vec3 keyLight) {
  vec3 oc = ro - center;
  float b = dot(oc, rd);
  float c = dot(oc, oc) - radius * radius;
  float disc = b * b - c;
  if (disc <= 0.0) return vec4(0.0);

  float tHit = -b - sqrt(disc);
  if (tHit <= 0.0) return vec4(0.0);

  vec3 pos = ro + rd * tHit;
  vec3 n = normalize(pos - center);
  float cosTheta = clamp(dot(-rd, n), 0.0, 1.0);
  vec3 refr = refract(rd, n, 1.333);
  bool isTir = dot(refr, refr) < 0.001;
  float fresnelRim = 0.02 + 0.98 * safePow(1.0 - cosTheta, 5.2);
  vec3 reflDir = reflect(rd, n);
  vec3 reflEnv = sampleWaterStudioEnvironment(reflDir, vec3(0.98, 0.99, 1.0));
  vec3 refrEnv = isTir ? reflEnv : sampleWaterStudioEnvironment(refr, vec3(0.95, 0.97, 1.0)) * 0.24;
  vec3 spec = evaluateGGXSpecular(n, -rd, keyLight, vec3(0.072), 0.0032);

  vec3 col = isTir
    ? reflEnv * 1.20 + vec3(0.96, 0.98, 1.0) * 0.26
    : mix(refrEnv + vec3(0.004, 0.005, 0.007), reflEnv * 0.95, fresnelRim);
  col += spec * vec3(6.2, 6.25, 6.3);
  float alpha = clamp((isTir ? 0.90 : 0.14) + fresnelRim * 0.82 + length(spec) * 0.48, 0.0, 0.98);
  return vec4(col, alpha);
}

// Atenuação volumétrica exponencial Beer-Lambert (linear)
vec3 applyBeerLambert(vec3 bgLinear, vec3 attenColor, float attenDist, float opticalDepth) {
  vec3 sigma = -log(max(attenColor, vec3(0.005))) / max(attenDist, 0.05);
  return bgLinear * exp(-sigma * max(opticalDepth, 0.0));
}

// Interferência de Filme Fino (Thin-Film Interference: Δ = 2 * n * d * cos(θ))
vec3 evalThinFilmIridescence(float cosTheta, float filmThicknessNm) {
  float opd = 2.0 * 1.333 * filmThicknessNm * clamp(cosTheta, 0.08, 1.0);
  vec3 wavelengths = vec3(650.0, 532.0, 460.0);
  vec3 phase = (6.2831853 * opd) / wavelengths;
  return 0.5 + 0.5 * cos(phase + vec3(0.0, 0.45, 0.90));
}

// Forward Subsurface Scattering (SSS) em cristas de onda e bordas finas de fluido
float evalForwardSSS(vec3 viewDir, vec3 lightDir, vec3 normal, float thinness) {
  vec3 h = normalize(lightDir + normal * 0.42);
  float v = clamp(dot(viewDir, -h), 0.0, 1.0);
  return (v * v * v) * clamp(thinness, 0.0, 1.5);
}

// Smooth-Min polinomial (Quilez / BigWings) para coalescência orgânica e menisco capilar
float sminCubic(float a, float b, float k) {
  float h = clamp(0.5 + 0.5 * (b - a) / max(k, 1e-4), 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

// Superelipse (Squircle n=4)
float sdSquircleCard(vec2 p, vec2 b, float r) {
  vec2 q = abs(p) - max(b - vec2(r), vec2(0.0));
  vec2 qp = max(q, vec2(1e-5));
  float superLen = pow(pow(qp.x, 3.4) + pow(qp.y, 3.4), 1.0 / 3.4);
  return superLen + min(max(q.x, q.y), 0.0) - r;
}

// Clotoide (Espiral de Cornu G3 contínua): taxa de curvatura variável para reflexo de vidro soprado sem saltos
float sdClothoidCard(vec2 p, vec2 b, float r) {
  vec2 inner = max(b - vec2(r), vec2(0.0));
  vec2 q = abs(p) - inner;
  vec2 qp = max(q, vec2(1e-5));
  float diagBlend = clamp(min(qp.x, qp.y) / max(qp.x + qp.y, 1e-4) * 2.0, 0.0, 1.0);
  // Rampa de curvatura suave G3: transita da reta (n alto) para a esquina clothoid (n ~ 2.75)
  float nExp = mix(4.2, 2.72, smoothstep(0.0, 1.0, diagBlend));
  float superLen = pow(pow(qp.x, nExp) + pow(qp.y, nExp), 1.0 / nExp);
  return superLen + min(max(q.x, q.y), 0.0) - r;
}

// Equação de Sellmeier física (λ em micrômetros) para água pura (Daimon & Masumura) e vidro borossilicato
float evalSellmeierWaterIOR(float lambdaMicron) {
  float l2 = lambdaMicron * lambdaMicron;
  float n2 = 1.0
    + (0.5684028 * l2) / max(l2 - 0.0051018, 1e-4)
    + (0.1726177 * l2) / max(l2 - 0.0182115, 1e-4)
    + (0.0208619 * l2) / max(l2 - 0.0262072, 1e-4);
  return sqrt(max(n2, 1.0));
}

float evalSellmeierGlassIOR(float lambdaMicron) {
  float l2 = lambdaMicron * lambdaMicron;
  float n2 = 1.0
    + (1.0396121 * l2) / max(l2 - 0.0060007, 1e-4)
    + (0.2317923 * l2) / max(l2 - 0.0200179, 1e-4)
    + (1.0104695 * l2) / max(l2 - 103.56065, -200.0);
  return sqrt(max(n2, 1.0));
}

// Soliton Korteweg-de Vries (KdV: η = A sech²(k(d - C t))) + derivada analítica (-2 k A sech² tanh)
vec2 evalKdVSoliton(float coord, float age, float strength, float widthK, float speedScale) {
  if (age <= 0.0 || age > 1.85 || strength <= 0.001) return vec2(0.0);
  float env = exp(-age * 1.18) * strength;
  float amp = 0.055 * env;
  float waveSpeed = (0.58 + 0.34 * env) * speedScale;
  float phase = clamp(widthK * (coord - waveSpeed * age), -10.0, 10.0);
  float c = cosh(phase);
  float sech2 = 1.0 / (c * c);
  float h = amp * sech2;
  float slope = -2.0 * widthK * amp * sech2 * tanh(phase);
  return vec2(h, slope);
}

// Micro-ondulação capilar multi-frequência e rugosidade dinâmica de superfície líquida
vec2 evalMicroCapillarySlope(vec2 pos, float t, float energy) {
  float n1 = valueNoise(pos * 18.0 + vec2(t * 1.4, -t * 0.9));
  float n2 = valueNoise(pos * 34.0 + vec2(-t * 1.9, t * 1.3));
  float amp = 0.018 + 0.042 * clamp(energy, 0.0, 1.0);
  return vec2(n1 - 0.5, n2 - 0.5) * amp;
}

// Dielétrico Aninhado (Nested Dielectrics: Ar 1.0 -> Vidro 1.515 -> Água 1.333 -> Vidro 1.515 -> Ar 1.0)
vec4 traceNestedGlassWater(
  vec3 incRay,
  vec3 frontN,
  vec3 backN,
  float glassIor,
  float waterIor,
  float inWater
) {
  vec3 rayGlassIn = refract(incRay, frontN, 1.0 / max(glassIor, 1.02));
  if (dot(rayGlassIn, rayGlassIn) < 0.001) {
    return vec4(reflect(incRay, frontN), 1.0);
  }
  float relIn = glassIor / max(mix(glassIor, waterIor, inWater), 1.02);
  vec3 rayInner = inWater > 0.01 ? refract(rayGlassIn, frontN, relIn) : rayGlassIn;
  if (dot(rayInner, rayInner) < 0.001) {
    rayInner = reflect(rayGlassIn, frontN);
  }
  float relOut = mix(glassIor, waterIor, inWater) / max(glassIor, 1.02);
  vec3 rayBackGlass = inWater > 0.01 ? refract(rayInner, -backN, relOut) : rayInner;
  if (dot(rayBackGlass, rayBackGlass) < 0.001) {
    return vec4(reflect(rayInner, -backN), 1.0);
  }
  vec3 rayExit = refract(rayBackGlass, -backN, glassIor);
  if (dot(rayExit, rayExit) < 0.001) {
    return vec4(reflect(rayBackGlass, -backN), 1.0);
  }
  return vec4(normalize(rayExit), 0.0);
}

// Blue-Noise R2 Dithering leve para eliminar banding de 8 bits no fallback sem FBO RGBA16F
float blueNoiseHash(vec2 fragCoord, float timeSeed) {
  vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
  float ig = fract(magic.z * fract(dot(fragCoord + vec2(fract(timeSeed) * 19.0), magic.xy)));
  return ig - 0.5;
}

vec4 finalizeHdrOrSrgb(vec3 linearHdr, float alpha, float hdrOutput, vec2 fragCoord, float timeSeed) {
  if (hdrOutput > 0.5) {
    return vec4(max(linearHdr, vec3(0.0)), alpha);
  }
  vec3 srgb = linearToSrgb(pbrNeutralAgx(linearHdr));
  float dither = (blueNoiseHash(fragCoord, timeSeed) / 255.0) * smoothstep(0.002, 0.03, alpha);
  srgb = clamp(srgb + dither, 0.0, 1.0);
  return vec4(srgb * alpha, alpha);
}
`;

// 1. Gota 3D Ray-Marched em Cristal Borossilicato + Volume de Água 3D Real
//    (Camera Orbital Parallax, SDF 3D de Revolução, Menisco Capilar Côncavo 360°,
//     Snell's Window + TIR Submersa, Refração Multi-Interface Ar->Vidro->Água->Vidro->Ar,
//     Beer-Lambert por Comprimento de Corda 3D, Dispersão Cauchy RGB, Bolhas 3D e Cáusticas)
const DROPLET_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform float u_fillY;
uniform float u_active;
uniform float u_ior;
uniform float u_fresnelR0;
uniform vec3 u_attenColor;
uniform float u_attenDist;
uniform float u_esrIntensity;
uniform float u_causticIntensity;
uniform float u_footprint;
uniform vec2 u_tilt;
uniform float u_wave[24];
uniform sampler2D u_fluidTex;
uniform vec4 u_soliton;
uniform float u_hdrOutput;

${SHARED_OPTICS_GLSL}

float sdRoundCone3D(vec3 pos, vec3 a, vec3 b, float r1, float r2) {
  vec3 ba = b - a;
  float l2 = dot(ba, ba);
  float rr = r1 - r2;
  float a2 = l2 - rr * rr;
  float il2 = 1.0 / max(l2, 1e-5);

  vec3 pa = pos - a;
  float y = dot(pa, ba);
  float z = y - l2;
  vec3 proj = pa * l2 - ba * y;
  float x2 = dot(proj, proj);
  float y2 = y * y * l2;
  float z2 = z * z * l2;

  float k = sign(rr) * rr * rr * x2;
  if (sign(z) * a2 * z2 > k) return sqrt(x2 + z2) * il2 - r2;
  if (sign(y) * a2 * y2 < k) return sqrt(x2 + y2) * il2 - r1;
  return (sqrt(x2 * a2 * il2) + y * rr) * il2 - r1;
}

float sdTeardropOuter3D(vec3 pos) {
  return sdRoundCone3D(pos, vec3(0.0, -0.155, 0.0), vec3(0.0, 0.435, 0.0), 0.305, 0.016);
}

float sdTeardropCavity3D(vec3 pos) {
  return sdTeardropOuter3D(pos) + 0.022;
}

vec3 calcTeardropNormal3D(vec3 pos) {
  const float h = 0.0014;
  const vec2 k = vec2(1.0, -1.0);
  return normalize(
    k.xyy * sdTeardropOuter3D(pos + k.xyy * h) +
    k.yyx * sdTeardropOuter3D(pos + k.yyx * h) +
    k.yxy * sdTeardropOuter3D(pos + k.yxy * h) +
    k.xxx * sdTeardropOuter3D(pos + k.xxx * h)
  );
}

float sampleDropWaveSpring(float u) {
  float idx = clamp(u, 0.0, 1.0) * 23.0;
  int i0 = clamp(int(floor(idx)), 0, 23);
  int i1 = min(23, i0 + 1);
  return mix(u_wave[i0], u_wave[i1], fract(idx));
}

float evalDropWaterSurface3D(
  vec3 pos,
  vec2 fluidVel,
  float fluidCurl,
  float waveEnergy,
  float dCav
) {
  float tiltSlope = clamp(u_tilt.x, -0.35, 0.35) * pos.x * 0.38 + clamp(u_tilt.y, -0.35, 0.35) * pos.z * 0.24;
  float uX = clamp((pos.x + 0.30) / 0.60, 0.0, 1.0);
  float springH = sampleDropWaveSpring(uX) * 0.028;

  float gerstH = 0.0;
  vec2 gerstGrad = vec2(0.0);
  float causticF = 0.0;
  if (u_fill > 0.004) {
    evalGerstnerCascade(pos.xz * 4.2 + fluidVel * 0.16, u_time, u_footprint, gerstH, gerstGrad, causticF);
    float radialRipple = sin(length(pos.xz) * 34.0 - u_time * 5.8 + fluidCurl * 1.4) * (0.0012 + 0.0034 * waveEnergy);
    vec2 sol = evalKdVSoliton(pos.x + 0.30 - (u_soliton.x - 0.5) * 0.35, u_soliton.z, u_soliton.w, 18.0, 0.78);
    gerstH += radialRipple * 0.85 + sol.x * 0.56;
  }

  // Menisco capilar côncavo 360° de Young-Laplace aderindo à parede interna curva de vidro
  float wallDist = max(-dCav, 0.0);
  float meniscusLift = evalYoungLaplaceMeniscus(wallDist, 0.052, 0.030) * step(0.015, u_fill) * step(u_fill, 0.985);
  return u_fillY + tiltSlope + springH + gerstH * 0.72 + meniscusLift;
}

vec3 calcDropWaterNormalSmooth3D(
  vec3 pos,
  vec2 fluidVel,
  float fluidCurl,
  float waveEnergy
) {
  const float e = 0.0028;
  float dcC = sdTeardropCavity3D(pos);
  float hX0 = evalDropWaterSurface3D(pos - vec3(e, 0.0, 0.0), fluidVel, fluidCurl, waveEnergy, dcC);
  float hX1 = evalDropWaterSurface3D(pos + vec3(e, 0.0, 0.0), fluidVel, fluidCurl, waveEnergy, dcC);
  float hZ0 = evalDropWaterSurface3D(pos - vec3(0.0, 0.0, e), fluidVel, fluidCurl, waveEnergy, dcC);
  float hZ1 = evalDropWaterSurface3D(pos + vec3(0.0, 0.0, e), fluidVel, fluidCurl, waveEnergy, dcC);
  return normalize(vec3((hX0 - hX1) / (2.0 * e), 1.0, (hZ0 - hZ1) / (2.0 * e)));
}

vec3 calcDropWaterNormal3D(
  vec3 pos,
  vec2 fluidVel,
  float fluidCurl,
  float waveEnergy
) {
  vec3 nBase = calcDropWaterNormalSmooth3D(pos, fluidVel, fluidCurl, waveEnergy);
  vec2 slope = evalMicroCapillarySlope(pos.xz * 4.0, u_time, waveEnergy);
  return normalize(vec3(nBase.x - slope.x * 0.68, nBase.y, nBase.z - slope.y * 0.68));
}

vec3 traceTeardropStudioExit(
  vec3 backPos,
  vec3 rayInside,
  vec3 backN,
  float mediaIor,
  float glassIor,
  float inWater,
  vec3 causticRgb,
  vec2 swirlOffset
) {
  vec3 nBackIn = dot(rayInside, backN) > 0.0 ? -backN : backN;
  bool alreadyAtOuterWall = abs(mediaIor - glassIor) < 0.005;
  vec3 rayGlass = alreadyAtOuterWall ? rayInside : refract(rayInside, nBackIn, mediaIor / glassIor);
  bool isTirBack = !alreadyAtOuterWall && dot(rayGlass, rayGlass) < 0.001;
  vec3 pGlassExit = backPos;
  vec3 nGlassExit = nBackIn;
  if (!isTirBack && !alreadyAtOuterWall) {
    // Marcha física pela espessura traseira da parede de borossilicato (0.022)
    pGlassExit = backPos + rayGlass * 0.022;
    nGlassExit = calcTeardropNormal3D(pGlassExit);
    if (dot(rayGlass, nGlassExit) > 0.0) nGlassExit = -nGlassExit;
  }

  // Separação espectral real de Sellmeier na saída curva do vidro borossilicato (650nm R / 532nm G / 455nm B)
  float iorR = glassIor - 0.006;
  float iorG = glassIor;
  float iorB = glassIor + 0.009;
  vec3 rayExitR = isTirBack ? reflect(rayInside, nBackIn) : refract(rayGlass, nGlassExit, iorR);
  vec3 rayExitG = isTirBack ? reflect(rayInside, nBackIn) : refract(rayGlass, nGlassExit, iorG);
  vec3 rayExitB = isTirBack ? reflect(rayInside, nBackIn) : refract(rayGlass, nGlassExit, iorB);
  if (dot(rayExitG, rayExitG) < 0.001) {
    rayExitG = reflect(rayInside, nGlassExit);
    rayExitR = rayExitG;
    rayExitB = rayExitG;
    isTirBack = true;
  } else {
    if (dot(rayExitR, rayExitR) < 0.001) rayExitR = rayExitG;
    if (dot(rayExitB, rayExitB) < 0.001) rayExitB = rayExitG;
  }

  vec2 lensDistort = inWater > 0.02
    ? vec2(pGlassExit.x * 0.72 + rayExitG.x * 0.24, pGlassExit.y * 0.62 + rayExitG.y * 0.22)
    : pGlassExit.xy + rayExitG.xy * 0.14;
  vec2 rearHit = lensDistort + swirlOffset * 0.032;
  vec3 cavityWall = sampleOpticalCavityWall(rearHit, vec2(6.5, 11.0), 0.5 + pGlassExit.z);

  float exitCos = clamp(abs(dot(rayInside, nBackIn)), 0.0, 1.0);
  float exitR0 = sq((mediaIor - glassIor) / max(mediaIor + glassIor, 1e-3));
  float exitFresnel = exitR0 + (1.0 - exitR0) * pow5(1.0 - exitCos);

  float dispWeight = smoothstep(0.18, 0.85, 1.0 - exitCos) * 0.45 + inWater * 0.35;
  vec3 studioG = sampleWaterStudioEnvironment(rayExitG, vec3(0.99, 0.995, 1.0));
  vec3 studioEnv = vec3(
    mix(studioG.r, sampleWaterStudioEnvironment(rayExitR, vec3(1.0, 0.98, 0.96)).r, dispWeight),
    studioG.g,
    mix(studioG.b, sampleWaterStudioEnvironment(rayExitB, vec3(0.97, 0.985, 1.0)).b, dispWeight)
  );
  vec3 reflDir1 = reflect(rayInside, nBackIn);
  vec3 backRefl = sampleWaterStudioEnvironment(reflDir1, vec3(0.99, 0.995, 1.0));

  // Segundo ressalto interno na parede oposta da gota para arcos prateados / TIR reais
  if (inWater > 0.05) {
    vec3 pBounce2 = backPos + reflDir1 * 0.16;
    vec3 nBounce2 = calcTeardropNormal3D(pBounce2);
    vec3 rayBounceExit = refract(reflDir1, dot(reflDir1, nBounce2) > 0.0 ? -nBounce2 : nBounce2, mediaIor);
    vec3 envBounce2 = dot(rayBounceExit, rayBounceExit) > 0.001
      ? sampleWaterStudioEnvironment(rayBounceExit, vec3(0.99, 0.995, 1.0))
      : sampleWaterStudioEnvironment(reflect(reflDir1, -nBounce2), vec3(1.0, 1.0, 1.0)) * 1.18;
    backRefl = mix(backRefl, envBounce2 * 0.94, 0.52 * inWater);
  }

  vec3 exitCol = isTirBack
    ? backRefl * 1.02
    : mix(mix(cavityWall, studioEnv, 0.70), backRefl, clamp(exitFresnel * 0.92, 0.0, 0.92));
  exitCol += causticRgb * inWater * 1.32;
  return exitCol;
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 sc = vec2((v_uv.x - 0.5) * aspect, v_uv.y - 0.5);
  float aa = 1.25 / max(min(u_resolution.x, u_resolution.y), 1.0);

  // Câmera 3D com paralaxe orbital elevada para revelar a elipse 3D da superfície livre + menisco real
  vec3 ro = vec3(clamp(u_tilt.x, -0.38, 0.38) * 0.58, 0.31 + clamp(u_tilt.y, -0.35, 0.35) * 0.36, 1.94);
  vec3 ta = vec3(0.0, 0.015, 0.0);
  vec3 ww = normalize(ta - ro);
  vec3 uu = normalize(cross(ww, vec3(0.0, 1.0, 0.0)));
  vec3 vv = normalize(cross(uu, ww));
  vec3 rd = normalize(sc.x * uu + sc.y * vv + 2.06 * ww);

  // Raymarch 3D até a casca externa de vidro borossilicato
  float tOuter = 0.0;
  float minD = 10.0;
  float minT = 0.0;
  bool hitOuter = false;
  for (int i = 0; i < 38; i++) {
    vec3 pCheck = ro + rd * tOuter;
    float dS = sdTeardropOuter3D(pCheck);
    if (dS < minD) {
      minD = dS;
      minT = tOuter;
    }
    if (dS < 0.0007) {
      hitOuter = true;
      break;
    }
    tOuter += dS;
    if (tOuter > 3.2) break;
  }

  if (!hitOuter && minD > 0.024) {
    fragColor = vec4(0.0);
    return;
  }

  vec3 pOuter = ro + rd * (hitOuter ? tOuter : minT);
  vec3 nOuter = calcTeardropNormal3D(pOuter);
  float glassIor = 1.515;
  float waterIor = max(u_ior, 1.02);

  // Refração inicial Ar -> Vidro
  vec3 rdGlass = refract(rd, nOuter, 1.0 / glassIor);
  if (dot(rdGlass, rdGlass) < 0.001) rdGlass = reflect(rd, nOuter);

  // Atravessa espessura da parede frontal e detecta se o raio realmente entra na cavidade interna
  vec3 pInner = pOuter + rdGlass * 0.018;
  bool enteredCavity = false;
  for (int k = 0; k < 8; k++) {
    float dc = sdTeardropCavity3D(pInner);
    if (dc <= 0.0005) {
      enteredCavity = true;
      break;
    }
    pInner += rdGlass * max(dc * 0.85, 0.004);
  }
  if (!enteredCavity) {
    pInner = pOuter + rdGlass * 0.022;
  }
  vec3 nInner = calcTeardropNormal3D(pInner);

  // Estado hidrodinâmico Navier-Stokes 2D acoplado ao volume 3D
  vec2 fluidUv = clamp(vec2((pInner.x + 0.30) / 0.60, (pInner.y + 0.44) / 0.88), 0.0, 1.0);
  vec4 fluidSample = texture(u_fluidTex, fluidUv);
  vec2 fluidVel = (fluidSample.rg - 0.5) * 2.0;
  float fluidCurl = (fluidSample.b - 0.5) * 2.0;
  float fluidAeration = fluidSample.a;
  float waveEnergy = clamp(abs(sampleDropWaveSpring(fluidUv.x)) * 45.0 + length(fluidVel) * 0.55, 0.0, 1.0);

  // Marcha 3D através da cavidade interna (Ar <-> Superfície da Água 3D <-> Vidro Traseiro)
  float fill = clamp(u_fill, 0.0, 1.0);
  float dCavStart = sdTeardropCavity3D(pInner);
  float startSurfY = evalDropWaterSurface3D(pInner, fluidVel, fluidCurl, waveEnergy, dCavStart);
  bool startedSubmerged = enteredCavity && fill > 0.004 && pInner.y <= startSurfY;

  vec3 rdCav = enteredCavity
    ? (startedSubmerged ? refract(rdGlass, nInner, glassIor / waterIor) : refract(rdGlass, nInner, glassIor))
    : rdGlass;
  if (dot(rdCav, rdCav) < 0.001) rdCav = reflect(rdGlass, nInner);

  vec3 pos = pInner;
  bool inWaterRay = startedSubmerged;
  float waterTravel3D = 0.0;
  float surfHitSpec = 0.0;
  vec3 surfReflCol = vec3(0.0);
  float surfFresnel = 0.0;
  float tirBounceCount = 0.0;
  float snellCritRing = 0.0;
  float snellWindowSky = 0.0;
  float meniscusEdgeContact = 0.0;
  float hitSurfaceGrazing = 0.0;
  float wallContactGlow = 0.0;
  vec3 pWaterEnter = pInner;
  vec3 rdWaterDir = rdCav;
  bool hitWaterSurface = false;
  vec3 nWaterSurf = vec3(0.0, 1.0, 0.0);

  if (enteredCavity) {
    const float cavStep = 0.022;
    for (int m = 0; m < 44; m++) {
      vec3 nextPos = pos + rdCav * cavStep;
      float dCavNext = sdTeardropCavity3D(nextPos);
      float surfNext = evalDropWaterSurface3D(nextPos, fluidVel, fluidCurl, waveEnergy, dCavNext);

      if (!inWaterRay && fill > 0.004 && nextPos.y <= surfNext) {
        // Refinamento binário da intersecção com a superfície livre 3D da água
        vec3 lo = pos;
        vec3 hi = nextPos;
        for (int bIdx = 0; bIdx < 4; bIdx++) {
          vec3 mid = 0.5 * (lo + hi);
          float dM = sdTeardropCavity3D(mid);
          if (mid.y <= evalDropWaterSurface3D(mid, fluidVel, fluidCurl, waveEnergy, dM)) {
            hi = mid;
          } else {
            lo = mid;
          }
        }
        pos = hi;
        hitWaterSurface = true;
        nWaterSurf = calcDropWaterNormal3D(pos, fluidVel, fluidCurl, waveEnergy);
        float sCos = clamp(dot(-rdCav, nWaterSurf), 0.0, 1.0);
        surfFresnel = u_fresnelR0 + (1.0 - u_fresnelR0) * pow5(1.0 - sCos);
        surfReflCol = sampleWaterStudioEnvironment(reflect(rdCav, nWaterSurf), vec3(0.99, 0.995, 1.0));
        vec3 keyL = normalize(vec3(-0.36 + u_tilt.x * 0.35, 0.88, 0.36));
        surfHitSpec = length(evaluateGGXSpecular(nWaterSurf, -rdCav, keyL, vec3(u_fresnelR0), 0.0011));
        float dSurfWall = sdTeardropCavity3D(pos);
        float wallProx = smoothstep(-0.046, -0.002, dSurfWall);
        meniscusEdgeContact = max(meniscusEdgeContact, wallProx);
        wallContactGlow = max(wallContactGlow, evalYoungLaplaceCurvature(-dSurfWall, 0.015));
        hitSurfaceGrazing = max(hitSurfaceGrazing, smoothstep(0.20, 0.88, 1.0 - sCos) * (0.45 + 0.55 * wallProx));

        vec3 refrDown = refract(rdCav, nWaterSurf, 1.0 / waterIor);
        rdCav = dot(refrDown, refrDown) > 0.001 ? normalize(refrDown) : reflect(rdCav, nWaterSurf);
        inWaterRay = true;
        pWaterEnter = pos;
        rdWaterDir = rdCav;
        continue;
      }

      if (inWaterRay && fill > 0.004 && fill < 0.985 && nextPos.y > surfNext) {
        // Raio submerso atinge a face inferior da superfície d'água -> Janela de Snell física (cone crítico 48.6°) + TIR real
        vec3 lo = pos;
        vec3 hi = nextPos;
        for (int bIdx = 0; bIdx < 3; bIdx++) {
          vec3 mid = 0.5 * (lo + hi);
          float dM = sdTeardropCavity3D(mid);
          if (mid.y > evalDropWaterSurface3D(mid, fluidVel, fluidCurl, waveEnergy, dM)) hi = mid;
          else lo = mid;
        }
        pos = hi;
        nWaterSurf = calcDropWaterNormal3D(pos, fluidVel, fluidCurl, waveEnergy);
        vec3 snellDir = rdCav;
        float critBand = 0.0;
        float winFactor = evalSnellsWindowAndCrit(rdCav, -nWaterSurf, waterIor, snellDir, critBand);
        snellCritRing = max(snellCritRing, critBand);
        float dSubWall = sdTeardropCavity3D(pos);
        float subWallProx = smoothstep(-0.052, -0.002, dSubWall);
        if (winFactor <= 0.01) {
          rdCav = reflect(rdCav, -nWaterSurf);
          tirBounceCount += 1.0;
          wallContactGlow = max(wallContactGlow, evalYoungLaplaceCurvature(-dSubWall, 0.018));
        } else {
          rdCav = snellDir;
          snellWindowSky = max(snellWindowSky, winFactor);
          inWaterRay = false;
        }
        meniscusEdgeContact = max(meniscusEdgeContact, subWallProx);
        continue;
      }

      if (dCavNext > 0.0) {
        vec3 lo = pos;
        vec3 hi = nextPos;
        for (int cIdx = 0; cIdx < 4; cIdx++) {
          vec3 mid = 0.5 * (lo + hi);
          if (sdTeardropCavity3D(mid) > 0.0) hi = mid;
          else lo = mid;
        }
        if (inWaterRay) waterTravel3D += length(lo - pos);
        pos = lo;
        break;
      }

      if (inWaterRay) {
        waterTravel3D += cavStep;
      }
      pos = nextPos;
    }

    // Garante convergência na parede traseira mesmo em refrações oblíquas
    for (int eIdx = 0; eIdx < 4; eIdx++) {
      float remCav = -sdTeardropCavity3D(pos);
      if (remCav <= 0.001) break;
      pos += rdCav * remCav;
      if (inWaterRay) waterTravel3D += remCav;
    }
  } else {
    // Raio sólido exclusivamente na parede espessa de cristal borossilicato
    for (int gIdx = 0; gIdx < 6; gIdx++) {
      float dg = -sdTeardropOuter3D(pos);
      if (dg <= 0.001) break;
      pos += rdGlass * clamp(dg, 0.002, 0.035);
    }
  }

  vec3 pBack = pos;
  vec3 nBack = calcTeardropNormal3D(pBack);

  vec3 keyLight = normalize(vec3(-0.36 + u_tilt.x * 0.38, 0.86, 0.38));
  float inWaterCov = enteredCavity
    ? step(0.004, fill) * smoothstep(0.001, 0.016, waterTravel3D + (hitWaterSurface ? 0.018 : 0.0))
    : 0.0;

  // Normal analítica suave para cáusticas dFdx/dFdy (zero ruído de pixel) vs normal micro-capilar para especular
  vec3 pSurfAbove = vec3(pBack.x, u_fillY, pBack.z);
  vec3 nCausticSmooth = calcDropWaterNormalSmooth3D(pSurfAbove, fluidVel, fluidCurl, waveEnergy);
  vec3 nCausticSurf = hitWaterSurface ? nWaterSurf : calcDropWaterNormal3D(pSurfAbove, fluidVel, fluidCurl, waveEnergy);
  vec2 schlierenCurl = vec2(fluidVel.x + fluidCurl * 0.35, fluidVel.y - fluidCurl * 0.25) * 0.042;

  // Cáustica espectral diferencial dFdx/dFdy (ondas suaves) + rede cáustica subaquática dual-camada
  vec3 refrLightR = refract(-keyLight, nCausticSmooth, 1.0 / (waterIor - 0.014));
  vec3 refrLightG = refract(-keyLight, nCausticSmooth, 1.0 / waterIor);
  vec3 refrLightB = refract(-keyLight, nCausticSmooth, 1.0 / (waterIor + 0.016));
  float projDist = clamp(waterTravel3D * 1.24 + 0.14, 0.04, 0.68);
  float cR = computeDifferentialCaustic(pBack.xy, pBack.xy + refrLightR.xy * projDist + schlierenCurl);
  float cG = computeDifferentialCaustic(pBack.xy, pBack.xy + refrLightG.xy * projDist + schlierenCurl);
  float cB = computeDifferentialCaustic(pBack.xy, pBack.xy + refrLightB.xy * projDist + schlierenCurl);
  float webR = evalWaterCausticWeb(pBack.xy + refrLightR.xy * 0.16 + schlierenCurl * 0.6, u_time, fluidVel, waveEnergy);
  float webG = evalWaterCausticWeb(pBack.xy + refrLightG.xy * 0.16 + schlierenCurl * 0.6, u_time, fluidVel, waveEnergy);
  float webB = evalWaterCausticWeb(pBack.xy + refrLightB.xy * 0.16 + schlierenCurl * 0.6, u_time, fluidVel, waveEnergy);
  float bottomFocus = (1.0 - smoothstep(-0.42, -0.02, pBack.y)) * 1.48 + 0.34;
  vec3 causticRgb = (
    vec3(cR * 1.00, cG * 1.005, cB * 1.015) * 1.02 +
    vec3(webR * 0.99, webG * 1.00, webB * 1.015) * 0.90
  ) * u_causticIntensity * bottomFocus * inWaterCov;

  vec2 bellyCenter = vec2(0.040 - u_tilt.x * 0.08, -0.22);
  float focalHeart = exp(-sq(length((pBack.xy - bellyCenter) * vec2(4.2, 6.2)))) * smoothstep(0.05, 0.25, waterTravel3D) * inWaterCov;

  // Saída com refração real em 3 raios de Sellmeier
  float wIorG = waterIor;
  float exitMediaIorG = enteredCavity ? (inWaterRay ? wIorG : 1.0) : glassIor;
  vec3 exitCol = inWaterCov > 0.02
    ? traceTeardropStudioExit(pBack, rdCav, nBack, exitMediaIorG, glassIor, inWaterCov, causticRgb, fluidVel)
    : traceTeardropStudioExit(pBack, rdCav, nBack, enteredCavity ? 1.0 : glassIor, glassIor, 0.0, vec3(0.0), vec2(0.0));

  // Água destilada oticamente pura por Beer-Lambert (H2O 100% incolor, contraste alto entre TIR escuro e focos prata)
  float opticalChord = clamp(waterTravel3D * 1.45, 0.01, 0.98);
  vec3 waterTint = vec3(0.988, 0.996, 1.0);
  vec3 backLight = normalize(vec3(0.08, 0.32, -0.94));
  vec3 refrBackIn = refract(-backLight, nCausticSmooth, 1.0 / waterIor);
  float hgPhase = evalHenyeyGreenstein(dot(-rdWaterDir, refrBackIn), 0.92);
  vec3 beerBody = applyBeerLambert(exitCol, waterTint, 1.05, opticalChord);
  beerBody += vec3(1.52, 1.54, 1.56) * focalHeart * (0.64 + 0.28 * waveEnergy + 0.06 * hgPhase) * inWaterCov;
  float dropEdgeTir = smoothstep(0.54, 0.93, 1.0 - abs(dot(rdCav, nBack))) * inWaterCov;
  vec3 dropWallMirror = sampleWaterStudioEnvironment(reflect(rdCav, -nBack), vec3(0.99, 0.995, 1.0));
  beerBody = mix(beerBody, dropWallMirror * 1.05, dropEdgeTir * 0.72);
  float dropShadowCore = exp(-sq((abs(pBack.x) - 0.162) * 15.0)) * invSmooth(-0.34, 0.06, pBack.y) * inWaterCov;
  beerBody *= 1.0 - dropShadowCore * 0.56;
  float forwardSss = evalForwardSSS(-rd, backLight, nCausticSurf, 1.0 - clamp(waterTravel3D * 1.35, 0.0, 0.85));
  beerBody += vec3(1.00, 1.01, 1.02) * forwardSss * (0.16 + 0.24 * waveEnergy + 0.12 * u_soliton.w) * inWaterCov;

  // Menisco 3D nítido em 360°: crescente escuro TIR diretamente abaixo + linha capilar fina de cristal + Janela de Snell
  float meniscusRamp = smoothstep(0.015, 0.06, fill) * invSmooth(0.955, 0.992, fill);
  float frontWallProx = smoothstep(-0.088, -0.002, dCavStart);
  float frontGrazing = smoothstep(0.16, 0.82, 1.0 - abs(dot(rdCav, nInner))) * (0.44 + 0.56 * frontWallProx);
  float frontWallTouch = exp(-sq((pInner.y - startSurfY) * 180.0)) * frontGrazing * meniscusRamp;
  float frontDarkRefr = exp(-sq((pInner.y - startSurfY + 0.010) * 130.0)) * (0.68 + 0.32 * frontGrazing) * meniscusRamp;
  float surfRimGlow = hitWaterSurface
    ? clamp(1.0 - nWaterSurf.y, 0.0, 1.0) * smoothstep(-0.065, -0.002, sdTeardropCavity3D(pos)) * meniscusRamp
    : 0.0;
  float capillaryLensFocus = evalYoungLaplaceCurvature(max(-dCavStart, 0.0), 0.018) * (frontWallTouch + surfRimGlow * 0.72);
  beerBody *= 1.0 - clamp(hitSurfaceGrazing * 0.72 + frontDarkRefr * 0.84, 0.0, 0.90);
  beerBody += vec3(2.65, 2.67, 2.70) * ((wallContactGlow * 0.62 + frontWallTouch * 1.15 + surfRimGlow * 0.74 + capillaryLensFocus * 0.68) * meniscusRamp + tirBounceCount * 0.52 * meniscusEdgeContact);
  beerBody += vec3(2.20, 2.22, 2.25) * snellCritRing * 0.50 * meniscusRamp;
  if (snellWindowSky > 0.02) {
    vec3 snellSky = sampleWaterStudioEnvironment(rdCav, vec3(0.99, 0.995, 1.0));
    beerBody = mix(beerBody, snellSky * 0.96, clamp(snellWindowSky * 0.50, 0.0, 0.50));
  }

  // Superfície superior 3D real da água (Fresnel cristalino limpo + GGX de estúdio afiado + micro-ondas capilares)
  if (hitWaterSurface) {
    vec3 surfCol = mix(beerBody, surfReflCol, clamp(surfFresnel * 1.44, 0.0, 0.98));
    surfCol += vec3(8.5, 8.55, 8.6) * surfHitSpec * 1.10;
    beerBody = surfCol;
  }

  vec3 dryGlassCol = enteredCavity ? exitCol * 0.28 : exitCol * 0.60;
  vec3 col = mix(dryGlassCol, beerBody, inWaterCov);

  // 8 Micro-bolhas de oxigênio 3D finas e cristalinas com nascimento e dissolução suaves
  if (inWaterCov > 0.12 && fill > 0.06) {
    float maxH = max(0.08, u_fillY - (-0.39));
    vec2 adv = fluidVel * 0.040;
    float p1 = fract(u_time * 0.22 + fluidAeration * 0.2);
    float p2 = fract(u_time * 0.14 + 0.41);
    float p3 = fract(u_time * 0.09 + 0.73);
    float p4 = fract(u_time * 0.06 + 0.19);
    float p5 = fract(u_time * 0.18 + 0.62);
    float p6 = fract(u_time * 0.11 + 0.87);
    float p7 = fract(u_time * 0.25 + 0.31);
    float p8 = fract(u_time * 0.16 + 0.54);

    vec3 c1 = vec3(-0.072 + sin(u_time * 1.3 + fluidCurl) * 0.014 + adv.x, -0.36 + p1 * maxH * 0.84, 0.06);
    vec3 c2 = vec3(0.082 + cos(u_time * 1.6 - fluidCurl) * 0.012 + adv.x * 0.8, -0.35 + p2 * maxH * 0.82, -0.04);
    vec3 c3 = vec3(0.014 + sin(u_time * 1.8 + 1.4) * 0.010 + adv.x * 0.6, -0.33 + p3 * maxH * 0.78, 0.02);
    vec3 c4 = vec3(-0.026 + cos(u_time * 1.1) * 0.010 + adv.x * 0.5, -0.31 + p4 * maxH * 0.74, -0.06);
    vec3 c5 = vec3(0.046 + sin(u_time * 2.1 + 0.8) * 0.008 + adv.x * 0.4, -0.34 + p5 * maxH * 0.79, 0.08);
    vec3 c6 = vec3(-0.048 + cos(u_time * 1.5 + 2.3) * 0.008 + adv.x * 0.4, -0.32 + p6 * maxH * 0.76, -0.02);
    vec3 c7 = vec3(0.024 + sin(u_time * 2.4 + 0.4) * 0.007 + adv.x * 0.7, -0.36 + p7 * maxH * 0.81, -0.07);
    vec3 c8 = vec3(-0.088 + cos(u_time * 1.7 + 1.1) * 0.009 + adv.x * 0.5, -0.34 + p8 * maxH * 0.75, 0.04);

    vec4 b1 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c1, 0.0092, keyLight);
    vec4 b2 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c2, 0.0074, keyLight);
    vec4 b3 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c3, 0.0060, keyLight);
    vec4 b4 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c4, 0.0050, keyLight);
    vec4 b5 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c5, 0.0042, keyLight);
    vec4 b6 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c6, 0.0036, keyLight);
    vec4 b7 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c7, 0.0032, keyLight);
    vec4 b8 = traceBubbleSphere3D(pWaterEnter, rdWaterDir, c8, 0.0046, keyLight);

    float bVis = inWaterCov * (hitWaterSurface ? 0.68 : 0.98) * (0.76 + fluidAeration * 0.54);
    float f1 = smoothstep(0.0, 0.14, p1) * invSmooth(0.84, 1.0, p1);
    float f2 = smoothstep(0.0, 0.14, p2) * invSmooth(0.84, 1.0, p2);
    float f3 = smoothstep(0.0, 0.14, p3) * invSmooth(0.84, 1.0, p3);
    float f4 = smoothstep(0.0, 0.14, p4) * invSmooth(0.84, 1.0, p4);
    float f5 = smoothstep(0.0, 0.14, p5) * invSmooth(0.84, 1.0, p5);
    float f6 = smoothstep(0.0, 0.14, p6) * invSmooth(0.84, 1.0, p6);
    float f7 = smoothstep(0.0, 0.14, p7) * invSmooth(0.84, 1.0, p7);
    float f8 = smoothstep(0.0, 0.14, p8) * invSmooth(0.84, 1.0, p8);
    col = mix(col, b1.rgb, b1.a * bVis * f1 * 0.94);
    col = mix(col, b2.rgb, b2.a * bVis * f2 * 0.88);
    col = mix(col, b3.rgb, b3.a * bVis * f3 * 0.90);
    col = mix(col, b4.rgb, b4.a * bVis * f4 * 0.82);
    col = mix(col, b5.rgb, b5.a * bVis * f5 * 0.78);
    col = mix(col, b6.rgb, b6.a * bVis * f6 * 0.74);
    col = mix(col, b7.rgb, b7.a * bVis * f7 * 0.72);
    col = mix(col, b8.rgb, b8.a * bVis * f8 * 0.76);
  }

  // Fresnel externo do vidro borossilicato + Borda refrativa fina + Dual GGX Estúdio
  float cosOuter = clamp(dot(nOuter, -rd), 0.0, 1.0);
  float r0Glass = 0.046;
  float fresnelOuter = r0Glass + (1.0 - r0Glass) * pow5(1.0 - cosOuter);
  float darkGlassEdge = smoothstep(0.62, 0.94, fresnelOuter);
  col *= 1.0 - darkGlassEdge * 0.36;
  vec3 outerRefl = sampleWaterStudioEnvironment(reflect(rd, nOuter), vec3(0.99, 0.995, 1.0));
  col = mix(col, outerRefl, clamp(fresnelOuter * u_esrIntensity * mix(0.78, 0.96, u_active), 0.0, 0.95));

  vec3 fillLight = normalize(vec3(0.56, 0.42, 0.58));
  vec3 specOuterKey = evaluateGGXSpecular(nOuter, -rd, keyLight, vec3(0.048), 0.0018);
  vec3 specOuterFill = evaluateGGXSpecular(nOuter, -rd, fillLight, vec3(0.042), 0.011);
  col += specOuterKey * vec3(6.8, 6.85, 6.9) + specOuterFill * vec3(1.18, 1.22, 1.26);

  // Espessura refrativa da dupla parede interna + orvalho fino na cúpula seca superior
  float wallRim = clamp(enteredCavity ? max(0.0, 1.0 - dot(nOuter, nInner)) : 0.46, 0.0, 1.0);
  col += vec3(1.00, 1.01, 1.02) * wallRim * mix(0.32, 0.66, inWaterCov);

  float dewCell = valueNoise(pInner.xy * 44.0 + vec2(3.1, 7.4));
  float dewSpec = smoothstep(0.89, 0.97, dewCell) * (1.0 - inWaterCov) * smoothstep(0.0, 0.35, pInner.y);
  col += vec3(1.30, 1.32, 1.35) * dewSpec * 0.24;

  float edgeDist = hitOuter ? min(0.0, sdTeardropOuter3D(pOuter)) : minD;
  float shapeMask = hitOuter ? 1.0 : invSmooth(-aa, aa, edgeDist);
  float glassAlpha = clamp(mix(0.24, 0.94, inWaterCov) + fresnelOuter * 0.68 + length(specOuterKey) * 0.18, 0.0, 0.98);
  float alpha = shapeMask * glassAlpha;
  fragColor = finalizeHdrOrSrgb(col, alpha, u_hdrOutput, gl_FragCoord.xy, u_time);
}
`;

// 2. Tubo Capilar de Cristal 3D Analítico (Inigo Quilez Ray-Capsule) + Coluna Líquida 3D
//    + Menisco Capilar Côncavo 360° + Janela de Snell TIR + Tipografia Submersa Refratada em Cauchy RGB
const TANK_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform float u_ior;
uniform float u_fresnelR0;
uniform vec3 u_attenColor;
uniform float u_attenDist;
uniform float u_esrIntensity;
uniform float u_causticIntensity;
uniform float u_footprint;
uniform vec2 u_tilt;
uniform float u_wave[24];
uniform sampler2D u_fluidTex;
uniform sampler2D u_textTex;
uniform float u_hasText;
uniform vec2 u_textDims;
uniform vec4 u_soliton;
uniform float u_hdrOutput;

${SHARED_OPTICS_GLSL}

// Intersecção analítica exata raio-cápsula ao longo do eixo X ([-halfAxis, +halfAxis], raio rad)
// Retorna x = distância t de entrada (-1 se não intersectar), y = distância t de saída (>0)
vec2 intersectTankCapsuleAnalytic(vec3 ro, vec3 rd, float halfAxis, float rad) {
  float r2 = rad * rad;
  // Cilindro infinito ao longo de X: y² + z² = rad²
  float a = rd.y * rd.y + rd.z * rd.z;
  float b = ro.y * rd.y + ro.z * rd.z;
  float c = ro.y * ro.y + ro.z * ro.z - r2;

  float tMin = 1e9;
  float tMax = -1e9;
  bool anyHit = false;

  if (a > 1e-6) {
    float disc = b * b - a * c;
    if (disc >= 0.0) {
      float sqD = sqrt(disc);
      float t0 = (-b - sqD) / a;
      float t1 = (-b + sqD) / a;
      float x0 = ro.x + rd.x * t0;
      float x1 = ro.x + rd.x * t1;
      if (abs(x0) <= halfAxis) { tMin = min(tMin, t0); tMax = max(tMax, t0); anyHit = true; }
      if (abs(x1) <= halfAxis) { tMin = min(tMin, t1); tMax = max(tMax, t1); anyHit = true; }
    }
  }

  // Semiesfera esquerda (centro (-halfAxis, 0, 0))
  vec3 ocL = ro - vec3(-halfAxis, 0.0, 0.0);
  float bL = dot(ocL, rd);
  float cL = dot(ocL, ocL) - r2;
  float dL = bL * bL - cL;
  if (dL >= 0.0) {
    float sL = sqrt(dL);
    float t0 = -bL - sL;
    float t1 = -bL + sL;
    if (ro.x + rd.x * t0 <= -halfAxis) { tMin = min(tMin, t0); tMax = max(tMax, t0); anyHit = true; }
    if (ro.x + rd.x * t1 <= -halfAxis) { tMin = min(tMin, t1); tMax = max(tMax, t1); anyHit = true; }
  }

  // Semiesfera direita (centro (+halfAxis, 0, 0))
  vec3 ocR = ro - vec3(halfAxis, 0.0, 0.0);
  float bR = dot(ocR, rd);
  float cR = dot(ocR, ocR) - r2;
  float dR = bR * bR - cR;
  if (dR >= 0.0) {
    float sR = sqrt(dR);
    float t0 = -bR - sR;
    float t1 = -bR + sR;
    if (ro.x + rd.x * t0 >= halfAxis) { tMin = min(tMin, t0); tMax = max(tMax, t0); anyHit = true; }
    if (ro.x + rd.x * t1 >= halfAxis) { tMin = min(tMin, t1); tMax = max(tMax, t1); anyHit = true; }
  }

  if (!anyHit) return vec2(-1.0);
  return vec2(tMin, tMax);
}

float sdTankCapsule3D(vec3 pos, float halfAxis, float rad) {
  vec3 pClamped = vec3(clamp(pos.x, -halfAxis, halfAxis), 0.0, 0.0);
  return length(pos - pClamped) - rad;
}

float sdTankCavity3D(vec3 pos, float halfAxis, float rad) {
  return sdTankCapsule3D(pos, halfAxis, rad) + 0.028;
}

vec3 calcTankNormalAnalytic(vec3 pos, float halfAxis) {
  vec3 pClamped = vec3(clamp(pos.x, -halfAxis, halfAxis), 0.0, 0.0);
  return normalize(pos - pClamped);
}

float sampleTankWave(float u) {
  float idx = clamp(u, 0.0, 1.0) * 23.0;
  int i0 = clamp(int(floor(idx)), 0, 23);
  int i1 = min(23, i0 + 1);
  return mix(u_wave[i0], u_wave[i1], fract(idx));
}

float evalTankWaterFrontX3D(
  vec3 pos,
  float fill,
  float innerHalf,
  vec2 fluidVel,
  float fluidCurl,
  float waveEnergy,
  float dCav
) {
  float baseX = mix(-innerHalf, innerHalf, fill);
  float tiltSlope = clamp(u_tilt.x, -0.35, 0.35) * pos.y * 0.28 + clamp(u_tilt.y, -0.35, 0.35) * pos.z * 0.18;
  float sloshWave = sampleTankWave(clamp(fill, 0.0, 1.0)) * 0.068;

  float capWave = sin(pos.y * 13.0 - u_time * 4.8 + fluidCurl * 1.2) * (0.0025 + 0.007 * waveEnergy);
  capWave += cos(pos.z * 10.0 + u_time * 3.6) * (0.002 + 0.005 * waveEnergy);
  vec2 sol = evalKdVSoliton(abs(pos.x - mix(-innerHalf, innerHalf, u_soliton.x)), u_soliton.z, u_soliton.w, 6.5, 1.35);

  float meniscusRamp = smoothstep(0.008, 0.048, fill) * invSmooth(0.952, 0.992, fill);
  float wallDist = max(-dCav, 0.0);
  // Menisco côncavo escultural 3D de Young-Laplace (visível em perspectiva teleobjetiva no tanque horizontal)
  float meniscusRing = evalYoungLaplaceMeniscus(wallDist, 0.125, 0.052);
  float domeConcave = (1.0 - clamp(dot(pos.yz, pos.yz) / 0.20, 0.0, 1.0)) * 0.135;
  return baseX + (tiltSlope + sloshWave + capWave + sol.x * 0.46 + fluidVel.x * 0.062 + meniscusRing - domeConcave) * meniscusRamp;
}

vec3 calcTankWaterNormal3D(
  vec3 pos,
  float fill,
  float innerHalf,
  float halfAxis,
  float rad,
  vec2 fluidVel,
  float fluidCurl,
  float waveEnergy
) {
  const float e = 0.0026;
  float dc0 = sdTankCavity3D(pos, halfAxis, rad);
  float xY0 = evalTankWaterFrontX3D(pos - vec3(0.0, e, 0.0), fill, innerHalf, fluidVel, fluidCurl, waveEnergy, dc0);
  float xY1 = evalTankWaterFrontX3D(pos + vec3(0.0, e, 0.0), fill, innerHalf, fluidVel, fluidCurl, waveEnergy, dc0);
  float xZ0 = evalTankWaterFrontX3D(pos - vec3(0.0, 0.0, e), fill, innerHalf, fluidVel, fluidCurl, waveEnergy, dc0);
  float xZ1 = evalTankWaterFrontX3D(pos + vec3(0.0, 0.0, e), fill, innerHalf, fluidVel, fluidCurl, waveEnergy, dc0);
  vec2 slope = evalMicroCapillarySlope(pos.yz * 2.4, u_time, waveEnergy);
  return normalize(vec3(1.0, (xY0 - xY1) / (2.0 * e) - slope.x * 0.58, (xZ0 - xZ1) / (2.0 * e) - slope.y * 0.58));
}

// Normal da superfície livre interna / corrente Gerstner analítica (suave para dFdx/dFdy) e versão micro-capilar
vec3 calcTankCrownWaveNormalSmooth3D(vec3 pos, vec2 fluidVel) {
  float h = 0.0;
  vec2 g = vec2(0.0);
  float cf = 0.0;
  evalGerstnerCascade(pos.xz * 2.4 + fluidVel * 0.14, u_time, u_footprint, h, g, cf);
  vec2 s = g * 0.85;
  return normalize(vec3(-s.x, 1.0, -s.y));
}

vec3 calcTankCrownWaveNormal3D(vec3 pos, vec2 fluidVel, float waveEnergy) {
  vec3 nBase = calcTankCrownWaveNormalSmooth3D(pos, fluidVel);
  vec2 micro = evalMicroCapillarySlope(pos.xz * 2.4, u_time, waveEnergy);
  return normalize(vec3(nBase.x - micro.x * 0.52, nBase.y, nBase.z - micro.y * 0.52));
}

vec3 traceTankStudioExit(
  vec3 backPos,
  vec3 rayInside,
  vec3 backN,
  float mediaIor,
  float glassIor,
  float inWater,
  vec3 causticRgb,
  vec2 swirlOffset,
  float innerHalf,
  float halfAxis,
  float rad
) {
  vec3 nBackIn = dot(rayInside, backN) > 0.0 ? -backN : backN;
  bool alreadyAtOuterWall = abs(mediaIor - glassIor) < 0.005;
  vec3 rayGlass = alreadyAtOuterWall ? rayInside : refract(rayInside, nBackIn, mediaIor / glassIor);
  bool isTirBack = !alreadyAtOuterWall && dot(rayGlass, rayGlass) < 0.001;
  vec3 pGlassExit = backPos;
  vec3 nGlassExit = nBackIn;
  if (!isTirBack && !alreadyAtOuterWall) {
    vec2 outerSpan = intersectTankCapsuleAnalytic(backPos + rayGlass * 0.002, rayGlass, halfAxis, rad);
    float wallSteps = outerSpan.y > 0.002 ? min(outerSpan.y, 0.095) : 0.028;
    pGlassExit = backPos + rayGlass * wallSteps;
    nGlassExit = -calcTankNormalAnalytic(pGlassExit, halfAxis);
  }

  // Separação espectral real de Sellmeier na saída cilíndrica do vidro borossilicato (R / G / B)
  float iorR = glassIor - 0.006;
  float iorG = glassIor;
  float iorB = glassIor + 0.009;
  vec3 rayExitR = isTirBack ? reflect(rayInside, nBackIn) : refract(rayGlass, nGlassExit, iorR);
  vec3 rayExitG = isTirBack ? reflect(rayInside, nBackIn) : refract(rayGlass, nGlassExit, iorG);
  vec3 rayExitB = isTirBack ? reflect(rayInside, nBackIn) : refract(rayGlass, nGlassExit, iorB);
  if (dot(rayExitG, rayExitG) < 0.001) {
    rayExitG = reflect(rayInside, nGlassExit);
    rayExitR = rayExitG;
    rayExitB = rayExitG;
    isTirBack = true;
  } else {
    if (dot(rayExitR, rayExitR) < 0.001) rayExitR = rayExitG;
    if (dot(rayExitB, rayExitB) < 0.001) rayExitB = rayExitG;
  }

  vec2 rearUv = vec2((pGlassExit.x + innerHalf) / max(2.0 * innerHalf, 0.1), (pGlassExit.y + rad) / max(2.0 * rad, 0.1));
  vec3 etchedScale = sampleCalibratedQuartzWall(rearUv, inWater, rayExitG.xy + swirlOffset * 0.22, 0.5 + pGlassExit.z);

  float exitCos = clamp(abs(dot(rayInside, nBackIn)), 0.0, 1.0);
  float exitR0 = sq((mediaIor - glassIor) / max(mediaIor + glassIor, 1e-3));
  float exitFresnel = exitR0 + (1.0 - exitR0) * pow5(1.0 - exitCos);

  float dispWeight = smoothstep(0.18, 0.85, 1.0 - exitCos) * 0.45 + inWater * 0.35;
  vec3 studioG = sampleWaterStudioEnvironment(rayExitG, vec3(0.99, 0.995, 1.0));
  vec3 studioEnv = vec3(
    mix(studioG.r, sampleWaterStudioEnvironment(rayExitR, vec3(1.0, 0.98, 0.96)).r, dispWeight),
    studioG.g,
    mix(studioG.b, sampleWaterStudioEnvironment(rayExitB, vec3(0.97, 0.985, 1.0)).b, dispWeight)
  );
  vec3 reflDir1 = reflect(rayInside, nBackIn);
  vec3 backRefl = sampleWaterStudioEnvironment(reflDir1, vec3(0.99, 0.995, 1.0));

  // Segundo ressalto interno na parede cilíndrica oposta para arcos especulares/TIR reais
  if (inWater > 0.05) {
    vec2 b2Span = intersectTankCapsuleAnalytic(backPos + reflDir1 * 0.003, reflDir1, halfAxis, rad - 0.028);
    if (b2Span.y > 0.01 && b2Span.y < 0.95) {
      vec3 pB2 = backPos + reflDir1 * b2Span.y;
      vec3 nB2 = calcTankNormalAnalytic(pB2, halfAxis);
      vec3 rayB2Exit = refract(reflDir1, dot(reflDir1, nB2) > 0.0 ? -nB2 : nB2, mediaIor);
      vec3 envB2 = dot(rayB2Exit, rayB2Exit) > 0.001
        ? sampleWaterStudioEnvironment(rayB2Exit, vec3(0.99, 0.995, 1.0))
        : sampleWaterStudioEnvironment(reflect(reflDir1, -nB2), vec3(1.0, 1.0, 1.0)) * 1.18;
      backRefl = mix(backRefl, envB2 * 0.94, 0.52 * inWater);
    }
  }

  vec3 exitCol = isTirBack
    ? backRefl * 1.02
    : mix(mix(etchedScale, studioEnv, 0.70), backRefl, clamp(exitFresnel * 0.92, 0.0, 0.92));
  exitCol += causticRgb * inWater * 1.32;
  return exitCol;
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 sc = vec2((v_uv.x - 0.5) * aspect, v_uv.y - 0.5);
  float aa = 1.25 / max(min(u_resolution.x, u_resolution.y), 1.0);

  // Lente teleobjetiva centrada simetricamente borda-a-borda com zero clipagem ou halo externo
  float R = 0.493;
  float halfAxis = max(0.25, aspect * 0.496 - R);
  float innerRad = R - 0.028;
  float innerHalf = halfAxis + innerRad;

  vec3 ro = vec3(clamp(u_tilt.x, -0.35, 0.35) * 0.09, 0.016 + clamp(u_tilt.y, -0.35, 0.35) * 0.05, 7.60);
  vec3 ta = vec3(0.0, 0.0, 0.0);
  vec3 ww = normalize(ta - ro);
  vec3 uu = normalize(cross(ww, vec3(0.0, 1.0, 0.0)));
  vec3 vv = normalize(cross(uu, ww));
  vec3 rd = normalize(sc.x * uu + sc.y * vv + 7.58 * ww);

  vec2 outerHit = intersectTankCapsuleAnalytic(ro, rd, halfAxis, R);
  bool hitOuter = outerHit.x > 0.0;
  float tClosest = max(0.0, dot(-ro, rd));
  float edgeMissDist = abs(sdTankCapsule3D(ro + rd * tClosest, halfAxis, R));
  if (!hitOuter && edgeMissDist > aa * 2.2) {
    fragColor = vec4(0.0);
    return;
  }

  vec3 pOuter = hitOuter ? (ro + rd * outerHit.x) : (ro + rd * tClosest);
  vec3 nOuter = calcTankNormalAnalytic(pOuter, halfAxis);
  float glassIor = 1.515;
  float waterIor = max(u_ior, 1.02);

  // Refração exata Ar -> Parede de Vidro Borossilicato -> Entrada na Cavidade Interna Analítica
  vec3 rdGlass = refract(rd, nOuter, 1.0 / glassIor);
  if (dot(rdGlass, rdGlass) < 0.001) rdGlass = reflect(rd, nOuter);

  vec2 innerEntry = intersectTankCapsuleAnalytic(pOuter + rdGlass * 0.002, rdGlass, halfAxis, innerRad);
  vec3 pCandInner = pOuter + rdGlass * (0.002 + max(innerEntry.x, 0.0));
  bool entersCavity = innerEntry.x > 0.0 && innerEntry.y > innerEntry.x && sdTankCavity3D(pCandInner + rdGlass * 0.001, halfAxis, R) <= 0.002;
  vec3 pInner = entersCavity ? pCandInner : (pOuter + rdGlass * 0.024);
  vec3 nInner = calcTankNormalAnalytic(pInner, halfAxis);

  vec2 fluidUv = clamp(vec2((pInner.x + innerHalf) / max(2.0 * innerHalf, 0.1), (pInner.y + innerRad) / max(2.0 * innerRad, 0.1)), 0.0, 1.0);
  vec4 fluidSample = texture(u_fluidTex, fluidUv);
  vec2 fluidVel = (fluidSample.rg - 0.5) * 2.0;
  float fluidCurl = (fluidSample.b - 0.5) * 2.0;
  float fluidAeration = fluidSample.a;

  float fill = clamp(u_fill, 0.0, 1.0);
  float waveEnergy = clamp(abs(sampleTankWave(fill)) * 45.0 + length(fluidVel) * 0.5, 0.0, 1.0);
  float dCavStart = sdTankCavity3D(pInner, halfAxis, R);
  float startFrontX = evalTankWaterFrontX3D(pInner, fill, innerHalf, fluidVel, fluidCurl, waveEnergy, dCavStart);
  bool startedSubmerged = entersCavity && fill > 0.004 && pInner.x <= startFrontX;

  vec3 rdCav = entersCavity
    ? (startedSubmerged ? refract(rdGlass, nInner, glassIor / waterIor) : refract(rdGlass, nInner, glassIor))
    : rdGlass;
  if (dot(rdCav, rdCav) < 0.001) rdCav = reflect(rdGlass, nInner);

  vec3 pos = pInner;
  bool inWaterRay = startedSubmerged;
  float waterTravel3D = 0.0;
  float meniscusTirCount = 0.0;
  float meniscusCritRim = 0.0;
  float meniscusSpec = 0.0;
  float frontFresnel = 0.0;
  float interfaceGrazing = 0.0;
  float interfaceWallGlow = 0.0;
  vec3 frontReflCol = vec3(0.0);
  bool hitInterface = false;
  vec3 nWaterWall = vec3(1.0, 0.0, 0.0);
  vec3 pWaterRef = pInner;
  vec3 rdWaterRef = rdCav;

  if (entersCavity) {
    vec2 cavSpan = intersectTankCapsuleAnalytic(pInner + rdCav * 0.002, rdCav, halfAxis, innerRad);
    float maxCavTravel = cavSpan.y > 0.004 ? cavSpan.y + 0.002 : clamp(innerRad * 0.85, 0.02, 0.45);
    const int CAV_STEPS = 16;
    float stepLen = maxCavTravel / float(CAV_STEPS);
    for (int m = 0; m < CAV_STEPS; m++) {
      vec3 nextPos = pos + rdCav * stepLen;
      if (fill > 0.008 && fill < 0.992) {
        float dCavNext = sdTankCavity3D(nextPos, halfAxis, R);
        float frontXNext = evalTankWaterFrontX3D(nextPos, fill, innerHalf, fluidVel, fluidCurl, waveEnergy, dCavNext);
        bool crossToDry = inWaterRay && nextPos.x > frontXNext;
        bool crossToWet = !inWaterRay && nextPos.x <= frontXNext;
        if (crossToDry || crossToWet) {
          vec3 lo = pos;
          vec3 hi = nextPos;
          for (int bIdx = 0; bIdx < 4; bIdx++) {
            vec3 mid = 0.5 * (lo + hi);
            float dM = sdTankCavity3D(mid, halfAxis, R);
            float fM = evalTankWaterFrontX3D(mid, fill, innerHalf, fluidVel, fluidCurl, waveEnergy, dM);
            if ((crossToWet && mid.x <= fM) || (crossToDry && mid.x > fM)) hi = mid;
            else lo = mid;
          }
          if (crossToDry) waterTravel3D += length(hi - pos);
          pos = hi;
          hitInterface = true;
          nWaterWall = calcTankWaterNormal3D(pos, fill, innerHalf, halfAxis, R, fluidVel, fluidCurl, waveEnergy);
          vec3 keyL = normalize(vec3(-0.32 + u_tilt.x * 0.25, 0.88, 0.35));
          float dWall = sdTankCavity3D(pos, halfAxis, R);
          interfaceWallGlow = max(interfaceWallGlow, evalYoungLaplaceCurvature(-dWall, 0.024));

          if (crossToWet) {
            float wCos = clamp(dot(-rdCav, nWaterWall), 0.0, 1.0);
            frontFresnel = u_fresnelR0 + (1.0 - u_fresnelR0) * pow5(1.0 - wCos);
            frontReflCol = sampleWaterStudioEnvironment(reflect(rdCav, nWaterWall), vec3(0.98, 0.99, 1.0));
            meniscusSpec += length(evaluateGGXSpecular(nWaterWall, -rdCav, keyL, vec3(u_fresnelR0), 0.0014));
            interfaceGrazing = max(interfaceGrazing, smoothstep(0.20, 0.86, 1.0 - wCos));
            vec3 refrW = refract(rdCav, nWaterWall, 1.0 / waterIor);
            rdCav = dot(refrW, refrW) > 0.001 ? normalize(refrW) : reflect(rdCav, nWaterWall);
            inWaterRay = true;
            pWaterRef = pos;
            rdWaterRef = rdCav;
          } else {
            float aCos = clamp(dot(-rdCav, -nWaterWall), 0.0, 1.0);
            interfaceGrazing = max(interfaceGrazing, smoothstep(0.20, 0.86, 1.0 - aCos) * 0.68);
            vec3 snellDirT = rdCav;
            float critBandT = 0.0;
            float winT = evalSnellsWindowAndCrit(rdCav, -nWaterWall, waterIor, snellDirT, critBandT);
            meniscusCritRim = max(meniscusCritRim, critBandT);
            if (winT <= 0.01) {
              rdCav = reflect(rdCav, -nWaterWall);
              meniscusTirCount += 1.0;
            } else {
              rdCav = snellDirT;
              inWaterRay = false;
            }
          }
          // Recalcula o trecho restante exato até a parede traseira após desvio da refração
          vec2 remSpan = intersectTankCapsuleAnalytic(pos + rdCav * 0.002, rdCav, halfAxis, innerRad);
          float remLen = remSpan.y > 0.002 ? remSpan.y : 0.0;
          if (inWaterRay) waterTravel3D += remLen;
          pos = pos + rdCav * remLen;
          break;
        }
      }
      if (inWaterRay) waterTravel3D += stepLen;
      pos = nextPos;
    }
    // Snap garantido na superfície interna traseira da cápsula
    float dBackErr = sdTankCavity3D(pos, halfAxis, R);
    if (dBackErr < -0.002) {
      vec2 snapSpan = intersectTankCapsuleAnalytic(pos + rdCav * 0.001, rdCav, halfAxis, innerRad);
      if (snapSpan.y > 0.001 && snapSpan.y < 0.45) {
        pos += rdCav * snapSpan.y;
        if (inWaterRay) waterTravel3D += snapSpan.y;
      }
    }
  } else {
    // Raio sólido exclusivamente na parede espessa do tubo de vidro borossilicato
    vec2 wallSpan = intersectTankCapsuleAnalytic(pOuter + rdGlass * 0.002, rdGlass, halfAxis, R);
    float wallLen = wallSpan.y > 0.002 ? min(wallSpan.y, 0.24) : 0.04;
    pos = pOuter + rdGlass * wallLen;
  }

  vec3 pBack = pos;
  vec3 nBack = calcTankNormalAnalytic(pBack, halfAxis);
  vec3 keyLight = normalize(vec3(-0.32 + u_tilt.x * 0.30, 0.88, 0.35));
  float inWaterCov = entersCavity
    ? step(0.004, fill) * smoothstep(0.002, 0.020, waterTravel3D + (hitInterface ? 0.020 : 0.0))
    : 0.0;

  // Ondulação Gerstner suave para dFdx/dFdy (zero aliasing) + normal micro-capilar para brilho na crista
  vec3 nTankCausticSmooth = calcTankCrownWaveNormalSmooth3D(pBack, fluidVel);
  vec3 nTankCaustic = hitInterface ? nWaterWall : calcTankCrownWaveNormal3D(pBack, fluidVel, waveEnergy);
  vec3 rdExitTank = inWaterRay
    ? normalize(rdCav + vec3(nTankCaustic.x * 1.35 + fluidVel.x * 0.14, nTankCaustic.z * 0.48 + fluidVel.y * 0.12, nTankCaustic.z * 0.9))
    : rdCav;
  vec2 schlierenT = vec2(fluidVel.x + fluidCurl * 0.35, fluidVel.y - fluidCurl * 0.26) * 0.042;

  // Cáustica focal cilíndrica + rede cáustica subaquática dual-camada (nítida e orgânica)
  vec3 refrLightR = refract(-keyLight, nTankCausticSmooth, 1.0 / (waterIor - 0.014));
  vec3 refrLightG = refract(-keyLight, nTankCausticSmooth, 1.0 / waterIor);
  vec3 refrLightB = refract(-keyLight, nTankCausticSmooth, 1.0 / (waterIor + 0.016));
  float projDist = clamp(waterTravel3D * 0.96 + 0.14, 0.04, 0.68);
  float cR = computeDifferentialCaustic(pBack.xy, pBack.xy + refrLightR.xy * projDist + schlierenT);
  float cG = computeDifferentialCaustic(pBack.xy, pBack.xy + refrLightG.xy * projDist + schlierenT);
  float cB = computeDifferentialCaustic(pBack.xy, pBack.xy + refrLightB.xy * projDist + schlierenT);
  float tWebR = evalWaterCausticWeb(vec2(pBack.x * 1.35, pBack.y * 2.15) + refrLightR.xy * 0.16 + schlierenT * 0.6, u_time, fluidVel, waveEnergy);
  float tWebG = evalWaterCausticWeb(vec2(pBack.x * 1.35, pBack.y * 2.15) + refrLightG.xy * 0.16 + schlierenT * 0.6, u_time, fluidVel, waveEnergy);
  float tWebB = evalWaterCausticWeb(vec2(pBack.x * 1.35, pBack.y * 2.15) + refrLightB.xy * 0.16 + schlierenT * 0.6, u_time, fluidVel, waveEnergy);
  float focalPlaneY = pBack.y + refrLightG.y * (R * 0.62) + fluidVel.y * 0.056;
  float cylLensRibbon = exp(-sq((focalPlaneY + 0.23) * 6.2));
  vec3 causticRgb = (
    vec3(cR * 1.00, cG * 1.005, cB * 1.015) * 1.02 +
    vec3(tWebR * 0.99, tWebG * 1.00, tWebB * 1.015) * 0.96
  ) * u_causticIntensity * (0.48 + 1.82 * cylLensRibbon) * inWaterCov;

  // Saída com refração real em 3 raios de Sellmeier
  float wIorG = waterIor;
  float exitTankIorG = entersCavity ? (inWaterRay ? wIorG : 1.0) : glassIor;
  vec3 exitCol = inWaterCov > 0.02
    ? traceTankStudioExit(pBack, rdExitTank, nBack, exitTankIorG, glassIor, inWaterCov, causticRgb, fluidVel, innerHalf, halfAxis, R)
    : traceTankStudioExit(pBack, rdCav, nBack, entersCavity ? 1.0 : glassIor, glassIor, 0.0, vec3(0.0), vec2(0.0), innerHalf, halfAxis, R);

  // Água destilada 100% incolor por Beer-Lambert (zero lavagem azulada) + contraste cilíndrico profundo + feixe focal inferior
  float opticalChord = clamp(waterTravel3D * 1.08, 0.01, 0.98);
  vec3 tankWaterTint = vec3(0.988, 0.996, 1.0);
  vec3 backLightTank = normalize(vec3(0.06, 0.30, -0.94));
  vec3 refrBackTank = refract(-backLightTank, nTankCausticSmooth, 1.0 / waterIor);
  float hgTank = evalHenyeyGreenstein(dot(-rdWaterRef, refrBackTank), 0.92);
  float flowSchlieren = 0.5 + 0.5 * sin(pBack.x * 8.5 - u_time * 3.2 + fluidCurl * 2.4 + fluidVel.x * 3.8);
  vec3 beerWater = applyBeerLambert(exitCol, tankWaterTint, 1.05, opticalChord);

  float cylNormY = pBack.y / max(innerRad, 0.1);
  // Borda TIR estritamente no ângulo crítico real + faixa escura de refração cilíndrica + tira superior limpa prata
  float cylWallTir = smoothstep(0.76, 0.97, abs(cylNormY)) * inWaterCov;
  vec3 cylWallMirror = sampleWaterStudioEnvironment(reflect(rdExitTank, -nBack), vec3(0.99, 0.995, 1.0));
  beerWater = mix(beerWater, cylWallMirror * 1.05, cylWallTir * 0.72);
  float cylDarkRim = exp(-sq((abs(cylNormY) - 0.70) * 11.8)) * inWaterCov;
  beerWater *= 1.0 - cylDarkRim * 0.72;
  float cylUpperStrip = exp(-sq((cylNormY - 0.54) * 16.5)) * inWaterCov;
  beerWater += vec3(1.56, 1.58, 1.60) * cylUpperStrip * (0.30 + 0.18 * flowSchlieren);

  // Feixe focal cilíndrico na base interna + reflexo especular das micro-ondas na crista interna
  float waveFocus = 0.56 + 0.44 * clamp(dot(nTankCausticSmooth, normalize(vec3(-0.2, 0.96, 0.15))), 0.0, 1.0);
  beerWater += vec3(1.42, 1.44, 1.46) * cylLensRibbon * waveFocus * (0.68 + 0.30 * flowSchlieren + 0.04 * hgTank);
  beerWater += vec3(1.00, 1.01, 1.02) * tWebG * 0.58 * (1.0 - cylWallTir * 0.5) * inWaterCov;
  vec3 crownRippleSpec = evaluateGGXSpecular(nTankCaustic, -rd, keyLight, vec3(0.030), 0.0014) * smoothstep(0.18, 0.84, cylNormY);
  beerWater += crownRippleSpec * vec3(5.0, 5.05, 5.1) * inWaterCov;
  float crestSSS = evalForwardSSS(-rd, backLightTank, nTankCaustic, 1.0 - clamp(waterTravel3D * 0.82, 0.0, 0.78));
  beerWater += vec3(1.00, 1.01, 1.02) * crestSSS * (0.16 + 0.24 * waveEnergy + 0.12 * u_soliton.w) * inWaterCov;

  // Menisco 3D escultural e nítido na interface água-ar (colar capilar fino + crescente TIR escuro + anel crítico de Snell)
  float tankMeniscusRamp = smoothstep(0.008, 0.048, fill) * invSmooth(0.952, 0.992, fill);
  float wallProximityBand = smoothstep(0.18, 0.92, abs(pInner.y / max(innerRad, 0.1)));
  float wallContactPin = exp(-sq((pInner.x - startFrontX) * 160.0)) * wallProximityBand * tankMeniscusRamp;
  float wallDarkPin = exp(-sq((pInner.x - startFrontX - 0.013) * 124.0)) * (0.66 + 0.34 * wallProximityBand) * tankMeniscusRamp;
  beerWater *= 1.0 - clamp(interfaceGrazing * 0.72 + wallDarkPin * 0.84, 0.0, 0.90);
  beerWater += vec3(2.62, 2.64, 2.68) * ((interfaceWallGlow * 0.62 + wallContactPin * 1.16) * tankMeniscusRamp + meniscusTirCount * 0.56);
  beerWater += vec3(2.20, 2.22, 2.25) * meniscusCritRim * 0.50 * tankMeniscusRamp;
  if (hitInterface) {
    beerWater = mix(beerWater, frontReflCol, clamp(frontFresnel * 1.42, 0.0, 0.97));
    beerWater += vec3(8.2, 8.25, 8.3) * meniscusSpec * 1.08;
  }

  // 8 Micro-bolhas de oxigênio 3D finas dentro da coluna cilíndrica
  if (inWaterCov > 0.12 && fill > 0.06) {
    vec2 bAdv = fluidVel * 0.040;
    float fillSpanX = mix(-innerHalf, innerHalf, fill);
    float tp1 = fract(u_time * 0.20 + fluidAeration * 0.2);
    float tp2 = fract(u_time * 0.13 + 0.52);
    float tp3 = fract(u_time * 0.08 + 0.24);
    float tp4 = fract(u_time * 0.16 + 0.78);
    float tp5 = fract(u_time * 0.23 + 0.37);
    float tp6 = fract(u_time * 0.11 + 0.66);
    float tp7 = fract(u_time * 0.19 + 0.14);
    float tp8 = fract(u_time * 0.26 + 0.89);

    float bRise1 = -0.26 + tp1 * 0.52;
    float bRise2 = -0.28 + tp2 * 0.56;
    float bRise3 = -0.28 + tp3 * 0.54;
    float bRise4 = -0.24 + tp4 * 0.48;
    float bRise5 = -0.27 + tp5 * 0.52;
    float bRise6 = -0.25 + tp6 * 0.50;
    float bRise7 = -0.26 + tp7 * 0.52;
    float bRise8 = -0.24 + tp8 * 0.48;

    vec4 b1 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(max(-innerHalf + 0.12, fillSpanX - 0.16) + bAdv.x, bRise1 + bAdv.y, 0.08), 0.018, keyLight);
    vec4 b2 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(max(-innerHalf + 0.10, fillSpanX - 0.36) + bAdv.x * 0.7, bRise2 + bAdv.y * 0.7, -0.06), 0.014, keyLight);
    vec4 b3 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(mix(-innerHalf + 0.10, fillSpanX, 0.45) + bAdv.x * 0.5, bRise3 + bAdv.y * 0.5, 0.04), 0.011, keyLight);
    vec4 b4 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(mix(-innerHalf + 0.10, fillSpanX, 0.72) + bAdv.x * 0.6, bRise4 + bAdv.y * 0.6, -0.09), 0.0095, keyLight);
    vec4 b5 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(mix(-innerHalf + 0.08, fillSpanX, 0.24) + bAdv.x * 0.4, bRise5 + bAdv.y * 0.4, 0.09), 0.0085, keyLight);
    vec4 b6 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(max(-innerHalf + 0.08, fillSpanX - 0.08) + bAdv.x * 0.8, bRise6 + bAdv.y * 0.8, -0.04), 0.0075, keyLight);
    vec4 b7 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(mix(-innerHalf + 0.09, fillSpanX, 0.58) + bAdv.x * 0.5, bRise7 + bAdv.y * 0.5, 0.07), 0.0070, keyLight);
    vec4 b8 = traceBubbleSphere3D(pWaterRef, rdWaterRef, vec3(mix(-innerHalf + 0.09, fillSpanX, 0.86) + bAdv.x * 0.7, bRise8 + bAdv.y * 0.7, -0.05), 0.0082, keyLight);

    float bVis = inWaterCov * (0.84 + fluidAeration * 0.52);
    float tf1 = smoothstep(0.0, 0.14, tp1) * invSmooth(0.84, 1.0, tp1);
    float tf2 = smoothstep(0.0, 0.14, tp2) * invSmooth(0.84, 1.0, tp2);
    float tf3 = smoothstep(0.0, 0.14, tp3) * invSmooth(0.84, 1.0, tp3);
    float tf4 = smoothstep(0.0, 0.14, tp4) * invSmooth(0.84, 1.0, tp4);
    float tf5 = smoothstep(0.0, 0.14, tp5) * invSmooth(0.84, 1.0, tp5);
    float tf6 = smoothstep(0.0, 0.14, tp6) * invSmooth(0.84, 1.0, tp6);
    float tf7 = smoothstep(0.0, 0.14, tp7) * invSmooth(0.84, 1.0, tp7);
    float tf8 = smoothstep(0.0, 0.14, tp8) * invSmooth(0.84, 1.0, tp8);
    beerWater = mix(beerWater, b1.rgb, b1.a * bVis * tf1 * 0.94);
    beerWater = mix(beerWater, b2.rgb, b2.a * bVis * tf2 * 0.88);
    beerWater = mix(beerWater, b3.rgb, b3.a * bVis * tf3 * 0.88);
    beerWater = mix(beerWater, b4.rgb, b4.a * bVis * tf4 * 0.80);
    beerWater = mix(beerWater, b5.rgb, b5.a * bVis * tf5 * 0.76);
    beerWater = mix(beerWater, b6.rgb, b6.a * bVis * tf6 * 0.74);
    beerWater = mix(beerWater, b7.rgb, b7.a * bVis * tf7 * 0.72);
    beerWater = mix(beerWater, b8.rgb, b8.a * bVis * tf8 * 0.78);
  }

  vec3 dryGlassCol = entersCavity ? exitCol * 0.25 : exitCol * 0.56;
  vec3 col = mix(dryGlassCol, beerWater, inWaterCov);

  // Fresnel externo cilíndrico + Borda refrativa fina + Dual GGX Estúdio
  float cosOuter = clamp(dot(nOuter, -rd), 0.0, 1.0);
  float r0Tank = mix(0.046, u_fresnelR0, inWaterCov);
  float fresnelOuter = r0Tank + (1.0 - r0Tank) * pow5(1.0 - cosOuter);
  float darkTankRim = smoothstep(0.62, 0.94, fresnelOuter);
  col *= 1.0 - darkTankRim * 0.36;
  vec3 outerRefl = sampleWaterStudioEnvironment(reflect(rd, nOuter), vec3(0.99, 0.995, 1.0));
  col = mix(col, outerRefl, clamp(fresnelOuter * u_esrIntensity * mix(0.58, 0.92, inWaterCov), 0.0, 0.95));

  vec3 fillLight = normalize(vec3(0.45, 0.42, 0.72));
  vec3 specKey = evaluateGGXSpecular(nOuter, -rd, keyLight, vec3(0.048), mix(0.014, 0.0017, inWaterCov));
  vec3 specFill = evaluateGGXSpecular(nOuter, -rd, fillLight, vec3(0.042), 0.011);
  col += specKey * vec3(6.4, 6.45, 6.5) + specFill * vec3(1.16, 1.20, 1.24);

  float wallRim = clamp(entersCavity ? max(0.0, 1.0 - dot(nOuter, nInner)) : 0.48, 0.0, 1.0);
  col += vec3(1.00, 1.01, 1.02) * wallRim * mix(0.32, 0.66, inWaterCov);

  float dewTank = valueNoise(vec2(pInner.x * 16.0, pInner.y * 22.0) + vec2(4.2, 1.9));
  float dewGlint = smoothstep(0.89, 0.97, dewTank) * (1.0 - inWaterCov);
  col += vec3(1.22, 1.25, 1.28) * dewGlint * 0.22;

  // Tipografia Líquida Submersa Refratada na Lente Cilíndrica 3D (alinhada com folga limpa do menisco)
  if (u_hasText > 0.5) {
    float frontNorm = (startFrontX + innerHalf) / max(2.0 * innerHalf, 0.1);
    float waterEndNorm = mix(fill, clamp(frontNorm, 0.0, 1.0), 0.28);
    float halfLabel = max(u_textDims.x * 0.5, 0.048);
    float edgeMargin = halfLabel + 0.034;
    float leadX = clamp(waterEndNorm + halfLabel + 0.032, edgeMargin, 1.0 - edgeMargin);
    float followX = clamp(waterEndNorm - halfLabel - 0.028, edgeMargin, 1.0 - edgeMargin);
    float followBlend = smoothstep(0.16, 0.26, fill);
    float textCenterX = mix(leadX, followX, followBlend);
    float textCenterY = 0.50 + (sampleTankWave(fill) * 0.026 + fluidVel.y * 0.015) * inWaterCov;

    float spriteW = max(u_textDims.y, 0.14);
    vec2 textPlaneUv = v_uv + vec2(clamp(rdCav.x, -0.35, 0.35) * 0.024, clamp(rdCav.y, -0.35, 0.35) * 0.009) * inWaterCov;
    vec2 spriteLocal = vec2((textPlaneUv.x - textCenterX) / spriteW + 0.5, (textPlaneUv.y - textCenterY) + 0.5);
    if (spriteLocal.x >= 0.0 && spriteLocal.x <= 1.0 && spriteLocal.y >= 0.0 && spriteLocal.y <= 1.0) {
      vec2 waveOffset = (clamp(rdCav.xy, vec2(-0.35), vec2(0.35)) * 0.014 + fluidVel * 0.007) * inWaterCov;
      vec2 lensScale = mix(vec2(1.0), vec2(0.94, 0.92), inWaterCov);
      vec2 refrTextUv = clamp(vec2(0.5) + (spriteLocal - vec2(0.5)) * lensScale + waveOffset, 0.002, 0.998);

      float waterlineZone = invSmooth(0.0, 0.026, abs(textPlaneUv.x - waterEndNorm)) * tankMeniscusRamp;
      float split = waterlineZone * 0.011 + inWaterCov * 0.0022;
      float txtR = texture(u_textTex, clamp(refrTextUv + vec2(split, 0.0), 0.002, 0.998)).a;
      float txtG = texture(u_textTex, refrTextUv).a;
      float txtB = texture(u_textTex, clamp(refrTextUv - vec2(split, 0.0), 0.002, 0.998)).a;
      vec3 txtRgb = vec3(txtR, txtG, txtB);
      float txtHalo = texture(u_textTex, clamp(refrTextUv + vec2(0.0, -0.02), 0.002, 0.998)).a;

      col *= 1.0 - txtHalo * 0.50;
      vec3 dryTxtCol = vec3(0.96, 0.98, 1.00);
      vec3 wetTxtCol = vec3(2.05, 2.12, 2.20) + vec3(0.68, 0.78, 0.88) * causticRgb.g * 0.44;
      vec3 meniscusSplitCol = vec3(2.22, 2.30, 2.38) * txtRgb;
      vec3 styledTxt = mix(dryTxtCol * txtG, wetTxtCol * txtRgb, inWaterCov);
      styledTxt = mix(styledTxt, meniscusSplitCol, waterlineZone * 0.78);
      float glyphCoverage = clamp(max(txtG, max(txtR, txtB)) * mix(0.96, 1.0, inWaterCov), 0.0, 1.0);
      col = mix(col, styledTxt + col * 0.06, glyphCoverage);
    }
  }

  float shapeMask = hitOuter ? 1.0 : invSmooth(0.0, aa * 2.0, edgeMissDist);
  float glassAlpha = clamp(mix(0.28, 0.95, inWaterCov) + fresnelOuter * 0.64 + length(specKey) * 0.18, 0.0, 0.98);
  float alpha = shapeMask * glassAlpha;
  fragColor = finalizeHdrOrSrgb(col, alpha, u_hdrOutput, gl_FragCoord.xy, u_time);
}
`;

// 2b. Liquid Glass Clothoid G3 Óptico + Soliton KdV Bore + Gotas 3D Escorrendo (Zero Linhas de Interação)
const CARD_DROPLETS_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform vec2 u_tilt;
uniform vec4 u_pointer;
uniform vec4 u_ripples[4];
uniform vec4 u_drops[12];
uniform vec2 u_dropVel[12];
uniform vec4 u_trails[12];
uniform vec4 u_obstacles[6];
uniform float u_obstacleWet[6];
uniform vec4 u_soliton;
uniform float u_hdrOutput;

${SHARED_OPTICS_GLSL}

float sdDropletCAH(vec2 p, vec2 center, float radius, float stretch, vec2 vel, float seed) {
  vec2 d = p - center;
  float speed = length(vel);
  float speedBoost = clamp(stretch + speed * 1.15, 0.0, 0.88);
  // Oscilação capilar sutil da tensão superficial ao escorregar
  float wobblePhase = u_time * (5.2 + speed * 4.0) + seed * 2.7;
  float wobble = sin(wobblePhase) * 0.055 * clamp(speed * 2.4 + stretch * 0.4, 0.0, 1.0);
  float isTail = smoothstep(-radius * 0.22, radius * 1.38, d.y);
  float yScale = mix(1.0 - speedBoost * 0.10 - wobble * 0.4, 1.0 + speedBoost * 0.96 + wobble * 0.5, isTail);
  float xTaper = mix(1.0 + speedBoost * 0.10 + wobble * 0.5, 1.0 - speedBoost * 0.27 - wobble * 0.4, isTail);
  vec2 warped = vec2(d.x / max(xTaper, 0.54), d.y / max(yScale, 0.64));
  return length(warped) - radius;
}

float evalProceduralBeadGrid(
  vec2 p,
  float aspect,
  float gridScale,
  float speedBase,
  float phaseAmp,
  float edgeMinThresh,
  float edgeMaxThresh,
  float radiusMin,
  float radiusVar,
  float clearedMask
) {
  float dGrid = 99.0;
  float colScaleX = gridScale * 1.12;
  float colX = floor(p.x * colScaleX);
  float colSeed = hash21(vec2(colX, gridScale * 0.37));

  // Movimento Stick-Slip não-linear (escorrega, desacelera por histerese e volta a escorregar)
  float driftSpeed = speedBase * (0.65 + 0.95 * colSeed);
  float tRaw = u_time * driftSpeed + colSeed * 6.2831853;
  float stickSlipY = tRaw + phaseAmp * sin(tRaw * 2.0 + colSeed * 4.1);

  vec2 shifted = vec2(p.x * colScaleX, p.y * gridScale + stickSlipY);
  vec2 cellId = floor(shifted);
  vec2 cellLocal = fract(shifted) - 0.5;

  // Meandro capilar sutil conforme a micro-gota contorna imperfeições do vidro
  float h1 = hash21(cellId + vec2(gridScale * 0.13, colSeed * 3.1));
  float h2 = hash21(cellId + vec2(19.7, 11.3));
  vec2 normPos = vec2(p.x / max(aspect, 0.1), p.y);
  float edgeBias = clamp(length((normPos - 0.5) * vec2(1.38, 1.78)), 0.0, 1.0);
  float thresh = mix(edgeMinThresh, edgeMaxThresh, smoothstep(0.24, 0.92, edgeBias));

  if (h1 > thresh && clearedMask < 0.88) {
    float meander = sin(p.y * 14.0 + h2 * 12.0 + u_time * 0.45) * 0.09;
    vec2 beadOffset = (vec2(h1, h2) - 0.5) * 0.36 + vec2(meander, 0.0);
    vec2 diff = cellLocal - beadOffset;
    // Leve assimetria CAH na micro-gota em movimento
    float pulse = 0.5 + 0.5 * cos(tRaw * 2.0 + colSeed * 4.1);
    float tailGate = smoothstep(-0.08, 0.18, diff.y);
    diff.y /= mix(0.95, 1.16 + 0.18 * pulse, tailGate);
    diff.x /= mix(1.06, 0.90, tailGate);
    float clearShrink = 1.0 - clearedMask * 0.92;
    float radius = (radiusMin + radiusVar * fract(h1 * 17.3)) * clearShrink;
    if (radius > 0.012) {
      dGrid = length(diff) / gridScale - radius / gridScale;
    }
  }
  return dGrid;
}

float evalCardDropField(vec2 p, float aspect, out float trailSheen, out float plateauSatellites) {
  float dField = 99.0;
  trailSheen = 0.0;
  plateauSatellites = 0.0;
  float clearedWake = 0.0;

  for (int i = 0; i < 12; i++) {
    vec4 drop = u_drops[i];
    if (drop.z <= 0.0005) continue;
    vec2 center = vec2(drop.x * aspect, 1.0 - drop.y);
    float maxReach = drop.z * 2.6 + 0.028;
    if (abs(p.x - center.x) < maxReach && abs(p.y - center.y) < maxReach) {
      float dDrop = sdDropletCAH(p, center, drop.z, drop.w, u_dropVel[i], float(i));
      dField = sminCubic(dField, dDrop, 0.0044);
    }

    // Limpa a condensação fina imediatamente atrás e dentro da gota em movimento
    float bodyClear = invSmooth(drop.z * 0.8, drop.z * 2.1, length(p - center));
    clearedWake = max(clearedWake, bodyClear);

    // Quebra discreta de Plateau-Rayleigh em micro-pérolas + limpeza física da névoa no rastro
    vec4 tr = u_trails[i];
    if (tr.w > 0.05) {
      float yTop = 1.0 - tr.y;
      float yBot = center.y;
      float yMin = min(yTop, yBot);
      float yMax = max(yTop, yBot);
      if (yMax - yMin > 0.020 && p.y >= yMin - 0.01 && p.y <= yMax + 0.01) {
        float tSpan = clamp((yMax - p.y) / max(yMax - yMin, 0.01), 0.0, 1.0);
        float startX = tr.x * aspect;
        float curveX = mix(startX, center.x, smoothstep(0.0, 1.0, tSpan)) + tr.z * aspect * sin(tSpan * 3.14159265);
        float dx = abs(p.x - curveX);
        if (dx < drop.z * 1.45 + 0.014) {
          float inSpan = smoothstep(yMin, yMin + 0.015, p.y) * invSmooth(yMax - 0.015, yMax, p.y);
          float wakeClear = invSmooth(drop.z * 0.45, drop.z * 1.35, dx) * inSpan * clamp(tr.w * 1.25, 0.0, 1.0);
          clearedWake = max(clearedWake, wakeClear);

          float breakNoise = smoothstep(0.45, 0.85, valueNoise(vec2(p.y * 48.0 + float(i) * 3.7, float(i))));
          float cellIdx = floor(p.y * 22.0 + float(i) * 0.43);
          float jitterX = (hash21(vec2(cellIdx, float(i))) - 0.5) * drop.z * 0.44;
          float cellY = fract(p.y * 22.0 + float(i) * 0.43) / 22.0 - 0.0227;
          float satDist = length(vec2(p.x - (curveX + jitterX), cellY));
          float satR = drop.z * (0.16 + 0.14 * hash21(vec2(cellIdx + 4.1, float(i))));
          float pearlGate = step(0.30, hash21(vec2(cellIdx + 11.3, float(i))));
          float sat = invSmooth(satR * 0.60, satR * 1.15, satDist) * inSpan * tr.w * pearlGate;
          plateauSatellites = max(plateauSatellites, sat);
          dField = sminCubic(dField, satDist - satR * 0.85 + (1.0 - inSpan * tr.w * pearlGate) * 0.45, 0.0020);
          trailSheen = max(trailSheen, invSmooth(drop.z * 0.10, drop.z * 0.90, dx) * inSpan * tr.w * breakNoise * 0.24);
        }
      }
    }
  }

  // Camada A: micro-gotas de condensação médias escorrendo continuamente em stick-slip
  float dCondMed = evalProceduralBeadGrid(
    p,
    aspect,
    13.5,
    0.052,
    0.42,
    0.86,
    0.58,
    0.042,
    0.052,
    clearedWake
  );
  dField = sminCubic(dField, dCondMed, 0.0018);

  // Camada B: orvalho fino deslizando lentamente e limpo na passagem das gotas maiores
  float dCondFine = evalProceduralBeadGrid(
    p,
    aspect,
    27.0,
    0.024,
    0.34,
    0.84,
    0.50,
    0.040,
    0.048,
    clearedWake
  );
  dField = min(dField, dCondFine);

  return dField;
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 p = vec2(v_uv.x * aspect, v_uv.y);

  vec3 viewDir = normalize(vec3(u_tilt.x * 0.16, -0.07 + u_tilt.y * 0.11, 0.985));
  vec3 keyLight = normalize(vec3(-0.36 + u_tilt.x * 0.46, 0.86 - u_tilt.y * 0.18, 0.38));
  vec3 fillLight = normalize(vec3(0.54 - u_tilt.x * 0.24, 0.42, 0.62));

  // -------------------------------------------------------------------------
  // Camada 1: Casca Clothoid G3 Liquid Glass (Curvatura Contínua + Sellmeier + KdV Soliton Bore)
  // -------------------------------------------------------------------------
  vec2 cardCenter = vec2(aspect * 0.5, 0.5);
  vec2 cardHalf = vec2(aspect * 0.5, 0.5);
  float cornerR = min(0.15, min(cardHalf.x, cardHalf.y) * 0.36);
  float cardD = sdClothoidCard(p - cardCenter, cardHalf, cornerR);
  float bevelBand = invSmooth(0.003, 0.088, -cardD);

  // Ondas capilares orgânicas suaves do toque/arraste (sem anéis/linhas duras)
  vec2 rippleGrad = vec2(0.0);
  float rippleCaustic = 0.0;
  for (int rIdx = 0; rIdx < 4; rIdx++) {
    vec4 rp = u_ripples[rIdx];
    if (rp.z <= 0.0 || rp.z > 1.75 || rp.w <= 0.001) continue;
    vec2 rCenter = vec2(rp.x * aspect, 1.0 - rp.y);
    vec2 diff = p - rCenter;
    float rDist = length(diff);
    float waveFront = rp.z * 0.52;
    float ringEnv = exp(-sq((rDist - waveFront) * 9.0)) * exp(-rp.z * 2.4) * rp.w;
    float phase = (rDist - waveFront) * 44.0;
    vec2 rDir = diff / max(rDist, 1e-4);
    rippleGrad += rDir * cos(phase) * ringEnv * 0.24;
    rippleCaustic += max(0.0, sin(phase)) * ringEnv * 0.55;
  }

  // Soliton Bore KdV disparado na abertura da barra/modal ou ao registrar água
  vec2 solCenter = vec2(u_soliton.x * aspect, 1.0 - u_soliton.y);
  vec2 solDiff = p - solCenter;
  float solDist = length(solDiff);
  vec2 solEval = evalKdVSoliton(solDist, u_soliton.z, u_soliton.w, 12.5, 1.28);
  vec2 solDir = solDiff / max(solDist, 1e-4);
  rippleGrad += solDir * solEval.y * 0.72;
  float solitonCrest = clamp(solEval.x * 16.0, 0.0, 1.6);

  // Deformação viscosa suave do campo de vidro sob o ponteiro predito (Kalman)
  vec2 ptrPos = vec2(u_pointer.x * aspect, 1.0 - u_pointer.y);
  vec2 ptrDiff = p - ptrPos;
  float ptrDist = length(ptrDiff);
  float ptrEnv = u_pointer.z * exp(-sq(ptrDist * 3.8));
  vec2 ptrLensGrad = ptrDiff * ptrEnv * (0.28 + u_pointer.w * 0.35);

  // Resposta úmida orgânica difusa próxima aos componentes tocados (sem linha horizontal)
  float wetAura = 0.0;
  for (int k = 0; k < 6; k++) {
    vec4 ob = u_obstacles[k];
    float wet = u_obstacleWet[k];
    if (ob.z <= ob.x || wet <= 0.01) continue;
    vec2 obCenter = vec2((ob.x + ob.z) * 0.5 * aspect, 1.0 - (ob.y + ob.w) * 0.5);
    vec2 obHalf = vec2(max(0.02, (ob.z - ob.x) * 0.5 * aspect), max(0.02, (ob.w - ob.y) * 0.5));
    float dOb = sdClothoidCard(p - obCenter, obHalf, 0.025);
    wetAura = max(wetAura, exp(-sq(max(dOb, 0.0) * 28.0)) * wet * 0.16);
  }

  vec3 cardGlassCol = vec3(0.0);
  float glassOverlayAlpha = 0.0;
  float bevelActivity = bevelBand + rippleCaustic + solitonCrest + ptrEnv + wetAura;
  if (bevelActivity > 0.002) {
    vec2 bevelEps = vec2(0.0035, 0.0);
    vec2 cardGrad = vec2(
      sdClothoidCard(p - cardCenter + bevelEps.xy, cardHalf, cornerR) -
        sdClothoidCard(p - cardCenter - bevelEps.xy, cardHalf, cornerR),
      sdClothoidCard(p - cardCenter + bevelEps.yx, cardHalf, cornerR) -
        sdClothoidCard(p - cardCenter - bevelEps.yx, cardHalf, cornerR)
    ) / (2.0 * bevelEps.x);
    float bevelSlope = safePow(bevelBand, 1.85) * 0.56;

    vec3 glassPlateN = normalize(vec3(
      cardGrad.x * bevelSlope - rippleGrad.x - ptrLensGrad.x,
      cardGrad.y * bevelSlope - rippleGrad.y - ptrLensGrad.y,
      sqrt(max(0.28, 1.0 - bevelSlope * bevelSlope * 0.62))
    ));

    // Dispersão cromática de Sellmeier no chanfro Clotoide do vidro líquido (com proteção TIR por canal)
    vec3 gReflDir = reflect(-viewDir, glassPlateN);
    vec3 gRefrR = refract(-viewDir, glassPlateN, 1.0 / evalSellmeierGlassIOR(0.650));
    vec3 gRefrG = refract(-viewDir, glassPlateN, 1.0 / evalSellmeierGlassIOR(0.532));
    vec3 gRefrB = refract(-viewDir, glassPlateN, 1.0 / evalSellmeierGlassIOR(0.455));
    vec3 prismR = sampleWaterStudioEnvironment(dot(gRefrR, gRefrR) > 0.001 ? gRefrR : gReflDir, vec3(0.76, 0.96, 1.0));
    vec3 prismG = sampleWaterStudioEnvironment(dot(gRefrG, gRefrG) > 0.001 ? gRefrG : gReflDir, vec3(0.76, 0.96, 1.0));
    vec3 prismB = sampleWaterStudioEnvironment(dot(gRefrB, gRefrB) > 0.001 ? gRefrB : gReflDir, vec3(0.76, 0.96, 1.0));
    vec3 glassRefr = vec3(prismR.r, prismG.g, prismB.b);

    float gCos = clamp(dot(glassPlateN, viewDir), 0.0, 1.0);
    float glassFresnel = 0.036 + 0.964 * pow5(1.0 - gCos);
    vec3 glassRefl = sampleWaterStudioEnvironment(gReflDir, vec3(0.84, 0.98, 1.0));
    vec3 glassThinFilm = evalThinFilmIridescence(gCos, 420.0 + bevelBand * 220.0 + rippleCaustic * 120.0 + solitonCrest * 180.0);
    vec3 glassSpec = evaluateGGXSpecular(glassPlateN, viewDir, keyLight, vec3(0.044), 0.016);

    float ptrSheen = ptrEnv * 0.14;

    cardGlassCol = mix(glassRefr * 0.24, glassRefl * 0.72, clamp(glassFresnel * 1.35, 0.0, 0.90)) * (bevelBand * 0.88 + 0.04 + solitonCrest * 0.55);
    cardGlassCol += glassSpec * vec3(2.8, 3.05, 3.25) * (0.16 + bevelBand * 0.78 + solitonCrest * 0.62);
    cardGlassCol += glassThinFilm * (bevelBand * 0.12 + rippleCaustic * 0.16 + solitonCrest * 0.24);
    cardGlassCol += vec3(0.70, 1.38, 1.64) * (rippleCaustic * 0.52 + ptrSheen + wetAura + solitonCrest * 0.65);

    glassOverlayAlpha = clamp(
      bevelBand * 0.24 +
      rippleCaustic * 0.16 +
      solitonCrest * 0.22 +
      ptrSheen * 0.14 +
      wetAura * 0.22,
      0.0,
      0.46
    );
  }

  // -------------------------------------------------------------------------
  // Camada 2: Gotas 3D Escorrendo (Calota Esférica + CAH + TIR + Lente Sellmeier)
  // -------------------------------------------------------------------------
  float trailSheen = 0.0;
  float plateauSat = 0.0;
  float d = evalCardDropField(p, aspect, trailSheen, plateauSat);

  vec2 lightOffset = vec2(0.0022, -0.0032);
  float dummySheen = 0.0;
  float dummySat = 0.0;
  float dShadow = evalCardDropField(p - lightOffset, aspect, dummySheen, dummySat);
  float castShadow = invSmooth(-0.0008, 0.0046, dShadow) * smoothstep(-0.0008, 0.0018, d);
  float causticSpot = invSmooth(0.0, 0.0025, abs(dShadow + 0.0011)) * smoothstep(-0.0005, 0.0020, d);

  if (d > 0.008 && trailSheen < 0.01 && castShadow < 0.01 && causticSpot < 0.01) {
    fragColor = finalizeHdrOrSrgb(cardGlassCol, glassOverlayAlpha, u_hdrOutput, gl_FragCoord.xy, u_time);
    return;
  }

  float aa = 1.15 / max(min(u_resolution.x, u_resolution.y), 1.0);
  vec2 eps = vec2(0.0011, 0.0);
  float t0 = 0.0;
  float s0 = 0.0;
  vec2 grad = vec2(
    evalCardDropField(p + eps.xy, aspect, t0, s0) - d,
    evalCardDropField(p + eps.yx, aspect, t0, s0) - d
  ) / eps.x;
  float gradLen = max(length(grad), 1e-4);
  vec2 n2 = grad / gradLen;

  // Perfil 3D real de calota esférica fina + menisco de contato nítido
  float depthInside = clamp(-d / 0.0056, 0.0, 1.0);
  float nz = sqrt(max(0.03, 1.0 - sq(1.0 - depthInside)));
  vec3 normal = normalize(vec3(n2 * (1.0 - nz * 0.42), nz));

  vec3 refrR = refract(-viewDir, normal, 1.0 / evalSellmeierWaterIOR(0.650));
  vec3 refrG = refract(-viewDir, normal, 1.0 / evalSellmeierWaterIOR(0.532));
  vec3 refrB = refract(-viewDir, normal, 1.0 / evalSellmeierWaterIOR(0.455));

  vec3 dropReflDir = reflect(-viewDir, normal);
  vec3 reflEnv = sampleWaterStudioEnvironment(dropReflDir, vec3(0.86, 0.99, 1.0));
  vec3 refractedLens;
  if (dot(refrG, refrG) < 0.001) {
    refractedLens = reflEnv * 0.96;
  } else {
    vec3 dirR = dot(refrR, refrR) > 0.001 ? vec3(refrR.x, refrR.y, abs(refrR.z)) : dropReflDir;
    vec3 dirG = vec3(refrG.x, refrG.y, abs(refrG.z));
    vec3 dirB = dot(refrB, refrB) > 0.001 ? vec3(refrB.x, refrB.y, abs(refrB.z)) : dropReflDir;
    vec3 invEnvR = sampleWaterStudioEnvironment(dirR, vec3(0.78, 0.96, 1.0));
    vec3 invEnvG = sampleWaterStudioEnvironment(dirG, vec3(0.78, 0.96, 1.0));
    vec3 invEnvB = sampleWaterStudioEnvironment(dirB, vec3(0.78, 0.96, 1.0));
    refractedLens = vec3(invEnvR.r, invEnvG.g, invEnvB.b) * 0.58;
  }

  float cosTheta = clamp(dot(normal, viewDir), 0.0, 1.0);
  float fresnel = 0.020 + 0.980 * pow5(1.0 - cosTheta);
  float tirRim = invSmooth(0.14, 0.52, cosTheta);
  vec3 specKey = evaluateGGXSpecular(normal, viewDir, keyLight, vec3(0.026), 0.0026);
  vec3 specFill = evaluateGGXSpecular(normal, viewDir, fillLight, vec3(0.022), 0.014);
  vec3 thinFilm = evalThinFilmIridescence(cosTheta, 360.0 + depthInside * 240.0);

  vec3 dropCol = mix(refractedLens, reflEnv, clamp(fresnel * 1.15 + tirRim * 0.48, 0.0, 0.96));
  dropCol += specKey * vec3(5.4, 5.6, 5.8) + specFill * vec3(0.95, 1.15, 1.25);
  dropCol += thinFilm * (tirRim * 0.14 + trailSheen * 0.12);

  // Crescente cáustico interno no lado oposto à luz
  float innerCaustic = smoothstep(0.0, 0.85, -dot(n2, keyLight.xy)) * invSmooth(0.0, 0.0026, abs(d + 0.0012));
  dropCol += vec3(0.94, 1.08, 1.16) * innerCaustic * 0.96;

  float dropMask = invSmooth(-aa, aa, d);
  float trailRender = trailSheen * (1.0 - dropMask) * 0.34;

  vec3 shadowCol = vec3(0.003, 0.009, 0.014);
  vec3 causticCol = vec3(1.10, 1.38, 1.50);
  vec3 trailCol = vec3(0.45, 0.84, 0.98) + thinFilm * 0.18;

  float wGlass = glassOverlayAlpha * (1.0 - dropMask);
  float wDrop = dropMask * mix(0.76, 0.97, fresnel + tirRim * 0.45);
  float wTrail = trailRender * 0.38;
  float wShadow = castShadow * (1.0 - dropMask) * 0.42;
  float wCaustic = causticSpot * (1.0 - dropMask) * 0.44;
  float alpha = clamp(wGlass + wDrop + wTrail + wShadow + wCaustic, 0.0, 0.98);
  vec3 linearOut = (
    cardGlassCol * wGlass +
    dropCol * wDrop +
    trailCol * wTrail +
    shadowCol * wShadow +
    causticCol * wCaustic
  ) / max(alpha, 1e-4);

  fragColor = finalizeHdrOrSrgb(linearOut, alpha, u_hdrOutput, gl_FragCoord.xy, u_time);
}
`;

// 2c. Superfície Liquid Glass Clothoid G3 + Soliton KdV Reveal + Sellmeier RGB (sem gotas)
const LIQUID_GLASS_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_tilt;
uniform vec4 u_pointer;
uniform vec4 u_ripples[4];
uniform vec4 u_soliton;
uniform float u_hdrOutput;

${SHARED_OPTICS_GLSL}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 p = vec2(v_uv.x * aspect, v_uv.y);

  vec3 viewDir = normalize(vec3(u_tilt.x * 0.14, -0.06 + u_tilt.y * 0.10, 0.988));
  vec3 keyLight = normalize(vec3(-0.34 + u_tilt.x * 0.40, 0.86 - u_tilt.y * 0.16, 0.38));

  vec2 panelCenter = vec2(aspect * 0.5, 0.5);
  vec2 panelHalf = vec2(aspect * 0.5, 0.5);
  float cornerR = min(0.14, min(panelHalf.x, panelHalf.y) * 0.32);
  float panelD = sdClothoidCard(p - panelCenter, panelHalf, cornerR);

  vec2 bevelEps = vec2(0.0035, 0.0);
  vec2 panelGrad = vec2(
    sdClothoidCard(p - panelCenter + bevelEps.xy, panelHalf, cornerR) -
      sdClothoidCard(p - panelCenter - bevelEps.xy, panelHalf, cornerR),
    sdClothoidCard(p - panelCenter + bevelEps.yx, panelHalf, cornerR) -
      sdClothoidCard(p - panelCenter - bevelEps.yx, panelHalf, cornerR)
  ) / (2.0 * bevelEps.x);
  float bevelBand = invSmooth(0.002, 0.072, -panelD);
  float bevelSlope = safePow(bevelBand, 1.85) * 0.58;

  // Ondas capilares orgânicas do toque sem gotas + Soliton KdV na entrada do modal
  vec2 rippleGrad = vec2(0.0);
  float rippleCaustic = 0.0;
  for (int rIdx = 0; rIdx < 4; rIdx++) {
    vec4 rp = u_ripples[rIdx];
    if (rp.z <= 0.0 || rp.z > 1.75 || rp.w <= 0.001) continue;
    vec2 rCenter = vec2(rp.x * aspect, 1.0 - rp.y);
    vec2 diff = p - rCenter;
    float rDist = length(diff);
    float waveFront = rp.z * 0.50;
    float ringEnv = exp(-sq((rDist - waveFront) * 9.5)) * exp(-rp.z * 2.5) * rp.w;
    float phase = (rDist - waveFront) * 42.0;
    vec2 rDir = diff / max(rDist, 1e-4);
    rippleGrad += rDir * cos(phase) * ringEnv * 0.22;
    rippleCaustic += max(0.0, sin(phase)) * ringEnv * 0.50;
  }

  vec2 solCenter = vec2(u_soliton.x * aspect, 1.0 - u_soliton.y);
  vec2 solDiff = p - solCenter;
  float solDist = length(solDiff);
  vec2 solEval = evalKdVSoliton(solDist, u_soliton.z, u_soliton.w, 8.8, 1.48);
  vec2 solDir = solDiff / max(solDist, 1e-4);
  rippleGrad += solDir * solEval.y * 0.85;
  float solitonCrest = clamp(solEval.x * 20.0, 0.0, 1.85);

  vec2 ptrPos = vec2(u_pointer.x * aspect, 1.0 - u_pointer.y);
  vec2 ptrDiff = p - ptrPos;
  float ptrDist = length(ptrDiff);
  float ptrEnv = u_pointer.z * exp(-sq(ptrDist * 3.6));
  vec2 ptrLensGrad = ptrDiff * ptrEnv * (0.26 + u_pointer.w * 0.32);

  vec3 glassPlateN = normalize(vec3(
    panelGrad.x * bevelSlope - rippleGrad.x - ptrLensGrad.x,
    panelGrad.y * bevelSlope - rippleGrad.y - ptrLensGrad.y,
    sqrt(max(0.28, 1.0 - bevelSlope * bevelSlope * 0.58))
  ));

  vec3 gReflDir = reflect(-viewDir, glassPlateN);
  vec3 gRefrR = refract(-viewDir, glassPlateN, 1.0 / evalSellmeierGlassIOR(0.650));
  vec3 gRefrG = refract(-viewDir, glassPlateN, 1.0 / evalSellmeierGlassIOR(0.532));
  vec3 gRefrB = refract(-viewDir, glassPlateN, 1.0 / evalSellmeierGlassIOR(0.455));
  vec3 prismR = sampleWaterStudioEnvironment(dot(gRefrR, gRefrR) > 0.001 ? gRefrR : gReflDir, vec3(0.76, 0.96, 1.0));
  vec3 prismG = sampleWaterStudioEnvironment(dot(gRefrG, gRefrG) > 0.001 ? gRefrG : gReflDir, vec3(0.76, 0.96, 1.0));
  vec3 prismB = sampleWaterStudioEnvironment(dot(gRefrB, gRefrB) > 0.001 ? gRefrB : gReflDir, vec3(0.76, 0.96, 1.0));
  vec3 glassRefr = vec3(prismR.r, prismG.g, prismB.b);

  float gCos = clamp(dot(glassPlateN, viewDir), 0.0, 1.0);
  float glassFresnel = 0.036 + 0.964 * pow5(1.0 - gCos);
  vec3 glassRefl = sampleWaterStudioEnvironment(gReflDir, vec3(0.84, 0.98, 1.0));
  vec3 glassThinFilm = evalThinFilmIridescence(gCos, 420.0 + bevelBand * 220.0 + rippleCaustic * 130.0 + solitonCrest * 210.0);
  vec3 glassSpec = evaluateGGXSpecular(glassPlateN, viewDir, keyLight, vec3(0.044), 0.015);

  vec3 col = mix(glassRefr * 0.28, glassRefl * 0.76, clamp(glassFresnel * 1.38, 0.0, 0.90)) * (bevelBand * 0.92 + 0.04 + solitonCrest * 0.62);
  col += glassSpec * vec3(2.9, 3.2, 3.4) * (0.16 + bevelBand * 0.84 + solitonCrest * 0.72);
  col += glassThinFilm * (bevelBand * 0.14 + rippleCaustic * 0.18 + solitonCrest * 0.28);
  col += vec3(0.76, 1.48, 1.76) * (rippleCaustic * 0.54 + ptrEnv * 0.14 + solitonCrest * 0.72);

  float alpha = clamp(bevelBand * 0.28 + rippleCaustic * 0.18 + solitonCrest * 0.28 + ptrEnv * 0.14, 0.0, 0.48);
  fragColor = finalizeHdrOrSrgb(col, alpha, u_hdrOutput, gl_FragCoord.xy, u_time);
}
`;

// 2d. Post-pass HDR (RGBA16F -> Khronos PBR Neutral / AgX + Blue-Noise LUT Dithering -> sRGB)
const HDR_TONEMAP_FRAGMENT_300 = `#version 300 es
precision highp float;

out vec4 fragColor;

uniform sampler2D u_hdrTex;
uniform sampler2D u_blueNoiseTex;
uniform float u_time;

vec3 hdrPbrNeutralAgx(vec3 color) {
  vec3 c = max(color, vec3(0.0));
  const float startCompression = 0.76;
  const float desaturation = 0.16;
  float x = min(c.r, min(c.g, c.b));
  float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
  c -= offset;
  float peak = max(c.r, max(c.g, c.b));
  if (peak >= startCompression) {
    float d = 1.0 - startCompression;
    float newPeak = 1.0 - (d * d) / (peak + d - startCompression);
    c *= newPeak / max(peak, 1e-5);
    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    c = mix(c, vec3(newPeak), g);
  }
  return clamp(c, 0.0, 1.0);
}

vec3 hdrLinearToSrgb(vec3 c) {
  vec3 linear = max(c, vec3(0.0));
  vec3 low = linear * 12.92;
  vec3 high = 1.055 * pow(max(linear, vec3(0.0031308)), vec3(1.0 / 2.4)) - 0.055;
  return mix(high, low, lessThanEqual(linear, vec3(0.0031308)));
}

void main() {
  ivec2 maxCoord = max(textureSize(u_hdrTex, 0) - ivec2(1), ivec2(0));
  ivec2 px = clamp(ivec2(gl_FragCoord.xy), ivec2(0), maxCoord);
  vec4 hdr = texelFetch(u_hdrTex, px, 0);
  float alpha = clamp(hdr.a, 0.0, 1.0);
  if (alpha <= 0.0005) {
    fragColor = vec4(0.0);
    return;
  }

  // Bloom óptico seletivo apenas acima do limiar HDR (>1.30): halação real em reflexos de cristal, raios e mercúrio sem embaçar bordas
  vec3 bloom = vec3(0.0);
  for (int oy = -1; oy <= 1; oy++) {
    for (int ox = -1; ox <= 1; ox++) {
      if (ox == 0 && oy == 0) continue;
      ivec2 sp = clamp(px + ivec2(ox * 2, oy * 2), ivec2(0), maxCoord);
      vec4 tap = texelFetch(u_hdrTex, sp, 0);
      float wDist = (ox == 0 || oy == 0) ? 1.0 : 0.62;
      float peak = max(tap.r, max(tap.g, tap.b));
      vec3 bright = max(tap.rgb - vec3(1.28), vec3(0.0)) * (tap.a / max(peak, 1e-4) * min(peak, 4.5));
      bloom += bright * wDist;
    }
  }
  vec3 hdrFinal = hdr.rgb + bloom * 0.036;

  vec3 srgb = hdrLinearToSrgb(hdrPbrNeutralAgx(hdrFinal));
  // Reprojeção temporal leve do deslocamento R2 no tile 64x64 de Blue-Noise
  ivec2 shift = ivec2(int(floor(fract(u_time * 0.6180339) * 64.0)), int(floor(fract(u_time * 0.3819660) * 64.0)));
  float bn = texelFetch(u_blueNoiseTex, (px + shift) & ivec2(63), 0).r - 0.5;
  srgb = clamp(srgb + (bn / 255.0) * smoothstep(0.002, 0.03, alpha), 0.0, 1.0);
  fragColor = vec4(srgb * alpha, alpha);
}
`;

// Helpers ópticos e de turbulência 3D da cápsula de energia (compilado isoladamente das rotinas de água/metal)
const ENERGY_NOISE_GLSL = `
float sq(float x) {
  return x * x;
}
float pow5(float x) {
  float x2 = x * x;
  return x2 * x2 * x;
}
float safePow(float x, float y) {
  return pow(max(x, 1e-5), y);
}
float invSmooth(float lo, float hi, float x) {
  return 1.0 - smoothstep(lo, hi, x);
}
float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}
float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
float fbm3(vec2 st) {
  float val = 0.0;
  float amp = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 3; i++) {
    val += amp * valueNoise(st);
    st = rot * st * 2.02 + vec2(1.7, 3.1);
    amp *= 0.5;
  }
  return val;
}
float energyHash31(vec3 p) {
  p = fract(p * vec3(0.1031, 0.1030, 0.0973));
  p += dot(p, p.yxz + 33.33);
  return fract((p.x + p.y) * p.z);
}
float energyNoise3D(vec3 x) {
  vec3 i = floor(x);
  vec3 f = fract(x);
  vec3 u = f * f * (3.0 - 2.0 * f);
  float n000 = energyHash31(i + vec3(0.0, 0.0, 0.0));
  float n100 = energyHash31(i + vec3(1.0, 0.0, 0.0));
  float n010 = energyHash31(i + vec3(0.0, 1.0, 0.0));
  float n110 = energyHash31(i + vec3(1.0, 1.0, 0.0));
  float n001 = energyHash31(i + vec3(0.0, 0.0, 1.0));
  float n101 = energyHash31(i + vec3(1.0, 0.0, 1.0));
  float n011 = energyHash31(i + vec3(0.0, 1.0, 1.0));
  float n111 = energyHash31(i + vec3(1.0, 1.0, 1.0));
  float nx00 = mix(n000, n100, u.x);
  float nx10 = mix(n010, n110, u.x);
  float nx01 = mix(n001, n101, u.x);
  float nx11 = mix(n011, n111, u.x);
  return mix(mix(nx00, nx10, u.y), mix(nx01, nx11, u.y), u.z);
}
float energyFbm3D(vec3 p) {
  float val = 0.0;
  float amp = 0.52;
  for (int i = 0; i < 3; i++) {
    val += amp * energyNoise3D(p);
    p = vec3(
      p.x * 1.62 - p.z * 1.22 + 2.3,
      p.y * 1.98 + 1.7,
      p.x * 1.22 + p.z * 1.62 - 3.1
    );
    amp *= 0.48;
  }
  return val;
}
vec3 energyCurl3D(vec3 p) {
  const float e = 0.085;
  float py1 = energyNoise3D(p + vec3(0.0, e, 0.0));
  float py0 = energyNoise3D(p - vec3(0.0, e, 0.0));
  float pz1 = energyNoise3D(p + vec3(0.0, 0.0, e));
  float pz0 = energyNoise3D(p - vec3(0.0, 0.0, e));
  float px1 = energyNoise3D(p + vec3(e, 0.0, 0.0));
  float px0 = energyNoise3D(p - vec3(e, 0.0, 0.0));
  float qy1 = energyNoise3D(p + vec3(11.4, e + 5.2, 3.7));
  float qy0 = energyNoise3D(p + vec3(11.4, -e + 5.2, 3.7));
  float qz1 = energyNoise3D(p + vec3(11.4, 5.2, e + 3.7));
  float qz0 = energyNoise3D(p + vec3(11.4, 5.2, -e + 3.7));
  float qx1 = energyNoise3D(p + vec3(e + 11.4, 5.2, 3.7));
  float qx0 = energyNoise3D(p + vec3(-e + 11.4, 5.2, 3.7));
  float inv2e = 0.5 / e;
  return vec3(
    (qz1 - qz0 - (py1 - py0)) * inv2e,
    (px1 - px0 - (pz1 - pz0)) * inv2e,
    (qy1 - qy0 - (qx1 - qx0)) * inv2e
  );
}
// Deslocamento angular dobrado (ridged-FBM stepped-leader) para vértices secos de descarga elétrica real
float energyRidgedLeader(float xCoord, float stepTime, float seed) {
  float v = 0.0;
  float amp = 0.58;
  float freq = 3.2;
  for (int i = 0; i < 4; i++) {
    float n = energyNoise3D(vec3(xCoord * freq - stepTime * (1.35 + float(i) * 0.50), seed + float(i) * 7.3, stepTime * 0.92));
    float ridge = (1.0 - abs(n * 2.0 - 1.0)) * 2.0 - 1.0;
    v += ridge * amp;
    freq *= 2.24;
    amp *= 0.48;
  }
  return v;
}
vec2 energyJaggedPath3D(float xCoord, float t, float seed) {
  float burstStep = floor(t * 18.0);
  float snap = mix(burstStep, t * 18.0, 0.24);
  // Quebras lineares por segmento discreto tipo stepped-leader real de alta tensão
  float segX = floor(xCoord * 5.6 + seed * 0.3) / 5.6;
  float nextSegX = segX + (1.0 / 5.6);
  float segT = fract(xCoord * 5.6 + seed * 0.3);
  float ry0 = energyRidgedLeader(segX, snap, seed);
  float ry1 = energyRidgedLeader(nextSegX, snap, seed);
  float rz0 = energyRidgedLeader(segX, snap + 3.7, seed + 19.4);
  float rz1 = energyRidgedLeader(nextSegX, snap + 3.7, seed + 19.4);
  float ry = mix(ry0, ry1, segT);
  float rz = mix(rz0, rz1, segT);
  float microJitterY = abs(fract(xCoord * 6.8 - snap * 0.72 + seed) - 0.5) * 2.0 - 0.5;
  float microJitterZ = abs(fract(xCoord * 6.2 + snap * 0.58 + seed * 1.7) - 0.5) * 2.0 - 0.5;
  return vec2(ry * 0.22 + microJitterY * 0.048, rz * 0.19 + microJitterZ * 0.042);
}
float energySoftboxRect(vec3 direction, vec3 centerDirection, vec2 halfSize, float softness) {
  vec3 center = normalize(centerDirection);
  vec3 referenceUp = abs(center.y) > 0.94 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
  vec3 axisU = normalize(cross(referenceUp, center));
  vec3 axisV = normalize(cross(center, axisU));
  float forward = max(dot(direction, center), 1e-3);
  vec2 panelUv = vec2(dot(direction, axisU), dot(direction, axisV)) / forward;
  float edge = max(abs(panelUv.x) / max(halfSize.x, 1e-3), abs(panelUv.y) / max(halfSize.y, 1e-3));
  return 1.0 - smoothstep(1.0 - softness, 1.0 + softness, edge);
}
float energySellmeierGlassIOR(float lambdaMicron) {
  float l2 = lambdaMicron * lambdaMicron;
  float n2 = 1.0
    + (1.0396121 * l2) / max(l2 - 0.0060007, 1e-4)
    + (0.2317923 * l2) / max(l2 - 0.0200179, 1e-4)
    + (1.0104695 * l2) / max(l2 - 103.56065, -200.0);
  return sqrt(max(n2, 1.0));
}
vec3 energyThinFilm(float cosTheta, float filmThicknessNm) {
  float opd = 2.0 * 1.42 * filmThicknessNm * clamp(cosTheta, 0.08, 1.0);
  vec3 wavelengths = vec3(650.0, 532.0, 460.0);
  vec3 phase = (6.2831853 * opd) / wavelengths;
  return 0.5 + 0.5 * cos(phase + vec3(0.0, 0.45, 0.90));
}
vec3 energyToneAgx(vec3 color) {
  vec3 c = max(color, vec3(0.0));
  const float startCompression = 0.76;
  const float desaturation = 0.16;
  float x = min(c.r, min(c.g, c.b));
  float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
  c -= offset;
  float peak = max(c.r, max(c.g, c.b));
  if (peak >= startCompression) {
    float d = 1.0 - startCompression;
    float newPeak = 1.0 - (d * d) / (peak + d - startCompression);
    c *= newPeak / max(peak, 1e-5);
    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    c = mix(c, vec3(newPeak), g);
  }
  return clamp(c, 0.0, 1.0);
}
vec3 energyToSrgb(vec3 c) {
  vec3 clamped = max(c, vec3(0.0));
  vec3 lo = clamped * 12.92;
  vec3 hi = 1.055 * pow(max(clamped, vec3(0.0031308)), vec3(1.0 / 2.4)) - 0.055;
  return mix(lo, hi, step(vec3(0.0031308), clamped));
}
float energyBlueNoiseHash(vec2 fragCoord, float timeSeed) {
  vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
  float ig = fract(magic.z * fract(dot(fragCoord + vec2(fract(timeSeed) * 19.0), magic.xy)));
  return ig - 0.5;
}
vec4 energyFinalizeHdrOrSrgb(vec3 linearHdr, float alpha, float hdrOutput, vec2 fragCoord, float timeSeed) {
  if (hdrOutput > 0.5) {
    return vec4(max(linearHdr, vec3(0.0)), alpha);
  }
  vec3 srgb = energyToSrgb(energyToneAgx(linearHdr));
  float dither = (energyBlueNoiseHash(fragCoord, timeSeed) / 255.0) * smoothstep(0.002, 0.03, alpha);
  srgb = clamp(srgb + dither, 0.0, 1.0);
  return vec4(srgb * alpha, alpha);
}
`;

// 3. Energia nutricional: Cápsula 3D em Vidro Borossilicato Levemente Roxo (nível ótico Hidratação)
//    com Bio-Plasma Volumétrico Verde Esmeralda Curl-Noise 3D e Raios Ramificados Stepped-Leader em HDR Linear
const ENERGY_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform vec2 u_tilt;
uniform float u_hdrOutput;

${ENERGY_NOISE_GLSL}

vec2 intersectEnergyCapsuleAnalytic(vec3 ro, vec3 rd, float halfAxis, float rad) {
  float r2 = rad * rad;
  float a = rd.y * rd.y + rd.z * rd.z;
  float b = ro.y * rd.y + ro.z * rd.z;
  float c = ro.y * ro.y + ro.z * ro.z - r2;

  float tMin = 1e9;
  float tMax = -1e9;
  bool anyHit = false;

  if (a > 1e-6) {
    float disc = b * b - a * c;
    if (disc >= 0.0) {
      float sqD = sqrt(disc);
      float t0 = (-b - sqD) / a;
      float t1 = (-b + sqD) / a;
      float x0 = ro.x + rd.x * t0;
      float x1 = ro.x + rd.x * t1;
      if (abs(x0) <= halfAxis) { tMin = min(tMin, t0); tMax = max(tMax, t0); anyHit = true; }
      if (abs(x1) <= halfAxis) { tMin = min(tMin, t1); tMax = max(tMax, t1); anyHit = true; }
    }
  }

  vec3 ocL = ro - vec3(-halfAxis, 0.0, 0.0);
  float bL = dot(ocL, rd);
  float cL = dot(ocL, ocL) - r2;
  float dL = bL * bL - cL;
  if (dL >= 0.0) {
    float sL = sqrt(dL);
    float t0 = -bL - sL;
    float t1 = -bL + sL;
    if (ro.x + rd.x * t0 <= -halfAxis) { tMin = min(tMin, t0); tMax = max(tMax, t0); anyHit = true; }
    if (ro.x + rd.x * t1 <= -halfAxis) { tMin = min(tMin, t1); tMax = max(tMax, t1); anyHit = true; }
  }

  vec3 ocR = ro - vec3(halfAxis, 0.0, 0.0);
  float bR = dot(ocR, rd);
  float cR = dot(ocR, ocR) - r2;
  float dR = bR * bR - cR;
  if (dR >= 0.0) {
    float sR = sqrt(dR);
    float t0 = -bR - sR;
    float t1 = -bR + sR;
    if (ro.x + rd.x * t0 >= halfAxis) { tMin = min(tMin, t0); tMax = max(tMax, t0); anyHit = true; }
    if (ro.x + rd.x * t1 >= halfAxis) { tMin = min(tMin, t1); tMax = max(tMax, t1); anyHit = true; }
  }

  if (!anyHit) return vec2(-1.0);
  return vec2(tMin, tMax);
}

float sdEnergyCapsule3D(vec3 pos, float halfAxis, float rad) {
  vec3 pClamped = vec3(clamp(pos.x, -halfAxis, halfAxis), 0.0, 0.0);
  return length(pos - pClamped) - rad;
}

float sdEnergyCavity3D(vec3 pos, float halfAxis, float rad) {
  return sdEnergyCapsule3D(pos, halfAxis, rad) + 0.028;
}

vec3 calcEnergyNormalAnalytic(vec3 pos, float halfAxis) {
  vec3 pClamped = vec3(clamp(pos.x, -halfAxis, halfAxis), 0.0, 0.0);
  return normalize(pos - pClamped);
}

// Estúdio Dark-Field para vidro borossilicato levemente roxo/ametista (contraste cirúrgico equivalente ao módulo de Hidratação)
vec3 energyStudioEnv(vec3 dir, vec3 tint) {
  float dLen = length(dir);
  vec3 d = dLen > 1e-4 ? dir / dLen : vec3(0.0, 0.0, 1.0);
  float elev = d.y;
  float az = atan(d.x, d.z);

  vec3 floorBounce = vec3(0.004, 0.002, 0.007);
  vec3 wallCol = vec3(0.009, 0.005, 0.015);
  vec3 horizonCol = mix(wallCol, tint * 0.050, 0.22);
  vec3 skyCol = mix(horizonCol, vec3(0.115, 0.095, 0.148), smoothstep(0.08, 0.92, elev));

  vec3 env = elev < 0.0
    ? mix(floorBounce, horizonCol * 0.44, smoothstep(-0.84, 0.0, elev))
    : skyCol;

  float darkContrastL = energySoftboxRect(d, vec3(-0.90, 0.04, 0.36), vec2(0.16, 0.68), 0.012);
  float darkContrastR = energySoftboxRect(d, vec3(0.90, -0.04, 0.36), vec2(0.16, 0.64), 0.012);
  float darkBackCore = energySoftboxRect(d, vec3(0.0, -0.02, -0.99), vec2(0.46, 0.30), 0.05);
  float darkHorizonBar = exp(-sq((elev + 0.028) * 48.0));
  env *= 1.0 - clamp((darkContrastL + darkContrastR) * 0.95 + darkBackCore * 0.90 + darkHorizonBar * 0.88, 0.0, 0.97);

  float stripLeft = energySoftboxRect(d, vec3(-0.46, 0.72, 0.51), vec2(0.056, 0.64), 0.005);
  float stripRight = energySoftboxRect(d, vec3(0.64, 0.42, 0.64), vec2(0.048, 0.54), 0.008);
  float overhead = energySoftboxRect(d, vec3(-0.06, 0.96, 0.26), vec2(0.48, 0.058), 0.008);
  float tableBounce = energySoftboxRect(d, vec3(0.04, -0.78, 0.58), vec2(0.58, 0.12), 0.06);

  float backRimLeft = energySoftboxRect(d, vec3(-0.62, 0.18, -0.76), vec2(0.078, 0.56), 0.008);
  float backRimRight = energySoftboxRect(d, vec3(0.62, -0.14, -0.76), vec2(0.078, 0.54), 0.008);
  float backSkyBank = energySoftboxRect(d, vec3(-0.08, 0.76, -0.64), vec2(0.48, 0.095), 0.020);
  float backFloorBounce = energySoftboxRect(d, vec3(0.04, -0.72, -0.68), vec2(0.54, 0.11), 0.040);

  float horizonBand = exp(-sq((elev - 0.042) * 56.0)) * (0.42 + 0.58 * cos(az * 2.0 + 0.4));
  float rimArc = exp(-sq((elev - 0.11) * 30.0)) * (0.40 + 0.60 * cos(az * 2.0));

  env += vec3(7.6, 7.35, 8.0) * stripLeft;
  env += mix(vec3(3.15, 2.95, 3.45), tint * 3.0, 0.24) * stripRight;
  env += vec3(7.25, 7.05, 7.65) * overhead;
  env += vec3(0.62, 0.44, 0.88) * tableBounce * 0.84;

  env += vec3(4.5, 4.15, 5.05) * backRimLeft * 0.94;
  env += vec3(3.05, 2.80, 3.60) * backRimRight * 0.84;
  env += vec3(4.3, 4.05, 4.75) * backSkyBank * 0.82;
  env += vec3(1.24, 0.92, 1.74) * backFloorBounce * 0.90;

  env += vec3(1.12, 1.00, 1.32) * horizonBand * 0.70;
  env += vec3(1.26, 1.12, 1.48) * rimArc * 0.76;
  return env;
}

float energyGGX(vec3 N, vec3 V, vec3 L, float rough) {
  vec3 H = normalize(V + L);
  float NdotH = max(dot(N, H), 0.0);
  float NdotV = max(dot(N, V), 0.001);
  float NdotL = max(dot(N, L), 0.001);
  float a = max(rough * rough, 0.0004);
  float a2 = a * a;
  float denom = NdotH * NdotH * (a2 - 1.0) + 1.0;
  float D = a2 / (3.14159265 * denom * denom);
  float k = (rough + 1.0) * (rough + 1.0) / 8.0;
  float G = (NdotV / (NdotV * (1.0 - k) + k)) * (NdotL / (NdotL * (1.0 - k) + k));
  return (D * G) / (4.0 * NdotV * NdotL + 0.001);
}

float evalEnergyMeniscusX(vec3 pos, float fill, float innerHalf, float dCav, float t) {
  float baseX = mix(-innerHalf, innerHalf + 0.025 * step(0.992, fill), fill);
  float ramp = smoothstep(0.008, 0.048, fill) * invSmooth(0.952, 0.992, fill);
  float wallDist = max(-dCav, 0.0);
  float cling = 0.095 * exp(-wallDist / 0.052);
  float dome = (1.0 - clamp(dot(pos.yz, pos.yz) / 0.20, 0.0, 1.0)) * 0.088;
  float ripple = sin(pos.y * 12.0 - t * 4.4) * 0.0055 + cos(pos.z * 9.5 + t * 3.1) * 0.0040;
  return baseX + (cling - dome + ripple) * ramp;
}

vec3 calcEnergyMeniscusNormal3D(vec3 pos, float fill, float innerHalf, float halfAxis, float rad, float t) {
  const float e = 0.0030;
  float dc0 = sdEnergyCavity3D(pos, halfAxis, rad);
  float xY0 = evalEnergyMeniscusX(pos - vec3(0.0, e, 0.0), fill, innerHalf, dc0, t);
  float xY1 = evalEnergyMeniscusX(pos + vec3(0.0, e, 0.0), fill, innerHalf, dc0, t);
  float xZ0 = evalEnergyMeniscusX(pos - vec3(0.0, 0.0, e), fill, innerHalf, dc0, t);
  float xZ1 = evalEnergyMeniscusX(pos + vec3(0.0, 0.0, e), fill, innerHalf, dc0, t);
  return normalize(vec3(1.0, (xY0 - xY1) / (2.0 * e), (xZ0 - xZ1) / (2.0 * e)));
}

void main() {
  float aspect = max(1.0, u_resolution.x / max(1.0, u_resolution.y));
  vec2 sc = vec2((v_uv.x - 0.5) * aspect, v_uv.y - 0.5);
  float aa = 1.40 / max(min(u_resolution.x, u_resolution.y), 1.0);

  // Cápsula borossilicato teleobjetiva perfeitamente enquadrada na barra slim (24px)
  float R = 0.493;
  float halfAxis = max(0.25, aspect * 0.496 - R);
  float innerRad = R - 0.028;
  float innerHalf = halfAxis + innerRad;

  vec3 ro = vec3(clamp(u_tilt.x, -0.35, 0.35) * 0.09, 0.014 + clamp(u_tilt.y, -0.35, 0.35) * 0.04, 7.60);
  vec3 ta = vec3(0.0, 0.0, 0.0);
  vec3 ww = normalize(ta - ro);
  vec3 uu = normalize(cross(ww, vec3(0.0, 1.0, 0.0)));
  vec3 vv = normalize(cross(uu, ww));
  vec3 rd = normalize(sc.x * uu + sc.y * vv + 7.58 * ww);

  vec2 outerHit = intersectEnergyCapsuleAnalytic(ro, rd, halfAxis, R);
  bool hitOuter = outerHit.x > 0.0;
  float tClosest = max(0.0, dot(-ro, rd));
  float edgeMissDist = abs(sdEnergyCapsule3D(ro + rd * tClosest, halfAxis, R));
  if (!hitOuter && edgeMissDist > aa * 2.2) {
    fragColor = vec4(0.0);
    return;
  }

  float fill = clamp(u_fill, 0.0, 1.0);
  float t = u_time;

  vec3 pOuter = hitOuter ? (ro + rd * outerHit.x) : (ro + rd * tClosest);
  vec3 nOuter = calcEnergyNormalAnalytic(pOuter, halfAxis);
  float glassIor = 1.515;
  float plasmaMediaIor = 1.345;

  // Refração exata Ar -> Parede Espessa de Borossilicato -> Cavidade Interna
  vec3 rdGlass = refract(rd, nOuter, 1.0 / glassIor);
  if (dot(rdGlass, rdGlass) < 0.001) rdGlass = reflect(rd, nOuter);

  vec2 innerEntry = intersectEnergyCapsuleAnalytic(pOuter + rdGlass * 0.002, rdGlass, halfAxis, innerRad);
  vec3 pCandInner = pOuter + rdGlass * (0.002 + max(innerEntry.x, 0.0));
  bool entersCavity = innerEntry.x > 0.0 && innerEntry.y > innerEntry.x &&
    sdEnergyCavity3D(pCandInner + rdGlass * 0.001, halfAxis, R) <= 0.002;
  vec3 pInner = entersCavity ? pCandInner : (pOuter + rdGlass * 0.024);
  vec3 nInner = calcEnergyNormalAnalytic(pInner, halfAxis);

  float dCavStart = sdEnergyCavity3D(pInner, halfAxis, R);
  float startMeniscusX = evalEnergyMeniscusX(pInner, fill, innerHalf, dCavStart, t);
  bool startedInPlasma = entersCavity && fill > 0.004 && pInner.x <= startMeniscusX;

  vec3 rdCav = entersCavity
    ? (startedInPlasma ? refract(rdGlass, nInner, glassIor / plasmaMediaIor) : refract(rdGlass, nInner, glassIor))
    : rdGlass;
  if (dot(rdCav, rdCav) < 0.001) rdCav = reflect(rdGlass, nInner);

  vec3 pBack = pInner;
  float cavLen = 0.04;
  if (entersCavity) {
    vec2 cavSpan = intersectEnergyCapsuleAnalytic(pInner + rdCav * 0.002, rdCav, halfAxis, innerRad);
    cavLen = cavSpan.y > 0.003 ? cavSpan.y + 0.002 : clamp(innerRad * 0.85, 0.02, 0.45);
    pBack = pInner + rdCav * cavLen;
  } else {
    vec2 wallSpan = intersectEnergyCapsuleAnalytic(pOuter + rdGlass * 0.002, rdGlass, halfAxis, R);
    float wallLen = wallSpan.y > 0.002 ? min(wallSpan.y, 0.24) : 0.04;
    pBack = pOuter + rdGlass * wallLen;
  }

  vec3 nBack = calcEnergyNormalAnalytic(pBack, halfAxis);
  vec3 nBackIn = dot(rdCav, nBack) > 0.0 ? -nBack : nBack;
  float mediaIor = entersCavity ? (startedInPlasma ? plasmaMediaIor : 1.0) : glassIor;
  bool alreadyAtOuterWall = abs(mediaIor - glassIor) < 0.005;
  vec3 rayBackGlass = alreadyAtOuterWall ? rdCav : refract(rdCav, nBackIn, mediaIor / glassIor);
  bool isTirBack = !alreadyAtOuterWall && dot(rayBackGlass, rayBackGlass) < 0.001;
  vec3 pGlassExit = pBack;
  vec3 nGlassExit = nBackIn;
  if (!isTirBack && !alreadyAtOuterWall) {
    vec2 outerExitSpan = intersectEnergyCapsuleAnalytic(pBack + rayBackGlass * 0.002, rayBackGlass, halfAxis, R);
    float exitSteps = outerExitSpan.y > 0.002 ? min(outerExitSpan.y, 0.095) : 0.028;
    pGlassExit = pBack + rayBackGlass * exitSteps;
    nGlassExit = -calcEnergyNormalAnalytic(pGlassExit, halfAxis);
  }
  vec3 rayExit = isTirBack ? reflect(rdCav, nBackIn) : refract(rayBackGlass, nGlassExit, glassIor);
  if (dot(rayExit, rayExit) < 0.001) {
    rayExit = reflect(rdCav, nGlassExit);
    isTirBack = true;
  }

  // Parede traseira de borossilicato ametista com escala óptica gravada a laser + absorção roxa Beer-Lambert
  vec2 rearUv = vec2(
    clamp((pGlassExit.x + innerHalf) / max(2.0 * innerHalf, 0.1), 0.0, 1.0),
    clamp((pGlassExit.y + R) / max(2.0 * R, 0.1), 0.0, 1.0)
  );
  float tickCoord = rearUv.x * 20.0;
  float tickDist = abs(fract(tickCoord) - 0.5);
  float tickIdx = floor(tickCoord + 0.5);
  float isMajorTick = step(0.5, 1.0 - mod(tickIdx, 5.0));
  float tickV = smoothstep(0.12, 0.25, rearUv.y) * invSmooth(mix(0.29, 0.43, isMajorTick), mix(0.35, 0.49, isMajorTick), rearUv.y);
  float etchedTicks = invSmooth(0.018, mix(0.070, 0.090, isMajorTick), tickDist) * tickV *
    smoothstep(0.05, 0.12, rearUv.x) * invSmooth(0.88, 0.95, rearUv.x);

  float exitCos = clamp(abs(dot(rdCav, nBackIn)), 0.0, 1.0);
  float exitR0 = sq((mediaIor - glassIor) / max(mediaIor + glassIor, 1e-3));
  float exitFresnel = exitR0 + (1.0 - exitR0) * pow5(1.0 - exitCos);
  vec3 boroPurpleTint = vec3(0.84, 0.62, 1.04);

  // Separação espectral de Sellmeier na parede borossilicato ametista (mesma nitidez ótica da Hidratação)
  vec3 rayExitR = isTirBack ? reflect(rdCav, nBackIn) : refract(rayBackGlass, nGlassExit, glassIor - 0.006);
  vec3 rayExitB = isTirBack ? reflect(rdCav, nBackIn) : refract(rayBackGlass, nGlassExit, glassIor + 0.009);
  if (dot(rayExitR, rayExitR) < 0.001) rayExitR = rayExit;
  if (dot(rayExitB, rayExitB) < 0.001) rayExitB = rayExit;
  float dispWeightE = smoothstep(0.20, 0.86, 1.0 - exitCos) * 0.42;
  vec3 studioBackG = energyStudioEnv(rayExit, boroPurpleTint);
  vec3 studioBackEnv = vec3(
    mix(studioBackG.r, energyStudioEnv(rayExitR, boroPurpleTint).r, dispWeightE),
    studioBackG.g,
    mix(studioBackG.b, energyStudioEnv(rayExitB, boroPurpleTint).b, dispWeightE)
  );
  vec3 backReflEnv = energyStudioEnv(reflect(rdCav, nBackIn), vec3(0.88, 0.72, 1.06));
  vec3 wallCavityBase = vec3(0.010, 0.004, 0.020) + vec3(0.32, 0.24, 0.42) * etchedTicks * 0.36;
  vec3 exitCol = isTirBack
    ? backReflEnv * 1.00
    : mix(mix(wallCavityBase, studioBackEnv, 0.64), backReflEnv, clamp(exitFresnel * 0.92, 0.0, 0.92));

  // Absorção espectral clara e vívida de vidro borossilicato levemente roxo-ametista
  float wallPath = entersCavity ? (0.050 + (1.0 - exitCos) * 0.056) : 0.125;
  vec3 boroGlassAtten = exp(-vec3(0.42, 1.06, 0.14) * wallPath * 4.0);
  exitCol *= boroGlassAtten;

  // Raymarching 3D volumétrico de Bio-Plasma Verde Esmeralda Curl-Noise + Raios Stepped-Leader Reais de Alta Tensão
  float inPlasmaCov = 0.0;
  vec3 plasmaOut = exitCol;
  float endMeniscusX = evalEnergyMeniscusX(pBack, fill, innerHalf, sdEnergyCavity3D(pBack, halfAxis, R), t);
  bool endedInPlasma = entersCavity && fill > 0.004 && pBack.x <= endMeniscusX;
  float meniscusMask = smoothstep(0.008, 0.048, fill) * invSmooth(0.952, 0.992, fill);
  float fillSpanX = mix(-innerHalf, innerHalf, fill);

  if (entersCavity && fill > 0.004 && (startedInPlasma || endedInPlasma)) {
    float tStart = 0.0;
    float tEnd = cavLen;
    if (startedInPlasma != endedInPlasma && meniscusMask > 0.01) {
      float loT = 0.0;
      float hiT = cavLen;
      for (int bIdx = 0; bIdx < 4; bIdx++) {
        float midT = 0.5 * (loT + hiT);
        vec3 midP = pInner + rdCav * midT;
        float mX = evalEnergyMeniscusX(midP, fill, innerHalf, sdEnergyCavity3D(midP, halfAxis, R), t);
        bool inP = midP.x <= mX;
        if (inP == startedInPlasma) loT = midT;
        else hiT = midT;
      }
      if (startedInPlasma) tEnd = 0.5 * (loT + hiT);
      else tStart = 0.5 * (loT + hiT);
    }

    float segLen = max(0.0, tEnd - tStart);
    inPlasmaCov = smoothstep(0.002, 0.022, segLen);

    if (segLen > 0.002) {
      const int VOL_STEPS = 16;
      float ds = segLen / float(VOL_STEPS);
      vec3 accum = vec3(0.0);
      vec3 trans = vec3(1.0);

      // Paleta Bio-Plasma Verde Esmeralda Ionizado + núcleo blackbody incandescente para raios
      vec3 colAbyss = vec3(0.002, 0.022, 0.010);
      vec3 colEmerald = vec3(0.020, 0.62, 0.24);
      vec3 colBioLime = vec3(0.28, 1.38, 0.52);
      vec3 colArcCorona = vec3(0.36, 2.25, 0.84);
      vec3 colArcCore = vec3(4.60, 6.40, 4.90);

      float maxXAct = max(fillSpanX, -innerHalf + 0.14);
      float burstCycle = 0.78 + 0.22 * exp(-fract(t * 5.2) * 3.8);
      float restrikeFlicker = 0.76 + 0.24 * step(0.16, energyHash31(vec3(floor(t * 24.0), 3.1, 7.4)));

      for (int stepIdx = 0; stepIdx < VOL_STEPS; stepIdx++) {
        float rayT = tStart + (float(stepIdx) + 0.5) * ds;
        vec3 pos3D = pInner + rdCav * rayT;
        float rNorm = clamp(length(pos3D.yz) / max(innerRad, 0.05), 0.0, 1.0);
        float radialConfine = invSmooth(0.12, 1.0, rNorm);
        float coreAxis = invSmooth(0.05, 0.88, rNorm);

        // Campo 3D livre de divergência (Curl-Noise) advectando plasma verde ionizado
        vec3 curl = energyCurl3D(vec3(pos3D.x * 1.48 - t * 0.82, pos3D.y * 2.2, pos3D.z * 2.2 + t * 0.42));
        vec3 warpP = pos3D * vec3(1.90, 2.95, 2.95) + curl * 0.48 - vec3(t * 1.28, t * 0.16, -t * 0.24);
        float fbmVal = energyFbm3D(warpP);
        float filamentWisp = safePow(max(0.0, 1.0 - abs(fbmVal * 2.0 - 1.0)), 2.4);

        // Canal primário Stepped-Leader 3D (fio fino incandescente 1/(d+eps) + corona ionizada)
        float tipTaper = smoothstep(0.0, 0.20, abs(pos3D.x - fillSpanX) + 0.04);
        vec2 arc1YZ = energyJaggedPath3D(pos3D.x, t, 1.7) * (0.50 + 0.50 * tipTaper);
        float dArc1 = length(pos3D.yz - arc1YZ);
        float surge1 = burstCycle * restrikeFlicker * (0.78 + 0.22 * energyNoise3D(vec3(pos3D.x * 9.0 - t * 15.0, 2.1, 4.7)));
        float boltCore1 = (0.0019 / (dArc1 + 0.00085)) * exp(-dArc1 * 21.0) * surge1;
        float boltHalo1 = exp(-dArc1 * 17.5) * surge1;

        // Canal secundário contra-polarizado com saltos discretos independentes
        vec2 arc2YZ = energyJaggedPath3D(pos3D.x + 1.15, t * 1.22 + 2.4, 9.3) * 0.90;
        float dArc2 = length(pos3D.yz - arc2YZ);
        float surgeGate2 = smoothstep(0.20, 0.82, energyNoise3D(vec3(pos3D.x * 1.5 - t * 4.2, floor(t * 10.0), 6.2)));
        float boltCore2 = (0.0015 / (dArc2 + 0.00095)) * exp(-dArc2 * 24.0) * surgeGate2;
        float boltHalo2 = exp(-dArc2 * 19.5) * surgeGate2;

        // Ramificações diagonais 3D de Lichtenberg saindo de nós angulares e tocando a parede interna de vidro
        float nodePhase = pos3D.x * 3.6 - floor(t * 8.5) * 0.85;
        float nodeId = floor(nodePhase);
        float nodeLocalX = fract(nodePhase) - 0.5;
        float branchGate = step(0.36, energyHash31(vec3(nodeId, floor(t * 8.5), 4.1))) *
          invSmooth(0.06, 0.44, abs(nodeLocalX)) * smoothstep(0.03, 0.34, rNorm);
        float bAng = energyHash31(vec3(nodeId, 8.2, floor(t * 8.5))) * 6.2831853;
        vec3 branchDir3D = normalize(vec3(0.55 * (energyHash31(vec3(nodeId, 1.9, 5.4)) - 0.3), cos(bAng), sin(bAng)));
        vec3 forkRel = vec3(nodeLocalX * 0.30, pos3D.yz - arc1YZ);
        float projBranch = clamp(dot(forkRel, branchDir3D), 0.0, innerRad * 0.96);
        float forkJag = energyRidgedLeader(projBranch * 7.2 + nodeId, floor(t * 16.0), 12.7) * 0.025;
        float dFork = length(forkRel - branchDir3D * projBranch) + abs(forkJag) * 0.32;
        float forkBolt = (0.0016 / (dFork + 0.00095)) * exp(-dFork * 26.0) * branchGate;
        float wallStrikeGlow = smoothstep(0.68, 0.98, rNorm) * exp(-dFork * 16.0) * branchGate;

        // Micro-centelhas em suspensão carregadas pelo fluxo de plasma
        vec3 sparkGrid = vec3(pos3D.x * 6.5 - t * 4.0, pos3D.y * 8.0 + curl.y * 2.0, pos3D.z * 8.0 + curl.z * 2.0);
        vec3 sparkCell = floor(sparkGrid);
        vec3 sparkLocal = fract(sparkGrid) - 0.5;
        float sparkSeed = energyHash31(sparkCell);
        float sparkMote = step(0.910, sparkSeed) * invSmooth(0.11, 0.30, length(sparkLocal)) * radialConfine;

        float tipCorona = invSmooth(0.0, 0.24, abs(pos3D.x - maxXAct)) * meniscusMask * (0.45 + 0.55 * filamentWisp);
        float plasmaDens = (0.38 + 0.94 * fbmVal + 1.24 * filamentWisp) * radialConfine + 0.14;

        vec3 sampleEmit = mix(colAbyss, colEmerald, smoothstep(0.14, 0.82, fbmVal * 0.74 + coreAxis * 0.42));
        sampleEmit += colBioLime * (filamentWisp * 1.02 + coreAxis * 0.24 + tipCorona * 0.88);
        sampleEmit += colArcCorona * (boltHalo1 * 1.28 + boltHalo2 * 0.96 + wallStrikeGlow * 1.65);
        sampleEmit += colArcCore * (boltCore1 * 1.58 + boltCore2 * 1.24 + forkBolt * 1.65 + sparkMote * 1.32);

        float alphaStep = plasmaDens * ds * 1.48;
        accum += sampleEmit * trans * (1.0 - exp(-alphaStep));
        trans *= exp(-vec3(1.68, 0.22, 1.26) * plasmaDens * ds * 1.12);
      }

      // Cáustica cilíndrica inferior verde + reflexão TIR interna no vidro borossilicato roxo
      float cylNormY = pBack.y / max(innerRad, 0.1);
      float cylWallTir = smoothstep(0.76, 0.97, abs(cylNormY));
      vec3 cylMirror = energyStudioEnv(reflect(rdCav, -nBack), boroPurpleTint);
      float bottomFocus = exp(-sq((cylNormY + 0.56) * 4.2)) * (0.64 + 0.36 * sin(pBack.x * 7.5 - t * 2.6));
      float upperStrip = exp(-sq((cylNormY - 0.56) * 15.0));

      vec3 volCombined = exitCol * trans + accum;
      volCombined = mix(volCombined, cylMirror * 1.00, cylWallTir * 0.54);
      volCombined += vec3(0.26, 1.28, 0.50) * bottomFocus * 0.42;
      volCombined += vec3(0.84, 1.38, 1.02) * upperStrip * 0.28;

      // Menisco 3D escultural + corona elétrica verde na ponta ativa do preenchimento
      if (startedInPlasma != endedInPlasma && meniscusMask > 0.01) {
        vec3 pMen = pInner + rdCav * (startedInPlasma ? tEnd : tStart);
        vec3 nMen = calcEnergyMeniscusNormal3D(pMen, fill, innerHalf, halfAxis, R, t);
        float mCos = clamp(dot(-rdCav, nMen), 0.0, 1.0);
        float mFres = 0.036 + 0.964 * pow5(1.0 - mCos);
        vec3 mRefl = energyStudioEnv(reflect(rdCav, nMen), vec3(0.76, 1.00, 0.88));
        vec3 keyL = normalize(vec3(-0.32, 0.88, 0.35));
        float mSpec = energyGGX(nMen, -rdCav, keyL, 0.005);
        float mWallProx = smoothstep(0.28, 0.96, length(pMen.yz) / max(innerRad, 0.05));
        volCombined = mix(volCombined, mRefl, clamp(mFres * 0.94, 0.0, 0.92));
        volCombined += vec3(3.2, 4.8, 3.6) * mSpec * 0.78;
        volCombined += vec3(0.48, 2.05, 0.92) * mWallProx * 0.66 * meniscusMask;
      }

      plasmaOut = mix(exitCol, volCombined, inPlasmaCov);
    }
  }

  vec3 col = mix(exitCol * (entersCavity ? 0.36 : 0.64), plasmaOut, inPlasmaCov);

  // Fresnel cilíndrico externo + reflexo dark-field de estúdio + Dual GGX Estúdio no vidro borossilicato roxo-ametista
  float cosOuter = clamp(dot(nOuter, -rd), 0.0, 1.0);
  float r0Glass = mix(0.046, 0.038, inPlasmaCov);
  float fresnelOuter = r0Glass + (1.0 - r0Glass) * pow5(1.0 - cosOuter);
  float darkGlassEdge = smoothstep(0.62, 0.94, fresnelOuter);
  col *= 1.0 - darkGlassEdge * 0.38;

  vec3 outerRefl = energyStudioEnv(reflect(rd, nOuter), vec3(0.86, 0.66, 1.08));
  col = mix(col, outerRefl, clamp(fresnelOuter * mix(0.76, 0.94, inPlasmaCov), 0.0, 0.96));

  vec3 keyLight = normalize(vec3(-0.32 + u_tilt.x * 0.30, 0.88, 0.35));
  vec3 fillLight = normalize(vec3(0.45, 0.42, 0.72));
  float specKey = energyGGX(nOuter, -rd, keyLight, mix(0.011, 0.0017, inPlasmaCov));
  float specFill = energyGGX(nOuter, -rd, fillLight, 0.011);
  col += vec3(6.4, 6.1, 6.7) * specKey * 1.00 + vec3(1.26, 0.94, 1.58) * specFill * 0.50;

  // Dupla parede refrativa borossilicato ametista (espessura real cristalina idêntica à Hidratação)
  float boreGraze = smoothstep(0.54, 0.96, 1.0 - abs(dot(rdGlass, nInner)));
  float wallRim = clamp(entersCavity ? boreGraze * 0.72 + max(0.0, 1.0 - dot(nOuter, nInner)) * 0.28 : 0.48, 0.0, 1.0);
  col += vec3(1.04, 0.74, 1.42) * wallRim * mix(0.42, 0.64, inPlasmaCov);

  // Anel capilar do menisco visível na fronteira externa do vidro borossilicato roxo
  float frontProx = smoothstep(0.18, 0.94, abs(pInner.y / max(innerRad, 0.05)));
  float frontPin = exp(-sq((pInner.x - startMeniscusX) * 148.0)) * frontProx * meniscusMask;
  float frontDarkPin = exp(-sq((pInner.x - startMeniscusX - 0.014) * 116.0)) * (0.64 + 0.36 * frontProx) * meniscusMask;
  col *= 1.0 - frontDarkPin * 0.74;
  col += vec3(1.85, 2.65, 2.08) * frontPin * 0.98;

  float shapeMask = hitOuter ? 1.0 : invSmooth(0.0, aa * 2.0, edgeMissDist);
  float glassAlpha = clamp(mix(0.36, 0.96, inPlasmaCov) + fresnelOuter * 0.66 + specKey * 0.18, 0.0, 0.98);
  float alpha = shapeMask * glassAlpha;
  fragColor = energyFinalizeHdrOrSrgb(col, alpha, u_hdrOutput, gl_FragCoord.xy, u_time);
}
`;

// 4. Semicírculo 3D Raymarched em Tubo de Cristal Borossilicato + Metal Líquido Condutor Complex-IOR (LSK) Anisotrópico e Menisco Convexo 3D
const METAL_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform vec2 u_tilt;
uniform vec3 u_metalColor;
uniform vec3 u_metalHighlight;
uniform float u_hdrOutput;

${SHARED_OPTICS_GLSL}

float sdSemiTorus3D(vec3 pos, float majorR, float minorR) {
  if (pos.y >= 0.0) {
    vec2 q = vec2(length(pos.xy) - majorR, pos.z);
    return length(q) - minorR;
  }
  float dL = length(pos - vec3(-majorR, 0.0, 0.0));
  float dR = length(pos - vec3(majorR, 0.0, 0.0));
  return min(dL, dR) - minorR;
}

vec3 calcSemiTorusNormal3D(vec3 pos, float majorR, float minorR) {
  const float h = 0.0014;
  const vec2 k = vec2(1.0, -1.0);
  return normalize(
    k.xyy * sdSemiTorus3D(pos + k.xyy * h, majorR, minorR) +
    k.yyx * sdSemiTorus3D(pos + k.yyx * h, majorR, minorR) +
    k.yxy * sdSemiTorus3D(pos + k.yxy * h, majorR, minorR) +
    k.xxx * sdSemiTorus3D(pos + k.xxx * h, majorR, minorR)
  );
}

float sdSemiMetalColumn3D(vec3 pos, float majorR, float metalRad, float fill) {
  if (fill <= 0.002) return 9.0;
  float maxAngle = clamp(fill, 0.0, 1.0) * 3.14159265;
  float theta = atan(pos.y, -pos.x);
  if (pos.y < 0.0) {
    theta = (maxAngle > 1.5707963 && pos.x > 0.0) ? 3.14159265 : 0.0;
  }
  float aClamped = clamp(theta, 0.0, maxAngle);
  vec3 backbone = vec3(-majorR * cos(aClamped), majorR * sin(aClamped), 0.0);
  vec3 tipTangent = vec3(sin(maxAngle), cos(maxAngle), 0.0);
  vec3 dTip = pos - vec3(-majorR * cos(maxAngle), majorR * sin(maxAngle), 0.0);
  float isTipZone = smoothstep(0.0, metalRad * 0.85, dot(dTip, tipTangent));
  // Menisco convexo não-molhante de mercúrio / metal líquido na frente de avanço
  float radialFrac = clamp(length(pos - backbone) / max(metalRad, 1e-4), 0.0, 1.0);
  float convexBead = isTipZone * (1.0 - sq(radialFrac)) * 0.0075 * step(fill, 0.992);
  return length(pos - backbone) - (metalRad + convexBead);
}

vec3 calcSemiMetalNormal3D(vec3 pos, float majorR, float metalRad, float fill) {
  const float h = 0.0012;
  const vec2 k = vec2(1.0, -1.0);
  return normalize(
    k.xyy * sdSemiMetalColumn3D(pos + k.xyy * h, majorR, metalRad, fill) +
    k.yyx * sdSemiMetalColumn3D(pos + k.yyx * h, majorR, metalRad, fill) +
    k.yxy * sdSemiMetalColumn3D(pos + k.yxy * h, majorR, metalRad, fill) +
    k.xxx * sdSemiMetalColumn3D(pos + k.xxx * h, majorR, metalRad, fill)
  );
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 sc = vec2((v_uv.x - 0.5) * aspect, v_uv.y - 0.5);
  float aa = 1.45 / max(min(u_resolution.x, u_resolution.y), 1.0);

  // Lente teleobjetiva frontal ortogonal ao plano do arco sem distorção de perspectiva nem corte nas bordas
  float majorR = 0.645;
  float minorR = 0.092;
  float wallThick = 0.022;
  float innerR = minorR - wallThick;
  float metalRad = innerR - 0.0022;
  vec3 tubeCenter = vec3(0.0, -0.35, 0.0);

  vec3 ro = vec3(clamp(u_tilt.x, -0.35, 0.35) * 0.16, clamp(u_tilt.y, -0.35, 0.35) * 0.10, 7.60);
  vec3 ta = vec3(0.0, 0.0, 0.0);
  vec3 ww = normalize(ta - ro);
  vec3 uu = normalize(cross(ww, vec3(0.0, 1.0, 0.0)));
  vec3 vv = normalize(cross(uu, ww));
  vec3 rd = normalize(sc.x * uu + sc.y * vv + 7.58 * ww);

  float tOuter = 7.00;
  float minD = 10.0;
  float minT = tOuter;
  bool hitOuter = false;
  for (int i = 0; i < 40; i++) {
    vec3 pCheck = ro + rd * tOuter - tubeCenter;
    float dS = sdSemiTorus3D(pCheck, majorR, minorR);
    if (dS < minD) {
      minD = dS;
      minT = tOuter;
    }
    if (dS < 0.0005) {
      hitOuter = true;
      break;
    }
    tOuter += dS;
    if (tOuter > 8.20) break;
  }

  if (!hitOuter && minD > 0.024) {
    fragColor = vec4(0.0);
    return;
  }

  vec3 pOuter = (ro + rd * (hitOuter ? tOuter : minT)) - tubeCenter;
  vec3 nOuter = calcSemiTorusNormal3D(pOuter, majorR, minorR);
  float glassIor = 1.515;

  // Refração exata Ar -> Parede de Vidro Borossilicato -> Entrada na Cavidade Interna Semitoroidal
  vec3 rdGlass = refract(rd, nOuter, 1.0 / glassIor);
  if (dot(rdGlass, rdGlass) < 0.001) rdGlass = reflect(rd, nOuter);

  vec3 pInner = pOuter + rdGlass * 0.014;
  bool entersCavity = false;
  for (int k = 0; k < 14; k++) {
    float dc = sdSemiTorus3D(pInner, majorR, innerR);
    if (dc <= 0.0004) {
      entersCavity = true;
      break;
    }
    pInner += rdGlass * max(dc * 0.72, 0.0020);
  }
  if (!entersCavity) {
    pInner = pOuter + rdGlass * 0.022;
  }
  vec3 nInner = calcSemiTorusNormal3D(pInner, majorR, innerR);
  vec3 rdCav = entersCavity ? refract(rdGlass, nInner, glassIor) : rdGlass;
  if (dot(rdCav, rdCav) < 0.001) rdCav = reflect(rdGlass, nInner);

  float fill = clamp(u_fill, 0.0, 1.0);
  vec3 pos = pInner + rdCav * 0.002;
  bool hitMetal = false;

  if (entersCavity) {
    for (int m = 0; m < 32; m++) {
      if (fill > 0.002) {
        float dm = sdSemiMetalColumn3D(pos, majorR, metalRad, fill);
        if (dm < 0.0005) {
          // Refinamento binário curto na superfície do metal líquido para silhueta e menisco convexo perfeitos
          vec3 loM = pos - rdCav * 0.003;
          vec3 hiM = pos;
          for (int bM = 0; bM < 3; bM++) {
            vec3 midM = 0.5 * (loM + hiM);
            if (sdSemiMetalColumn3D(midM, majorR, metalRad, fill) < 0.0) hiM = midM;
            else loM = midM;
          }
          pos = hiM;
          hitMetal = true;
          break;
        }
        pos += rdCav * min(max(dm * 0.82, 0.0020), 0.012);
      } else {
        pos += rdCav * 0.012;
      }
      if (sdSemiTorus3D(pos, majorR, innerR) > 0.0) {
        vec3 lo = pos - rdCav * 0.012;
        vec3 hi = pos;
        for (int bIdx = 0; bIdx < 3; bIdx++) {
          vec3 mid = 0.5 * (lo + hi);
          if (sdSemiTorus3D(mid, majorR, innerR) > 0.0) hi = mid;
          else lo = mid;
        }
        pos = lo;
        break;
      }
    }
  }

  // Saída refratada através da parede traseira de borossilicato com dispersão RGB de Sellmeier (idêntica à Hidratação)
  vec3 pBack = pos;
  if (!hitMetal && !entersCavity) {
    for (int gIdx = 0; gIdx < 6; gIdx++) {
      float dg = -sdSemiTorus3D(pBack, majorR, minorR);
      if (dg <= 0.0008) break;
      pBack += rdGlass * clamp(dg * 0.88, 0.002, 0.040);
    }
  }

  vec3 nBack = calcSemiTorusNormal3D(pBack, majorR, innerR);
  vec3 nBackIn = dot(rdCav, nBack) > 0.0 ? -nBack : nBack;
  float mediaBackIor = entersCavity ? 1.0 : glassIor;
  vec3 rayBackGlass = abs(mediaBackIor - glassIor) < 0.005
    ? rdCav
    : refract(rdCav, nBackIn, mediaBackIor / glassIor);
  bool isTirBack = abs(mediaBackIor - glassIor) >= 0.005 && dot(rayBackGlass, rayBackGlass) < 0.001;
  vec3 pGlassExit = pBack + (isTirBack ? vec3(0.0) : rayBackGlass * 0.022);
  vec3 nGlassExit = -calcSemiTorusNormal3D(pGlassExit, majorR, minorR);
  vec3 rayExitR = isTirBack ? reflect(rdCav, nBackIn) : refract(rayBackGlass, nGlassExit, glassIor - 0.006);
  vec3 rayExit = isTirBack ? reflect(rdCav, nBackIn) : refract(rayBackGlass, nGlassExit, glassIor);
  vec3 rayExitB = isTirBack ? reflect(rdCav, nBackIn) : refract(rayBackGlass, nGlassExit, glassIor + 0.009);
  if (dot(rayExit, rayExit) < 0.001) {
    rayExit = reflect(rdCav, nGlassExit);
    rayExitR = rayExit;
    rayExitB = rayExit;
    isTirBack = true;
  } else {
    if (dot(rayExitR, rayExitR) < 0.001) rayExitR = rayExit;
    if (dot(rayExitB, rayExitB) < 0.001) rayExitB = rayExit;
  }

  // Parede interna oca em cristal borossilicato neutro dark-field idêntica à Hidratação + micro-escala a laser
  float backTheta = atan(pGlassExit.y, -pGlassExit.x);
  float backCrossU = clamp((length(pGlassExit.xy) - majorR) / max(minorR, 1e-4), -1.0, 1.0);
  float arcTicks = invSmooth(0.0, 0.062, abs(fract((max(backTheta, 0.0) / 3.14159265) * 10.0) - 0.5)) *
    step(0.0, pGlassExit.y) * smoothstep(0.32, 0.86, abs(backCrossU));

  float exitCos = clamp(abs(dot(rdCav, nBackIn)), 0.0, 1.0);
  float exitR0 = 0.044;
  float exitFresnel = exitR0 + (1.0 - exitR0) * pow5(1.0 - exitCos);
  float dispWeightM = smoothstep(0.18, 0.86, 1.0 - exitCos) * 0.45;
  vec3 cavityBackWall = sampleOpticalCavityWall(pGlassExit.xy + rayExit.xy * 0.14, vec2(10.0, 4.0), 0.5 + pGlassExit.z);
  vec3 dryExitG = sampleWaterStudioEnvironment(rayExit, vec3(0.99, 0.995, 1.0));
  vec3 dryExitEnv = vec3(
    mix(dryExitG.r, sampleWaterStudioEnvironment(rayExitR, vec3(1.0, 0.98, 0.96)).r, dispWeightM),
    dryExitG.g,
    mix(dryExitG.b, sampleWaterStudioEnvironment(rayExitB, vec3(0.97, 0.985, 1.0)).b, dispWeightM)
  );
  vec3 dryReflEnv = sampleWaterStudioEnvironment(reflect(rdCav, nBackIn), vec3(0.99, 0.995, 1.0));
  vec3 rawDryExit = isTirBack
    ? dryReflEnv * 1.02
    : mix(mix(cavityBackWall, dryExitEnv, 0.68), dryReflEnv, clamp(exitFresnel * 0.90, 0.0, 0.90));
  vec3 grooveColor = entersCavity ? rawDryExit * 0.25 : rawDryExit * 0.56;
  grooveColor += vec3(0.94, 0.96, 0.98) * arcTicks * 0.20;

  vec3 col = grooveColor;
  vec3 keyLight = normalize(vec3(-0.36 + u_tilt.x * 0.34, 0.86 - u_tilt.y * 0.14, 0.42));
  vec3 fillLight = normalize(vec3(0.56, 0.42, 0.64));

  if (hitMetal) {
    float t = u_time * 0.30;
    vec2 mUv = pos.xy * 6.5;

    // Uma única amostra FBM3 para micro-acetinado sem dFdx/dFdy
    float satinNoise = fbm3(mUv * 0.82 + vec2(t * 0.055, -t * 0.035));

    vec3 nMetalGeom = calcSemiMetalNormal3D(pos, majorR, metalRad, fill);
    float mTheta = atan(max(pos.y, 0.0), -pos.x);
    vec2 radial2D = normalize(pos.xy + vec2(1e-5));
    vec2 tangent2D = vec2(-radial2D.y, radial2D.x);
    float crossTube = clamp((length(pos.xy) - majorR) / max(metalRad, 1e-4), -1.0, 1.0);

    // Ondulação capilar fluida contínua de mercúrio/liga líquida ao longo do tubo curvo (reflexo espelhado ondulante real)
    float phaseA = mTheta * 5.0 - t * 2.6 + sin(crossTube * 2.9 + t * 1.1) * 0.50;
    float phaseB = crossTube * 5.4 - mTheta * 2.1 - t * 1.5;
    float phaseC = mTheta * 9.2 - t * 4.0 + (satinNoise - 0.5) * 1.5;
    float phaseD = (mTheta * 13.5 + crossTube * 7.2) - t * 4.8;
    float waveA = sin(phaseA);
    float waveB = sin(phaseB);
    float waveC = cos(phaseC);
    vec2 heightGrad =
      tangent2D * (cos(phaseA) * 0.30 - sin(phaseC) * 0.18 + cos(phaseD) * 0.09) +
      radial2D * (cos(phaseB) * 0.24 + sin(phaseD) * 0.07) +
      vec2(waveA, waveB) * (satinNoise - 0.5) * 0.036;

    vec3 normal = normalize(vec3(nMetalGeom.xy - heightGrad * 0.36, nMetalGeom.z));
    vec3 tangent = normalize(vec3(tangent2D, 0.0));
    vec3 viewM = -rdCav;
    float nDotV = clamp(dot(normal, viewM), 0.0, 1.0);

    // Complex IOR (n + i*k) Lazanyi-Szirmay-Kalos Conductor Fresnel derivado da liga metálica líquida
    vec3 alloyHue = clamp(u_metalColor * 1.28 + vec3(0.06), vec3(0.06), vec3(1.0));
    vec3 nCond = mix(vec3(1.42, 1.52, 1.62), vec3(0.32, 0.42, 0.58), alloyHue);
    vec3 kCond = mix(vec3(3.30, 3.45, 3.65), vec3(5.20, 5.55, 5.85), alloyHue);
    vec3 fConductor = evalConductorFresnelLSK(nCond, kCond, nDotV);

    // Reflexo puro de cromo/mercúrio líquido no estúdio Dark-Field (sem preenchimento fosco de tinta!)
    vec3 refl = reflect(-viewM, normal);
    vec3 studioEnv = sampleLiquidMetalStudioEnv(refl, u_metalColor, u_metalHighlight);
    vec3 conductorTint = clamp(mix(u_metalColor * 1.38, u_metalHighlight * 1.18, 0.48), 0.0, 1.38);
    vec3 esr = studioEnv * fConductor * conductorTint;
    float moltenCurrent = 0.5 + 0.5 * (waveA * 0.54 + waveC * 0.46);
    vec3 deepCavityTint = u_metalColor * (0.04 + 0.06 * moltenCurrent);
    vec3 chromeCol = deepCavityTint + esr * 1.18;
    chromeCol *= mix(0.94, 1.06, satinNoise);

    // Anisotropic GGX acetinado + lóbulo espelhado líquido ultra-afiado (0.0014) de mercúrio fundido
    float roughness = mix(0.24, 0.32, satinNoise);
    vec3 conductorF0 = clamp(mix(u_metalColor * 1.48, u_metalHighlight, 0.54), 0.0, 1.30);
    vec3 specular = evaluateGGXAnisotropicSpecular(
      normal, tangent, viewM, keyLight, conductorF0, roughness, 0.28
    ) * 3.10;
    specular += evaluateGGXAnisotropicSpecular(
      normal, tangent, viewM, fillLight, conductorF0, roughness + 0.045, 0.21
    ) * 1.35;
    specular += evaluateGGXSpecular(normal, viewM, keyLight, mix(conductorF0, vec3(1.0), 0.45), 0.0014) * 4.40;
    chromeCol += specular;

    // Menisco convexo não-molhante de mercúrio na frente do arco com sombra capilar e domo brilhante
    float maxAngle = fill * 3.14159265;
    vec3 tipCenter = vec3(-majorR * cos(maxAngle), majorR * sin(maxAngle), 0.0);
    float tipDist = length(pos - tipCenter);
    float tipDome = invSmooth(0.012, metalRad * 0.94, tipDist);
    float wallSilhouetteDark = smoothstep(0.46, 0.92, 1.0 - abs(dot(nMetalGeom, viewM)));
    float tipRimDark = invSmooth(metalRad * 0.70, metalRad * 1.04, tipDist) * smoothstep(metalRad * 0.40, metalRad * 0.94, tipDist);
    chromeCol *= 1.0 - clamp(tipRimDark * 0.64 * step(fill, 0.992) + wallSilhouetteDark * 0.54, 0.0, 0.76);
    chromeCol += mix(u_metalColor * 1.42, u_metalHighlight * 1.85, 0.80) * tipDome * 0.88 * (1.0 - wallSilhouetteDark * 0.18);

    col = chromeCol;
  }

  // Óptica externa cristalina do tubo borossilicato (idêntica à Hidratação: borda dark-field + fresnel prata + GGX cirúrgico + dupla parede limpa)
  float cosOuter = clamp(dot(nOuter, -rd), 0.0, 1.0);
  float r0Outer = 0.046;
  float fresnelOuter = r0Outer + (1.0 - r0Outer) * pow5(1.0 - cosOuter);
  float darkOuterRim = smoothstep(0.62, 0.94, fresnelOuter);
  col *= 1.0 - darkOuterRim * 0.36;

  vec3 outerRefl = sampleWaterStudioEnvironment(reflect(rd, nOuter), vec3(0.99, 0.995, 1.0));
  col = mix(col, outerRefl, clamp(fresnelOuter * (hitMetal ? 0.92 : 0.82), 0.0, 0.95));

  vec3 specOuterKey = evaluateGGXSpecular(nOuter, -rd, keyLight, vec3(0.048), hitMetal ? 0.0017 : 0.011);
  vec3 specOuterFill = evaluateGGXSpecular(nOuter, -rd, fillLight, vec3(0.042), 0.010);
  col += specOuterKey * vec3(6.4, 6.46, 6.52) + specOuterFill * vec3(1.16, 1.20, 1.24);

  // Espessura refrativa limpa da dupla parede interna (idêntica à Hidratação)
  float boreGraze = smoothstep(0.56, 0.96, 1.0 - abs(dot(rdGlass, nInner)));
  float wallRim = clamp(entersCavity ? boreGraze * 0.74 + max(0.0, 1.0 - dot(nOuter, nInner)) * 0.26 : 0.46, 0.0, 1.0);
  col += vec3(1.00, 1.01, 1.03) * wallRim * (hitMetal ? 0.50 : 0.38);

  // Fio fino escuro de separação não-molhante entre metal líquido e parede interna de vidro
  if (hitMetal) {
    float wallGap = smoothstep(-0.022, 0.002, sdSemiTorus3D(pos, majorR, innerR));
    col *= 1.0 - wallGap * 0.54;
  }

  float shapeMask = hitOuter ? 1.0 : invSmooth(0.0, aa * 2.0, minD);
  float glassAlpha = clamp(mix(0.30, 0.97, hitMetal ? 1.0 : 0.0) + fresnelOuter * 0.64 + length(specOuterKey) * 0.18, 0.0, 0.98);
  float alpha = shapeMask * glassAlpha;
  fragColor = finalizeHdrOrSrgb(col, alpha, u_hdrOutput, gl_FragCoord.xy, u_time);
}
`;


interface CachedProgram {
  program: WebGLProgram;
  uResolution: WebGLUniformLocation | null;
  uTime: WebGLUniformLocation | null;
  uFill: WebGLUniformLocation | null;
  uFillY: WebGLUniformLocation | null;
  uActive: WebGLUniformLocation | null;
  uIor: WebGLUniformLocation | null;
  uFresnelR0: WebGLUniformLocation | null;
  uAttenColor: WebGLUniformLocation | null;
  uAttenDist: WebGLUniformLocation | null;
  uEsrIntensity: WebGLUniformLocation | null;
  uCausticIntensity: WebGLUniformLocation | null;
  uFootprint: WebGLUniformLocation | null;
  uTilt: WebGLUniformLocation | null;
  uWave: WebGLUniformLocation | null;
  uFluidTex: WebGLUniformLocation | null;
  uTextTex: WebGLUniformLocation | null;
  uHasText: WebGLUniformLocation | null;
  uTextDims: WebGLUniformLocation | null;
  uPointer: WebGLUniformLocation | null;
  uRipples: WebGLUniformLocation | null;
  uDrops: WebGLUniformLocation | null;
  uDropVel: WebGLUniformLocation | null;
  uTrails: WebGLUniformLocation | null;
  uObstacles: WebGLUniformLocation | null;
  uObstacleWet: WebGLUniformLocation | null;
  uSoliton: WebGLUniformLocation | null;
  uHdrOutput: WebGLUniformLocation | null;
  uMetalColor: WebGLUniformLocation | null;
  uMetalHighlight: WebGLUniformLocation | null;
}

interface HdrTonemapProgram {
  program: WebGLProgram;
  uHdrTex: WebGLUniformLocation | null;
  uBlueNoiseTex: WebGLUniformLocation | null;
  uTime: WebGLUniformLocation | null;
}

type TargetBlitHandle = { ctx: CanvasRenderingContext2D };

function buildProceduralBlueNoise64(): Uint8Array {
  const size = 64;
  const out = new Uint8Array(size * size);
  const g1 = 0.7548776662466927;
  const g2 = 0.5698402909980532;
  const raw = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      // R2 low-discrepancy + triangular jittered spatial decorrelation
      const r2 = (0.5 + g1 * (x + 17 * (y % 7)) + g2 * (y + 13 * (x % 5))) % 1;
      raw[y * size + x] = r2;
    }
  }
  // Single high-pass Laplacian boost so adjacent pixels have strong negative correlation (blue spectrum)
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const c = raw[y * size + x] ?? 0.5;
      const n =
        ((raw[y * size + ((x + 1) & 63)] ?? 0.5) +
          (raw[y * size + ((x + 63) & 63)] ?? 0.5) +
          (raw[((y + 1) & 63) * size + x] ?? 0.5) +
          (raw[((y + 63) & 63) * size + x] ?? 0.5)) *
        0.25;
      const hp = Math.max(0, Math.min(1, 0.5 + (c - n) * 1.45));
      out[y * size + x] = Math.round(hp * 255);
    }
  }
  return out;
}

class SharedFluidShaderEngine {
  private offscreenCanvas: OffscreenCanvas | null = null;
  private fallbackCanvas: HTMLCanvasElement | null = null;
  private gl: WebGL2RenderingContext | null = null;
  private programs = new Map<FluidProgramKind, CachedProgram>();
  private hdrTonemapProg: HdrTonemapProgram | null = null;
  private hdrSupported = false;
  private hdrFbo: WebGLFramebuffer | null = null;
  private hdrTex: WebGLTexture | null = null;
  private hdrW = 0;
  private hdrH = 0;
  private blueNoiseTex: WebGLTexture | null = null;
  private targetCtxCache = new WeakMap<HTMLCanvasElement, TargetBlitHandle>();
  private lastJobRenderAt = new WeakMap<HTMLCanvasElement, number>();
  private quadVao: WebGLVertexArrayObject | null = null;
  private quadBuffer: WebGLBuffer | null = null;
  private fluidTex: WebGLTexture | null = null;
  private lastUploadedFluidGrid: FluidVorticityGrid | null = null;
  private lastUploadedFluidVersion = -1;
  private textTex: WebGLTexture | null = null;
  private lastUploadedTextVersion = -1;
  private lastUploadedTextCanvas: HTMLCanvasElement | null = null;
  private activeJobScratch: FluidDrawJob[] = [];
  private webglFailed = false;
  private subscribers = new Set<() => FluidDrawJob | null>();
  private rafId = 0;
  private lastTime = 0;
  private elapsed = 1.35;
  private springAccumulator = 0;
  private waveUploadBuf = new Float32Array(24);
  private neutralFluidPixel = new Uint8Array([128, 128, 128, 0]);
  private maxDpr = 1.5;
  private visibilityListenerAttached = false;
  private readonly handleVisibilityChange = () => {
    if (typeof document === 'undefined') return;
    if (document.hidden) {
      if (this.rafId) cancelAnimationFrame(this.rafId);
      this.rafId = 0;
      return;
    }
    for (const provider of this.subscribers) {
      this.renderSinglePass(provider);
    }
    this.startLoopIfNeeded();
  };

  private ensureContext(): WebGL2RenderingContext | null {
    if (this.webglFailed || typeof document === 'undefined') return null;
    if (this.gl) return this.gl;

    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      const isCoarse = window.matchMedia('(pointer: coarse)').matches;
      this.maxDpr = isCoarse ? 2 : 2.25;
    }

    const attrs: WebGLContextAttributes = {
      alpha: true,
      antialias: false,
      depth: false,
      stencil: false,
      premultipliedAlpha: true,
      powerPreference: 'high-performance',
    };

    let gl: WebGL2RenderingContext | null = null;
    if (typeof OffscreenCanvas !== 'undefined') {
      const oc = new OffscreenCanvas(64, 64);
      gl = oc.getContext('webgl2', attrs);
      if (gl) {
        this.offscreenCanvas = oc;
        oc.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          if (this.rafId) cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          this.teardownContext();
          this.webglFailed = true;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-fallback'));
        });
        oc.addEventListener('webglcontextrestored', () => {
          this.teardownContext();
          this.webglFailed = false;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-restored'));
          this.wake();
        });
      }
    }

    if (!gl) {
      const hc = document.createElement('canvas');
      gl = hc.getContext('webgl2', attrs);
      if (gl) {
        this.fallbackCanvas = hc;
        hc.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          if (this.rafId) cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          this.teardownContext();
          this.webglFailed = true;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-fallback'));
        });
        hc.addEventListener('webglcontextrestored', () => {
          this.teardownContext();
          this.webglFailed = false;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-restored'));
          this.wake();
        });
      }
    }

    if (!gl) {
      this.webglFailed = true;
      return null;
    }

    const vao = gl.createVertexArray();
    const buf = gl.createBuffer();
    if (!vao || !buf) {
      if (vao) gl.deleteVertexArray(vao);
      if (buf) gl.deleteBuffer(buf);
      this.webglFailed = true;
      return null;
    }

    gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
      gl.STATIC_DRAW,
    );
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);

    this.gl = gl;
    this.quadVao = vao;
    this.quadBuffer = buf;
    this.hdrSupported = Boolean(
      gl.getExtension('EXT_color_buffer_float') || gl.getExtension('EXT_color_buffer_half_float'),
    );
    return gl;
  }

  private ensureHdrResources(gl: WebGL2RenderingContext, pxW: number, pxH: number): boolean {
    if (!this.hdrSupported) return false;

    if (!this.hdrTonemapProg) {
      const vs = this.compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER_300, 'hdr:vertex');
      const fs = this.compileShader(gl, gl.FRAGMENT_SHADER, HDR_TONEMAP_FRAGMENT_300, 'hdr:fragment');
      if (!vs || !fs) {
        if (vs) gl.deleteShader(vs);
        if (fs) gl.deleteShader(fs);
        this.hdrSupported = false;
        return false;
      }
      const prog = gl.createProgram();
      if (!prog) {
        gl.deleteShader(vs);
        gl.deleteShader(fs);
        this.hdrSupported = false;
        return false;
      }
      gl.attachShader(prog, vs);
      gl.attachShader(prog, fs);
      gl.bindAttribLocation(prog, 0, 'a_position');
      gl.linkProgram(prog);
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
        gl.deleteProgram(prog);
        this.hdrSupported = false;
        return false;
      }
      this.hdrTonemapProg = {
        program: prog,
        uHdrTex: gl.getUniformLocation(prog, 'u_hdrTex'),
        uBlueNoiseTex: gl.getUniformLocation(prog, 'u_blueNoiseTex'),
        uTime: gl.getUniformLocation(prog, 'u_time'),
      };
    }

    if (!this.blueNoiseTex) {
      const bnTex = gl.createTexture();
      if (!bnTex) {
        this.hdrSupported = false;
        return false;
      }
      gl.activeTexture(gl.TEXTURE3);
      gl.bindTexture(gl.TEXTURE_2D, bnTex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 64, 64, 0, gl.RED, gl.UNSIGNED_BYTE, buildProceduralBlueNoise64());
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
      this.blueNoiseTex = bnTex;
    }

    const reqW = Math.max(this.hdrW, pxW);
    const reqH = Math.max(this.hdrH, pxH);
    if (!this.hdrFbo || !this.hdrTex || reqW !== this.hdrW || reqH !== this.hdrH) {
      if (!this.hdrFbo) this.hdrFbo = gl.createFramebuffer();
      if (!this.hdrTex) this.hdrTex = gl.createTexture();
      if (!this.hdrFbo || !this.hdrTex) {
        this.hdrSupported = false;
        return false;
      }
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, this.hdrTex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, reqW, reqH, 0, gl.RGBA, gl.HALF_FLOAT, null);

      gl.bindFramebuffer(gl.FRAMEBUFFER, this.hdrFbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.hdrTex, 0);
      const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      if (status !== gl.FRAMEBUFFER_COMPLETE) {
        this.hdrSupported = false;
        return false;
      }
      this.hdrW = reqW;
      this.hdrH = reqH;
    }

    return true;
  }

  private getProgram(gl: WebGL2RenderingContext, kind: FluidProgramKind): CachedProgram | null {
    const existing = this.programs.get(kind);
    if (existing) return existing;

    const fsSource =
      kind === 'droplet'
        ? DROPLET_FRAGMENT_300
        : kind === 'tank'
        ? TANK_FRAGMENT_300
        : kind === 'card-droplets'
        ? CARD_DROPLETS_FRAGMENT_300
        : kind === 'liquid-glass'
        ? LIQUID_GLASS_FRAGMENT_300
        : kind === 'energy'
        ? ENERGY_FRAGMENT_300
        : METAL_FRAGMENT_300;

    const vs = this.compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER_300, `${kind}:vertex`);
    const fs = this.compileShader(gl, gl.FRAGMENT_SHADER, fsSource, `${kind}:fragment`);
    if (!vs || !fs) {
      if (vs) gl.deleteShader(vs);
      if (fs) gl.deleteShader(fs);
      return null;
    }

    const prog = gl.createProgram();
    if (!prog) {
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      return null;
    }
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.bindAttribLocation(prog, 0, 'a_position');
    gl.linkProgram(prog);

    gl.deleteShader(vs);
    gl.deleteShader(fs);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      const info = gl.getProgramInfoLog(prog);
      console.error(`[FluidEngine] ${kind} program link failed`, info);
      gl.deleteProgram(prog);
      return null;
    }

    const cached: CachedProgram = {
      program: prog,
      uResolution: gl.getUniformLocation(prog, 'u_resolution'),
      uTime: gl.getUniformLocation(prog, 'u_time'),
      uFill: gl.getUniformLocation(prog, 'u_fill'),
      uFillY: gl.getUniformLocation(prog, 'u_fillY'),
      uActive: gl.getUniformLocation(prog, 'u_active'),
      uIor: gl.getUniformLocation(prog, 'u_ior'),
      uFresnelR0: gl.getUniformLocation(prog, 'u_fresnelR0'),
      uAttenColor: gl.getUniformLocation(prog, 'u_attenColor'),
      uAttenDist: gl.getUniformLocation(prog, 'u_attenDist'),
      uEsrIntensity: gl.getUniformLocation(prog, 'u_esrIntensity'),
      uCausticIntensity: gl.getUniformLocation(prog, 'u_causticIntensity'),
      uFootprint: gl.getUniformLocation(prog, 'u_footprint'),
      uTilt: gl.getUniformLocation(prog, 'u_tilt'),
      uWave: gl.getUniformLocation(prog, 'u_wave[0]'),
      uFluidTex: gl.getUniformLocation(prog, 'u_fluidTex'),
      uTextTex: gl.getUniformLocation(prog, 'u_textTex'),
      uHasText: gl.getUniformLocation(prog, 'u_hasText'),
      uTextDims: gl.getUniformLocation(prog, 'u_textDims'),
      uPointer: gl.getUniformLocation(prog, 'u_pointer'),
      uRipples: gl.getUniformLocation(prog, 'u_ripples[0]'),
      uDrops: gl.getUniformLocation(prog, 'u_drops[0]'),
      uDropVel: gl.getUniformLocation(prog, 'u_dropVel[0]'),
      uTrails: gl.getUniformLocation(prog, 'u_trails[0]'),
      uObstacles: gl.getUniformLocation(prog, 'u_obstacles[0]'),
      uObstacleWet: gl.getUniformLocation(prog, 'u_obstacleWet[0]'),
      uSoliton: gl.getUniformLocation(prog, 'u_soliton'),
      uHdrOutput: gl.getUniformLocation(prog, 'u_hdrOutput'),
      uMetalColor: gl.getUniformLocation(prog, 'u_metalColor'),
      uMetalHighlight: gl.getUniformLocation(prog, 'u_metalHighlight'),
    };
    this.programs.set(kind, cached);
    return cached;
  }

  private compileShader(
    gl: WebGL2RenderingContext,
    type: number,
    src: string,
    label: string,
  ): WebGLShader | null {
    const shader = gl.createShader(type);
    if (!shader) return null;
    gl.shaderSource(shader, src);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const info = gl.getShaderInfoLog(shader);
      console.error(`[FluidEngine] ${label} shader compilation failed`, info);
      gl.deleteShader(shader);
      return null;
    }
    return shader;
  }

  private getTargetBlitHandle(canvas: HTMLCanvasElement): TargetBlitHandle | null {
    const existing = this.targetCtxCache.get(canvas);
    if (existing) return existing;

    const ctx2d =
      canvas.getContext('2d', { alpha: true, desynchronized: true }) ??
      canvas.getContext('2d');
    if (!ctx2d) return null;
    const handle: TargetBlitHandle = { ctx: ctx2d };
    this.targetCtxCache.set(canvas, handle);
    return handle;
  }

  private renderJobToTarget(job: FluidDrawJob, timeSec: number): boolean {
    if (!Number.isFinite(job.width) || !Number.isFinite(job.height) || job.width <= 0 || job.height <= 0) {
      return false;
    }
    const gl = this.ensureContext();
    const offscreen = this.offscreenCanvas;
    const fallback = this.fallbackCanvas;
    if (!gl || !this.quadVao || (!offscreen && !fallback)) return false;

    const dpr = Math.min(window.devicePixelRatio || 1, this.maxDpr);
    const pxW = Math.max(2, Math.round(job.width * dpr));
    const pxH = Math.max(2, Math.round(job.height * dpr));

    if (job.targetCanvas.width !== pxW || job.targetCanvas.height !== pxH) {
      job.targetCanvas.width = pxW;
      job.targetCanvas.height = pxH;
    }

    const cached = this.getProgram(gl, job.kind);
    if (!cached) {
      if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-fallback'));
      return false;
    }

    const blit = this.getTargetBlitHandle(job.targetCanvas);
    if (!blit) return false;

    if (fallback) {
      if (fallback.width < pxW || fallback.height < pxH) {
        fallback.width = Math.max(fallback.width, pxW);
        fallback.height = Math.max(fallback.height, pxH);
      }
    } else if (offscreen) {
      if (offscreen.width < pxW || offscreen.height < pxH) {
        offscreen.width = Math.max(offscreen.width, pxW);
        offscreen.height = Math.max(offscreen.height, pxH);
      }
    }

    const supportsHdrKind =
      job.kind === 'droplet' ||
      job.kind === 'tank' ||
      job.kind === 'card-droplets' ||
      job.kind === 'liquid-glass' ||
      job.kind === 'energy' ||
      job.kind === 'metal';
    const useHdrPass = supportsHdrKind && this.ensureHdrResources(gl, pxW, pxH) && Boolean(this.blueNoiseTex);

    gl.bindFramebuffer(gl.FRAMEBUFFER, useHdrPass ? this.hdrFbo : null);
    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(0, 0, pxW, pxH);
    gl.viewport(0, 0, pxW, pxH);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(cached.program);
    gl.bindVertexArray(this.quadVao);

    if (cached.uResolution) gl.uniform2f(cached.uResolution, pxW, pxH);
    if (cached.uTime) gl.uniform1f(cached.uTime, timeSec);
    if (cached.uHdrOutput) gl.uniform1f(cached.uHdrOutput, useHdrPass ? 1 : 0);
    if (cached.uSoliton) {
      const sol = job.soliton ?? [0.5, 0.5, 0, 0];
      gl.uniform4f(cached.uSoliton, sol[0], sol[1], sol[2], sol[3]);
    }
    if (cached.uFill) gl.uniform1f(cached.uFill, job.fill);
    if (cached.uFillY) {
      const fallbackY = -0.43 + Math.min(1, Math.max(0, job.fill)) * 0.80;
      gl.uniform1f(cached.uFillY, job.fillY ?? fallbackY);
    }
    if (cached.uTilt) {
      gl.uniform2f(cached.uTilt, job.tilt?.[0] ?? 0, job.tilt?.[1] ?? 0);
    }

    if (job.kind === 'droplet' && cached.uActive) {
      gl.uniform1f(cached.uActive, job.active ? 1 : 0);
    }

    if (job.kind === 'droplet' || job.kind === 'tank') {
      const cfg = job.opticalConfig;
      const ior = cfg?.ior ?? DEFAULT_WATER_OPTICAL_CONFIG.ior;
      const r0 = cfg?.fresnelR0 ?? DEFAULT_WATER_OPTICAL_CONFIG.fresnelR0;
      const ac = cfg?.attenuationColor ?? DEFAULT_WATER_OPTICAL_CONFIG.attenuationColor;
      const ad = cfg?.attenuationDistance ?? DEFAULT_WATER_OPTICAL_CONFIG.attenuationDistance;
      const esr = cfg?.esrIntensity ?? DEFAULT_WATER_OPTICAL_CONFIG.esrIntensity;
      const caust = cfg?.causticIntensity ?? DEFAULT_WATER_OPTICAL_CONFIG.causticIntensity;
      const fp = cfg?.footprintFilter ?? DEFAULT_WATER_OPTICAL_CONFIG.footprintFilter;

      if (cached.uIor) gl.uniform1f(cached.uIor, ior);
      if (cached.uFresnelR0) gl.uniform1f(cached.uFresnelR0, r0);
      if (cached.uAttenColor) gl.uniform3f(cached.uAttenColor, ac[0], ac[1], ac[2]);
      if (cached.uAttenDist) gl.uniform1f(cached.uAttenDist, ad);
      if (cached.uEsrIntensity) gl.uniform1f(cached.uEsrIntensity, esr);
      if (cached.uCausticIntensity) gl.uniform1f(cached.uCausticIntensity, caust);
      if (cached.uFootprint) gl.uniform1f(cached.uFootprint, fp ? 1 : 0);

      if (job.wave && cached.uWave) {
        const srcLen = job.wave.length;
        for (let i = 0; i < 24; i++) {
          const mapped = Math.min(srcLen - 1, Math.round((i / 23) * (srcLen - 1)));
          this.waveUploadBuf[i] = job.wave[mapped]?.height ?? 0;
        }
        gl.uniform1fv(cached.uWave, this.waveUploadBuf);
      }

      if (cached.uFluidTex) {
        if (!this.fluidTex) {
          this.fluidTex = gl.createTexture();
          if (this.fluidTex) {
            gl.bindTexture(gl.TEXTURE_2D, this.fluidTex);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
          }
        }
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, this.fluidTex);
        if (job.fluidGrid) {
          const gridVersion = job.fluidGrid.version;
          if (
            this.lastUploadedFluidGrid !== job.fluidGrid ||
            this.lastUploadedFluidVersion !== gridVersion
          ) {
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
            gl.texImage2D(
              gl.TEXTURE_2D,
              0,
              gl.RGBA,
              job.fluidGrid.width,
              job.fluidGrid.height,
              0,
              gl.RGBA,
              gl.UNSIGNED_BYTE,
              job.fluidGrid.packedRgba,
            );
            this.lastUploadedFluidGrid = job.fluidGrid;
            this.lastUploadedFluidVersion = gridVersion;
          }
        } else if (this.lastUploadedFluidVersion !== -2) {
          gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
          gl.texImage2D(
            gl.TEXTURE_2D,
            0,
            gl.RGBA,
            1,
            1,
            0,
            gl.RGBA,
            gl.UNSIGNED_BYTE,
            this.neutralFluidPixel,
          );
          this.lastUploadedFluidGrid = null;
          this.lastUploadedFluidVersion = -2;
        }
        gl.uniform1i(cached.uFluidTex, 0);
      }

      if (job.kind === 'tank' && cached.uTextTex && cached.uHasText) {
        if (job.textCanvas && job.textCanvas.width > 0 && job.textCanvas.height > 0) {
          if (!this.textTex) {
            this.textTex = gl.createTexture();
            if (this.textTex) {
              gl.bindTexture(gl.TEXTURE_2D, this.textTex);
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            }
          }
          gl.activeTexture(gl.TEXTURE1);
          gl.bindTexture(gl.TEXTURE_2D, this.textTex);
          const version = job.textVersion ?? 0;
          if (
            this.lastUploadedTextCanvas !== job.textCanvas ||
            this.lastUploadedTextVersion !== version
          ) {
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, job.textCanvas);
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
            this.lastUploadedTextCanvas = job.textCanvas;
            this.lastUploadedTextVersion = version;
          }
          gl.uniform1i(cached.uTextTex, 1);
          gl.uniform1f(cached.uHasText, 1);
          if (cached.uTextDims) {
            const labelNorm = job.textDims?.[0] ?? 0.14;
            const spriteNorm = job.textDims?.[1] ?? 0.34;
            gl.uniform2f(cached.uTextDims, labelNorm, spriteNorm);
          }
        } else {
          gl.uniform1f(cached.uHasText, 0);
        }
      }
    }

    if (job.kind === 'card-droplets' && job.cardDroplets) {
      if (cached.uDrops) gl.uniform4fv(cached.uDrops, job.cardDroplets.drops);
      if (cached.uDropVel) gl.uniform2fv(cached.uDropVel, job.cardDroplets.velocities);
      if (cached.uTrails) gl.uniform4fv(cached.uTrails, job.cardDroplets.trails);
      if (cached.uObstacles) gl.uniform4fv(cached.uObstacles, job.cardDroplets.obstacles);
      if (cached.uObstacleWet) gl.uniform1fv(cached.uObstacleWet, job.cardDroplets.obstacleWetness);
    }

    if (job.kind === 'card-droplets' || job.kind === 'liquid-glass') {
      if (cached.uPointer) {
        const pt = job.cardPointer ?? [0.5, 0.5, 0, 0];
        gl.uniform4f(cached.uPointer, pt[0], pt[1], pt[2], pt[3]);
      }
      if (cached.uRipples && job.cardRipples) {
        gl.uniform4fv(cached.uRipples, job.cardRipples);
      }
    }

    if (job.kind === 'metal') {
      const mc = job.metalColor ?? [0.56, 0.69, 0.75];
      const mh = job.metalHighlight ?? [0.92, 0.98, 1.0];
      if (cached.uMetalColor) gl.uniform3f(cached.uMetalColor, mc[0], mc[1], mc[2]);
      if (cached.uMetalHighlight) gl.uniform3f(cached.uMetalHighlight, mh[0], mh[1], mh[2]);
    }

    gl.drawArrays(gl.TRIANGLES, 0, 6);

    if (useHdrPass && this.hdrTonemapProg && this.hdrTex) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.scissor(0, 0, pxW, pxH);
      gl.viewport(0, 0, pxW, pxH);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(this.hdrTonemapProg.program);
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, this.hdrTex);
      if (this.hdrTonemapProg.uHdrTex) gl.uniform1i(this.hdrTonemapProg.uHdrTex, 2);
      if (this.blueNoiseTex && this.hdrTonemapProg.uBlueNoiseTex) {
        gl.activeTexture(gl.TEXTURE3);
        gl.bindTexture(gl.TEXTURE_2D, this.blueNoiseTex);
        gl.uniform1i(this.hdrTonemapProg.uBlueNoiseTex, 3);
      }
      if (this.hdrTonemapProg.uTime) gl.uniform1f(this.hdrTonemapProg.uTime, timeSec);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
    }

    gl.disable(gl.SCISSOR_TEST);

    const src = fallback ?? offscreen;
    if (!src) return false;
    blit.ctx.clearRect(0, 0, pxW, pxH);
    // OffscreenCanvas is itself a CanvasImageSource. Drawing it directly avoids
    // allocating/transferring/closing a new ImageBitmap for every gauge frame.
    blit.ctx.drawImage(src, 0, src.height - pxH, pxW, pxH, 0, 0, pxW, pxH);
    return true;
  }

  subscribe(
    provider: () => FluidDrawJob | null,
    initialRenderAlreadyDone = false,
  ): () => void {
    this.subscribers.add(provider);
    if (!this.visibilityListenerAttached && typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', this.handleVisibilityChange);
      this.visibilityListenerAttached = true;
    }

    if (!initialRenderAlreadyDone) this.renderSinglePass(provider);
    const initialJob = provider();
    if (
      !this.webglFailed &&
      initialJob &&
      (initialJob.isAnimating || (initialJob.wave && this.hasActiveWave(initialJob.wave)))
    ) {
      this.startLoopIfNeeded();
    }

    return () => {
      this.subscribers.delete(provider);
      if (this.subscribers.size === 0) {
        if (this.rafId) cancelAnimationFrame(this.rafId);
        this.rafId = 0;
        if (this.visibilityListenerAttached && typeof document !== 'undefined') {
          document.removeEventListener('visibilitychange', this.handleVisibilityChange);
          this.visibilityListenerAttached = false;
        }
      }
    };
  }

  /**
   * Starts the shared renderer only after a value transition or a user impulse.
   * Static liquid is rendered once and then remains completely still.
   */
  wake(): void {
    if (this.webglFailed) return;
    if (
      typeof window === 'undefined' ||
      prefersReducedMotion() ||
      (typeof document !== 'undefined' && document.hidden)
    ) {
      return;
    }
    this.startLoopIfNeeded();
  }

  renderSinglePass(provider: () => FluidDrawJob | null): boolean {
    const job = provider();
    if (!job || !job.isVisible) return false;
    const ok = this.renderJobToTarget(job, this.elapsed);
    if (ok) {
      this.lastJobRenderAt.set(job.targetCanvas, performance.now());
    }
    return ok;
  }

  private hasActiveWave(nodes: SpringNode[]): boolean {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node && (Math.abs(node.height) > 0.012 || Math.abs(node.velocity) > 0.012)) {
        return true;
      }
    }
    return false;
  }

  private startLoopIfNeeded(): void {
    if (this.rafId || this.subscribers.size === 0) return;
    if (
      typeof window === 'undefined' ||
      prefersReducedMotion() ||
      (typeof document !== 'undefined' && document.hidden)
    ) {
      return;
    }

    this.lastTime = performance.now();

    const tick = (now: number) => {
      if (typeof document !== 'undefined' && document.hidden) {
        this.rafId = 0;
        return;
      }
      if (typeof window !== 'undefined' && prefersReducedMotion()) {
        for (const provider of this.subscribers) {
          const job = provider();
          if (job?.isVisible) this.renderJobToTarget(job, this.elapsed);
        }
        this.rafId = 0;
        return;
      }

      const dt = Math.min(0.05, Math.max(0, (now - this.lastTime) / 1000));
      this.lastTime = now;
      this.elapsed += dt;

      this.springAccumulator += dt;
      const springSubsteps = Math.min(3, Math.floor(this.springAccumulator * 60));
      if (springSubsteps > 0) this.springAccumulator -= springSubsteps / 60;
      this.activeJobScratch.length = 0;
      for (const provider of this.subscribers) {
        const job = provider();
        if (!job || !job.isVisible) continue;

        const waveActive = job.wave ? this.hasActiveWave(job.wave) : false;
        // Do not redraw static water at 30 fps. Only a fill transition or a
        // physical spring impulse is allowed to keep the GPU loop alive.
        if (!job.isAnimating && !waveActive) continue;

        if (waveActive && job.wave && springSubsteps > 0) {
          for (let step = 0; step < springSubsteps; step++) {
            stepSpringNodes(job.wave, 0.12, 0.20, 0.14);
          }
        }
        this.activeJobScratch.push(job);
      }

      if (this.activeJobScratch.length === 0) {
        this.rafId = 0;
        return;
      }

      for (let i = 0; i < this.activeJobScratch.length; i++) {
        const job = this.activeJobScratch[i];
        if (!job) continue;

        const prevAt = this.lastJobRenderAt.get(job.targetCanvas) ?? 0;
        if (now - prevAt >= MIN_FLUID_FRAME_INTERVAL_MS) {
          const budgetMs = job.idleFrameIntervalMs
            ? Math.max(MIN_FLUID_FRAME_INTERVAL_MS, job.idleFrameIntervalMs)
            : MIN_FLUID_FRAME_INTERVAL_MS;
          if (now - prevAt >= budgetMs) {
            this.lastJobRenderAt.set(job.targetCanvas, now);
            this.renderJobToTarget(job, this.elapsed);
          }
        }
      }

      this.rafId = requestAnimationFrame(tick);
    };

    this.rafId = requestAnimationFrame(tick);
  }

  private teardownContext(): void {
    const gl = this.gl;
    if (gl) {
      for (const cached of this.programs.values()) {
        gl.deleteProgram(cached.program);
      }
      this.programs.clear();
      if (this.hdrTonemapProg) gl.deleteProgram(this.hdrTonemapProg.program);
      if (this.hdrFbo) gl.deleteFramebuffer(this.hdrFbo);
      if (this.hdrTex) gl.deleteTexture(this.hdrTex);
      if (this.blueNoiseTex) gl.deleteTexture(this.blueNoiseTex);
      if (this.fluidTex) gl.deleteTexture(this.fluidTex);
      if (this.textTex) gl.deleteTexture(this.textTex);
      if (this.quadBuffer) gl.deleteBuffer(this.quadBuffer);
      if (this.quadVao) gl.deleteVertexArray(this.quadVao);
    }
    this.hdrTonemapProg = null;
    this.hdrFbo = null;
    this.hdrTex = null;
    this.hdrW = 0;
    this.hdrH = 0;
    this.hdrSupported = false;
    this.blueNoiseTex = null;
    this.fluidTex = null;
    this.lastUploadedFluidGrid = null;
    this.lastUploadedFluidVersion = -1;
    this.textTex = null;
    this.lastUploadedTextCanvas = null;
    this.lastUploadedTextVersion = -1;
    this.quadBuffer = null;
    this.quadVao = null;
    this.gl = null;
    this.offscreenCanvas = null;
    this.fallbackCanvas = null;
  }
}

let sharedEngineSingleton: SharedFluidShaderEngine | null = null;

export function getSharedFluidEngine(): SharedFluidShaderEngine {
  if (!sharedEngineSingleton) {
    sharedEngineSingleton = new SharedFluidShaderEngine();
  }
  return sharedEngineSingleton;
}
