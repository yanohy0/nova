import assert from 'node:assert/strict';
import {
  buildComposerDayFromMeals,
  computeDayNutrition,
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
} from '../../../domain/rules/cardapio-composer-engine.ts';

const day = buildComposerDayFromMeals('2026-11-25', []);
const baselineSummary = computeDayNutrition(day);

// Lock one specific ingredient (index 0 of slot 0) and ask solver to hit a higher calorie/protein target
const lockedId = day.slots[0]!.recipes[0]!.ingredients[0]!.id;
const lockedOriginalG = day.slots[0]!.recipes[0]!.ingredients[0]!.currentQuantityG;
day.slots[0]!.recipes[0]!.ingredients[0]!.mode = 'locked';

const target = {
  kcal: Math.round(baselineSummary.macros.kcal + 240),
  proteinG: Math.round(baselineSummary.macros.proteinG + 20),
  carbsG: Math.round(baselineSummary.macros.carbsG + 20),
  fatG: Math.round(baselineSummary.macros.fatG + 8),
};

const proposal = solveNutritionalBalanceQP(day, target, { goalFocus: 'balanced' });

assert.ok(['optimal', 'feasible', 'approximate'].includes(proposal.certificate));
assert.ok(proposal.adjustedCount > 0, 'QP solver must adjust flexible ingredients');
assert.equal(proposal.lockedCount, 1, 'Locked count must be preserved accurately');

// Verify locked ingredient did NOT change inside proposedDayPlan
const proposedLockedG = proposal.proposedDayPlan.slots[0]!.recipes[0]!.ingredients.find(
  (i) => i.id === lockedId,
)?.currentQuantityG;
assert.equal(proposedLockedG, lockedOriginalG, 'Locked ingredient quantity must remain invariant');

// Verify proposed plan moved closer to target kcal than baseline
const beforeError = Math.abs(baselineSummary.macros.kcal - target.kcal);
const afterError = Math.abs(proposal.afterMacros.kcal - target.kcal);
assert.ok(afterError < beforeError, 'QP optimization must reduce target calorie error');

// Verify discrete substitution proposals are ranked independently
const subs = proposeDiscreteSubstitutions(day, { ...target, kcal: 1750, carbsG: 180 }, 3);
assert.ok(subs.length >= 1, 'Discrete substitution recommender should propose catalog swaps');

console.log('composition-preview.test.ts passed.');
