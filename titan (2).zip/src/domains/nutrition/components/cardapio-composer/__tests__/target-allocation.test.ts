import assert from 'node:assert/strict';
import {
  buildComposerDayFromMeals,
  buildDefaultMealAllocations,
  evaluateMealAllocations,
} from '../../../domain/rules/cardapio-composer-engine.ts';

const day = buildComposerDayFromMeals('2026-11-25', []);
const defaultAllocs = buildDefaultMealAllocations(day.slots);

const targets = {
  kcal: 2500,
  proteinG: 170,
  carbsG: 280,
  fatG: 75,
};

const balanced = evaluateMealAllocations(day, targets, defaultAllocs);
assert.equal(balanced.isBalanced, true);
assert.equal(balanced.totalSharePercent, 100);
assert.equal(balanced.unallocatedPercent, 0);
assert.equal(balanced.slots.length, 4);

// Flag unallocated share explicitly when percentages do not sum to 100%
const underAllocated = defaultAllocs.map((a, idx) =>
  idx === 0 ? { ...a, energySharePercent: 10 } : a,
);
const evaluatedUnder = evaluateMealAllocations(day, targets, underAllocated);
assert.equal(evaluatedUnder.isBalanced, false);
assert.equal(evaluatedUnder.unallocatedPercent, 12);

console.log('target-allocation.test.ts passed.');
