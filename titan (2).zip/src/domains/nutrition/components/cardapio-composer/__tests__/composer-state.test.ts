import assert from 'node:assert/strict';
import {
  buildInitialComposerPlans,
  cloneCardapioPlan,
  computeCompositionDiff,
} from '../../../domain/rules/cardapio-composer-engine.ts';
import { mergeNutritionPersistedState } from '../../../state/nutrition-persistence.ts';

const anchorDate = '2026-11-25';
const plans = buildInitialComposerPlans(
  anchorDate,
  { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
  [],
);

assert.equal(plans.length, 2);
const planA = plans[0]!;
const planB = cloneCardapioPlan(planA);
planB.id = 'plan-cloned';
planB.name = 'Cópia isolada';

// Mutating cloned plan B must NEVER leak into plan A
const dayB = planB.days[anchorDate]!;
dayB.slots[0]!.recipes[0]!.ingredients[0]!.currentQuantityG = 220;
assert.notEqual(
  planA.days[anchorDate]!.slots[0]!.recipes[0]!.ingredients[0]!.currentQuantityG,
  220,
  'Independent plans must never share mutable ingredient references',
);

// Composition diff must catch the gram modification
const diff = computeCompositionDiff(planA.days[anchorDate]!, dayB);
assert.ok(diff.ingredientDiffs.some((row) => Math.abs(row.deltaGrams) > 0));
assert.ok(diff.deltaMacros.kcal > 0);

// Persistence validation accepts valid plans and filters corrupted entries
const fallback = {
  activeDateKey: anchorDate,
  referenceProfileId: 'adult_male_19_50' as const,
  dailyGoals: { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
  meals: [],
  intakeDayConfirmations: [],
  composerPlans: plans,
  activeComposerPlanId: planA.id,
};

const persistedValid = mergeNutritionPersistedState(
  {
    composerPlans: [planA, { id: 'corrupt-plan', name: '' }],
    activeComposerPlanId: planA.id,
  },
  fallback,
);
assert.equal(persistedValid.composerPlans?.length, 1);
assert.equal(persistedValid.activeComposerPlanId, planA.id);

console.log('composer-state.test.ts passed.');
