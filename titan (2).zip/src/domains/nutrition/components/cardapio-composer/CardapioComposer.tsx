import { startTransition, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  buildComposerDayFromMeals,
  computeDayNutrition,
} from '../../domain/rules/cardapio-composer-engine';
import type {
  DiscreteSubstitutionProposal,
  OptimizationProposal,
} from '../../domain/entities/nutrient';
import { runComposerOptimizationAsync } from '../../application/composer-optimizer-client';
import { useNutritionStore } from '../../state/nutrition.store';
import { ComposerHeader } from './composer/ComposerHeader';
import { ComposerDayRail } from './composer/ComposerDayRail';
import { MealCompositionLanes } from './composer/MealCompositionLanes';
import { RecipeProportionMatrix } from './composer/RecipeProportionMatrix';
import { LiveBalancePanel } from './composer/LiveBalancePanel';
import { ComposerActionDock } from './composer/ComposerActionDock';
import { OptimizationPreview } from './variants/OptimizationPreview';
import { CompositionComparison } from './variants/CompositionComparison';

export function CardapioComposer() {
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const meals = useNutritionStore((s) => s.meals);
  const intakeDayConfirmations = useNutritionStore((s) => s.intakeDayConfirmations);
  const composerPlans = useNutritionStore((s) => s.composerPlans);
  const activeComposerPlanId = useNutritionStore((s) => s.activeComposerPlanId);

  const setActiveDateKey = useNutritionStore((s) => s.setActiveDateKey);
  const selectComposerPlan = useNutritionStore((s) => s.selectComposerPlan);
  const createComposerPlan = useNutritionStore((s) => s.createComposerPlan);
  const updateComposerPlanMeta = useNutritionStore((s) => s.updateComposerPlanMeta);
  const updateComposerPlanTargets = useNutritionStore((s) => s.updateComposerPlanTargets);
  const updateComposerMealAllocations = useNutritionStore((s) => s.updateComposerMealAllocations);
  const setComposerSlotRecipeYield = useNutritionStore((s) => s.setComposerSlotRecipeYield);
  const setComposerRecipeAdjustmentMode = useNutritionStore((s) => s.setComposerRecipeAdjustmentMode);
  const updateComposerIngredient = useNutritionStore((s) => s.updateComposerIngredient);
  const addIngredientToComposerRecipe = useNutritionStore((s) => s.addIngredientToComposerRecipe);
  const removeIngredientFromComposerRecipe = useNutritionStore((s) => s.removeIngredientFromComposerRecipe);
  const swapComposerSlotRecipe = useNutritionStore((s) => s.swapComposerSlotRecipe);
  const addComposerMealSlot = useNutritionStore((s) => s.addComposerMealSlot);
  const removeComposerMealSlot = useNutritionStore((s) => s.removeComposerMealSlot);
  const applyOptimizationProposal = useNutritionStore((s) => s.applyOptimizationProposal);
  const saveCompositionVariant = useNutritionStore((s) => s.saveCompositionVariant);
  const activateCompositionVariant = useNutritionStore((s) => s.activateCompositionVariant);
  const deleteCompositionVariant = useNutritionStore((s) => s.deleteCompositionVariant);

  const confirmMealConsumed = useNutritionStore((s) => s.confirmMealConsumed);
  const setMealPartial = useNutritionStore((s) => s.setMealPartial);
  const skipMeal = useNutritionStore((s) => s.skipMeal);
  const restoreMealPlanned = useNutritionStore((s) => s.restoreMealPlanned);
  const confirmIntakeDay = useNutritionStore((s) => s.confirmIntakeDay);

  const activePlan = useMemo(
    () => composerPlans.find((p) => p.id === activeComposerPlanId) ?? composerPlans[0]!,
    [composerPlans, activeComposerPlanId],
  );

  const dayMeals = useMemo(
    () => meals.filter((m) => m.dateKey === activeDateKey),
    [meals, activeDateKey],
  );

  const activeDay = useMemo(
    () => activePlan.days[activeDateKey] ?? buildComposerDayFromMeals(activeDateKey, dayMeals),
    [activePlan.days, activeDateKey, dayMeals],
  );

  const [selectedSlotId, setSelectedSlotId] = useState<string>(
    () => activeDay.slots[0]?.id ?? '',
  );
  const [goalFocus, setGoalFocus] = useState<'balanced' | 'energy' | 'protein'>('balanced');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [proposal, setProposal] = useState<OptimizationProposal | null>(null);
  const [substitutions, setSubstitutions] = useState<DiscreteSubstitutionProposal[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);
  const [intakeFeedback, setIntakeFeedback] = useState<string | null>(null);
  const balancePanelRef = useRef<HTMLDivElement | null>(null);

  // Ensure selectedSlotId stays valid across day/plan switches
  useEffect(() => {
    if (!activeDay.slots.some((slot) => slot.id === selectedSlotId)) {
      setSelectedSlotId(activeDay.slots[0]?.id ?? '');
    }
  }, [activeDay.slots, selectedSlotId]);

  const activeSlot = useMemo(
    () => activeDay.slots.find((slot) => slot.id === selectedSlotId) ?? activeDay.slots[0],
    [activeDay.slots, selectedSlotId],
  );

  const daySummary = useMemo(() => computeDayNutrition(activeDay), [activeDay]);
  const isIntakeDayConfirmed = intakeDayConfirmations.includes(activeDateKey);
  const canConfirmIntakeDay =
    dayMeals.length > 0 && dayMeals.every((meal) => meal.status !== 'planned');

  const handleSelectDateKey = useCallback(
    (nextDate: string) => {
      startTransition(() => {
        setActiveDateKey(nextDate);
        setProposal(null);
        setIntakeFeedback(null);
      });
    },
    [setActiveDateKey],
  );

  const handleSelectPlan = useCallback(
    (planId: string) => {
      startTransition(() => {
        selectComposerPlan(planId);
        setProposal(null);
      });
    },
    [selectComposerPlan],
  );

  const handleSelectSlot = useCallback((slotId: string) => {
    startTransition(() => {
      setSelectedSlotId(slotId);
    });
  }, []);

  const handleSimulateBalance = useCallback(
    async (scope: 'day' | 'slot') => {
      setIsOptimizing(true);
      try {
        const result = await runComposerOptimizationAsync(
          activeDay,
          activePlan.targets,
          {
            scopeSlotId: scope === 'slot' ? activeSlot?.id : undefined,
            goalFocus,
          },
          true,
        );
        setProposal(result.proposal);
        setSubstitutions(result.substitutions);
      } finally {
        setIsOptimizing(false);
      }
    },
    [activeDay, activePlan.targets, activeSlot?.id, goalFocus],
  );

  return (
    <div className="space-y-5 pb-20 lg:pb-4">
      <ComposerHeader
        plans={composerPlans}
        activePlan={activePlan}
        compareOpen={compareOpen}
        onSelectPlan={handleSelectPlan}
        onCreatePlan={createComposerPlan}
        onUpdatePlanMeta={updateComposerPlanMeta}
        onUpdateTargets={updateComposerPlanTargets}
        onToggleCompare={() => setCompareOpen((prev) => !prev)}
      />

      <ComposerDayRail
        plan={activePlan}
        activeDateKey={activeDateKey}
        onSelectDateKey={handleSelectDateKey}
      />

      {compareOpen && (
        <CompositionComparison
          plans={composerPlans}
          activePlan={activePlan}
          activeDay={activeDay}
          activeDateKey={activeDateKey}
          onClose={() => setCompareOpen(false)}
        />
      )}

      {proposal && (
        <OptimizationPreview
          proposal={proposal}
          substitutions={substitutions}
          onApplyProposal={() => {
            applyOptimizationProposal(activeDateKey, proposal);
            setProposal(null);
          }}
          onSaveAsVariant={(name) => {
            saveCompositionVariant(
              activeDateKey,
              name,
              proposal.proposedDayPlan,
              proposal.explanation,
            );
            setProposal(null);
          }}
          onApplyDiscreteSubstitution={(sub) => {
            swapComposerSlotRecipe(
              activeDateKey,
              sub.slotId,
              sub.currentRecipeId,
              sub.candidateRecipeId,
            );
            setProposal(null);
          }}
          onDiscard={() => setProposal(null)}
        />
      )}

      {/* Dual-Reading Studio: ~64% Composition Stage | ~36% Persistent Live Balance */}
      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1.72fr)_minmax(340px,1fr)] gap-5 items-start">
        <div className="space-y-5 min-w-0">
          <MealCompositionLanes
            dayPlan={activeDay}
            dayMeals={dayMeals}
            targets={activePlan.targets}
            allocations={activePlan.mealAllocations}
            selectedSlotId={activeSlot?.id ?? ''}
            isActivePlan={activePlan.status === 'active'}
            onSelectSlot={handleSelectSlot}
            onAddSlot={(title, time, recipeId) => {
              const id = addComposerMealSlot(activeDateKey, title, time, recipeId);
              if (id) setSelectedSlotId(id);
            }}
            onRemoveSlot={(slotId) => removeComposerMealSlot(activeDateKey, slotId)}
            onConfirmMealConsumed={confirmMealConsumed}
            onSetMealPartial={setMealPartial}
            onSkipMeal={skipMeal}
            onRestoreMealPlanned={restoreMealPlanned}
          />

          {activeSlot && (
            <RecipeProportionMatrix
              slot={activeSlot}
              onChangeYield={(recipeId, targetServings) =>
                setComposerSlotRecipeYield(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  targetServings,
                )
              }
              onChangeAdjustmentMode={(recipeId, mode, resetToScaled) =>
                setComposerRecipeAdjustmentMode(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  mode,
                  resetToScaled,
                )
              }
              onUpdateIngredient={(recipeId, ingredientId, patch) =>
                updateComposerIngredient(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  ingredientId,
                  patch,
                )
              }
              onAddIngredient={(recipeId, foodId, quantityG) =>
                addIngredientToComposerRecipe(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  foodId,
                  quantityG,
                )
              }
              onRemoveIngredient={(recipeId, ingredientId) =>
                removeIngredientFromComposerRecipe(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  ingredientId,
                )
              }
              onSwapRecipe={(recipeId, newCatalogRecipeId) =>
                swapComposerSlotRecipe(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  newCatalogRecipeId,
                )
              }
            />
          )}
        </div>

        <div ref={balancePanelRef} className="lg:sticky lg:top-24">
          <LiveBalancePanel
            plan={activePlan}
            dayPlan={activeDay}
            selectedSlotId={activeSlot?.id ?? ''}
            goalFocus={goalFocus}
            isOptimizing={isOptimizing}
            isIntakeDayConfirmed={isIntakeDayConfirmed}
            canConfirmIntakeDay={canConfirmIntakeDay}
            intakeFeedback={intakeFeedback}
            onChangeGoalFocus={setGoalFocus}
            onSimulateBalance={handleSimulateBalance}
            onUpdateAllocations={(next) => updateComposerMealAllocations(activePlan.id, next)}
            onSaveVariant={(name) => saveCompositionVariant(activeDateKey, name)}
            onActivateVariant={(variantId) => activateCompositionVariant(activeDateKey, variantId)}
            onDeleteVariant={deleteCompositionVariant}
            onConfirmIntakeDay={() => {
              const result = confirmIntakeDay(activeDateKey);
              setIntakeFeedback(
                result.ok
                  ? 'Dia confirmado. Será usado quando houver histórico suficiente.'
                  : result.error,
              );
            }}
          />
        </div>
      </div>

      <ComposerActionDock
        planned={daySummary.macros}
        targets={activePlan.targets}
        isOptimizing={isOptimizing}
        onSimulateBalance={() => void handleSimulateBalance('day')}
        onJumpToBalance={() =>
          balancePanelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
        }
      />
    </div>
  );
}
