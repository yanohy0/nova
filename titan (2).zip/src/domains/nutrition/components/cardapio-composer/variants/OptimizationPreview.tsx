import { memo, useState } from 'react';
import { ArrowRight, BookmarkPlus, Check, Sparkles, X } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import type {
  DiscreteSubstitutionProposal,
  OptimizationProposal,
  SolverCertificate,
} from '../../../domain/entities/nutrient';

interface OptimizationPreviewProps {
  proposal: OptimizationProposal;
  substitutions: readonly DiscreteSubstitutionProposal[];
  onApplyProposal: () => void;
  onSaveAsVariant: (name: string) => void;
  onApplyDiscreteSubstitution: (sub: DiscreteSubstitutionProposal) => void;
  onDiscard: () => void;
}

const CERTIFICATE_LABELS: Record<SolverCertificate, { label: string; colorClass: string }> = {
  optimal: {
    label: 'Ótimo convexo atingido',
    colorClass: 'text-[var(--titan-status-success)]',
  },
  feasible: {
    label: 'Melhor solução viável',
    colorClass: 'text-[var(--titan-champagne)]',
  },
  approximate: {
    label: 'Aproximação sujeita a restrições',
    colorClass: 'text-[var(--titan-status-warning)]',
  },
};

export const OptimizationPreview = memo(function OptimizationPreview({
  proposal,
  substitutions,
  onApplyProposal,
  onSaveAsVariant,
  onApplyDiscreteSubstitution,
  onDiscard,
}: OptimizationPreviewProps) {
  const [variantName, setVariantName] = useState(
    `Ajuste equilibrado (${Math.round(proposal.afterMacros.kcal)} kcal)`,
  );
  const [showAllChanges, setShowAllChanges] = useState(false);

  const cert = CERTIFICATE_LABELS[proposal.certificate];
  const visibleChanges = showAllChanges ? proposal.changes : proposal.changes.slice(0, 6);
  const afterDeltaKcal = Math.round(proposal.afterMacros.kcal - proposal.targets.kcal);

  return (
    <Surface
      data-elevation="2"
      aria-label="Prévia de ajuste nutricional"
      className="p-4 sm:p-5 space-y-4 border-[var(--titan-champagne)]/45"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-mono-metric">
            <span className={`font-semibold ${cert.colorClass}`}>{cert.label}</span>
            <span className="text-[var(--titan-text-muted)]">·</span>
            <span className="text-[var(--titan-text-muted)]">
              {proposal.solveDurationMs.toFixed(1)} ms
            </span>
          </div>
          <h3 className="text-base font-semibold text-[var(--titan-text-primary)] mt-1">
            Prévia da otimização contínua
          </h3>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5 leading-relaxed">
            {proposal.explanation}
          </p>
        </div>

        <button
          type="button"
          onClick={onDiscard}
          aria-label="Descartar simulação"
          className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Before vs After Summary Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 rounded-2xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] p-3 font-mono-metric">
        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            Energia
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
            {Math.round(proposal.beforeMacros.kcal)} <ArrowRight className="inline w-3 h-3" />{' '}
            <strong className="text-[var(--titan-text-primary)]">
              {Math.round(proposal.afterMacros.kcal)} kcal
            </strong>
          </p>
          <p className="text-[10px] text-[var(--titan-text-muted)]">
            Alvo {afterDeltaKcal >= 0 ? `+${afterDeltaKcal}` : afterDeltaKcal} kcal
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-accent)]">
            Proteína
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
            {proposal.beforeMacros.proteinG.toFixed(0)} <ArrowRight className="inline w-3 h-3" />{' '}
            <strong className="text-[var(--titan-text-primary)]">
              {proposal.afterMacros.proteinG.toFixed(0)} g
            </strong>
          </p>
          <p className="text-[10px] text-[var(--titan-text-muted)]">
            Alvo {proposal.targets.proteinG} g
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-info)]">
            Carboidratos
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
            {proposal.beforeMacros.carbsG.toFixed(0)} <ArrowRight className="inline w-3 h-3" />{' '}
            <strong className="text-[var(--titan-text-primary)]">
              {proposal.afterMacros.carbsG.toFixed(0)} g
            </strong>
          </p>
          <p className="text-[10px] text-[var(--titan-text-muted)]">
            Alvo {proposal.targets.carbsG} g
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-copper)]">
            Gorduras
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
            {proposal.beforeMacros.fatG.toFixed(0)} <ArrowRight className="inline w-3 h-3" />{' '}
            <strong className="text-[var(--titan-text-primary)]">
              {proposal.afterMacros.fatG.toFixed(0)} g
            </strong>
          </p>
          <p className="text-[10px] text-[var(--titan-text-muted)]">
            Alvo {proposal.targets.fatG} g
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-champagne)]">
            Desvio D
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
            {proposal.weightedDeviationBeforePercent.toFixed(1)}% <ArrowRight className="inline w-3 h-3" />{' '}
            <strong className="text-[var(--titan-text-primary)]">
              {proposal.weightedDeviationAfterPercent.toFixed(1)}%
            </strong>
          </p>
          <p className="text-[10px] text-[var(--titan-text-muted)]">
            {proposal.adjustedCount} ajust. · {proposal.lockedCount} fixo(s)
          </p>
        </div>
      </div>

      {/* Per-ingredient Proposed Mass Changes */}
      {proposal.changes.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
              Ajustes por ingrediente ({proposal.changes.filter((c) => Math.abs(c.deltaG) >= 0.5).length} modificados)
            </h4>
            {proposal.changes.length > 6 && (
              <button
                type="button"
                onClick={() => setShowAllChanges((prev) => !prev)}
                className="text-xs text-[var(--titan-champagne)] min-h-[36px] px-2"
              >
                {showAllChanges ? 'Ver menos' : `Ver todos (${proposal.changes.length})`}
              </button>
            )}
          </div>

          <div className="divide-y divide-[var(--titan-border-subtle)] rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)]">
            {visibleChanges.map((change) => (
              <div
                key={`${change.slotId}-${change.ingredientId}`}
                className="px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs"
              >
                <div className="min-w-0">
                  <p className="font-medium text-[var(--titan-text-primary)] truncate">
                    {change.foodName}
                  </p>
                  <p className="text-[11px] text-[var(--titan-text-muted)]">
                    {change.slotTitle}
                    {change.atUpperBound ? ' · limite máx.' : change.atLowerBound ? ' · limite mín.' : ''}
                  </p>
                </div>
                <div className="font-mono-metric text-right shrink-0">
                  <span className="text-[var(--titan-text-secondary)]">
                    {change.currentQuantityG} g <ArrowRight className="inline w-3 h-3" />{' '}
                  </span>
                  <strong className="text-[var(--titan-text-primary)]">
                    {change.proposedQuantityG} g
                  </strong>
                  <span
                    className={`ml-2 text-[11px] ${
                      change.deltaG > 0
                        ? 'text-[var(--titan-champagne)]'
                        : change.deltaG < 0
                          ? 'text-[var(--titan-info)]'
                          : 'text-[var(--titan-text-muted)]'
                    }`}
                  >
                    {change.deltaG > 0 ? `+${change.deltaG}` : change.deltaG} g
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Discrete Recipe Swap Proposals (separated from continuous QP) */}
      {substitutions.length > 0 && (
        <div className="space-y-2 pt-2 border-t border-[var(--titan-border-subtle)]">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            <Sparkles className="w-3.5 h-3.5 text-[var(--titan-champagne)]" aria-hidden="true" />
            <span>Substituições discretas sugeridas (opcional)</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {substitutions.slice(0, 2).map((sub) => (
              <div
                key={sub.id}
                className="rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] p-3 flex flex-col justify-between gap-2"
              >
                <div>
                  <p className="text-[10px] font-mono-metric uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
                    {sub.slotTitle} · {sub.sourceSummary}
                  </p>
                  <p className="text-xs font-medium text-[var(--titan-text-primary)] mt-0.5">
                    Trocar por {sub.candidateRecipeName}
                  </p>
                  <p className="text-[11px] font-mono-metric text-[var(--titan-text-secondary)] mt-1">
                    Dia projetado: {Math.round(sub.projectedDayMacros.kcal)} kcal · P{' '}
                    {sub.projectedDayMacros.proteinG.toFixed(0)} g
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onApplyDiscreteSubstitution(sub)}
                  className="titan-button titan-button--secondary !min-h-[40px] !px-3 !text-xs w-full"
                >
                  Aplicar troca nesta refeição
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Save Variant or Apply Proposal Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pt-2 border-t border-[var(--titan-border-subtle)]">
        <label className="text-xs text-[var(--titan-text-secondary)] flex-1">
          Nome para salvar como variante
          <input
            type="text"
            maxLength={80}
            value={variantName}
            onChange={(event) => setVariantName(event.target.value)}
            className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-[var(--titan-text-primary)]"
          />
        </label>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onDiscard}
            className="titan-button titan-button--ghost !min-h-[44px] !px-3.5 !text-xs"
          >
            Descartar
          </button>
          <button
            type="button"
            disabled={!variantName.trim()}
            onClick={() => onSaveAsVariant(variantName)}
            className="titan-button titan-button--secondary !min-h-[44px] !px-3.5 !text-xs disabled:opacity-45"
          >
            <BookmarkPlus className="w-4 h-4" aria-hidden="true" />
            <span>Salvar variante</span>
          </button>
          <button
            type="button"
            onClick={onApplyProposal}
            className="titan-button titan-button--primary !min-h-[44px] !px-4 !text-xs"
          >
            <Check className="w-4 h-4" aria-hidden="true" />
            <span>Aplicar ao plano</span>
          </button>
        </div>
      </div>
    </Surface>
  );
});
