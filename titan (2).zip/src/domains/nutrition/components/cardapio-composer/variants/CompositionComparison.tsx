import { memo, useMemo, useState } from 'react';
import { X } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import type {
  CardapioPlan,
  ComposerDayPlan,
} from '../../../domain/entities/nutrient';
import { computeCompositionDiff } from '../../../domain/rules/cardapio-composer-engine';

interface CompositionComparisonProps {
  plans: readonly CardapioPlan[];
  activePlan: CardapioPlan;
  activeDay: ComposerDayPlan;
  activeDateKey: string;
  onClose: () => void;
}

export const CompositionComparison = memo(function CompositionComparison({
  plans,
  activePlan,
  activeDay,
  activeDateKey,
  onClose,
}: CompositionComparisonProps) {
  const otherPlans = plans.filter((p) => p.id !== activePlan.id);
  const [targetRef, setTargetRef] = useState<string>(() => {
    if (activePlan.variants[0]) return `var:${activePlan.variants[0].id}`;
    if (otherPlans[0]) return `plan:${otherPlans[0].id}`;
    return 'self';
  });

  const candidateSelection = useMemo(() => {
    if (targetRef.startsWith('var:')) {
      const id = targetRef.slice(4);
      const variant = activePlan.variants.find((v) => v.id === id);
      if (variant) {
        return {
          label: `Variante: ${variant.name}`,
          dayPlan: variant.dayPlan,
        };
      }
    }
    if (targetRef.startsWith('plan:')) {
      const id = targetRef.slice(5);
      const plan = plans.find((p) => p.id === id);
      const day = plan?.days[activeDateKey] ?? (plan ? Object.values(plan.days)[0] : undefined);
      if (plan && day) {
        return {
          label: `${plan.name} (Rev. ${String(plan.revision).padStart(2, '0')})`,
          dayPlan: day,
        };
      }
    }
    return {
      label: activePlan.name,
      dayPlan: activeDay,
    };
  }, [activeDateKey, activeDay, activePlan.name, activePlan.variants, plans, targetRef]);

  const diff = useMemo(
    () => computeCompositionDiff(activeDay, candidateSelection.dayPlan),
    [activeDay, candidateSelection.dayPlan],
  );

  const fmtSigned = (value: number, unit: string, decimals = 0) => {
    const abs = decimals > 0 ? Math.abs(value).toFixed(decimals) : Math.round(Math.abs(value));
    const sign = value > 0 ? '+' : value < 0 ? '−' : '';
    return `${sign}${abs} ${unit}`;
  };

  return (
    <Surface
      data-elevation="2"
      aria-label="Comparação lado a lado"
      className="p-4 sm:p-5 space-y-4 border-[var(--titan-accent)]/40"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="titan-eyebrow">Comparação estrutural</p>
          <h2 className="text-lg font-semibold text-[var(--titan-text-primary)] mt-0.5">
            Comparar planos e variantes
          </h2>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            Base atual: {activePlan.name} ({activeDateKey})
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            aria-label="Selecionar plano ou variante para comparar"
            value={targetRef}
            onChange={(event) => setTargetRef(event.target.value)}
            className="min-h-[44px] rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-sm text-[var(--titan-text-primary)]"
          >
            {otherPlans.map((plan) => (
              <option key={plan.id} value={`plan:${plan.id}`}>
                Plano: {plan.name}
              </option>
            ))}
            {activePlan.variants.map((variant) => (
              <option key={variant.id} value={`var:${variant.id}`}>
                Variante: {variant.name}
              </option>
            ))}
            {otherPlans.length === 0 && activePlan.variants.length === 0 && (
              <option value="self">Nenhum outro plano ou variante salvo</option>
            )}
          </select>

          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar comparação"
            className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Side-by-side Macro Totals & Deltas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 rounded-2xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] p-3.5 font-mono-metric">
        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            Atual · {activePlan.name}
          </p>
          <p className="text-base font-semibold text-[var(--titan-text-primary)] mt-1">
            {Math.round(diff.baselineMacros.kcal)} kcal
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            P {diff.baselineMacros.proteinG.toFixed(0)} g · C {diff.baselineMacros.carbsG.toFixed(0)} g · G{' '}
            {diff.baselineMacros.fatG.toFixed(0)} g
          </p>
          <p className="text-[11px] text-[var(--titan-text-muted)] mt-1">
            Desvio D: {diff.baselineDeviationPercent.toFixed(1)}% · Fontes:{' '}
            {diff.baselineSources.join(', ') || '—'}
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-champagne)]">
            Comparado · {candidateSelection.label}
          </p>
          <p className="text-base font-semibold text-[var(--titan-text-primary)] mt-1">
            {Math.round(diff.candidateMacros.kcal)} kcal
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            P {diff.candidateMacros.proteinG.toFixed(0)} g · C {diff.candidateMacros.carbsG.toFixed(0)} g · G{' '}
            {diff.candidateMacros.fatG.toFixed(0)} g
          </p>
          <p className="text-[11px] text-[var(--titan-text-muted)] mt-1">
            Desvio D: {diff.candidateDeviationPercent.toFixed(1)}% · Fontes:{' '}
            {diff.candidateSources.join(', ') || '—'}
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            Diferença líquida (Comparado − Atual)
          </p>
          <p className="text-base font-semibold text-[var(--titan-champagne)] mt-1">
            {fmtSigned(diff.deltaMacros.kcal, 'kcal')}
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            P {fmtSigned(diff.deltaMacros.proteinG, 'g')} · C {fmtSigned(diff.deltaMacros.carbsG, 'g')} · G{' '}
            {fmtSigned(diff.deltaMacros.fatG, 'g')}
          </p>
        </div>
      </div>

      {/* Added / Removed Recipes + Ingredient Gram Diffs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Diferenças por alimento (gramas)
          </h3>
          <div className="max-h-60 overflow-y-auto rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] divide-y divide-[var(--titan-border-subtle)]">
            {diff.ingredientDiffs.filter((row) => row.status !== 'unchanged').length === 0 ? (
              <p className="p-3 text-xs text-[var(--titan-text-muted)]">
                Nenhuma diferença de peso entre os ingredientes selecionados.
              </p>
            ) : (
              diff.ingredientDiffs
                .filter((row) => row.status !== 'unchanged')
                .map((row) => (
                  <div
                    key={row.foodId}
                    className="px-3 py-2 flex items-center justify-between gap-2 text-xs"
                  >
                    <span className="text-[var(--titan-text-primary)] truncate">{row.foodName}</span>
                    <span className="font-mono-metric text-[var(--titan-text-secondary)] shrink-0">
                      {row.baselineGrams} g → {row.candidateGrams} g{' '}
                      <strong
                        className={
                          row.deltaGrams > 0
                            ? 'text-[var(--titan-champagne)]'
                            : 'text-[var(--titan-info)]'
                        }
                      >
                        ({row.deltaGrams > 0 ? `+${row.deltaGrams}` : row.deltaGrams} g)
                      </strong>
                    </span>
                  </div>
                ))
            )}
          </div>
        </div>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
              Receitas adicionadas / removidas
            </h3>
            {diff.addedRecipes.length === 0 && diff.removedRecipes.length === 0 ? (
              <p className="text-xs text-[var(--titan-text-muted)]">
                Mesmas receitas nos dois cenários; apenas as quantidades variam.
              </p>
            ) : (
              <div className="text-xs space-y-1">
                {diff.addedRecipes.map((name) => (
                  <p key={`add-${name}`} className="text-[var(--titan-status-success)]">
                    + {name}
                  </p>
                ))}
                {diff.removedRecipes.map((name) => (
                  <p key={`rem-${name}`} className="text-[var(--titan-status-error)]">
                    − {name}
                  </p>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-1.5 pt-2 border-t border-[var(--titan-border-subtle)]">
            <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
              Micronutrientes quantificados
            </h3>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono-metric">
              {diff.micronutrientDeltas.map((m) => (
                <div
                  key={m.nutrientId}
                  className="flex items-baseline justify-between border-b border-[var(--titan-border-subtle)] pb-1"
                >
                  <span className="text-[var(--titan-text-muted)]">{m.label}</span>
                  <span className="text-[var(--titan-text-primary)]">
                    {m.baselineValue !== null ? m.baselineValue.toFixed(1) : 'NA'} →{' '}
                    {m.candidateValue !== null ? m.candidateValue.toFixed(1) : 'NA'} {m.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Surface>
  );
});
