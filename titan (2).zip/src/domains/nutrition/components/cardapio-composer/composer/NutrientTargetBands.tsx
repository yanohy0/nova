import { memo, useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import type {
  ComposerMacroTotals,
  NutrientId,
  NutritionTargets,
} from '../../../domain/entities/nutrient';
import {
  KEY_COMPOSER_MICRONUTRIENTS,
  MICRONUTRIENT_PT_LABELS,
} from '../../../domain/rules/cardapio-composer-engine';
import { formatKcal } from '@/src/shared/utils/formatters';

interface NutrientTargetBandsProps {
  planned: ComposerMacroTotals;
  targets: NutritionTargets;
  micronutrients: Record<NutrientId, { value: number | null; unit: string; quantifiedCount: number }>;
  coveragePercent: number;
  unresolvedCount: number;
  compact?: boolean;
}

interface BandRowProps {
  label: string;
  unit: string;
  value: number;
  target: number;
  min?: number | null;
  max?: number | null;
  colorVar: string;
  decimalPlaces?: number;
}

const TargetBandRow = memo(function TargetBandRow({
  label,
  unit,
  value,
  target,
  min,
  max,
  colorVar,
  decimalPlaces = 0,
}: BandRowProps) {
  const hasMin = typeof min === 'number' && Number.isFinite(min) && min > 0;
  const hasMax = typeof max === 'number' && Number.isFinite(max) && max > 0;
  const ceiling = Math.max(target * 1.28, hasMax ? max * 1.12 : 0, value * 1.08, 1);

  const fillPct = Math.max(0, Math.min(100, (value / ceiling) * 100));
  const targetPct = Math.max(0, Math.min(100, (target / ceiling) * 100));
  const minPct = hasMin ? Math.max(0, Math.min(100, (min / ceiling) * 100)) : null;
  const maxPct = hasMax ? Math.max(0, Math.min(100, (max / ceiling) * 100)) : null;

  const delta = value - target;
  const formattedVal = decimalPlaces > 0 ? value.toFixed(decimalPlaces) : Math.round(value).toLocaleString('pt-BR');
  const formattedTarget = decimalPlaces > 0 ? target.toFixed(decimalPlaces) : Math.round(target).toLocaleString('pt-BR');
  const formattedDelta =
    Math.abs(delta) < 0.5
      ? 'No alvo'
      : `${delta > 0 ? '+' : '−'}${Math.round(Math.abs(delta)).toLocaleString('pt-BR')} ${unit}`;

  const withinCustomBounds =
    (!hasMin || value >= min) && (!hasMax || value <= max);

  return (
    <div className="space-y-1.5">
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-medium text-[var(--titan-text-secondary)]">{label}</span>
        <div className="flex items-baseline gap-2 font-mono-metric">
          <span className="text-sm font-semibold text-[var(--titan-text-primary)]">
            {formattedVal} {unit}
          </span>
          <span className="text-[11px] text-[var(--titan-text-muted)]">
            / {formattedTarget} {unit}
          </span>
          <span
            className={`text-[11px] ${
              Math.abs(delta) <= Math.max(4, target * 0.03) || (hasMin && hasMax && withinCustomBounds)
                ? 'text-[var(--titan-status-success)]'
                : delta > 0
                  ? 'text-[var(--titan-champagne)]'
                  : 'text-[var(--titan-text-secondary)]'
            }`}
          >
            {formattedDelta}
          </span>
        </div>
      </div>

      {/* Horizontal precision band (never rings/donuts) */}
      <div
        className="relative h-3.5 w-full rounded-[5px] border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] overflow-hidden"
        role="img"
        aria-label={`${label}: ${formattedVal} de ${formattedTarget} ${unit}`}
      >
        {/* Optional configured tolerance corridor (only rendered when bounds exist) */}
        {minPct !== null && maxPct !== null && maxPct > minPct && (
          <div
            aria-hidden="true"
            style={{ left: `${minPct}%`, width: `${maxPct - minPct}%` }}
            className="absolute inset-y-0 bg-[rgba(241,240,232,0.06)] border-x border-[rgba(200,173,122,0.28)]"
          />
        )}

        {/* Active composition fill */}
        <div
          aria-hidden="true"
          style={{
            width: `${fillPct}%`,
            background: colorVar,
          }}
          className="absolute inset-y-[2px] left-[2px] rounded-[3px] transition-[width] duration-150"
        />

        {/* Target point vertical hairline */}
        <div
          aria-hidden="true"
          style={{ left: `${targetPct}%` }}
          className="absolute inset-y-0 w-[2px] -translate-x-1/2 bg-[var(--titan-champagne)]"
        />
      </div>

      {(hasMin || hasMax) && (
        <p className="text-[10px] font-mono-metric text-[var(--titan-text-muted)]">
          Faixa configurada: {hasMin ? `${Math.round(min)} ${unit}` : '—'} a {hasMax ? `${Math.round(max)} ${unit}` : '—'}
        </p>
      )}
    </div>
  );
});

export const NutrientTargetBands = memo(function NutrientTargetBands({
  planned,
  targets,
  micronutrients,
  coveragePercent,
  unresolvedCount,
  compact = false,
}: NutrientTargetBandsProps) {
  const [showMicros, setShowMicros] = useState(false);
  const energyDelta = Math.round(planned.kcal - targets.kcal);

  return (
    <div className="space-y-4">
      {/* Primary Energy Readout + Band */}
      <div className="space-y-2.5">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)] font-semibold">
              Energia planejada
            </p>
            <p className="text-3xl font-semibold font-mono-metric text-[var(--titan-text-primary)] leading-none mt-1">
              {formatKcal(Math.round(planned.kcal))} <span className="text-sm font-normal text-[var(--titan-text-muted)]">kcal</span>
            </p>
          </div>
          <div className="text-right font-mono-metric">
            <p className="text-[11px] text-[var(--titan-text-muted)]">
              Alvo {formatKcal(targets.kcal)} kcal
            </p>
            <p
              className={`text-sm font-semibold mt-0.5 ${
                Math.abs(energyDelta) <= 60
                  ? 'text-[var(--titan-status-success)]'
                  : energyDelta > 0
                    ? 'text-[var(--titan-champagne)]'
                    : 'text-[var(--titan-info)]'
              }`}
            >
              {energyDelta === 0
                ? '0 kcal'
                : `${energyDelta > 0 ? '+' : '−'}${formatKcal(Math.abs(energyDelta))} kcal`}
            </p>
          </div>
        </div>

        <TargetBandRow
          label="Balanço energético"
          unit="kcal"
          value={planned.kcal}
          target={targets.kcal}
          min={targets.kcalMin}
          max={targets.kcalMax}
          colorVar="rgba(241, 240, 232, 0.85)"
        />
      </div>

      {/* Macro Target Bands */}
      <div className={`space-y-3 pt-3 border-t border-[var(--titan-border-subtle)] ${compact ? 'text-xs' : ''}`}>
        <TargetBandRow
          label="Proteína"
          unit="g"
          value={planned.proteinG}
          target={targets.proteinG}
          min={targets.proteinMinG}
          max={targets.proteinMaxG}
          colorVar="var(--titan-macro-protein)"
        />
        <TargetBandRow
          label="Carboidratos"
          unit="g"
          value={planned.carbsG}
          target={targets.carbsG}
          min={targets.carbsMinG}
          max={targets.carbsMaxG}
          colorVar="var(--titan-macro-carbs)"
        />
        <TargetBandRow
          label="Gorduras"
          unit="g"
          value={planned.fatG}
          target={targets.fatG}
          min={targets.fatMinG}
          max={targets.fatMaxG}
          colorVar="var(--titan-macro-fat)"
        />
      </div>

      {/* Traceable Coverage & Expandable Micronutrient Drawer */}
      <div className="pt-2 border-t border-[var(--titan-border-subtle)]">
        <button
          type="button"
          onClick={() => setShowMicros((prev) => !prev)}
          aria-expanded={showMicros}
          className="w-full min-h-[44px] flex items-center justify-between text-left text-xs text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)]"
        >
          <span>
            Micronutrientes (TBCA / OFF) · Cobertura {coveragePercent.toFixed(0)}%
            {unresolvedCount > 0 ? ` · ${unresolvedCount} sem base` : ''}
          </span>
          {showMicros ? <ChevronUp className="w-4 h-4 shrink-0" /> : <ChevronDown className="w-4 h-4 shrink-0" />}
        </button>

        {showMicros && (
          <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 pb-1">
            {KEY_COMPOSER_MICRONUTRIENTS.map((id) => {
              const info = MICRONUTRIENT_PT_LABELS[id];
              const reading = micronutrients[id];
              return (
                <div
                  key={id}
                  className="flex items-baseline justify-between border-b border-[var(--titan-border-subtle)] py-1.5 text-[11px]"
                >
                  <span className="text-[var(--titan-text-secondary)]">{info.label}</span>
                  <span className="font-mono-metric text-[var(--titan-text-primary)]">
                    {reading.value !== null
                      ? `${reading.value >= 100 ? Math.round(reading.value) : reading.value.toFixed(1)} ${reading.unit}`
                      : 'Não analisado'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
});
