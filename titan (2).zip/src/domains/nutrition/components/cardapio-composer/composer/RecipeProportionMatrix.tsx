import { memo, useDeferredValue, useMemo, useState } from 'react';
import { ArrowLeftRight, Minus, Plus, RotateCcw, Search } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import { RECIPE_CATALOG } from '../../../data/recipes/recipe-catalog';
import { getSharedFoodSearchIndex } from '../../../data/sources/food-search-index';
import { searchFoodIndex } from '../../../domain/rules/food-search';
import type {
  ComposerAdjustmentMode,
  ComposerMealSlot,
  IngredientLockMode,
} from '../../../domain/entities/nutrient';
import {
  computeRecipeNutrition,
  getRecipeScaleFactor,
} from '../../../domain/rules/cardapio-composer-engine';
import { ProportionRail } from './ProportionRail';

interface RecipeProportionMatrixProps {
  slot: ComposerMealSlot;
  onChangeYield: (recipeId: string, nextTargetServings: number) => void;
  onChangeAdjustmentMode: (
    recipeId: string,
    mode: ComposerAdjustmentMode,
    resetToScaled?: boolean,
  ) => void;
  onUpdateIngredient: (
    recipeId: string,
    ingredientId: string,
    patch: { currentQuantityG?: number; mode?: IngredientLockMode },
  ) => void;
  onAddIngredient: (recipeId: string, foodId: string, quantityG: number) => boolean;
  onRemoveIngredient: (recipeId: string, ingredientId: string) => void;
  onSwapRecipe: (recipeId: string, newCatalogRecipeId: string) => void;
}

const YIELD_PRESETS = [0.5, 1, 1.25, 1.5, 2] as const;

const ADJUSTMENT_MODES: ReadonlyArray<{
  id: ComposerAdjustmentMode;
  label: string;
  hint: string;
}> = [
  {
    id: 'proportional',
    label: 'Proporcional',
    hint: 'Escala todos os ingredientes pelo fator de rendimento (xᵢ = s · qᵢ).',
  },
  {
    id: 'balanced',
    label: 'Equilibrado',
    hint: 'Permite ajustes por ingrediente e otimização contínua preservando fixos.',
  },
  {
    id: 'flexible',
    label: 'Flexível',
    hint: 'Habilita substituição discreta de receitas e adição livre de alimentos.',
  },
];

export const RecipeProportionMatrix = memo(function RecipeProportionMatrix({
  slot,
  onChangeYield,
  onChangeAdjustmentMode,
  onUpdateIngredient,
  onAddIngredient,
  onRemoveIngredient,
  onSwapRecipe,
}: RecipeProportionMatrixProps) {
  const recipe = slot.recipes[0];
  const [swapOpen, setSwapOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [foodQuery, setFoodQuery] = useState('');
  const [selectedFoodId, setSelectedFoodId] = useState('');
  const [addGrams, setAddGrams] = useState(100);
  const deferredFoodQuery = useDeferredValue(foodQuery);

  const foodIndex = useMemo(
    () => (addOpen ? getSharedFoodSearchIndex() : null),
    [addOpen],
  );
  const searchResults = useMemo(
    () => (foodIndex && deferredFoodQuery.trim() ? searchFoodIndex(foodIndex, deferredFoodQuery, 10) : []),
    [deferredFoodQuery, foodIndex],
  );

  if (!recipe) {
    return (
      <Surface className="p-5 text-sm text-[var(--titan-text-secondary)]">
        Selecione ou adicione uma refeição para compor suas proporções.
      </Surface>
    );
  }

  const scaleFactor = getRecipeScaleFactor(recipe);
  const summary = computeRecipeNutrition(recipe);
  const activeModeHint =
    ADJUSTMENT_MODES.find((m) => m.id === recipe.adjustmentMode)?.hint ?? '';

  const handleConfirmAddFood = () => {
    if (!selectedFoodId) return;
    if (onAddIngredient(recipe.id, selectedFoodId, addGrams)) {
      setFoodQuery('');
      setSelectedFoodId('');
      setAddGrams(100);
      setAddOpen(false);
    }
  };

  return (
    <Surface data-elevation="2" className="p-4 sm:p-5 space-y-4">
      {/* Header: Recipe Identity + Swap + Adjustment Mode */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
            <span className="text-[var(--titan-champagne)]">{slot.time}</span>
            <span>·</span>
            <span className="uppercase tracking-[0.08em]">{slot.title}</span>
            <span>·</span>
            <span>Fontes: {summary.sources.join(' · ') || 'TBCA'}</span>
          </div>
          <h3 className="text-lg font-semibold text-[var(--titan-text-primary)] mt-1">
            {recipe.name}
          </h3>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
            {Math.round(summary.macros.kcal)} kcal · P {summary.macros.proteinG.toFixed(1)} g · C{' '}
            {summary.macros.carbsG.toFixed(1)} g · G {summary.macros.fatG.toFixed(1)} g ·{' '}
            {Math.round(summary.totalGrams)} g totais
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setSwapOpen((prev) => !prev)}
            aria-expanded={swapOpen}
            className="titan-button titan-button--secondary !min-h-[44px] !px-3.5 !text-xs"
          >
            <ArrowLeftRight className="w-4 h-4" aria-hidden="true" />
            <span>Trocar receita</span>
          </button>

          <button
            type="button"
            onClick={() => setAddOpen((prev) => !prev)}
            aria-expanded={addOpen}
            className="titan-button titan-button--mineral !min-h-[44px] !px-3.5 !text-xs"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Ingrediente</span>
          </button>
        </div>
      </div>

      {/* Inline Recipe Catalog Swap Picker */}
      {swapOpen && (
        <div className="rounded-2xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] p-3 space-y-2">
          <p className="text-xs font-semibold text-[var(--titan-text-primary)]">
            Substituir receita mantendo horário e estrutura do plano (catálogo intacto)
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto">
            {RECIPE_CATALOG.map((candidate) => (
              <button
                key={candidate.id}
                type="button"
                onClick={() => {
                  onSwapRecipe(recipe.id, candidate.id);
                  setSwapOpen(false);
                }}
                className={`min-h-[48px] rounded-xl border p-2.5 text-left transition-colors ${
                  candidate.id === recipe.sourceRecipeId
                    ? 'border-[var(--titan-champagne)]/70 bg-[var(--titan-surface-raised)]'
                    : 'border-[var(--titan-border-subtle)] bg-[var(--titan-surface)] hover:border-[var(--titan-accent)]/40'
                }`}
              >
                <span className="block text-xs font-semibold text-[var(--titan-text-primary)]">
                  {candidate.name}
                </span>
                <span className="block text-[11px] text-[var(--titan-text-muted)] mt-0.5">
                  {candidate.description}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Yield Scaling Control + Adjustment Mode + Weighted Deviation Metric D */}
      <div className="grid grid-cols-1 lg:grid-cols-[auto_1fr] gap-3 items-center rounded-2xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] p-3">
        {/* Yield Control */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            Rendimento
          </span>
          <div className="flex items-center gap-1">
            <button
              type="button"
              aria-label="Reduzir rendimento em 0,25 porção"
              onClick={() => onChangeYield(recipe.id, Math.max(0.25, Number((recipe.targetServings - 0.25).toFixed(2))))}
              className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface)] text-[var(--titan-text-primary)] hover:border-[var(--titan-accent)]/45"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="min-w-[60px] text-center font-mono-metric text-sm font-semibold text-[var(--titan-text-primary)]">
              {scaleFactor.toFixed(2).replace('.', ',')}×
            </span>
            <button
              type="button"
              aria-label="Aumentar rendimento em 0,25 porção"
              onClick={() => onChangeYield(recipe.id, Math.min(4, Number((recipe.targetServings + 0.25).toFixed(2))))}
              className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface)] text-[var(--titan-text-primary)] hover:border-[var(--titan-accent)]/45"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          <div className="flex flex-wrap gap-1">
            {YIELD_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => onChangeYield(recipe.id, preset * recipe.baseServings)}
                className={`min-h-[36px] px-2 rounded-lg text-[11px] font-mono-metric border transition-colors ${
                  Math.abs(scaleFactor - preset) < 0.02
                    ? 'border-[var(--titan-champagne)]/70 bg-[var(--titan-surface-raised)] text-[var(--titan-text-primary)]'
                    : 'border-transparent text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]'
                }`}
              >
                {preset}×
              </button>
            ))}
          </div>
        </div>

        {/* 3 Adjustment Modes + Exact Deviation Formula Readout */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 lg:justify-end">
          <div role="group" aria-label="Modo de composição da receita" className="titan-segmented">
            {ADJUSTMENT_MODES.map((modeOpt) => {
              const active = recipe.adjustmentMode === modeOpt.id;
              return (
                <button
                  key={modeOpt.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() =>
                    onChangeAdjustmentMode(
                      recipe.id,
                      modeOpt.id,
                      modeOpt.id === 'proportional',
                    )
                  }
                  className={`titan-segment !min-h-[36px] !px-2.5 !text-xs ${active ? 'is-active' : ''}`}
                >
                  {modeOpt.label}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 font-mono-metric">
            <div className="text-right">
              <p className="text-xs font-semibold text-[var(--titan-text-primary)]">
                Desvio D:{' '}
                <span
                  className={
                    summary.weightedDeviationPercent === 0
                      ? 'text-[var(--titan-status-success)]'
                      : summary.weightedDeviationPercent <= 12
                        ? 'text-[var(--titan-champagne)]'
                        : 'text-[var(--titan-copper)]'
                  }
                >
                  {summary.weightedDeviationPercent.toFixed(1)}%
                </span>
              </p>
              <p className="text-[10px] text-[var(--titan-text-muted)]">
                Σ|xᵢ − qᵢʳᵉᶠ| / Σqᵢʳᵉᶠ
              </p>
            </div>
            {summary.weightedDeviationPercent > 0 && (
              <button
                type="button"
                title="Restaurar proporção escalada original"
                onClick={() => onChangeAdjustmentMode(recipe.id, 'proportional', true)}
                className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl border border-[var(--titan-border-subtle)] text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)]"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      <p className="text-[11px] text-[var(--titan-text-muted)]">{activeModeHint}</p>

      {/* Inline Add Ingredient Drawer (TBCA / Open Food Facts) */}
      {addOpen && (
        <div className="rounded-2xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] p-3.5 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-[1fr_110px_auto] gap-2.5 items-end">
            <label className="text-xs text-[var(--titan-text-secondary)]">
              Buscar alimento (TBCA / OFF)
              <div className="relative mt-1">
                <Search className="w-4 h-4 text-[var(--titan-text-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={foodQuery}
                  onChange={(event) => {
                    setFoodQuery(event.target.value);
                    setSelectedFoodId('');
                  }}
                  placeholder="Ex.: aveia, peito de frango, azeite"
                  className="w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] pl-9 pr-3 text-[var(--titan-text-primary)]"
                />
              </div>
            </label>
            <label className="text-xs text-[var(--titan-text-secondary)]">
              Gramas
              <BufferedNumberInput
                min={1}
                max={2000}
                step={5}
                value={addGrams}
                onCommit={setAddGrams}
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-3 font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>
            <button
              type="button"
              disabled={!selectedFoodId}
              onClick={handleConfirmAddFood}
              className="titan-button titan-button--primary !min-h-[44px] !px-4 !text-xs disabled:opacity-45"
            >
              Adicionar
            </button>
          </div>

          {foodQuery.trim() && (
            <div className="max-h-48 overflow-y-auto rounded-xl border border-[var(--titan-border-subtle)] divide-y divide-[var(--titan-border-subtle)]">
              {searchResults.length === 0 ? (
                <p className="p-3 text-xs text-[var(--titan-text-muted)]">
                  Nenhum alimento encontrado para "{foodQuery}".
                </p>
              ) : (
                searchResults.map((food) => (
                  <button
                    key={food.food_id}
                    type="button"
                    onClick={() => {
                      setSelectedFoodId(food.food_id);
                      setFoodQuery(food.name);
                    }}
                    className={`w-full p-2.5 text-left transition-colors ${
                      selectedFoodId === food.food_id
                        ? 'bg-[var(--titan-surface-raised)]'
                        : 'hover:bg-[var(--titan-surface)]'
                    }`}
                  >
                    <span className="block text-xs font-medium text-[var(--titan-text-primary)]">
                      {food.name}
                    </span>
                    <span className="block text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
                      {food.source_id} · {food.source_record_id} · {food.macros.kcalPerBasis} kcal/{food.macros.basisQuantityG} g
                    </span>
                  </button>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {/* Ingredients Proportion Matrix */}
      <div className="divide-y divide-[var(--titan-border-subtle)]">
        {recipe.ingredients.length === 0 ? (
          <p className="py-4 text-xs text-[var(--titan-text-muted)]">
            Nenhum ingrediente nesta refeição. Use "+ Ingrediente" para compor com alimentos reais.
          </p>
        ) : (
          recipe.ingredients.map((ingredient) => (
            <ProportionRail
              key={ingredient.id}
              ingredient={ingredient}
              scaleFactor={scaleFactor}
              onChangeQuantity={(quantityG) =>
                onUpdateIngredient(recipe.id, ingredient.id, {
                  currentQuantityG: quantityG,
                  mode: ingredient.mode === 'proportional' ? 'flexible' : ingredient.mode,
                })
              }
              onChangeMode={(mode) =>
                onUpdateIngredient(recipe.id, ingredient.id, { mode })
              }
              onRemove={
                recipe.ingredients.length > 1
                  ? () => onRemoveIngredient(recipe.id, ingredient.id)
                  : undefined
              }
            />
          ))
        )}
      </div>
    </Surface>
  );
});
