import { memo, useCallback, useId, useRef, useState } from 'react';
import { Lock, Scale, SlidersHorizontal, Trash2 } from 'lucide-react';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import type {
  IngredientAdjustment,
  IngredientLockMode,
} from '../../../domain/entities/nutrient';
import {
  computeIngredientNutritionImpact,
  getEffectiveIngredientBounds,
  getScaledReferenceGrams,
  roundGramsHalf,
} from '../../../domain/rules/cardapio-composer-engine';

interface ProportionRailProps {
  ingredient: IngredientAdjustment;
  scaleFactor: number;
  disabled?: boolean;
  onChangeQuantity: (quantityG: number) => void;
  onChangeMode: (mode: IngredientLockMode) => void;
  onRemove?: () => void;
}

const MODE_OPTIONS: ReadonlyArray<{
  mode: IngredientLockMode;
  label: string;
  shortLabel: string;
  icon: typeof Scale;
}> = [
  { mode: 'proportional', label: 'Proporcional ao rendimento', shortLabel: 'Prop.', icon: Scale },
  { mode: 'locked', label: 'Fixo (bloqueado no solver)', shortLabel: 'Fixo', icon: Lock },
  { mode: 'flexible', label: 'Flexível dentro da faixa', shortLabel: 'Flex.', icon: SlidersHorizontal },
];

export const ProportionRail = memo(function ProportionRail({
  ingredient,
  scaleFactor,
  disabled = false,
  onChangeQuantity,
  onChangeMode,
  onRemove,
}: ProportionRailProps) {
  const railRef = useRef<HTMLDivElement | null>(null);
  const [editingNumeric, setEditingNumeric] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const labelId = useId();

  const impact = computeIngredientNutritionImpact(ingredient, scaleFactor);
  const refG = getScaledReferenceGrams(ingredient, scaleFactor);
  const bounds = getEffectiveIngredientBounds(ingredient, scaleFactor);
  const span = Math.max(1, bounds.maxG - bounds.minG);
  const activeG =
    ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
      ? ingredient.currentQuantityG
      : (refG ?? bounds.minG);

  const clampedActive = Math.max(bounds.minG, Math.min(bounds.maxG, activeG));
  const activePct = ((clampedActive - bounds.minG) / span) * 100;
  const refPct = refG !== null ? Math.max(0, Math.min(100, ((refG - bounds.minG) / span) * 100)) : activePct;

  const isLocked = ingredient.mode === 'locked' || disabled;
  const deltaG = refG !== null ? Number((clampedActive - refG).toFixed(1)) : 0;
  const deltaPct = refG !== null && refG > 0 ? Math.round(((clampedActive - refG) / refG) * 100) : 0;

  const updateFromClientX = useCallback(
    (clientX: number) => {
      if (isLocked || !railRef.current || ingredient.quantityStatus !== 'known') return;
      const rect = railRef.current.getBoundingClientRect();
      if (rect.width <= 0) return;
      const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      let rawG = bounds.minG + ratio * span;
      // Gentle magnetic snap within +-2g of scaled recipe reference
      if (refG !== null && Math.abs(rawG - refG) <= 2) {
        rawG = refG;
      } else {
        rawG = roundGramsHalf(rawG);
      }
      const nextG = Math.max(bounds.minG, Math.min(bounds.maxG, rawG));
      if (nextG !== clampedActive) {
        onChangeQuantity(nextG);
      }
    },
    [bounds.maxG, bounds.minG, clampedActive, ingredient.quantityStatus, isLocked, onChangeQuantity, refG, span],
  );

  // Render honest non-numeric state for "to_taste" and "missing" ingredients
  if (ingredient.quantityStatus !== 'known') {
    return (
      <div className="py-3 border-b border-[var(--titan-border-subtle)] last:border-b-0 flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-medium text-[var(--titan-text-primary)] truncate">
            {impact.foodName}
          </p>
          <p className="text-[11px] text-[var(--titan-text-muted)]">
            {ingredient.quantityStatus === 'to_taste'
              ? 'Tempero / preparo a gosto · sem peso numérico'
              : 'Quantidade pendente · informe peso em gramas para incluir no cálculo'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {ingredient.quantityStatus === 'missing' && (
            <button
              type="button"
              onClick={() => onChangeQuantity(100)}
              className="titan-button titan-button--secondary !min-h-[44px] !px-3 !text-xs"
            >
              Definir gramas
            </button>
          )}
          <span className="text-xs font-mono-metric text-[var(--titan-text-muted)]">
            {ingredient.quantityStatus === 'to_taste' ? 'a gosto' : 'Quantidade pendente'}
          </span>
          {onRemove && (
            <button
              type="button"
              onClick={onRemove}
              aria-label={`Remover ${impact.foodName}`}
              className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-status-error)]"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    );
  }

  const fillStartPct = Math.min(refPct, activePct);
  const fillWidthPct = Math.abs(activePct - refPct);
  const isIncreased = clampedActive >= (refG ?? clampedActive);

  return (
    <div className="py-3.5 border-b border-[var(--titan-border-subtle)] last:border-b-0 space-y-2.5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
            <span id={labelId} className="text-sm font-medium text-[var(--titan-text-primary)]">
              {impact.foodName}
            </span>
            <span className="text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
              {impact.calculable
                ? `${impact.sourceId} · ${impact.sourceRecordId}`
                : 'Fonte não resolvida'}
              {ingredient.isCompositeDish ? ' · Prato composto' : ''}
            </span>
          </div>

          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-mono-metric text-[var(--titan-text-secondary)]">
            <span>
              Base escalada:{' '}
              <strong className="text-[var(--titan-text-primary)] font-medium">
                {refG !== null ? `${refG} g` : '—'}
              </strong>
            </span>
            <span>
              Faixa:{' '}
              <span className="text-[var(--titan-text-muted)]">
                {bounds.minG}–{bounds.maxG} g
              </span>
            </span>
            {deltaG !== 0 && (
              <span
                className={
                  deltaG > 0
                    ? 'text-[var(--titan-champagne)]'
                    : 'text-[var(--titan-info)]'
                }
              >
                {deltaG > 0 ? `+${deltaG} g` : `${deltaG} g`} ({deltaPct > 0 ? `+${deltaPct}%` : `${deltaPct}%`})
              </span>
            )}
          </div>
        </div>

        {/* Active Weight & Impact Attribution */}
        <div className="flex items-center gap-2 shrink-0">
          {editingNumeric ? (
            <div className="flex items-center gap-1.5">
              <BufferedNumberInput
                min={bounds.minG}
                max={bounds.maxG}
                step={0.5}
                value={clampedActive}
                ariaLabel={`Quantidade em gramas para ${impact.foodName}`}
                onCommit={(val) => {
                  onChangeQuantity(val);
                  setEditingNumeric(false);
                }}
                className="w-24 px-2.5 rounded-lg border border-[var(--titan-champagne)]/60 bg-[var(--titan-surface-inset)] font-mono-metric text-right text-[var(--titan-text-primary)]"
              />
              <button
                type="button"
                onClick={() => setEditingNumeric(false)}
                className="titan-button titan-button--ghost !min-h-[44px] !px-2 !text-xs"
              >
                OK
              </button>
            </div>
          ) : (
            <button
              type="button"
              disabled={isLocked}
              onClick={() => setEditingNumeric(true)}
              title="Editar gramas exatas"
              className="min-h-[44px] px-3 rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] font-mono-metric text-sm font-semibold text-[var(--titan-text-primary)] hover:border-[var(--titan-champagne)]/50 disabled:opacity-70"
            >
              {clampedActive} g
            </button>
          )}

          {onRemove && (
            <button
              type="button"
              onClick={onRemove}
              aria-label={`Remover ${impact.foodName}`}
              className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-status-error)] hover:bg-[rgba(210,143,135,0.08)]"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Proprietary ProportionRail Instrument + 3-state lock + Live Impact */}
      <div className="grid grid-cols-1 md:grid-cols-[minmax(0,1fr)_auto_auto] gap-3 items-center">
        <div
          ref={railRef}
          role="slider"
          tabIndex={isLocked ? -1 : 0}
          aria-labelledby={labelId}
          aria-valuemin={bounds.minG}
          aria-valuemax={bounds.maxG}
          aria-valuenow={clampedActive}
          aria-valuetext={`${clampedActive} gramas${refG !== null ? `, base ${refG} gramas` : ''}`}
          aria-disabled={isLocked}
          onPointerDown={(event) => {
            if (isLocked) return;
            event.currentTarget.setPointerCapture(event.pointerId);
            setIsDragging(true);
            updateFromClientX(event.clientX);
          }}
          onPointerMove={(event) => {
            if (!isDragging || isLocked) return;
            updateFromClientX(event.clientX);
          }}
          onPointerUp={(event) => {
            if (isDragging) {
              if (event.currentTarget.hasPointerCapture(event.pointerId)) {
                event.currentTarget.releasePointerCapture(event.pointerId);
              }
              setIsDragging(false);
            }
          }}
          onPointerCancel={() => setIsDragging(false)}
          onKeyDown={(event) => {
            if (isLocked) return;
            const step = event.shiftKey ? 10 : 1;
            if (event.key === 'ArrowRight' || event.key === 'ArrowUp') {
              event.preventDefault();
              onChangeQuantity(Math.min(bounds.maxG, roundGramsHalf(clampedActive + step)));
            } else if (event.key === 'ArrowLeft' || event.key === 'ArrowDown') {
              event.preventDefault();
              onChangeQuantity(Math.max(bounds.minG, roundGramsHalf(clampedActive - step)));
            } else if (event.key === 'Home') {
              event.preventDefault();
              onChangeQuantity(bounds.minG);
            } else if (event.key === 'End') {
              event.preventDefault();
              onChangeQuantity(bounds.maxG);
            } else if (event.key === '0' && refG !== null) {
              event.preventDefault();
              onChangeQuantity(refG);
            }
          }}
          className={`relative min-h-[44px] flex items-center select-none touch-none rounded-xl px-2.5 border transition-colors ${
            isLocked
              ? 'border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)]/60 opacity-65 cursor-not-allowed'
              : isDragging
                ? 'border-[var(--titan-champagne)]/70 bg-[var(--titan-surface-inset)] cursor-grabbing'
                : 'border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] hover:border-[var(--titan-accent)]/40 cursor-grab'
          }`}
        >
          <div className="relative w-full h-5 flex items-center">
            {/* Calibrated SVG scale graduation ticks */}
            <svg
              aria-hidden="true"
              className="absolute inset-0 w-full h-full pointer-events-none"
              preserveAspectRatio="none"
              viewBox="0 0 200 20"
            >
              <line x1="0" y1="10" x2="200" y2="10" stroke="rgba(193, 204, 196, 0.16)" strokeWidth="1.5" />
              {[0, 25, 50, 75, 100, 125, 150, 175, 200].map((x) => (
                <line
                  key={x}
                  x1={x}
                  y1={x % 50 === 0 ? 5 : 7}
                  x2={x}
                  y2={x % 50 === 0 ? 15 : 13}
                  stroke="rgba(183, 193, 186, 0.22)"
                  strokeWidth="1"
                />
              ))}
            </svg>

            {/* Delta span bar between original scaled quantity and active quantity */}
            {fillWidthPct > 0.4 && (
              <div
                aria-hidden="true"
                style={{
                  left: `${fillStartPct}%`,
                  width: `${fillWidthPct}%`,
                }}
                className={`absolute h-1.5 rounded-sm transition-[left,width] duration-75 ${
                  isIncreased ? 'bg-[var(--titan-champagne)]/75' : 'bg-[var(--titan-info)]/75'
                }`}
              />
            )}

            {/* Original scaled recipe reference tick q_i^{ref} */}
            <div
              aria-hidden="true"
              style={{ left: `${refPct}%` }}
              title={refG !== null ? `Referência escalada: ${refG} g` : undefined}
              className="absolute top-0.5 bottom-0.5 w-[2px] -translate-x-1/2 bg-[var(--titan-text-primary)]/70"
            />

            {/* Active tactile machined reticle handle */}
            <div
              aria-hidden="true"
              style={{ left: `${activePct}%` }}
              className={`absolute -translate-x-1/2 w-3.5 h-5 rounded-[4px] border shadow-sm transition-transform duration-75 ${
                isLocked
                  ? 'bg-[var(--titan-surface-elevated)] border-[var(--titan-text-muted)]'
                  : isDragging
                    ? 'scale-110 bg-[var(--titan-champagne)] border-[var(--titan-text-primary)]'
                    : 'bg-[var(--titan-accent)] border-[var(--titan-bg-canvas)]'
              }`}
            />
          </div>
        </div>

        {/* 3-State Mode Toggle */}
        <div
          role="group"
          aria-label={`Modo de ajuste para ${impact.foodName}`}
          className="titan-segmented shrink-0"
        >
          {MODE_OPTIONS.map((opt) => {
            const Icon = opt.icon;
            const active = ingredient.mode === opt.mode;
            return (
              <button
                key={opt.mode}
                type="button"
                aria-pressed={active}
                title={opt.label}
                onClick={() => onChangeMode(opt.mode)}
                className={`titan-segment !min-h-[38px] !px-2.5 !text-[11px] ${active ? 'is-active' : ''}`}
              >
                <Icon className="w-3 h-3" aria-hidden="true" />
                <span>{opt.shortLabel}</span>
              </button>
            );
          })}
        </div>

        {/* Live Nutritional Impact Readout */}
        <div className="min-w-[148px] text-left md:text-right font-mono-metric">
          {impact.calculable ? (
            <>
              <p className="text-xs font-semibold text-[var(--titan-text-primary)]">
                {Math.round(impact.activeMacros.kcal)} kcal
                {Math.abs(impact.deltaMacros.kcal) >= 1 && (
                  <span
                    className={`ml-1.5 text-[11px] ${
                      impact.deltaMacros.kcal > 0
                        ? 'text-[var(--titan-champagne)]'
                        : 'text-[var(--titan-info)]'
                    }`}
                  >
                    ({impact.deltaMacros.kcal > 0 ? '+' : ''}
                    {Math.round(impact.deltaMacros.kcal)})
                  </span>
                )}
              </p>
              <p className="text-[11px] text-[var(--titan-text-muted)]">
                P {impact.activeMacros.proteinG.toFixed(1)} · C {impact.activeMacros.carbsG.toFixed(1)} · G {impact.activeMacros.fatG.toFixed(1)}
              </p>
            </>
          ) : (
            <p className="text-[11px] text-[var(--titan-status-warning)]">{impact.reason}</p>
          )}
        </div>
      </div>
    </div>
  );
});
