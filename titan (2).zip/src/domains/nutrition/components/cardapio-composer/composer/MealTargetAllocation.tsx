import { memo } from 'react';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import type {
  ComposerDayPlan,
  MealTargetAllocation,
  NutritionTargets,
} from '../../../domain/entities/nutrient';
import { evaluateMealAllocations } from '../../../domain/rules/cardapio-composer-engine';

interface MealTargetAllocationProps {
  dayPlan: ComposerDayPlan;
  targets: NutritionTargets;
  allocations: readonly MealTargetAllocation[];
  onChangeAllocations: (next: MealTargetAllocation[]) => void;
}

export const MealTargetAllocationPanel = memo(function MealTargetAllocationPanel({
  dayPlan,
  targets,
  allocations,
  onChangeAllocations,
}: MealTargetAllocationProps) {
  const evaluation = evaluateMealAllocations(dayPlan, targets, allocations);

  const handleShareChange = (slotId: string, nextPercent: number) => {
    const clean = Math.max(0, Math.min(100, Number(nextPercent.toFixed(1))));
    const updated = evaluation.slots.map((slot) => ({
      slotId: slot.slotId,
      energySharePercent: slot.slotId === slotId ? clean : slot.sharePercent,
    }));
    onChangeAllocations(updated);
  };

  const handleEqualize = () => {
    const count = evaluation.slots.length;
    if (count === 0) return;
    const base = Math.floor((100 / count) * 10) / 10;
    let running = 0;
    const next = evaluation.slots.map((slot, index) => {
      if (index === count - 1) {
        return {
          slotId: slot.slotId,
          energySharePercent: Number((100 - running).toFixed(1)),
        };
      }
      running += base;
      return {
        slotId: slot.slotId,
        energySharePercent: base,
      };
    });
    onChangeAllocations(next);
  };

  const handleProportionalNormalize = () => {
    const sum = evaluation.totalSharePercent;
    if (sum <= 0) {
      handleEqualize();
      return;
    }
    let running = 0;
    const next = evaluation.slots.map((slot, index) => {
      if (index === evaluation.slots.length - 1) {
        return {
          slotId: slot.slotId,
          energySharePercent: Math.max(0, Number((100 - running).toFixed(1))),
        };
      }
      const scaled = Math.round(((slot.sharePercent / sum) * 100) * 10) / 10;
      running += scaled;
      return {
        slotId: slot.slotId,
        energySharePercent: scaled,
      };
    });
    onChangeAllocations(next);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-[var(--titan-text-secondary)]">
            Distribuição entre refeições
          </h3>
          <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] mt-0.5">
            Soma: {evaluation.totalSharePercent.toFixed(1)}% ·{' '}
            {evaluation.isBalanced ? (
              <span className="text-[var(--titan-status-success)]">100% distribuído</span>
            ) : evaluation.unallocatedPercent > 0 ? (
              <span className="text-[var(--titan-champagne)]">
                Não alocado: {evaluation.unallocatedPercent.toFixed(1)}%
              </span>
            ) : (
              <span className="text-[var(--titan-status-error)]">
                Excedente: +{Math.abs(evaluation.unallocatedPercent).toFixed(1)}%
              </span>
            )}
          </p>
        </div>

        {!evaluation.isBalanced && (
          <button
            type="button"
            onClick={handleProportionalNormalize}
            className="titan-button titan-button--secondary !min-h-[38px] !px-2.5 !text-[11px]"
          >
            Fechar 100%
          </button>
        )}
      </div>

      <div className="space-y-2">
        {evaluation.slots.map((slot) => (
          <div
            key={slot.slotId}
            className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b border-[var(--titan-border-subtle)] pb-2 last:border-b-0 last:pb-0"
          >
            <div className="min-w-0">
              <p className="text-xs font-medium text-[var(--titan-text-primary)] truncate">
                {slot.slotTime} · {slot.slotTitle}
              </p>
              <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
                Atual {slot.actualKcal} kcal / Alvo {slot.targetKcal} kcal{' '}
                <span
                  className={
                    Math.abs(slot.deltaKcal) <= 45
                      ? 'text-[var(--titan-status-success)]'
                      : 'text-[var(--titan-text-secondary)]'
                  }
                >
                  ({slot.deltaKcal >= 0 ? `+${slot.deltaKcal}` : slot.deltaKcal})
                </span>
              </p>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <BufferedNumberInput
                min={0}
                max={100}
                step={1}
                value={slot.sharePercent}
                ariaLabel={`Percentual da meta para ${slot.slotTitle}`}
                onCommit={(val) => handleShareChange(slot.slotId, val)}
                className="w-20 rounded-lg border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2 font-mono-metric text-right text-[var(--titan-text-primary)]"
              />
              <span className="text-xs font-mono-metric text-[var(--titan-text-muted)]">%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
});
