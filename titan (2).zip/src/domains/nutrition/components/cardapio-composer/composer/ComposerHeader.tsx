import { memo, useState } from 'react';
import { Copy, GitCompareArrows, Plus, SlidersHorizontal, X } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import type {
  CardapioPlan,
  ComposerPlanStatus,
  NutritionTargets,
} from '../../../domain/entities/nutrient';

interface ComposerHeaderProps {
  plans: readonly CardapioPlan[];
  activePlan: CardapioPlan;
  compareOpen: boolean;
  onSelectPlan: (planId: string) => void;
  onCreatePlan: (input: {
    name: string;
    duplicateFromPlanId?: string;
    status?: ComposerPlanStatus;
  }) => void;
  onUpdatePlanMeta: (planId: string, patch: { name?: string; status?: ComposerPlanStatus }) => void;
  onUpdateTargets: (planId: string, patch: Partial<NutritionTargets>) => void;
  onToggleCompare: () => void;
}

const PLAN_STATUS_LABELS: Record<ComposerPlanStatus, string> = {
  active: 'Ativo',
  draft: 'Em edição',
  archived: 'Arquivado',
};

export const ComposerHeader = memo(function ComposerHeader({
  plans,
  activePlan,
  compareOpen,
  onSelectPlan,
  onCreatePlan,
  onUpdatePlanMeta,
  onUpdateTargets,
  onToggleCompare,
}: ComposerHeaderProps) {
  const [drawer, setDrawer] = useState<'none' | 'new_plan' | 'targets'>('none');
  const [newPlanName, setNewPlanName] = useState('');
  const [duplicateCurrent, setDuplicateCurrent] = useState(true);
  const [configureBounds, setConfigureBounds] = useState(
    Boolean(activePlan.targets.kcalMin || activePlan.targets.kcalMax),
  );

  const handleCreatePlan = () => {
    const clean = newPlanName.trim();
    if (!clean) return;
    onCreatePlan({
      name: clean,
      duplicateFromPlanId: duplicateCurrent ? activePlan.id : undefined,
      status: 'draft',
    });
    setNewPlanName('');
    setDrawer('none');
  };

  return (
    <header className="space-y-4">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
            <span className="titan-eyebrow">TITAN · COMPOSER</span>
            <span className="text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
              {PLAN_STATUS_LABELS[activePlan.status]} · Revisão {String(activePlan.revision).padStart(2, '0')}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-[var(--titan-text-primary)] tracking-tight">
            Compor cardápio
          </h1>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            {activePlan.name} · Período {activePlan.startDateKey} a {activePlan.endDateKey} ·{' '}
            {activePlan.targets.sourceLabel ?? 'Metas personalizadas'}
          </p>
        </div>

        {/* Plan Selector & Workspace Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <label className="sr-only" htmlFor="composer-plan-select">
            Selecionar plano de cardápio
          </label>
          <select
            id="composer-plan-select"
            value={activePlan.id}
            onChange={(event) => onSelectPlan(event.target.value)}
            className="min-h-[44px] min-w-[220px] rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-sm text-[var(--titan-text-primary)]"
          >
            {plans.map((plan) => (
              <option key={plan.id} value={plan.id}>
                {plan.name} ({PLAN_STATUS_LABELS[plan.status]} · Rev. {String(plan.revision).padStart(2, '0')})
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => setDrawer((prev) => (prev === 'targets' ? 'none' : 'targets'))}
            aria-expanded={drawer === 'targets'}
            className={`titan-button !min-h-[44px] !px-3.5 !text-xs ${
              drawer === 'targets' ? 'titan-button--mineral' : 'titan-button--secondary'
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" aria-hidden="true" />
            <span>Metas</span>
          </button>

          <button
            type="button"
            onClick={() => setDrawer((prev) => (prev === 'new_plan' ? 'none' : 'new_plan'))}
            aria-expanded={drawer === 'new_plan'}
            className={`titan-button !min-h-[44px] !px-3.5 !text-xs ${
              drawer === 'new_plan' ? 'titan-button--mineral' : 'titan-button--secondary'
            }`}
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Novo plano</span>
          </button>

          <button
            type="button"
            onClick={onToggleCompare}
            aria-pressed={compareOpen}
            className={`titan-button !min-h-[44px] !px-3.5 !text-xs ${
              compareOpen ? 'titan-button--mineral' : 'titan-button--secondary'
            }`}
          >
            <GitCompareArrows className="w-4 h-4" aria-hidden="true" />
            <span>Comparar</span>
          </button>
        </div>
      </div>

      {/* Inline Create / Duplicate Independent Plan Panel */}
      {drawer === 'new_plan' && (
        <Surface data-elevation="2" className="p-4 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">
                Novo plano independente
              </h2>
              <p className="text-xs text-[var(--titan-text-secondary)]">
                Cada plano possui metas, revisões e dias isolados sem compartilhar alterações acidentais.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setDrawer('none')}
              aria-label="Fechar criação de plano"
              className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-[minmax(0,1fr)_auto] gap-3 items-end">
            <label className="text-xs text-[var(--titan-text-secondary)]">
              Nome do plano
              <input
                type="text"
                maxLength={100}
                value={newPlanName}
                onChange={(event) => setNewPlanName(event.target.value)}
                placeholder="Ex.: Fase de consolidação · Semana 2"
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-[var(--titan-text-primary)]"
              />
            </label>
            <button
              type="button"
              disabled={!newPlanName.trim()}
              onClick={handleCreatePlan}
              className="titan-button titan-button--primary !min-h-[44px] !px-4 !text-xs disabled:opacity-45"
            >
              <Copy className="w-4 h-4" aria-hidden="true" />
              <span>{duplicateCurrent ? 'Duplicar plano atual' : 'Criar em branco'}</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <label className="inline-flex items-center gap-2 text-xs text-[var(--titan-text-secondary)] cursor-pointer min-h-[44px]">
              <input
                type="checkbox"
                checked={duplicateCurrent}
                onChange={(event) => setDuplicateCurrent(event.target.checked)}
                className="w-4 h-4 rounded"
              />
              <span>Copiar estrutura e metas atuais como ponto de partida independente</span>
            </label>

            {activePlan.status !== 'active' && (
              <button
                type="button"
                onClick={() => onUpdatePlanMeta(activePlan.id, { status: 'active' })}
                className="titan-button titan-button--secondary !min-h-[44px] !px-3 !text-xs"
              >
                Definir "{activePlan.name}" como plano ativo
              </button>
            )}
          </div>
        </Surface>
      )}

      {/* Inline Target & Optional Corridor Configuration Panel */}
      {drawer === 'targets' && (
        <Surface data-elevation="2" className="p-4 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">
                Metas nutricionais de "{activePlan.name}"
              </h2>
              <p className="text-xs text-[var(--titan-text-secondary)]">
                Ajuste o ponto alvo diário e configure limites mínimo/máximo apenas quando desejar faixas explícitas.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setDrawer('none')}
              aria-label="Fechar metas do plano"
              className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <label className="text-xs text-[var(--titan-text-secondary)]">
              Energia (kcal)
              <BufferedNumberInput
                min={500}
                max={10000}
                step={10}
                integer
                value={activePlan.targets.kcal}
                onCommit={(kcal) =>
                  onUpdateTargets(activePlan.id, { kcal, sourceLabel: 'Meta ajustada no plano' })
                }
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>
            <label className="text-xs text-[var(--titan-accent)]">
              Proteína (g)
              <BufferedNumberInput
                min={20}
                max={500}
                step={1}
                integer
                value={activePlan.targets.proteinG}
                onCommit={(proteinG) =>
                  onUpdateTargets(activePlan.id, { proteinG, sourceLabel: 'Meta ajustada no plano' })
                }
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>
            <label className="text-xs text-[var(--titan-info)]">
              Carboidratos (g)
              <BufferedNumberInput
                min={0}
                max={1000}
                step={1}
                integer
                value={activePlan.targets.carbsG}
                onCommit={(carbsG) =>
                  onUpdateTargets(activePlan.id, { carbsG, sourceLabel: 'Meta ajustada no plano' })
                }
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>
            <label className="text-xs text-[var(--titan-copper)]">
              Gorduras (g)
              <BufferedNumberInput
                min={10}
                max={350}
                step={1}
                integer
                value={activePlan.targets.fatG}
                onCommit={(fatG) =>
                  onUpdateTargets(activePlan.id, { fatG, sourceLabel: 'Meta ajustada no plano' })
                }
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--titan-border-subtle)] pt-3">
            <label className="inline-flex items-center gap-2 text-xs text-[var(--titan-text-secondary)] cursor-pointer min-h-[44px]">
              <input
                type="checkbox"
                checked={configureBounds}
                onChange={(event) => {
                  const enabled = event.target.checked;
                  setConfigureBounds(enabled);
                  if (!enabled) {
                    onUpdateTargets(activePlan.id, {
                      kcalMin: null,
                      kcalMax: null,
                      proteinMinG: null,
                      proteinMaxG: null,
                    });
                  } else {
                    onUpdateTargets(activePlan.id, {
                      kcalMin: Math.max(500, activePlan.targets.kcal - 90),
                      kcalMax: activePlan.targets.kcal + 90,
                      proteinMinG: Math.max(20, activePlan.targets.proteinG - 10),
                      proteinMaxG: activePlan.targets.proteinG + 15,
                    });
                  }
                }}
                className="w-4 h-4 rounded"
              />
              <span>Definir faixa de tolerância calórica e proteica</span>
            </label>

            {configureBounds && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full">
                <label className="text-[11px] text-[var(--titan-text-muted)]">
                  Kcal mín.
                  <BufferedNumberInput
                    min={400}
                    max={activePlan.targets.kcal}
                    integer
                    value={activePlan.targets.kcalMin ?? Math.max(500, activePlan.targets.kcal - 90)}
                    onCommit={(kcalMin) => onUpdateTargets(activePlan.id, { kcalMin })}
                    className="mt-1 w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2 font-mono-metric"
                  />
                </label>
                <label className="text-[11px] text-[var(--titan-text-muted)]">
                  Kcal máx.
                  <BufferedNumberInput
                    min={activePlan.targets.kcal}
                    max={11000}
                    integer
                    value={activePlan.targets.kcalMax ?? activePlan.targets.kcal + 90}
                    onCommit={(kcalMax) => onUpdateTargets(activePlan.id, { kcalMax })}
                    className="mt-1 w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2 font-mono-metric"
                  />
                </label>
                <label className="text-[11px] text-[var(--titan-text-muted)]">
                  Prot. mín. (g)
                  <BufferedNumberInput
                    min={0}
                    max={activePlan.targets.proteinG}
                    integer
                    value={activePlan.targets.proteinMinG ?? Math.max(0, activePlan.targets.proteinG - 10)}
                    onCommit={(proteinMinG) => onUpdateTargets(activePlan.id, { proteinMinG })}
                    className="mt-1 w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2 font-mono-metric"
                  />
                </label>
                <label className="text-[11px] text-[var(--titan-text-muted)]">
                  Prot. máx. (g)
                  <BufferedNumberInput
                    min={activePlan.targets.proteinG}
                    max={1000}
                    integer
                    value={activePlan.targets.proteinMaxG ?? activePlan.targets.proteinG + 15}
                    onCommit={(proteinMaxG) => onUpdateTargets(activePlan.id, { proteinMaxG })}
                    className="mt-1 w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2 font-mono-metric"
                  />
                </label>
              </div>
            )}
          </div>
        </Surface>
      )}
    </header>
  );
});
