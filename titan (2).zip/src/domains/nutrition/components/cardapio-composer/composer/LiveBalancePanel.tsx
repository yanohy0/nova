import { memo, useState } from 'react';
import { CheckCircle2, ChevronDown, ChevronUp, Sliders } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import type {
  CardapioPlan,
  ComposerDayPlan,
  MealTargetAllocation,
} from '../../../domain/entities/nutrient';
import { computeDayNutrition } from '../../../domain/rules/cardapio-composer-engine';
import { NutrientTargetBands } from './NutrientTargetBands';
import { MealTargetAllocationPanel } from './MealTargetAllocation';
import { VariantSwitcher } from '../variants/VariantSwitcher';

interface LiveBalancePanelProps {
  plan: CardapioPlan;
  dayPlan: ComposerDayPlan;
  selectedSlotId: string;
  goalFocus: 'balanced' | 'energy' | 'protein';
  isOptimizing: boolean;
  isIntakeDayConfirmed: boolean;
  canConfirmIntakeDay: boolean;
  intakeFeedback: string | null;
  onChangeGoalFocus: (focus: 'balanced' | 'energy' | 'protein') => void;
  onSimulateBalance: (scope: 'day' | 'slot') => void;
  onUpdateAllocations: (next: MealTargetAllocation[]) => void;
  onSaveVariant: (name: string) => void;
  onActivateVariant: (variantId: string) => void;
  onDeleteVariant: (variantId: string) => void;
  onConfirmIntakeDay: () => void;
}

export const LiveBalancePanel = memo(function LiveBalancePanel({
  plan,
  dayPlan,
  selectedSlotId,
  goalFocus,
  isOptimizing,
  isIntakeDayConfirmed,
  canConfirmIntakeDay,
  intakeFeedback,
  onChangeGoalFocus,
  onSimulateBalance,
  onUpdateAllocations,
  onSaveVariant,
  onActivateVariant,
  onDeleteVariant,
  onConfirmIntakeDay,
}: LiveBalancePanelProps) {
  const [showAllocations, setShowAllocations] = useState(true);
  const summary = computeDayNutrition(dayPlan);

  return (
    <aside aria-label="Balanço nutricional em tempo real" className="space-y-4">
      <Surface data-elevation="2" className="p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <div>
            <p className="titan-eyebrow">Balanço nutricional</p>
            <p className="text-xs text-[var(--titan-text-muted)] font-mono-metric mt-0.5">
              Dia completo · Desvio D {summary.weightedDeviationPercent.toFixed(1)}%
            </p>
          </div>
          <span className="text-[11px] font-mono-metric text-[var(--titan-text-secondary)]">
            {dayPlan.dateKey}
          </span>
        </div>

        <NutrientTargetBands
          planned={summary.macros}
          targets={plan.targets}
          micronutrients={summary.micronutrients}
          coveragePercent={summary.coveragePercent}
          unresolvedCount={summary.unresolvedFoodIds.length}
        />

        {/* Continuous QP Optimization Controls */}
        <div className="space-y-2.5 pt-3 border-t border-[var(--titan-border-subtle)]">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
              Equilibrar proporções
            </span>
            <span className="text-[10px] font-mono-metric text-[var(--titan-text-muted)]">
              Solver QP em segundo plano
            </span>
          </div>

          <div
            role="group"
            aria-label="Prioridade de otimização"
            className="titan-segmented w-full grid grid-cols-3"
          >
            {(
              [
                { id: 'balanced', label: 'Equilíbrio' },
                { id: 'energy', label: 'Energia' },
                { id: 'protein', label: 'Proteína' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                aria-pressed={goalFocus === opt.id}
                onClick={() => onChangeGoalFocus(opt.id)}
                className={`titan-segment !min-h-[36px] !text-[11px] ${
                  goalFocus === opt.id ? 'is-active' : ''
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              type="button"
              disabled={isOptimizing}
              onClick={() => onSimulateBalance('day')}
              className="titan-button titan-button--primary !min-h-[44px] !px-3.5 !text-xs w-full disabled:opacity-60"
            >
              <Sliders className="w-4 h-4" aria-hidden="true" />
              <span>{isOptimizing ? 'Calculando…' : 'Simular ajuste do dia'}</span>
            </button>

            <button
              type="button"
              disabled={isOptimizing || !selectedSlotId}
              onClick={() => onSimulateBalance('slot')}
              className="titan-button titan-button--secondary !min-h-[44px] !px-3 !text-xs w-full disabled:opacity-60"
            >
              <span>Ajustar refeição ativa</span>
            </button>
          </div>
        </div>

        {/* Collapsible Per-Meal Target Allocation */}
        <div className="pt-2 border-t border-[var(--titan-border-subtle)]">
          <button
            type="button"
            onClick={() => setShowAllocations((prev) => !prev)}
            aria-expanded={showAllocations}
            className="w-full min-h-[44px] flex items-center justify-between text-left text-xs font-medium text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)]"
          >
            <span>Metas por refeição (% da energia diária)</span>
            {showAllocations ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showAllocations && (
            <div className="mt-2">
              <MealTargetAllocationPanel
                dayPlan={dayPlan}
                targets={plan.targets}
                allocations={plan.mealAllocations}
                onChangeAllocations={onUpdateAllocations}
              />
            </div>
          )}
        </div>

        {/* Named Variants Management */}
        <VariantSwitcher
          variants={plan.variants}
          activeVariantId={plan.activeVariantId}
          onSaveSnapshot={onSaveVariant}
          onActivateVariant={onActivateVariant}
          onDeleteVariant={onDeleteVariant}
        />

        {/* Daily Food Intake Confirmation Closure */}
        <div className="pt-3 border-t border-[var(--titan-border-subtle)] space-y-2">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h3 className="text-xs font-semibold text-[var(--titan-text-primary)]">
                Fechamento do registro alimentar
              </h3>
              <p className="text-[11px] text-[var(--titan-text-muted)]">
                Confirme após registrar ou pular todas as refeições do dia.
              </p>
            </div>
            {isIntakeDayConfirmed ? (
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-[var(--titan-status-success)] shrink-0">
                <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                <span>Confirmado</span>
              </span>
            ) : (
              <button
                type="button"
                disabled={!canConfirmIntakeDay}
                onClick={onConfirmIntakeDay}
                className="titan-button titan-button--mineral !min-h-[44px] !px-3.5 !text-xs shrink-0 disabled:opacity-45"
              >
                Confirmar dia
              </button>
            )}
          </div>
          {intakeFeedback && (
            <p className="text-[11px] text-[var(--titan-text-secondary)]" role="status">
              {intakeFeedback}
            </p>
          )}
        </div>
      </Surface>
    </aside>
  );
});
