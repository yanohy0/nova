import { lazy, startTransition, Suspense, useEffect, useState } from 'react';
import { Apple, BookOpen, CalendarDays } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { useNutritionStore } from '../state/nutrition.store';
import { resolveDriProfileId, useProfileStore } from '@/src/domains/profile/application/profile-public';
import { CardapioComposer } from '../components/cardapio-composer/CardapioComposer';

const FoodCatalogBrowser = lazy(() =>
  import('../components/FoodCatalogBrowser').then((m) => ({ default: m.FoodCatalogBrowser })),
);
const RecipeCatalogBrowser = lazy(() =>
  import('../components/RecipeCatalogBrowser').then((m) => ({ default: m.RecipeCatalogBrowser })),
);

export type NutritionSection = 'cardapio' | 'receitas' | 'alimentos';

interface NutritionWorkspaceProps {
  section?: NutritionSection;
  onSectionChange?: (section: NutritionSection) => void;
}

export function NutritionWorkspace({
  section,
  onSectionChange,
}: NutritionWorkspaceProps = {}) {
  const [internalSection, setInternalSection] = useState<NutritionSection>('cardapio');
  const activeSection = section ?? internalSection;
  const handleSectionChange = (nextSection: NutritionSection) => {
    startTransition(() => {
      if (onSectionChange) {
        onSectionChange(nextSection);
      } else {
        setInternalSection(nextSection);
      }
    });
  };

  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const setReferenceProfileId = useNutritionStore((s) => s.setReferenceProfileId);
  const physiologicalProfile = useProfileStore((s) => s.profile);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const driProfileId = resolveDriProfileId(physiologicalProfile.sex, physiologicalProfile.age);

  useEffect(() => {
    if (!profileConfigured) return;
    setReferenceProfileId(driProfileId);
  }, [profileConfigured, driProfileId, setReferenceProfileId]);

  return (
    <div className="space-y-5">
      <div className="titan-segmented grid grid-cols-3 w-full" role="tablist" aria-label="Biblioteca de nutrição">
        {([
          { id: 'cardapio', label: 'Cardápios', icon: CalendarDays },
          { id: 'receitas', label: 'Receitas', icon: BookOpen },
          { id: 'alimentos', label: 'Alimentos', icon: Apple },
        ] as const).map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={activeSection === item.id}
              className={`titan-segment flex items-center justify-center gap-1.5 ${activeSection === item.id ? 'is-active' : ''}`}
              onClick={() => handleSectionChange(item.id)}
            >
              <Icon className="w-3.5 h-3.5" aria-hidden="true" />
              {item.label}
            </button>
          );
        })}
      </div>

      {activeSection === 'cardapio' && (
        <>
          {!profileConfigured && (
            <p className="text-[11px] text-[var(--titan-status-warning)]" role="note">
              Configure sexo e idade em Metas para interpretar as referências de micronutrientes. Os valores iniciais são apenas parâmetros temporários.
            </p>
          )}
          <CardapioComposer />
        </>
      )}

      {activeSection === 'receitas' && (
        <div className="space-y-4">
          <div className="titan-page-heading titan-page-heading--compact">
            <p className="titan-eyebrow">Base culinária</p>
            <h1>Receitas</h1>
            <p className="text-xs text-[var(--titan-text-secondary)]">
              Receitas rastreáveis para composição e substituição ({activeDateKey})
            </p>
          </div>
          <Suspense fallback={<Surface className="p-4 text-xs text-[var(--titan-text-secondary)]">Carregando catálogo de receitas…</Surface>}>
            <RecipeCatalogBrowser />
          </Suspense>
        </div>
      )}

      {activeSection === 'alimentos' && (
        <div className="space-y-4">
          <div className="titan-page-heading titan-page-heading--compact">
            <p className="titan-eyebrow">Catálogo analítico</p>
            <h1>Alimentos</h1>
            <p className="text-xs text-[var(--titan-text-secondary)]">
              TBCA e Open Food Facts com preservação de dados não analisados ({activeDateKey})
            </p>
          </div>
          <Suspense fallback={<Surface className="p-4 text-xs text-[var(--titan-text-secondary)]">Carregando catálogo de alimentos TBCA…</Surface>}>
            <FoodCatalogBrowser />
          </Suspense>
        </div>
      )}
    </div>
  );
}


/** Compatibility export for the existing lazy route; nutrition lives in one unified workspace. */
export const CardapioScreen = NutritionWorkspace;
