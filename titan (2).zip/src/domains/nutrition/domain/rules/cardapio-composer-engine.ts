import { RECIPE_CATALOG, findRecipeById } from '../../data/recipes/recipe-catalog.ts';
import { shiftLocalDateKey } from '../../../../shared/utils/local-date.ts';
import {
  MICRONUTRIENT_ORDER,
  type CardapioPlan,
  type ComposerAdjustmentMode,
  type ComposerDayPlan,
  type ComposerMacroTotals,
  type ComposerMealSlot,
  type DiscreteSubstitutionProposal,
  type FoodSourceId,
  type IngredientAdjustment,
  type MealFoodPortion,
  type MealItem,
  type MealTargetAllocation,
  type NutrientId,
  type NutritionTargets,
  type OptimizationProposal,
  type ProposedIngredientChange,
  type RecipeInstance,
  type RecipeItem,
  type SolverCertificate,
} from '../entities/nutrient.ts';
import { normalizeNutrientEntry, resolveFoodById } from './nutrition-calculator.ts';

const COMPOSITE_DISH_FOOD_IDS = new Set([
  'tbca-frango-arroz-legumes',
  'tbca-salmao-batata-doce',
  'tbca-mamao-aveia',
]);

const DEFAULT_MEAL_SHARE_PERCENTS: readonly number[] = [22, 33, 18, 27];

export const KEY_COMPOSER_MICRONUTRIENTS: readonly NutrientId[] = [
  'iron',
  'calcium',
  'potassium',
  'sodium',
  'vitamin_c',
  'magnesium',
];

export const MICRONUTRIENT_PT_LABELS: Record<NutrientId, { label: string; unit: string }> = {
  vitamin_a: { label: 'Vitamina A', unit: 'µg RAE' },
  vitamin_c: { label: 'Vitamina C', unit: 'mg' },
  vitamin_d: { label: 'Vitamina D', unit: 'µg' },
  vitamin_e: { label: 'Vitamina E', unit: 'mg' },
  vitamin_k: { label: 'Vitamina K', unit: 'µg' },
  vitamin_b1: { label: 'Tiamina (B1)', unit: 'mg' },
  vitamin_b2: { label: 'Riboflavina (B2)', unit: 'mg' },
  vitamin_b3: { label: 'Niacina (B3)', unit: 'mg' },
  vitamin_b5: { label: 'Ác. Pantotênico (B5)', unit: 'mg' },
  vitamin_b6: { label: 'Piridoxina (B6)', unit: 'mg' },
  vitamin_b7: { label: 'Biotina (B7)', unit: 'µg' },
  vitamin_b9: { label: 'Folato (B9)', unit: 'µg' },
  vitamin_b12: { label: 'Vitamina B12', unit: 'µg' },
  calcium: { label: 'Cálcio', unit: 'mg' },
  copper: { label: 'Cobre', unit: 'µg' },
  iron: { label: 'Ferro', unit: 'mg' },
  phosphorus: { label: 'Fósforo', unit: 'mg' },
  magnesium: { label: 'Magnésio', unit: 'mg' },
  manganese: { label: 'Manganês', unit: 'mg' },
  potassium: { label: 'Potássio', unit: 'mg' },
  selenium: { label: 'Selênio', unit: 'µg' },
  sodium: { label: 'Sódio', unit: 'mg' },
  zinc: { label: 'Zinco', unit: 'mg' },
};

export function isCompositeFoodId(foodId: string): boolean {
  return COMPOSITE_DISH_FOOD_IDS.has(foodId);
}

export function roundGramsHalf(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round(value * 2) / 2;
}

export function cloneDayPlan(dayPlan: ComposerDayPlan): ComposerDayPlan {
  return {
    dateKey: dayPlan.dateKey,
    slots: dayPlan.slots.map((slot) => ({
      ...slot,
      recipes: slot.recipes.map((recipe) => ({
        ...recipe,
        ingredients: recipe.ingredients.map((ingredient) => ({ ...ingredient })),
      })),
    })),
  };
}

export function cloneCardapioPlan(plan: CardapioPlan): CardapioPlan {
  const days: Record<string, ComposerDayPlan> = {};
  for (const [dateKey, day] of Object.entries(plan.days)) {
    days[dateKey] = cloneDayPlan(day);
  }
  return {
    ...plan,
    targets: { ...plan.targets },
    mealAllocations: plan.mealAllocations.map((allocation) => ({ ...allocation })),
    days,
    variants: plan.variants.map((variant) => ({
      ...variant,
      macros: { ...variant.macros },
      dayPlan: cloneDayPlan(variant.dayPlan),
    })),
  };
}

export function createRecipeInstanceFromCatalog(
  recipe: RecipeItem,
  instanceId: string,
  targetServings = 1,
  adjustmentMode: ComposerAdjustmentMode = 'balanced',
): RecipeInstance {
  const safeTarget = Number.isFinite(targetServings)
    ? Math.max(0.25, Math.min(4, targetServings))
    : 1;
  return {
    id: instanceId,
    sourceRecipeId: recipe.id,
    name: recipe.name,
    description: recipe.description,
    category: recipe.category,
    imageUrl: recipe.imageUrl,
    baseServings: 1,
    targetServings: safeTarget,
    adjustmentMode,
    ingredients: recipe.ingredients.map((line, index) => {
      const scaled = roundGramsHalf(line.quantityG * safeTarget);
      const isComposite = isCompositeFoodId(line.ingredientId);
      return {
        id: `${instanceId}-ing-${index + 1}`,
        foodId: line.ingredientId,
        displayName: resolveFoodById(line.ingredientId)?.name ?? line.ingredientId,
        baseQuantityG: line.quantityG,
        currentQuantityG: scaled,
        quantityStatus: 'known',
        mode: adjustmentMode === 'proportional' ? 'proportional' : 'flexible',
        minQuantityG: Math.max(5, roundGramsHalf(scaled * 0.45)),
        maxQuantityG: Math.min(2000, Math.max(10, roundGramsHalf(scaled * 1.85))),
        isCompositeDish: isComposite,
      };
    }),
  };
}

export function createRecipeInstanceFromMeal(
  meal: MealItem,
  slotId: string,
): RecipeInstance {
  const catalogRecipe = meal.recipeId ? findRecipeById(meal.recipeId) : undefined;
  const inferredCategory: RecipeItem['category'] =
    catalogRecipe?.category ??
    (meal.time < '11:00'
      ? 'cafe'
      : meal.time < '15:00'
        ? 'almoco'
        : meal.time < '19:00'
          ? 'lanche'
          : 'jantar');

  const portions = meal.planned_foods.length > 0 ? meal.planned_foods : [];
  const ingredients: IngredientAdjustment[] = portions.map((portion, index) => {
    const baseFromRecipe =
      catalogRecipe?.ingredients.find((line) => line.ingredientId === portion.foodId)?.quantityG ??
      portion.quantityG;
    const isComposite = isCompositeFoodId(portion.foodId);
    const currentG = roundGramsHalf(portion.quantityG);
    const minG = Math.max(5, roundGramsHalf(baseFromRecipe * 0.45));
    const maxG = Math.min(2000, Math.max(minG + 10, roundGramsHalf(baseFromRecipe * 1.85)));
    return {
      id: `${slotId}-ing-${index + 1}`,
      foodId: portion.foodId,
      displayName: resolveFoodById(portion.foodId)?.name ?? portion.foodId,
      baseQuantityG: baseFromRecipe,
      currentQuantityG: currentG,
      quantityStatus: 'known',
      mode: 'flexible',
      minQuantityG: minG,
      maxQuantityG: maxG,
      isCompositeDish: isComposite,
    };
  });

  return {
    id: `${slotId}-rec-1`,
    sourceRecipeId: catalogRecipe?.id ?? meal.recipeId,
    name: catalogRecipe?.name ?? meal.title,
    description: catalogRecipe?.description ?? meal.description,
    category: inferredCategory,
    imageUrl: meal.imageUrl ?? catalogRecipe?.imageUrl,
    baseServings: 1,
    targetServings: 1,
    adjustmentMode: 'balanced',
    ingredients,
  };
}

export function buildComposerDayFromMeals(
  dateKey: string,
  dayMeals: readonly MealItem[],
): ComposerDayPlan {
  if (dayMeals.length > 0) {
    const sorted = [...dayMeals].sort((a, b) => a.time.localeCompare(b.time));
    return {
      dateKey,
      slots: sorted.map((meal, index) => {
        const slotId = meal.id || `slot-${dateKey}-${index + 1}`;
        return {
          id: slotId,
          time: meal.time,
          title: meal.title,
          linkedMealId: meal.id,
          recipes: [createRecipeInstanceFromMeal(meal, slotId)],
        };
      }),
    };
  }

  const defaults: Array<{
    id: string;
    time: string;
    title: string;
    recipeId: string;
  }> = [
    { id: 'slot-cafe', time: '07:30', title: 'Café da manhã', recipeId: 'rec-cafe-completo' },
    { id: 'slot-almoco', time: '12:30', title: 'Almoço', recipeId: 'rec-almoco-frango' },
    { id: 'slot-lanche', time: '16:00', title: 'Lanche da tarde', recipeId: 'rec-lanche-iogurte' },
    { id: 'slot-jantar', time: '20:30', title: 'Jantar', recipeId: 'rec-jantar-salmao' },
  ];

  return {
    dateKey,
    slots: defaults.map((item) => {
      const recipe = findRecipeById(item.recipeId) ?? RECIPE_CATALOG[0]!;
      return {
        id: item.id,
        time: item.time,
        title: item.title,
        recipes: [createRecipeInstanceFromCatalog(recipe, `${item.id}-rec-1`, 1, 'balanced')],
      };
    }),
  };
}

export function buildDefaultMealAllocations(slots: readonly ComposerMealSlot[]): MealTargetAllocation[] {
  if (slots.length === 0) return [];
  if (slots.length === DEFAULT_MEAL_SHARE_PERCENTS.length) {
    return slots.map((slot, index) => ({
      slotId: slot.id,
      energySharePercent: DEFAULT_MEAL_SHARE_PERCENTS[index] ?? 25,
    }));
  }
  const base = Math.floor((100 / slots.length) * 10) / 10;
  let running = 0;
  return slots.map((slot, index) => {
    if (index === slots.length - 1) {
      return {
        slotId: slot.id,
        energySharePercent: Math.max(0, Number((100 - running).toFixed(1))),
      };
    }
    running += base;
    return {
      slotId: slot.id,
      energySharePercent: base,
    };
  });
}

export function buildPlanDateRange(anchorDateKey: string, length = 7): string[] {
  const keys: string[] = [];
  for (let offset = -2; offset < length - 2; offset += 1) {
    const shifted = shiftLocalDateKey(anchorDateKey, offset);
    if (shifted) keys.push(shifted);
  }
  return keys.length > 0 ? keys : [anchorDateKey];
}

export function buildInitialComposerPlans(
  anchorDateKey: string,
  dailyGoals: { kcal: number; proteinG: number; carbsG: number; fatG: number },
  allMeals: readonly MealItem[],
): CardapioPlan[] {
  const dateRange = buildPlanDateRange(anchorDateKey, 7);
  const startDateKey = dateRange[0] ?? anchorDateKey;
  const endDateKey = dateRange[dateRange.length - 1] ?? anchorDateKey;

  const primaryDays: Record<string, ComposerDayPlan> = {};
  for (const dateKey of dateRange) {
    const dayMeals = allMeals.filter((meal) => meal.dateKey === dateKey);
    primaryDays[dateKey] = buildComposerDayFromMeals(dateKey, dayMeals);
  }

  const anchorDay = primaryDays[anchorDateKey] ?? buildComposerDayFromMeals(anchorDateKey, []);
  const primaryAllocations = buildDefaultMealAllocations(anchorDay.slots);

  const primaryPlan: CardapioPlan = {
    id: 'plan-principal',
    name: 'Plano principal · Equilíbrio ativo',
    revision: 4,
    status: 'active',
    startDateKey,
    endDateKey,
    targets: {
      kcal: dailyGoals.kcal,
      proteinG: dailyGoals.proteinG,
      carbsG: dailyGoals.carbsG,
      fatG: dailyGoals.fatG,
      kcalMin: Math.max(500, dailyGoals.kcal - 90),
      kcalMax: dailyGoals.kcal + 90,
      proteinMinG: Math.max(40, dailyGoals.proteinG - 10),
      proteinMaxG: dailyGoals.proteinG + 15,
      sourceLabel: 'Metas diárias TITAN',
    },
    mealAllocations: primaryAllocations,
    days: primaryDays,
    variants: [],
    activeVariantId: null,
  };

  // Secondary independent plan so side-by-side plan switching & comparison work out of the box
  const secondaryDays: Record<string, ComposerDayPlan> = {};
  for (const dateKey of dateRange) {
    const slots: ComposerMealSlot[] = [
      {
        id: 'sec-cafe',
        time: '07:30',
        title: 'Café da manhã',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-sanduiche-ovos') ?? RECIPE_CATALOG[0]!,
            'sec-cafe-rec-1',
            1,
            'balanced',
          ),
        ],
      },
      {
        id: 'sec-almoco',
        time: '12:30',
        title: 'Almoço',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-frango-leve') ?? RECIPE_CATALOG[1]!,
            'sec-almoco-rec-1',
            1,
            'balanced',
          ),
        ],
      },
      {
        id: 'sec-lanche',
        time: '16:00',
        title: 'Lanche da tarde',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-iogurte-leve') ?? RECIPE_CATALOG[2]!,
            'sec-lanche-rec-1',
            1,
            'balanced',
          ),
        ],
      },
      {
        id: 'sec-jantar',
        time: '20:30',
        title: 'Jantar',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-salmao-power') ?? RECIPE_CATALOG[3]!,
            'sec-jantar-rec-1',
            1,
            'balanced',
          ),
        ],
      },
    ];
    secondaryDays[dateKey] = { dateKey, slots };
  }

  const secondaryTargets: NutritionTargets = {
    kcal: Math.max(1400, Math.round(dailyGoals.kcal * 0.86)),
    proteinG: Math.max(100, Math.round(dailyGoals.proteinG * 1.02)),
    carbsG: Math.max(100, Math.round(dailyGoals.carbsG * 0.78)),
    fatG: Math.max(40, Math.round(dailyGoals.fatG * 0.85)),
    sourceLabel: 'Cenário de déficit controlado',
  };

  const secondaryPlan: CardapioPlan = {
    id: 'plan-cutting-controlado',
    name: 'Déficit técnico · Alta saciedade',
    revision: 2,
    status: 'draft',
    startDateKey,
    endDateKey,
    targets: secondaryTargets,
    mealAllocations: buildDefaultMealAllocations(secondaryDays[anchorDateKey]?.slots ?? []),
    days: secondaryDays,
    variants: [],
    activeVariantId: null,
  };

  return [primaryPlan, secondaryPlan];
}

export function getRecipeScaleFactor(recipe: Pick<RecipeInstance, 'baseServings' | 'targetServings'>): number {
  const base = Number.isFinite(recipe.baseServings) && recipe.baseServings > 0 ? recipe.baseServings : 1;
  const target = Number.isFinite(recipe.targetServings) && recipe.targetServings > 0 ? recipe.targetServings : 1;
  return Math.max(0.25, Math.min(4, target / base));
}

export function getScaledReferenceGrams(
  ingredient: Pick<IngredientAdjustment, 'baseQuantityG' | 'quantityStatus'>,
  scaleFactor: number,
): number | null {
  if (ingredient.quantityStatus !== 'known' || ingredient.baseQuantityG === null) {
    return null;
  }
  if (!Number.isFinite(ingredient.baseQuantityG) || ingredient.baseQuantityG <= 0) {
    return null;
  }
  return roundGramsHalf(ingredient.baseQuantityG * scaleFactor);
}

export function getEffectiveIngredientBounds(
  ingredient: IngredientAdjustment,
  scaleFactor: number,
): { minG: number; maxG: number } {
  const ref = getScaledReferenceGrams(ingredient, scaleFactor) ?? ingredient.currentQuantityG ?? 100;
  const rawMin =
    ingredient.minQuantityG !== null &&
    ingredient.minQuantityG !== undefined &&
    Number.isFinite(ingredient.minQuantityG) &&
    ingredient.minQuantityG > 0
      ? ingredient.minQuantityG
      : Math.max(5, roundGramsHalf(ref * 0.45));
  const rawMax =
    ingredient.maxQuantityG !== null &&
    ingredient.maxQuantityG !== undefined &&
    Number.isFinite(ingredient.maxQuantityG) &&
    ingredient.maxQuantityG > 0
      ? ingredient.maxQuantityG
      : Math.min(2000, Math.max(rawMin + 10, roundGramsHalf(ref * 1.85)));

  const minG = Math.max(1, Math.min(2000, rawMin));
  const maxG = Math.max(minG, Math.min(2000, rawMax));
  return { minG, maxG };
}

export function applyYieldScaleToRecipe(
  recipe: RecipeInstance,
  nextTargetServings: number,
): RecipeInstance {
  const safeTarget = Number.isFinite(nextTargetServings)
    ? Math.max(0.25, Math.min(4, Number(nextTargetServings.toFixed(2))))
    : recipe.targetServings;
  const prevScale = getRecipeScaleFactor(recipe);
  const nextScale = getRecipeScaleFactor({ baseServings: recipe.baseServings, targetServings: safeTarget });

  return {
    ...recipe,
    targetServings: safeTarget,
    ingredients: recipe.ingredients.map((ingredient) => {
      if (ingredient.quantityStatus !== 'known' || ingredient.baseQuantityG === null) {
        return ingredient;
      }
      const nextRef = roundGramsHalf(ingredient.baseQuantityG * nextScale);
      const nextMin = Math.max(1, roundGramsHalf(nextRef * 0.45));
      const nextMax = Math.min(2000, Math.max(nextMin + 10, roundGramsHalf(nextRef * 1.85)));

      if (ingredient.mode === 'locked') {
        return {
          ...ingredient,
          minQuantityG: nextMin,
          maxQuantityG: nextMax,
        };
      }
      if (ingredient.mode === 'proportional' || recipe.adjustmentMode === 'proportional') {
        return {
          ...ingredient,
          currentQuantityG: Math.max(1, Math.min(2000, nextRef)),
          minQuantityG: nextMin,
          maxQuantityG: nextMax,
        };
      }
      // Flexible keeps manual relative proportion when scaling recipe yield, clamped within updated corridor
      const ratioToPrev = prevScale > 0 && ingredient.currentQuantityG !== null
        ? ingredient.currentQuantityG / (ingredient.baseQuantityG * prevScale)
        : 1;
      const adjusted = roundGramsHalf(nextRef * ratioToPrev);
      return {
        ...ingredient,
        currentQuantityG: Math.max(nextMin, Math.min(nextMax, adjusted)),
        minQuantityG: nextMin,
        maxQuantityG: nextMax,
      };
    }),
  };
}

/**
 * Exact weighted quantity deviation metric:
 * D = (sum_i |x_i - q_i^{ref}| / sum_i q_i^{ref}) * 100
 */
export function computeWeightedDeviationPercent(
  ingredients: readonly IngredientAdjustment[],
  scaleFactor: number,
): number {
  let numerator = 0;
  let denominator = 0;
  for (const ingredient of ingredients) {
    if (ingredient.quantityStatus !== 'known') continue;
    const refG = getScaledReferenceGrams(ingredient, scaleFactor);
    if (refG === null || refG <= 0) continue;
    const currentG =
      ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
        ? Math.max(0, ingredient.currentQuantityG)
        : refG;
    numerator += Math.abs(currentG - refG);
    denominator += refG;
  }
  if (denominator <= 0) return 0;
  return Number(((numerator / denominator) * 100).toFixed(1));
}

export function computeDayWeightedDeviationPercent(dayPlan: ComposerDayPlan): number {
  let numerator = 0;
  let denominator = 0;
  for (const slot of dayPlan.slots) {
    for (const recipe of slot.recipes) {
      const scale = getRecipeScaleFactor(recipe);
      for (const ingredient of recipe.ingredients) {
        if (ingredient.quantityStatus !== 'known') continue;
        const refG = getScaledReferenceGrams(ingredient, scale);
        if (refG === null || refG <= 0) continue;
        const currentG =
          ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
            ? Math.max(0, ingredient.currentQuantityG)
            : refG;
        numerator += Math.abs(currentG - refG);
        denominator += refG;
      }
    }
  }
  if (denominator <= 0) return 0;
  return Number(((numerator / denominator) * 100).toFixed(1));
}

export type IngredientNutritionImpact =
  | {
      calculable: true;
      foodName: string;
      sourceId: FoodSourceId;
      sourceRecordId: string;
      sourceVersion: string;
      qualityStatus: string;
      activeQuantityG: number;
      referenceQuantityG: number;
      activeMacros: ComposerMacroTotals;
      deltaMacros: ComposerMacroTotals;
    }
  | {
      calculable: false;
      foodName: string;
      sourceId?: FoodSourceId;
      reason: string;
    };

export function computeIngredientNutritionImpact(
  ingredient: IngredientAdjustment,
  scaleFactor: number,
): IngredientNutritionImpact {
  const food = resolveFoodById(ingredient.foodId);
  const foodName = food?.name ?? ingredient.displayName ?? ingredient.foodId;

  if (ingredient.quantityStatus === 'to_taste') {
    return {
      calculable: false,
      foodName,
      sourceId: food?.source_id,
      reason: 'A gosto · peso não quantificado',
    };
  }
  if (ingredient.quantityStatus === 'missing') {
    return {
      calculable: false,
      foodName,
      sourceId: food?.source_id,
      reason: 'Quantidade pendente',
    };
  }
  if (!food) {
    return {
      calculable: false,
      foodName,
      reason: 'Impacto não calculável',
    };
  }

  const macros = food.macros;
  const macroFields = [
    macros.kcalPerBasis,
    macros.proteinGPerBasis,
    macros.carbsGPerBasis,
    macros.fatGPerBasis,
    macros.basisQuantityG,
  ];
  if (!macroFields.every((val) => Number.isFinite(val) && val >= 0) || macros.basisQuantityG <= 0) {
    return {
      calculable: false,
      foodName,
      sourceId: food.source_id,
      reason: 'Impacto não calculável',
    };
  }

  const refG = getScaledReferenceGrams(ingredient, scaleFactor);
  const activeG =
    ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
      ? Math.max(0, ingredient.currentQuantityG)
      : (refG ?? 0);

  if (refG === null || activeG <= 0) {
    return {
      calculable: false,
      foodName,
      sourceId: food.source_id,
      reason: 'Impacto não calculável',
    };
  }

  const activeRatio = activeG / macros.basisQuantityG;
  const refRatio = refG / macros.basisQuantityG;

  const activeMacros: ComposerMacroTotals = {
    kcal: macros.kcalPerBasis * activeRatio,
    proteinG: macros.proteinGPerBasis * activeRatio,
    carbsG: macros.carbsGPerBasis * activeRatio,
    fatG: macros.fatGPerBasis * activeRatio,
  };

  const deltaMacros: ComposerMacroTotals = {
    kcal: macros.kcalPerBasis * (activeRatio - refRatio),
    proteinG: macros.proteinGPerBasis * (activeRatio - refRatio),
    carbsG: macros.carbsGPerBasis * (activeRatio - refRatio),
    fatG: macros.fatGPerBasis * (activeRatio - refRatio),
  };

  return {
    calculable: true,
    foodName,
    sourceId: food.source_id,
    sourceRecordId: food.source_record_id,
    sourceVersion: food.source_version,
    qualityStatus: food.quality_status,
    activeQuantityG: activeG,
    referenceQuantityG: refG,
    activeMacros,
    deltaMacros,
  };
}

export interface ComposerNutritionSummary {
  macros: ComposerMacroTotals;
  totalGrams: number;
  knownIngredientsCount: number;
  missingIngredientsCount: number;
  toTasteIngredientsCount: number;
  unresolvedFoodIds: string[];
  coveragePercent: number;
  weightedDeviationPercent: number;
  sources: FoodSourceId[];
  micronutrients: Record<NutrientId, { value: number | null; unit: string; quantifiedCount: number }>;
}

function emptyMicronutrientTotals(): Record<
  NutrientId,
  { value: number | null; unit: string; quantifiedCount: number }
> {
  const out = {} as Record<NutrientId, { value: number | null; unit: string; quantifiedCount: number }>;
  for (const id of MICRONUTRIENT_ORDER) {
    out[id] = {
      value: null,
      unit: MICRONUTRIENT_PT_LABELS[id].unit,
      quantifiedCount: 0,
    };
  }
  return out;
}

export function computeRecipeNutrition(recipe: RecipeInstance): ComposerNutritionSummary {
  const scale = getRecipeScaleFactor(recipe);
  const macros: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const micronutrients = emptyMicronutrientTotals();
  let totalGrams = 0;
  let quantifiedGrams = 0;
  let knownIngredientsCount = 0;
  let missingIngredientsCount = 0;
  let toTasteIngredientsCount = 0;
  const unresolvedSet = new Set<string>();
  const sourceSet = new Set<FoodSourceId>();

  for (const ingredient of recipe.ingredients) {
    if (ingredient.quantityStatus === 'to_taste') {
      toTasteIngredientsCount += 1;
      const food = resolveFoodById(ingredient.foodId);
      if (food) sourceSet.add(food.source_id);
      continue;
    }
    if (
      ingredient.quantityStatus === 'missing' ||
      ingredient.currentQuantityG === null ||
      !Number.isFinite(ingredient.currentQuantityG) ||
      ingredient.currentQuantityG <= 0
    ) {
      missingIngredientsCount += 1;
      continue;
    }

    knownIngredientsCount += 1;
    totalGrams += ingredient.currentQuantityG;

    const food = resolveFoodById(ingredient.foodId);
    if (!food) {
      unresolvedSet.add(ingredient.foodId);
      continue;
    }
    sourceSet.add(food.source_id);

    const basis = food.macros.basisQuantityG;
    if (!Number.isFinite(basis) || basis <= 0) {
      unresolvedSet.add(ingredient.foodId);
      continue;
    }

    const ratio = ingredient.currentQuantityG / basis;
    macros.kcal += food.macros.kcalPerBasis * ratio;
    macros.proteinG += food.macros.proteinGPerBasis * ratio;
    macros.carbsG += food.macros.carbsGPerBasis * ratio;
    macros.fatG += food.macros.fatGPerBasis * ratio;
    quantifiedGrams += ingredient.currentQuantityG;

    for (const nutrientId of KEY_COMPOSER_MICRONUTRIENTS) {
      const record = normalizeNutrientEntry(food, nutrientId);
      if (
        record.data_status === 'quantified' &&
        record.normalized_value !== null &&
        Number.isFinite(record.basis_quantity) &&
        record.basis_quantity > 0
      ) {
        const contribution = (record.normalized_value / record.basis_quantity) * ingredient.currentQuantityG;
        const current = micronutrients[nutrientId];
        micronutrients[nutrientId] = {
          value: (current.value ?? 0) + contribution,
          unit: record.normalized_unit || current.unit,
          quantifiedCount: current.quantifiedCount + 1,
        };
      }
    }
  }

  return {
    macros,
    totalGrams,
    knownIngredientsCount,
    missingIngredientsCount,
    toTasteIngredientsCount,
    unresolvedFoodIds: [...unresolvedSet],
    coveragePercent: totalGrams > 0 ? Number(((quantifiedGrams / totalGrams) * 100).toFixed(1)) : 0,
    weightedDeviationPercent: computeWeightedDeviationPercent(recipe.ingredients, scale),
    sources: [...sourceSet],
    micronutrients,
  };
}

export function computeSlotNutrition(slot: ComposerMealSlot): ComposerNutritionSummary {
  const macros: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const micronutrients = emptyMicronutrientTotals();
  let totalGrams = 0;
  let quantifiedGrams = 0;
  let knownIngredientsCount = 0;
  let missingIngredientsCount = 0;
  let toTasteIngredientsCount = 0;
  const unresolvedSet = new Set<string>();
  const sourceSet = new Set<FoodSourceId>();

  for (const recipe of slot.recipes) {
    const recSummary = computeRecipeNutrition(recipe);
    macros.kcal += recSummary.macros.kcal;
    macros.proteinG += recSummary.macros.proteinG;
    macros.carbsG += recSummary.macros.carbsG;
    macros.fatG += recSummary.macros.fatG;
    totalGrams += recSummary.totalGrams;
    quantifiedGrams += (recSummary.totalGrams * recSummary.coveragePercent) / 100;
    knownIngredientsCount += recSummary.knownIngredientsCount;
    missingIngredientsCount += recSummary.missingIngredientsCount;
    toTasteIngredientsCount += recSummary.toTasteIngredientsCount;
    recSummary.unresolvedFoodIds.forEach((id) => unresolvedSet.add(id));
    recSummary.sources.forEach((src) => sourceSet.add(src));
    for (const nutrientId of KEY_COMPOSER_MICRONUTRIENTS) {
      const recMicro = recSummary.micronutrients[nutrientId];
      if (recMicro.value !== null) {
        const cur = micronutrients[nutrientId];
        micronutrients[nutrientId] = {
          value: (cur.value ?? 0) + recMicro.value,
          unit: recMicro.unit,
          quantifiedCount: cur.quantifiedCount + recMicro.quantifiedCount,
        };
      }
    }
  }

  // Exact weighted deviation across all recipes inside the slot
  let devNum = 0;
  let devDen = 0;
  for (const recipe of slot.recipes) {
    const scale = getRecipeScaleFactor(recipe);
    for (const ingredient of recipe.ingredients) {
      if (ingredient.quantityStatus !== 'known') continue;
      const refG = getScaledReferenceGrams(ingredient, scale);
      if (refG === null || refG <= 0) continue;
      const curG = ingredient.currentQuantityG ?? refG;
      devNum += Math.abs(curG - refG);
      devDen += refG;
    }
  }

  return {
    macros,
    totalGrams,
    knownIngredientsCount,
    missingIngredientsCount,
    toTasteIngredientsCount,
    unresolvedFoodIds: [...unresolvedSet],
    coveragePercent: totalGrams > 0 ? Number(((quantifiedGrams / totalGrams) * 100).toFixed(1)) : 0,
    weightedDeviationPercent: devDen > 0 ? Number(((devNum / devDen) * 100).toFixed(1)) : 0,
    sources: [...sourceSet],
    micronutrients,
  };
}

export function computeDayNutrition(dayPlan: ComposerDayPlan): ComposerNutritionSummary {
  const macros: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const micronutrients = emptyMicronutrientTotals();
  let totalGrams = 0;
  let quantifiedGrams = 0;
  let knownIngredientsCount = 0;
  let missingIngredientsCount = 0;
  let toTasteIngredientsCount = 0;
  const unresolvedSet = new Set<string>();
  const sourceSet = new Set<FoodSourceId>();

  for (const slot of dayPlan.slots) {
    const slotSummary = computeSlotNutrition(slot);
    macros.kcal += slotSummary.macros.kcal;
    macros.proteinG += slotSummary.macros.proteinG;
    macros.carbsG += slotSummary.macros.carbsG;
    macros.fatG += slotSummary.macros.fatG;
    totalGrams += slotSummary.totalGrams;
    quantifiedGrams += (slotSummary.totalGrams * slotSummary.coveragePercent) / 100;
    knownIngredientsCount += slotSummary.knownIngredientsCount;
    missingIngredientsCount += slotSummary.missingIngredientsCount;
    toTasteIngredientsCount += slotSummary.toTasteIngredientsCount;
    slotSummary.unresolvedFoodIds.forEach((id) => unresolvedSet.add(id));
    slotSummary.sources.forEach((src) => sourceSet.add(src));
    for (const nutrientId of KEY_COMPOSER_MICRONUTRIENTS) {
      const slotMicro = slotSummary.micronutrients[nutrientId];
      if (slotMicro.value !== null) {
        const cur = micronutrients[nutrientId];
        micronutrients[nutrientId] = {
          value: (cur.value ?? 0) + slotMicro.value,
          unit: slotMicro.unit,
          quantifiedCount: cur.quantifiedCount + slotMicro.quantifiedCount,
        };
      }
    }
  }

  return {
    macros,
    totalGrams,
    knownIngredientsCount,
    missingIngredientsCount,
    toTasteIngredientsCount,
    unresolvedFoodIds: [...unresolvedSet],
    coveragePercent: totalGrams > 0 ? Number(((quantifiedGrams / totalGrams) * 100).toFixed(1)) : 0,
    weightedDeviationPercent: computeDayWeightedDeviationPercent(dayPlan),
    sources: [...sourceSet],
    micronutrients,
  };
}

export function extractMealPortionsFromSlot(slot: ComposerMealSlot): MealFoodPortion[] {
  const portions: MealFoodPortion[] = [];
  for (const recipe of slot.recipes) {
    for (const ingredient of recipe.ingredients) {
      if (
        ingredient.quantityStatus === 'known' &&
        ingredient.currentQuantityG !== null &&
        Number.isFinite(ingredient.currentQuantityG) &&
        ingredient.currentQuantityG > 0
      ) {
        const existing = portions.find((p) => p.foodId === ingredient.foodId);
        if (existing) {
          existing.quantityG = Number((existing.quantityG + ingredient.currentQuantityG).toFixed(2));
        } else {
          portions.push({
            foodId: ingredient.foodId,
            quantityG: Number(ingredient.currentQuantityG.toFixed(2)),
          });
        }
      }
    }
  }
  return portions;
}

export interface SlotAllocationEvaluation {
  slotId: string;
  slotTitle: string;
  slotTime: string;
  sharePercent: number;
  targetKcal: number;
  actualKcal: number;
  deltaKcal: number;
  targetProteinG: number;
  actualProteinG: number;
}

export interface MealAllocationSummary {
  totalSharePercent: number;
  unallocatedPercent: number;
  isBalanced: boolean;
  slots: SlotAllocationEvaluation[];
}

export function evaluateMealAllocations(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  allocations: readonly MealTargetAllocation[],
): MealAllocationSummary {
  const allocationById = new Map(allocations.map((a) => [a.slotId, a]));
  const fallbackShare = dayPlan.slots.length > 0 ? Number((100 / dayPlan.slots.length).toFixed(1)) : 0;

  let totalSharePercent = 0;
  const slots: SlotAllocationEvaluation[] = dayPlan.slots.map((slot) => {
    const config = allocationById.get(slot.id);
    const sharePercent =
      config && Number.isFinite(config.energySharePercent)
        ? Math.max(0, Math.min(100, config.energySharePercent))
        : fallbackShare;
    totalSharePercent += sharePercent;
    const summary = computeSlotNutrition(slot);
    const targetKcal = Math.round((targets.kcal * sharePercent) / 100);
    const proteinShare = config?.proteinSharePercent ?? sharePercent;
    const targetProteinG = Math.round((targets.proteinG * proteinShare) / 100);
    return {
      slotId: slot.id,
      slotTitle: slot.title,
      slotTime: slot.time,
      sharePercent: Number(sharePercent.toFixed(1)),
      targetKcal,
      actualKcal: Math.round(summary.macros.kcal),
      deltaKcal: Math.round(summary.macros.kcal - targetKcal),
      targetProteinG,
      actualProteinG: Math.round(summary.macros.proteinG),
    };
  });

  const roundedTotal = Number(totalSharePercent.toFixed(1));
  const unallocatedPercent = Number((100 - roundedTotal).toFixed(1));
  return {
    totalSharePercent: roundedTotal,
    unallocatedPercent,
    isBalanced: Math.abs(unallocatedPercent) <= 0.2,
    slots,
  };
}

export interface OptimizeBalanceOptions {
  scopeSlotId?: string;
  lambda?: number;
  goalFocus?: 'balanced' | 'energy' | 'protein';
}

interface DecisionVar {
  slotId: string;
  slotTitle: string;
  recipeId: string;
  recipeName: string;
  ingredientId: string;
  foodId: string;
  foodName: string;
  currentG: number;
  refG: number;
  minG: number;
  maxG: number;
  kcalPerG: number;
  proteinPerG: number;
  carbsPerG: number;
  fatPerG: number;
}

/**
 * Deterministic Strictly Convex Quadratic Programming Solver (Projected FISTA + Coordinate Polish)
 *
 * Minimizes:
 *   sum_k w_k * ((N_k(x) - T_k) / S_k)^2 + lambda * sum_i ((x_i - q_i^{ref}) / (q_i^{ref} + eps))^2
 * subject to l_i <= x_i <= u_i over `flexible` ingredients.
 *
 * `locked` ingredients keep their fixed x_i; `proportional` ingredients stay at s * q_i.
 */
export function solveNutritionalBalanceQP(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions = {},
): OptimizationProposal {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const beforeSummary = computeDayNutrition(dayPlan);
  const lambda = Number.isFinite(options.lambda) ? Math.max(0.01, options.lambda!) : 0.08;
  const focus = options.goalFocus ?? 'balanced';

  const weights =
    focus === 'protein'
      ? { kcal: 1.15, proteinG: 2.1, carbsG: 0.7, fatG: 0.75 }
      : focus === 'energy'
        ? { kcal: 2.2, proteinG: 1.1, carbsG: 0.85, fatG: 0.85 }
        : { kcal: 1.45, proteinG: 1.35, carbsG: 0.9, fatG: 0.9 };

  const scales = {
    kcal: Math.max(400, targets.kcal),
    proteinG: Math.max(30, targets.proteinG),
    carbsG: Math.max(40, targets.carbsG),
    fatG: Math.max(15, targets.fatG),
  };

  const fixedTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const vars: DecisionVar[] = [];
  let lockedCount = 0;
  let proportionalCount = 0;

  for (const slot of dayPlan.slots) {
    const inScope = !options.scopeSlotId || slot.id === options.scopeSlotId;
    for (const recipe of slot.recipes) {
      const scaleFactor = getRecipeScaleFactor(recipe);
      for (const ingredient of recipe.ingredients) {
        if (ingredient.quantityStatus !== 'known') continue;
        const food = resolveFoodById(ingredient.foodId);
        const refG = getScaledReferenceGrams(ingredient, scaleFactor);
        const curG =
          ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
            ? ingredient.currentQuantityG
            : (refG ?? 0);

        if (!food || food.macros.basisQuantityG <= 0 || curG <= 0) {
          continue;
        }

        const basis = food.macros.basisQuantityG;
        const kcalPerG = food.macros.kcalPerBasis / basis;
        const proteinPerG = food.macros.proteinGPerBasis / basis;
        const carbsPerG = food.macros.carbsGPerBasis / basis;
        const fatPerG = food.macros.fatGPerBasis / basis;

        if (!inScope || ingredient.mode === 'locked' || ingredient.mode === 'proportional') {
          if (ingredient.mode === 'locked') lockedCount += 1;
          else proportionalCount += 1;

          const effectiveG =
            ingredient.mode === 'proportional' && refG !== null ? refG : curG;
          fixedTotals.kcal += kcalPerG * effectiveG;
          fixedTotals.proteinG += proteinPerG * effectiveG;
          fixedTotals.carbsG += carbsPerG * effectiveG;
          fixedTotals.fatG += fatPerG * effectiveG;
          continue;
        }

        const bounds = getEffectiveBounds(ingredient, scaleFactor);
        vars.push({
          slotId: slot.id,
          slotTitle: slot.title,
          recipeId: recipe.id,
          recipeName: recipe.name,
          ingredientId: ingredient.id,
          foodId: ingredient.foodId,
          foodName: food.name,
          currentG: Math.max(bounds.minG, Math.min(bounds.maxG, curG)),
          refG: refG ?? curG,
          minG: bounds.minG,
          maxG: bounds.maxG,
          kcalPerG,
          proteinPerG,
          carbsPerG,
          fatPerG,
        });
      }
    }
  }

  const n = vars.length;
  if (n === 0) {
    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
    return {
      id: `opt-${Date.now().toString(36)}`,
      certificate: 'approximate',
      explanation:
        'Nenhum ingrediente flexível com composição calculável está desbloqueado para otimização contínua. Libere ao menos um ingrediente para o modo Flexível.',
      beforeMacros: beforeSummary.macros,
      afterMacros: beforeSummary.macros,
      targets: { ...targets },
      weightedDeviationBeforePercent: beforeSummary.weightedDeviationPercent,
      weightedDeviationAfterPercent: beforeSummary.weightedDeviationPercent,
      adjustedCount: 0,
      lockedCount,
      proportionalCount,
      changes: [],
      proposedDayPlan: cloneDayPlan(dayPlan),
      solveDurationMs: Number((t1 - t0).toFixed(2)),
    };
  }

  const invScale2 = {
    kcal: (2 * weights.kcal) / (scales.kcal * scales.kcal),
    proteinG: (2 * weights.proteinG) / (scales.proteinG * scales.proteinG),
    carbsG: (2 * weights.carbsG) / (scales.carbsG * scales.carbsG),
    fatG: (2 * weights.fatG) / (scales.fatG * scales.fatG),
  };

  // Compute global Lipschitz constant L for exact projected gradient step 1/L
  let sumA2Kcal = 0;
  let sumA2P = 0;
  let sumA2C = 0;
  let sumA2F = 0;
  let maxProxHessian = 0;
  const proxCoeff = new Float64Array(n);

  for (let i = 0; i < n; i += 1) {
    const v = vars[i]!;
    sumA2Kcal += v.kcalPerG * v.kcalPerG;
    sumA2P += v.proteinPerG * v.proteinPerG;
    sumA2C += v.carbsPerG * v.carbsPerG;
    sumA2F += v.fatPerG * v.fatPerG;
    const denom = v.refG + 25;
    const pCoeff = (2 * lambda) / (denom * denom);
    proxCoeff[i] = pCoeff;
    if (pCoeff > maxProxHessian) maxProxHessian = pCoeff;
  }

  const lipschitz =
    invScale2.kcal * sumA2Kcal +
    invScale2.proteinG * sumA2P +
    invScale2.carbsG * sumA2C +
    invScale2.fatG * sumA2F +
    maxProxHessian +
    1e-9;
  const stepSize = 1 / lipschitz;

  const x = new Float64Array(n);
  const y = new Float64Array(n);
  const xPrev = new Float64Array(n);
  const grad = new Float64Array(n);

  for (let i = 0; i < n; i += 1) {
    const v = vars[i]!;
    x[i] = v.currentG;
    y[i] = v.currentG;
    xPrev[i] = v.currentG;
  }

  const computeTotalsFromVec = (vec: Float64Array) => {
    let kcal = fixedTotals.kcal;
    let proteinG = fixedTotals.proteinG;
    let carbsG = fixedTotals.carbsG;
    let fatG = fixedTotals.fatG;
    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      const q = vec[i]!;
      kcal += v.kcalPerG * q;
      proteinG += v.proteinPerG * q;
      carbsG += v.carbsPerG * q;
      fatG += v.fatPerG * q;
    }
    return { kcal, proteinG, carbsG, fatG };
  };

  const computeGradAt = (vec: Float64Array, outGrad: Float64Array) => {
    const totals = computeTotalsFromVec(vec);
    const resKcal = (totals.kcal - targets.kcal) * invScale2.kcal;
    const resP = (totals.proteinG - targets.proteinG) * invScale2.proteinG;
    const resC = (totals.carbsG - targets.carbsG) * invScale2.carbsG;
    const resF = (totals.fatG - targets.fatG) * invScale2.fatG;

    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      outGrad[i] =
        resKcal * v.kcalPerG +
        resP * v.proteinPerG +
        resC * v.carbsPerG +
        resF * v.fatPerG +
        proxCoeff[i]! * (vec[i]! - v.refG);
    }
  };

  // Phase 1: FISTA with adaptive gradient restart
  let tMomentum = 1;
  for (let iter = 0; iter < 320; iter += 1) {
    computeGradAt(y, grad);
    let restartDot = 0;
    let maxMove = 0;
    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      const rawNext = y[i]! - stepSize * grad[i]!;
      const clamped = Math.max(v.minG, Math.min(v.maxG, rawNext));
      xPrev[i] = x[i]!;
      x[i] = clamped;
      restartDot += (y[i]! - clamped) * (clamped - xPrev[i]!);
      const diff = Math.abs(clamped - xPrev[i]!);
      if (diff > maxMove) maxMove = diff;
    }

    if (restartDot > 0) {
      tMomentum = 1;
      for (let i = 0; i < n; i += 1) {
        y[i] = x[i]!;
      }
    } else {
      const tNext = 0.5 * (1 + Math.sqrt(1 + 4 * tMomentum * tMomentum));
      const beta = (tMomentum - 1) / tNext;
      for (let i = 0; i < n; i += 1) {
        const v = vars[i]!;
        const extrapolated = x[i]! + beta * (x[i]! - xPrev[i]!);
        y[i] = Math.max(v.minG, Math.min(v.maxG, extrapolated));
      }
      tMomentum = tNext;
    }

    if (maxMove < 1e-5 && iter > 20) break;
  }

  // Phase 2: Exact coordinate-descent box-constrained QP polish
  for (let sweep = 0; sweep < 40; sweep += 1) {
    let sweepDelta = 0;
    const totals = computeTotalsFromVec(x);
    let curKcal = totals.kcal;
    let curP = totals.proteinG;
    let curC = totals.carbsG;
    let curF = totals.fatG;

    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      const oldXi = x[i]!;
      const hDiag =
        invScale2.kcal * v.kcalPerG * v.kcalPerG +
        invScale2.proteinG * v.proteinPerG * v.proteinPerG +
        invScale2.carbsG * v.carbsPerG * v.carbsPerG +
        invScale2.fatG * v.fatPerG * v.fatPerG +
        proxCoeff[i]!;
      if (hDiag <= 1e-12) continue;

      const gCoord =
        (curKcal - targets.kcal) * invScale2.kcal * v.kcalPerG +
        (curP - targets.proteinG) * invScale2.proteinG * v.proteinPerG +
        (curC - targets.carbsG) * invScale2.carbsG * v.carbsPerG +
        (curF - targets.fatG) * invScale2.fatG * v.fatPerG +
        proxCoeff[i]! * (oldXi - v.refG);

      const newXi = Math.max(v.minG, Math.min(v.maxG, oldXi - gCoord / hDiag));
      const delta = newXi - oldXi;
      if (Math.abs(delta) > 1e-8) {
        x[i] = newXi;
        curKcal += v.kcalPerG * delta;
        curP += v.proteinPerG * delta;
        curC += v.carbsPerG * delta;
        curF += v.fatPerG * delta;
        sweepDelta = Math.max(sweepDelta, Math.abs(delta));
      }
    }
    if (sweepDelta < 1e-5) break;
  }

  // KKT residual verification before rounding
  computeGradAt(x, grad);
  let maxKktViolation = 0;
  for (let i = 0; i < n; i += 1) {
    const v = vars[i]!;
    const xi = x[i]!;
    const gi = grad[i]!;
    let violation = 0;
    if (xi <= v.minG + 1e-4) {
      violation = Math.max(0, -gi);
    } else if (xi >= v.maxG - 1e-4) {
      violation = Math.max(0, gi);
    } else {
      violation = Math.abs(gi);
    }
    if (violation > maxKktViolation) maxKktViolation = violation;
  }

  // Apply 0.5 g quantization respecting [minG, maxG]
  const proposedMap = new Map<string, number>();
  const changes: ProposedIngredientChange[] = [];
  let atBoundCount = 0;

  for (let i = 0; i < n; i += 1) {
    const v = vars[i]!;
    const rounded = Math.max(v.minG, Math.min(v.maxG, roundGramsHalf(x[i]!)));
    const key = `${v.slotId}::${v.recipeId}::${v.ingredientId}`;
    proposedMap.set(key, rounded);

    const atLowerBound = Math.abs(rounded - v.minG) <= 0.5;
    const atUpperBound = Math.abs(rounded - v.maxG) <= 0.5;
    if (atLowerBound || atUpperBound) atBoundCount += 1;

    changes.push({
      slotId: v.slotId,
      slotTitle: v.slotTitle,
      recipeId: v.recipeId,
      recipeName: v.recipeName,
      ingredientId: v.ingredientId,
      foodId: v.foodId,
      foodName: v.foodName,
      currentQuantityG: v.currentG,
      proposedQuantityG: rounded,
      referenceQuantityG: v.refG,
      deltaG: Number((rounded - v.currentG).toFixed(1)),
      atLowerBound,
      atUpperBound,
    });
  }

  const proposedDayPlan = cloneDayPlan(dayPlan);
  for (const slot of proposedDayPlan.slots) {
    for (const recipe of slot.recipes) {
      for (const ingredient of recipe.ingredients) {
        const key = `${slot.id}::${recipe.id}::${ingredient.id}`;
        const nextQ = proposedMap.get(key);
        if (nextQ !== undefined) {
          ingredient.currentQuantityG = nextQ;
        }
      }
    }
  }

  const afterSummary = computeDayNutrition(proposedDayPlan);
  const kcalGap = Math.abs(afterSummary.macros.kcal - targets.kcal);
  const pGap = Math.abs(afterSummary.macros.proteinG - targets.proteinG);
  const cGap = Math.abs(afterSummary.macros.carbsG - targets.carbsG);
  const fGap = Math.abs(afterSummary.macros.fatG - targets.fatG);

  const kcalTol = Math.max(55, targets.kcal * 0.03);
  const pTol = Math.max(8, targets.proteinG * 0.06);
  const cTol = Math.max(12, targets.carbsG * 0.07);
  const fTol = Math.max(6, targets.fatG * 0.08);

  const targetsCloselyMet = kcalGap <= kcalTol && pGap <= pTol && cGap <= cTol && fGap <= fTol;

  let certificate: SolverCertificate = 'optimal';
  let explanation = 'Ótimo convexo alcançado dentro dos limites culinários e com menor desvio ponderado possível.';

  if (maxKktViolation > 5e-3) {
    certificate = 'approximate';
    explanation =
      'Aproximação numérica gerada; refine limites mínimos/máximos ou desbloqueie mais ingredientes para convergência exata.';
  } else if (!targetsCloselyMet) {
    certificate = 'feasible';
    const reasons: string[] = [];
    if (atBoundCount > 0) {
      reasons.push(`${atBoundCount} ingrediente(s) atingiram limite mínimo/máximo de porção`);
    }
    if (lockedCount > 0) {
      reasons.push(`${lockedCount} item(ns) estão fixados`);
    }
    explanation =
      reasons.length > 0
        ? `Melhor solução viável encontrada (${reasons.join(' · ')}). Para fechar o restante da meta, avalie trocas discretas de receita.`
        : 'Melhor equilíbrio contínuo encontrado preservando as proporções das receitas. Use substituições discretas se quiser alterar o perfil dos alimentos.';
  }

  const adjustedCount = changes.filter((c) => Math.abs(c.deltaG) >= 0.5).length;
  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();

  return {
    id: `opt-${Date.now().toString(36)}`,
    certificate,
    explanation,
    beforeMacros: beforeSummary.macros,
    afterMacros: afterSummary.macros,
    targets: { ...targets },
    weightedDeviationBeforePercent: beforeSummary.weightedDeviationPercent,
    weightedDeviationAfterPercent: afterSummary.weightedDeviationPercent,
    adjustedCount,
    lockedCount,
    proportionalCount,
    changes,
    proposedDayPlan,
    solveDurationMs: Number((t1 - t0).toFixed(2)),
  };
}

function normalizedTargetGap(macros: ComposerMacroTotals, targets: NutritionTargets): number {
  const e = (macros.kcal - targets.kcal) / Math.max(400, targets.kcal);
  const p = (macros.proteinG - targets.proteinG) / Math.max(30, targets.proteinG);
  const c = (macros.carbsG - targets.carbsG) / Math.max(40, targets.carbsG);
  const f = (macros.fatG - targets.fatG) / Math.max(15, targets.fatG);
  return Math.sqrt(1.4 * e * e + 1.3 * p * p + 0.85 * c * c + 0.85 * f * f);
}

export function proposeDiscreteSubstitutions(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  limit = 4,
): DiscreteSubstitutionProposal[] {
  const currentSummary = computeDayNutrition(dayPlan);
  const currentGap = normalizedTargetGap(currentSummary.macros, targets);
  const candidates: DiscreteSubstitutionProposal[] = [];

  for (const slot of dayPlan.slots) {
    const primaryRecipe = slot.recipes[0];
    if (!primaryRecipe) continue;

    const currentRecipeSummary = computeRecipeNutrition(primaryRecipe);
    for (const catalogRecipe of RECIPE_CATALOG) {
      if (catalogRecipe.id === primaryRecipe.sourceRecipeId) continue;

      const candidateInstance = createRecipeInstanceFromCatalog(
        catalogRecipe,
        `${slot.id}-cand-${catalogRecipe.id}`,
        1,
        'balanced',
      );
      const candidateSummary = computeRecipeNutrition(candidateInstance);
      const deltaMacros: ComposerMacroTotals = {
        kcal: candidateSummary.macros.kcal - currentRecipeSummary.macros.kcal,
        proteinG: candidateSummary.macros.proteinG - currentRecipeSummary.macros.proteinG,
        carbsG: candidateSummary.macros.carbsG - currentRecipeSummary.macros.carbsG,
        fatG: candidateSummary.macros.fatG - currentRecipeSummary.macros.fatG,
      };
      const projectedDayMacros: ComposerMacroTotals = {
        kcal: currentSummary.macros.kcal + deltaMacros.kcal,
        proteinG: currentSummary.macros.proteinG + deltaMacros.proteinG,
        carbsG: currentSummary.macros.carbsG + deltaMacros.carbsG,
        fatG: currentSummary.macros.fatG + deltaMacros.fatG,
      };
      const targetGapAfter = normalizedTargetGap(projectedDayMacros, targets);
      const sameCategoryBonus = catalogRecipe.category === primaryRecipe.category ? -0.02 : 0;

      if (targetGapAfter + sameCategoryBonus < currentGap + 0.08) {
        candidates.push({
          id: `sub-${slot.id}-${catalogRecipe.id}`,
          slotId: slot.id,
          slotTitle: slot.title,
          currentRecipeId: primaryRecipe.id,
          currentRecipeName: primaryRecipe.name,
          candidateRecipeId: catalogRecipe.id,
          candidateRecipeName: catalogRecipe.name,
          sourceSummary: candidateSummary.sources.join(' · ') || 'TBCA',
          deltaMacros,
          projectedDayMacros,
          targetGapAfter: Number((targetGapAfter + sameCategoryBonus).toFixed(4)),
        });
      }
    }
  }

  candidates.sort((a, b) => a.targetGapAfter - b.targetGapAfter);
  return candidates.slice(0, Math.max(1, limit));
}

export interface IngredientDiffRow {
  foodId: string;
  foodName: string;
  baselineGrams: number;
  candidateGrams: number;
  deltaGrams: number;
  status: 'added' | 'removed' | 'modified' | 'unchanged';
}

export interface CompositionDiffSummary {
  baselineMacros: ComposerMacroTotals;
  candidateMacros: ComposerMacroTotals;
  deltaMacros: ComposerMacroTotals;
  baselineDeviationPercent: number;
  candidateDeviationPercent: number;
  addedRecipes: string[];
  removedRecipes: string[];
  ingredientDiffs: IngredientDiffRow[];
  micronutrientDeltas: Array<{
    nutrientId: NutrientId;
    label: string;
    unit: string;
    baselineValue: number | null;
    candidateValue: number | null;
  }>;
  baselineSources: FoodSourceId[];
  candidateSources: FoodSourceId[];
}

export function computeCompositionDiff(
  baselineDay: ComposerDayPlan,
  candidateDay: ComposerDayPlan,
): CompositionDiffSummary {
  const baselineSummary = computeDayNutrition(baselineDay);
  const candidateSummary = computeDayNutrition(candidateDay);

  const baselineRecipes = new Map<string, string>();
  const candidateRecipes = new Map<string, string>();
  const baselineFoods = new Map<string, { name: string; grams: number }>();
  const candidateFoods = new Map<string, { name: string; grams: number }>();

  const collect = (
    day: ComposerDayPlan,
    recipeMap: Map<string, string>,
    foodMap: Map<string, { name: string; grams: number }>,
  ) => {
    for (const slot of day.slots) {
      for (const recipe of slot.recipes) {
        const recipeKey = recipe.sourceRecipeId ?? recipe.name;
        recipeMap.set(recipeKey, recipe.name);
        for (const ing of recipe.ingredients) {
          if (ing.quantityStatus !== 'known' || ing.currentQuantityG === null) continue;
          const food = resolveFoodById(ing.foodId);
          const name = food?.name ?? ing.displayName ?? ing.foodId;
          const prev = foodMap.get(ing.foodId);
          foodMap.set(ing.foodId, {
            name,
            grams: (prev?.grams ?? 0) + ing.currentQuantityG,
          });
        }
      }
    }
  };

  collect(baselineDay, baselineRecipes, baselineFoods);
  collect(candidateDay, candidateRecipes, candidateFoods);

  const addedRecipes: string[] = [];
  const removedRecipes: string[] = [];
  for (const [key, name] of candidateRecipes.entries()) {
    if (!baselineRecipes.has(key)) addedRecipes.push(name);
  }
  for (const [key, name] of baselineRecipes.entries()) {
    if (!candidateRecipes.has(key)) removedRecipes.push(name);
  }

  const allFoodIds = new Set([...baselineFoods.keys(), ...candidateFoods.keys()]);
  const ingredientDiffs: IngredientDiffRow[] = [];
  for (const foodId of allFoodIds) {
    const base = baselineFoods.get(foodId);
    const cand = candidateFoods.get(foodId);
    const baselineGrams = Number((base?.grams ?? 0).toFixed(1));
    const candidateGrams = Number((cand?.grams ?? 0).toFixed(1));
    const deltaGrams = Number((candidateGrams - baselineGrams).toFixed(1));
    const status: IngredientDiffRow['status'] = !base
      ? 'added'
      : !cand
        ? 'removed'
        : Math.abs(deltaGrams) >= 0.5
          ? 'modified'
          : 'unchanged';
    ingredientDiffs.push({
      foodId,
      foodName: cand?.name ?? base?.name ?? foodId,
      baselineGrams,
      candidateGrams,
      deltaGrams,
      status,
    });
  }

  ingredientDiffs.sort((a, b) => Math.abs(b.deltaGrams) - Math.abs(a.deltaGrams));

  const micronutrientDeltas = KEY_COMPOSER_MICRONUTRIENTS.map((nutrientId) => ({
    nutrientId,
    label: MICRONUTRIENT_PT_LABELS[nutrientId].label,
    unit: MICRONUTRIENT_PT_LABELS[nutrientId].unit,
    baselineValue: baselineSummary.micronutrients[nutrientId].value,
    candidateValue: candidateSummary.micronutrients[nutrientId].value,
  }));

  return {
    baselineMacros: baselineSummary.macros,
    candidateMacros: candidateSummary.macros,
    deltaMacros: {
      kcal: candidateSummary.macros.kcal - baselineSummary.macros.kcal,
      proteinG: candidateSummary.macros.proteinG - baselineSummary.macros.proteinG,
      carbsG: candidateSummary.macros.carbsG - baselineSummary.macros.carbsG,
      fatG: candidateSummary.macros.fatG - baselineSummary.macros.fatG,
    },
    baselineDeviationPercent: baselineSummary.weightedDeviationPercent,
    candidateDeviationPercent: candidateSummary.weightedDeviationPercent,
    addedRecipes,
    removedRecipes,
    ingredientDiffs,
    micronutrientDeltas,
    baselineSources: baselineSummary.sources,
    candidateSources: candidateSummary.sources,
  };
}
