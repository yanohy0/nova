import type {
  ComposerDayPlan,
  DiscreteSubstitutionProposal,
  NutritionTargets,
  OptimizationProposal,
} from '../domain/entities/nutrient.ts';
import {
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
} from '../domain/rules/cardapio-composer-engine.ts';

export interface OptimizerWorkerRequest {
  requestId: number;
  dayPlan: ComposerDayPlan;
  targets: NutritionTargets;
  options?: OptimizeBalanceOptions;
  includeSubstitutions?: boolean;
}

export interface OptimizerWorkerResponse {
  requestId: number;
  proposal: OptimizationProposal;
  substitutions: DiscreteSubstitutionProposal[];
}

const workerScope = globalThis as unknown as {
  onmessage: ((event: MessageEvent<OptimizerWorkerRequest>) => void) | null;
  postMessage: (message: OptimizerWorkerResponse) => void;
};

if (typeof workerScope.postMessage === 'function') {
  workerScope.onmessage = (event: MessageEvent<OptimizerWorkerRequest>) => {
    const { requestId, dayPlan, targets, options, includeSubstitutions } = event.data;
    const proposal = solveNutritionalBalanceQP(dayPlan, targets, options);
    const substitutions = includeSubstitutions
      ? proposeDiscreteSubstitutions(dayPlan, targets, 4)
      : [];
    workerScope.postMessage({
      requestId,
      proposal,
      substitutions,
    });
  };
}
