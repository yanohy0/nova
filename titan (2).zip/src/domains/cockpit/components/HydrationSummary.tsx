import { memo, useCallback, useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { Plus, RotateCcw, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  correctValidatedLastWater,
  getHydrationSummary,
  logValidatedWater,
  useHydrationStore,
} from '@/src/domains/hydration/application/hydration-actions';
import { useNutritionStore } from '@/src/domains/nutrition/application/nutrition-public';
import {
  createSpringArray,
  DEFAULT_WATER_OPTICAL_CONFIG,
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '@/src/shared/graphics/fluid-shader-engine';
import {
  CardDropletSim,
  FluidVorticityGrid,
  volumeToDropletFillY,
  type CardColliderRect,
} from '@/src/shared/graphics/hydration-fluid-solver';
import {
  extractCoalescedSamples,
  KalmanTouchPredictor,
  stepRK4Spring,
} from '@/src/shared/motion/titan-motion';
import { BottomSheet, type SheetOriginRect } from '@/src/shared/ui/BottomSheet';
import {
  playCrystalGlassTap,
  playDropletPlop,
  playLiquidGlassOpenCue,
} from '@/src/shared/audio/hydration-acoustics';
import { formatMilliliters, parseLocaleNumber } from '@/src/shared/utils/formatters';

const DROPLET_W = 84;
const DROPLET_H = 100;
const TANK_HEIGHT = 34;
const MAX_GLASS_RIPPLES = 4;

interface HydrationImpulseDetail {
  normX?: number;
  strength?: number;
  target?: 'droplet' | 'tank' | 'both';
  soliton?: boolean;
}

function dispatchHydrationFluidImpulse(detail: HydrationImpulseDetail): void {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent('titan-hydration-impulse', { detail }));
}

function showHydrationToast(label: string, tone: 'add' | 'remove'): void {
  const gradId = `titan-toast-droplet-${tone}`;
  toast.custom(
    () => (
      <div
        role="status"
        className="titan-liquid-glass-toast inline-flex items-center gap-2.5 px-3.5 py-2.5 shadow-lg pointer-events-auto"
      >
        <span
          aria-hidden="true"
          className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border ${
            tone === 'add'
              ? 'border-[rgba(176,236,255,0.44)] bg-[radial-gradient(circle_at_32%_28%,rgba(220,248,255,0.45),rgba(48,168,214,0.22))]'
              : 'border-[rgba(196,226,238,0.30)] bg-[radial-gradient(circle_at_32%_28%,rgba(206,232,242,0.24),rgba(22,56,72,0.34))]'
          } shadow-[inset_0_1px_0_rgba(255,255,255,0.55)]`}
        >
          <svg viewBox="0 0 16 20" className="h-3.5 w-3" fill="none">
            <defs>
              <linearGradient id={gradId} x1="2" y1="1" x2="14" y2="19" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#F5FEFF" />
                <stop offset="44%" stopColor={tone === 'add' ? '#88E2FC' : '#9DC3D4'} />
                <stop offset="100%" stopColor={tone === 'add' ? '#1775A3' : '#2D5569'} />
              </linearGradient>
            </defs>
            <path
              d="M8 1.2C7.4 2.4 2.2 9.1 2.2 13.1C2.2 16.4 4.8 18.8 8 18.8C11.2 18.8 13.8 16.4 13.8 13.1C13.8 9.1 8.6 2.4 8 1.2Z"
              fill={`url(#${gradId})`}
              stroke="rgba(244,253,255,0.78)"
              strokeWidth="0.9"
            />
            <path
              d="M5.6 8.2C4.9 9.7 4.4 11.1 4.4 12.6"
              stroke="rgba(255,255,255,0.9)"
              strokeWidth="1.25"
              strokeLinecap="round"
            />
          </svg>
        </span>
        <span className="font-mono-metric text-[13px] font-semibold tracking-[0.01em] text-[#F2FBFF] tabular-nums">
          {label}
        </span>
      </div>
    ),
    { duration: 2200 },
  );
}

function useSpringNumber(targetValue: number): number {
  const safeTarget = Number.isFinite(targetValue) ? targetValue : 0;
  const [displayValue, setDisplayValue] = useState(() => Math.round(safeTarget));
  const springRef = useRef({ value: safeTarget, velocity: 0 });
  const lastRoundedRef = useRef(Math.round(safeTarget));

  useEffect(() => {
    if (typeof window === 'undefined' || prefersReducedMotion()) {
      springRef.current.value = safeTarget;
      springRef.current.velocity = 0;
      const rounded = Math.round(safeTarget);
      if (lastRoundedRef.current !== rounded) {
        lastRoundedRef.current = rounded;
        setDisplayValue(rounded);
      }
      return;
    }

    if (Math.abs(safeTarget - springRef.current.value) < 0.4 && Math.abs(springRef.current.velocity) < 0.5) {
      springRef.current.value = safeTarget;
      springRef.current.velocity = 0;
      const rounded = Math.round(safeTarget);
      if (lastRoundedRef.current !== rounded) {
        lastRoundedRef.current = rounded;
        setDisplayValue(rounded);
      }
      return;
    }

    let rafId = 0;
    let lastAt = performance.now();

    const tick = (now: number) => {
      const dt = Math.min(0.033, Math.max(0.002, (now - lastAt) / 1000));
      lastAt = now;
      stepRK4Spring(springRef.current, safeTarget, 210, 24, dt);

      const settled =
        Math.abs(safeTarget - springRef.current.value) < 0.4 &&
        Math.abs(springRef.current.velocity) < 0.5;
      if (settled) {
        springRef.current.value = safeTarget;
        springRef.current.velocity = 0;
      }

      const rounded = Math.round(springRef.current.value);
      if (rounded !== lastRoundedRef.current) {
        lastRoundedRef.current = rounded;
        setDisplayValue(rounded);
      }

      if (!settled) {
        rafId = window.requestAnimationFrame(tick);
      }
    };

    rafId = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(rafId);
  }, [safeTarget]);

  return displayValue;
}

const AnimatedPercentBadge = memo(function AnimatedPercentBadge({
  percent,
  hasValidGoal,
  percentBumpKey,
}: {
  percent: number;
  hasValidGoal: boolean;
  percentBumpKey: number;
}) {
  const animatedPercent = useSpringNumber(percent);
  return (
    <span
      key={percentBumpKey > 0 ? `pct-${percentBumpKey}` : 'pct-init'}
      className={`mt-1.5 text-[11.5px] font-semibold font-mono-metric tracking-[0.03em] tabular-nums text-[#A2DCF0] leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.4)] ${
        percentBumpKey > 0 ? 'animate-hydration-pop' : ''
      }`}
    >
      {hasValidGoal ? `${animatedPercent}%` : '—'}
    </span>
  );
});

const AnimatedVolumeDisplay = memo(function AnimatedVolumeDisplay({
  targetMl,
  volumeBumpKey,
  variant,
}: {
  targetMl: number;
  volumeBumpKey: number;
  variant: 'hero' | 'modal';
}) {
  const animatedCurrentMl = useSpringNumber(targetMl);
  const displayVolume = formatMilliliters(animatedCurrentMl);
  const volumeParts = displayVolume.split(' ');
  const volumeNumber = volumeParts[0] ?? displayVolume;
  const volumeUnit = volumeParts.slice(1).join(' ');

  return (
    <span
      key={volumeBumpKey > 0 ? `${variant}-vol-${volumeBumpKey}` : `${variant}-vol-init`}
      className={`inline-flex items-baseline ${volumeBumpKey > 0 ? 'animate-hydration-pop' : ''}`}
    >
      <span
        className={`font-display ${
          variant === 'hero' ? 'text-[28px] sm:text-[31px]' : 'text-[26px]'
        } font-semibold tracking-[-0.045em] text-[#F5FBFF] leading-none tabular-nums`}
      >
        {volumeNumber}
      </span>
      {volumeUnit && (
        <span className="ml-1.5 font-mono-metric text-[13px] sm:text-[13.5px] font-medium tracking-[0.03em] text-[#93C9DD] leading-none">
          {volumeUnit}
        </span>
      )}
    </span>
  );
});

const AnimatedRemainingLabel = memo(function AnimatedRemainingLabel({
  currentMl,
  goalMl,
  volumeBumpKey,
  keyPrefix,
}: {
  currentMl: number;
  goalMl: number;
  volumeBumpKey: number;
  keyPrefix: string;
}) {
  const animatedCurrentMl = useSpringNumber(currentMl);
  const remainingMl = Math.max(0, goalMl - animatedCurrentMl);

  return (
    <span
      key={currentMl >= goalMl ? `${keyPrefix}-done` : `${keyPrefix}-rem-${volumeBumpKey}`}
      className="font-medium tracking-[0.015em] text-[#9BC4D5]/88 tabular-nums animate-hydration-status"
    >
      {currentMl >= goalMl
        ? 'Hidratação completa'
        : `Faltam ${formatMilliliters(remainingMl)}`}
    </span>
  );
});

function drawFallbackDroplet(
  canvas: HTMLCanvasElement,
  ratio: number,
  hasRecords: boolean,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const pixelWidth = Math.round(DROPLET_W * dpr);
  const pixelHeight = Math.round(DROPLET_H * dpr);
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, DROPLET_W, DROPLET_H);

  const sx = DROPLET_W / 84;
  const sy = DROPLET_H / 100;
  ctx.scale(sx, sy);

  const shape = () => {
    ctx.beginPath();
    ctx.moveTo(42, 4);
    ctx.bezierCurveTo(39, 8, 13, 43, 13, 62);
    ctx.bezierCurveTo(13, 79, 25, 92, 42, 92);
    ctx.bezierCurveTo(59, 92, 71, 79, 71, 62);
    ctx.bezierCurveTo(71, 43, 45, 8, 42, 4);
    ctx.closePath();
  };

  ctx.save();
  shape();
  ctx.clip();

  const shell = ctx.createLinearGradient(8, 10, 76, 90);
  shell.addColorStop(0, 'rgba(242, 252, 255, 0.14)');
  shell.addColorStop(0.42, 'rgba(105, 170, 194, 0.04)');
  shell.addColorStop(1, 'rgba(18, 50, 66, 0.20)');
  ctx.fillStyle = shell;
  ctx.fillRect(0, 0, 84, 100);

  const fill = Math.min(1, Math.max(0, ratio));
  if (fill > 0.002) {
    const surfaceY = 88 - fill * 76;
    const water = ctx.createLinearGradient(0, surfaceY - 4, 0, 96);
    water.addColorStop(0, 'rgba(232, 252, 255, 0.84)');
    water.addColorStop(0.14, 'rgba(138, 224, 248, 0.68)');
    water.addColorStop(0.55, 'rgba(72, 168, 206, 0.72)');
    water.addColorStop(1, 'rgba(32, 98, 134, 0.80)');
    ctx.fillStyle = water;
    ctx.fillRect(0, surfaceY, 84, 100 - surfaceY);

    ctx.beginPath();
    ctx.moveTo(10, surfaceY + 2);
    ctx.bezierCurveTo(22, surfaceY - 3, 29, surfaceY - 1, 42, surfaceY + 1);
    ctx.bezierCurveTo(55, surfaceY - 1, 63, surfaceY - 3, 74, surfaceY + 2);
    ctx.strokeStyle = 'rgba(242, 253, 255, 0.96)';
    ctx.lineWidth = 1.6;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(18, surfaceY + 5);
    ctx.bezierCurveTo(30, surfaceY + 3, 53, surfaceY + 3, 66, surfaceY + 5);
    ctx.strokeStyle = 'rgba(128, 214, 245, 0.55)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    const caustic = ctx.createRadialGradient(42, 76, 2, 42, 76, 28);
    caustic.addColorStop(0, 'rgba(226, 250, 255, 0.48)');
    caustic.addColorStop(1, 'rgba(145, 224, 246, 0)');
    ctx.fillStyle = caustic;
    ctx.fillRect(10, 52, 64, 42);

    for (const [bx, by, br] of [
      [33, Math.max(surfaceY + 8, 66), 1.9],
      [51, Math.max(surfaceY + 12, 74), 1.5],
      [41, Math.max(surfaceY + 5, 58), 1.2],
    ] as const) {
      if (by < 88) {
        ctx.beginPath();
        ctx.arc(bx, by, br, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(235, 252, 255, 0.55)';
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }
    }
  }
  ctx.restore();

  shape();
  const edge = ctx.createLinearGradient(10, 8, 72, 91);
  edge.addColorStop(0, 'rgba(248, 254, 255, 0.96)');
  edge.addColorStop(0.28, 'rgba(166, 220, 238, 0.62)');
  edge.addColorStop(0.7, 'rgba(63, 130, 157, 0.52)');
  edge.addColorStop(1, 'rgba(226, 246, 252, 0.88)');
  ctx.strokeStyle = edge;
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.save();
  ctx.globalAlpha = hasRecords ? 0.9 : 0.48;
  ctx.lineCap = 'round';
  ctx.strokeStyle = 'rgba(247, 253, 255, 0.88)';
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(31, 24);
  ctx.bezierCurveTo(24, 34, 20, 43, 19, 51);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(163, 224, 242, 0.55)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(60, 58);
  ctx.bezierCurveTo(65, 69, 61, 79, 54, 84);
  ctx.stroke();
  ctx.restore();
}

function drawFallbackTank(
  canvas: HTMLCanvasElement,
  width: number,
  height: number,
  ratio: number,
  label: string,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
  const w = Math.max(120, width);
  const h = Math.max(24, height);
  const pixelWidth = Math.round(w * dpr);
  const pixelHeight = Math.round(h * dpr);
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const inset = 1.25;
  const x = inset;
  const y = inset;
  const trackW = w - inset * 2;
  const trackH = h - inset * 2;
  const radius = trackH / 2;

  ctx.save();
  ctx.beginPath();
  ctx.roundRect(x, y, trackW, trackH, radius);
  ctx.clip();

  const cavity = ctx.createLinearGradient(0, y, 0, y + trackH);
  cavity.addColorStop(0, 'rgba(238, 250, 255, 0.14)');
  cavity.addColorStop(0.26, 'rgba(111, 168, 190, 0.05)');
  cavity.addColorStop(0.72, 'rgba(7, 22, 32, 0.16)');
  cavity.addColorStop(1, 'rgba(204, 236, 247, 0.10)');
  ctx.fillStyle = cavity;
  ctx.fillRect(x, y, trackW, trackH);

  const fill = Math.min(1, Math.max(0, ratio));
  const liquidW = trackW * fill;
  if (liquidW > 0.5) {
    const water = ctx.createLinearGradient(0, y + 1, 0, y + trackH - 1);
    water.addColorStop(0, 'rgba(226, 250, 255, 0.84)');
    water.addColorStop(0.18, 'rgba(136, 222, 248, 0.72)');
    water.addColorStop(0.54, 'rgba(72, 174, 214, 0.78)');
    water.addColorStop(0.84, 'rgba(48, 136, 176, 0.86)');
    water.addColorStop(1, 'rgba(34, 102, 138, 0.82)');

    ctx.fillStyle = water;
    ctx.fillRect(x, y, liquidW, trackH);

    const frontX = x + liquidW;
    const menInset = Math.max(4, trackH * 0.16);
    ctx.beginPath();
    ctx.moveTo(frontX - 1, y + menInset);
    ctx.bezierCurveTo(frontX + 3.5, y + trackH * 0.34, frontX + 3.5, y + trackH * 0.66, frontX - 1, y + trackH - menInset);
    ctx.strokeStyle = 'rgba(240, 253, 255, 0.94)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    const reflH = Math.max(8, Math.round(trackH * 0.36));
    const reflection = ctx.createLinearGradient(0, y + 2, 0, y + 2 + reflH);
    reflection.addColorStop(0, 'rgba(255, 255, 255, 0.38)');
    reflection.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = reflection;
    ctx.fillRect(x + 4, y + 2, Math.max(0, liquidW - 8), reflH);

    const lensH = Math.max(7, Math.round(trackH * 0.30));
    const lens = ctx.createLinearGradient(0, y + trackH - lensH, 0, y + trackH);
    lens.addColorStop(0, 'rgba(137, 219, 245, 0)');
    lens.addColorStop(1, 'rgba(196, 242, 255, 0.42)');
    ctx.fillStyle = lens;
    ctx.fillRect(x, y + trackH - lensH, liquidW, lensH);
  }

  // Water-tracking percentage typography in 2D fallback mode
  ctx.font = `700 ${Math.round(h * 0.42)}px "JetBrains Mono", ui-monospace, SFMono-Regular, monospace`;
  ctx.textBaseline = 'middle';
  const textW = ctx.measureText(label).width;
  const marginX = 12;
  let textX: number;
  if (fill >= 0.22) {
    ctx.textAlign = 'right';
    textX = Math.min(x + trackW - marginX, Math.max(x + textW + marginX, x + liquidW - 10));
    ctx.fillStyle = 'rgba(244, 253, 255, 0.96)';
  } else {
    ctx.textAlign = 'left';
    textX = Math.min(x + trackW - textW - marginX, Math.max(x + marginX, x + liquidW + 10));
    ctx.fillStyle = 'rgba(206, 236, 248, 0.90)';
  }
  ctx.shadowColor = 'rgba(4, 14, 20, 0.45)';
  ctx.shadowBlur = 4;
  ctx.fillText(label, textX, y + trackH * 0.51);
  ctx.shadowBlur = 0;

  ctx.restore();

  ctx.beginPath();
  ctx.roundRect(x, y, trackW, trackH, radius);
  const shell = ctx.createLinearGradient(0, y, 0, y + trackH);
  shell.addColorStop(0, 'rgba(244, 253, 255, 0.80)');
  shell.addColorStop(0.18, 'rgba(146, 198, 215, 0.30)');
  shell.addColorStop(0.52, 'rgba(73, 119, 139, 0.22)');
  shell.addColorStop(0.84, 'rgba(163, 213, 229, 0.36)');
  shell.addColorStop(1, 'rgba(240, 252, 255, 0.74)');
  ctx.strokeStyle = shell;
  ctx.lineWidth = 1.4;
  ctx.stroke();

  ctx.strokeStyle = 'rgba(170, 224, 240, 0.20)';
  ctx.lineWidth = 1;
  for (let t = 1; t < 8; t++) {
    const tx = x + (trackW * t) / 8;
    ctx.beginPath();
    ctx.moveTo(tx, y + 4);
    ctx.lineTo(tx, y + (t % 2 === 0 ? 10 : 7));
    ctx.stroke();
  }

  ctx.beginPath();
  ctx.moveTo(x + radius, y + 2.5);
  ctx.lineTo(x + trackW - radius, y + 2.5);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.38)';
  ctx.lineWidth = 1;
  ctx.stroke();
}

interface DropletGaugeProps {
  percent: number;
  barPercent: number;
  hasRecords: boolean;
  hasValidGoal: boolean;
  tiltRef: { current: [number, number] };
  boxRef?: { current: HTMLDivElement | null };
  onTiltTarget?: (tx: number, ty: number) => void;
}

const WaterDropletGauge = memo(function WaterDropletGauge({
  percent,
  barPercent,
  hasRecords,
  hasValidGoal,
  tiltRef,
  boxRef,
  onTiltTarget,
}: DropletGaugeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const normalizedPercent = Number.isFinite(barPercent)
    ? Math.min(100, Math.max(0, barPercent))
    : 0;
  const targetRatioRef = useRef(normalizedPercent / 100);
  const currentRatioRef = useRef(targetRatioRef.current);
  const lastInterpolationAtRef = useRef(0);
  const lastSolverStepAtRef = useRef(0);
  const hasRecordsRef = useRef(hasRecords);
  const isVisibleRef = useRef(true);
  const waveRef = useRef(createSpringArray(24));
  const fluidGridRef = useRef(new FluidVorticityGrid(48, 24));
  const solitonRef = useRef<[number, number, number, number]>([0.5, 0.5, 0, 0]);
  const kalmanRef = useRef(new KalmanTouchPredictor());
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);
  const prevPercentRef = useRef(percent);
  const [percentBumpKey, setPercentBumpKey] = useState(0);

  useEffect(() => {
    if (prevPercentRef.current !== percent) {
      prevPercentRef.current = percent;
      if (!prefersReducedMotion()) {
        setPercentBumpKey((k) => k + 1);
      }
    }
  }, [percent]);

  useEffect(() => {
    const nextRatio = normalizedPercent / 100;
    const delta = nextRatio - targetRatioRef.current;
    targetRatioRef.current = nextRatio;
    hasRecordsRef.current = hasRecords;
    if (typeof window !== 'undefined' && prefersReducedMotion()) {
      currentRatioRef.current = nextRatio;
      solitonRef.current = [0.5, 0.5, 0, 0];
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackDroplet(canvasRef.current, nextRatio, hasRecords);
      }
      return;
    }
    if (Math.abs(delta) > 0.005) {
      const wave = waveRef.current;
      const mid = wave[12];
      if (mid) mid.velocity += delta > 0 ? -3.8 : 2.2;
      solitonRef.current = [0.5, 0.5, 0.015, Math.min(1.25, 0.72 + Math.abs(delta) * 2.5)];
      fluidGridRef.current.injectImpulse(0.5, 0.72, delta > 0 ? 0.6 : -0.4, delta > 0 ? -2.2 : 1.1, 0.9);
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackDroplet(canvasRef.current, nextRatio, hasRecords);
      }
      getSharedFluidEngine().wake();
    }
  }, [normalizedPercent, hasRecords]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = getSharedFluidEngine();
    const drawFallback = () => drawFallbackDroplet(canvas, targetRatioRef.current, hasRecordsRef.current);
    const onEngineFallback = () => drawFallback();
    const onEngineRestored = () => {
      if (providerRef.current) engine.renderSinglePass(providerRef.current);
    };
    const onExternalImpulse = (event: Event) => {
      if (prefersReducedMotion()) return;
      const custom = event as CustomEvent<HydrationImpulseDetail>;
      const detail = custom.detail;
      if (!detail || (detail.target && detail.target !== 'droplet' && detail.target !== 'both')) return;
      const normX = Math.min(1, Math.max(0, detail.normX ?? 0.5));
      const strength = detail.strength ?? -2.4;
      const idx = Math.min(23, Math.max(0, Math.round(normX * 23)));
      const wave = waveRef.current;
      if (wave[idx - 1]) wave[idx - 1]!.velocity += strength * 0.45;
      if (wave[idx]) wave[idx]!.velocity += strength;
      if (wave[idx + 1]) wave[idx + 1]!.velocity += strength * 0.45;
      if (detail.soliton) {
        solitonRef.current = [normX, 0.5, 0.015, Math.min(1.25, Math.max(0.65, Math.abs(strength) * 0.28))];
      }
      fluidGridRef.current.injectImpulse(normX, 0.65, (normX - 0.5) * 1.4, strength * 0.65, 0.85);
      engine.wake();
    };
    window.addEventListener('fluid-engine-fallback', onEngineFallback);
    window.addEventListener('fluid-engine-restored', onEngineRestored);
    window.addEventListener('titan-hydration-impulse', onExternalImpulse);

    const io =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current && providerRef.current) {
                engine.renderSinglePass(providerRef.current);
                engine.wake();
              }
            },
            { threshold: 0.05 },
          )
        : null;
    io?.observe(canvas);

    const provider = (): FluidDrawJob | null => {
      if (prefersReducedMotion()) {
        currentRatioRef.current = targetRatioRef.current;
        solitonRef.current = [0.5, 0.5, 0, 0];
        lastInterpolationAtRef.current = 0;
        lastSolverStepAtRef.current = 0;
      }
      const now = performance.now();
      const diff = targetRatioRef.current - currentRatioRef.current;
      const isInterpolating = Math.abs(diff) > 0.0005;
      if (isInterpolating) {
        const dt = lastInterpolationAtRef.current
          ? Math.min(0.05, Math.max(0, (now - lastInterpolationAtRef.current) / 1000))
          : 1 / 60;
        currentRatioRef.current = interpolateRatio(
          currentRatioRef.current,
          targetRatioRef.current,
          dt,
          1 / 10.5,
        );
        lastInterpolationAtRef.current = now;
      } else {
        currentRatioRef.current = targetRatioRef.current;
        lastInterpolationAtRef.current = 0;
      }
      const motionAllowed = typeof window === 'undefined' ? false : !prefersReducedMotion();
      const grid = fluidGridRef.current;
      const solverDt = lastSolverStepAtRef.current
        ? Math.min(0.033, Math.max(0.004, (now - lastSolverStepAtRef.current) / 1000))
        : 1 / 60;
      lastSolverStepAtRef.current = now;

      if (motionAllowed && isVisibleRef.current && currentRatioRef.current > 0.004) {
        if (grid.isActive() || isInterpolating || Math.abs(tiltRef.current[0]) > 0.03) {
          grid.step(solverDt, tiltRef.current[0], tiltRef.current[1]);
        }
      }

      let hasSoliton = false;
      const sol = solitonRef.current;
      if (motionAllowed && sol[3] > 0.001) {
        const nextAge = sol[2] + solverDt;
        if (nextAge > 1.85) {
          sol[2] = 0;
          sol[3] = 0;
        } else {
          sol[2] = nextAge;
          hasSoliton = true;
        }
      }

      const isFlowActive = isVisibleRef.current && motionAllowed && currentRatioRef.current > 0.004;
      const isInteractive = isInterpolating || grid.isActive() || hasSoliton || Math.abs(tiltRef.current[0]) > 0.03;
      const fillRatio = currentRatioRef.current;
      return {
        kind: 'droplet',
        targetCanvas: canvas,
        width: DROPLET_W,
        height: DROPLET_H,
        fill: fillRatio,
        fillY: volumeToDropletFillY(fillRatio),
        active: hasRecordsRef.current,
        isAnimating: isInterpolating || isFlowActive || grid.isActive() || hasSoliton,
        idleFrameIntervalMs: isInteractive ? undefined : 33,
        wave: waveRef.current,
        fluidGrid: grid,
        soliton: sol,
        tilt: tiltRef.current,
        opticalConfig: DEFAULT_WATER_OPTICAL_CONFIG,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const rendered = engine.renderSinglePass(provider);
    if (!rendered) {
      drawFallbackDroplet(canvas, targetRatioRef.current, hasRecordsRef.current);
    }

    const unsubscribe = engine.subscribe(provider, true);
    if (!prefersReducedMotion() && currentRatioRef.current > 0.004) {
      engine.wake();
    }
    return () => {
      providerRef.current = null;
      unsubscribe();
      io?.disconnect();
      window.removeEventListener('fluid-engine-fallback', onEngineFallback);
      window.removeEventListener('fluid-engine-restored', onEngineRestored);
      window.removeEventListener('titan-hydration-impulse', onExternalImpulse);
    };
  }, [tiltRef]);

  const triggerDropletImpulse = (
    normX = 0.5,
    normY = 0.55,
    vx = 0,
    vy = -3.2,
    spawnSoliton = false,
  ) => {
    if (prefersReducedMotion()) return;
    const wave = waveRef.current;
    const clampedX = Math.min(1, Math.max(0, normX));
    const clampedY = Math.min(1, Math.max(0, normY));
    const idx = Math.min(23, Math.max(0, Math.round(clampedX * 23)));
    const prev2 = wave[idx - 2];
    const prev = wave[idx - 1];
    const curr = wave[idx];
    const next = wave[idx + 1];
    const next2 = wave[idx + 2];
    const waveForce = vy;
    if (prev2) prev2.velocity += waveForce * 0.22;
    if (prev) prev.velocity += waveForce * 0.56;
    if (curr) curr.velocity += waveForce;
    if (next) next.velocity += waveForce * 0.56;
    if (next2) next2.velocity += waveForce * 0.22;
    if (spawnSoliton) {
      solitonRef.current = [clampedX, clampedY, 0.015, 0.95];
    }
    fluidGridRef.current.injectImpulse(
      clampedX,
      clampedY,
      vx + (clampedX - 0.5) * 2.4,
      vy * 0.72,
      0.95,
    );
    getSharedFluidEngine().wake();
  };

  const handleDropletPointer = (
    event: ReactPointerEvent<HTMLCanvasElement>,
    isDown: boolean,
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const samples = extractCoalescedSamples(
      event.nativeEvent,
      event.clientX,
      event.clientY,
      rect,
    );
    let pred = kalmanRef.current.update(
      samples[0]?.x ?? 0.5,
      samples[0]?.y ?? 0.5,
      samples[0]?.t ?? performance.now(),
    );
    for (let i = 1; i < samples.length; i++) {
      const s = samples[i];
      if (!s) continue;
      pred = kalmanRef.current.update(s.x, s.y, s.t);
    }

    if (isDown) {
      playDropletPlop(targetRatioRef.current, 1.0);
      triggerDropletImpulse(pred.x, pred.y, 0, -4.4, true);
      dispatchHydrationFluidImpulse({ target: 'tank', normX: 0.14, strength: -2.8, soliton: true });
      onTiltTarget?.((pred.x - 0.5) * 0.28, (pred.y - 0.5) * 0.18);
      return;
    }
    onTiltTarget?.((pred.x - 0.5) * 0.26, (pred.y - 0.5) * 0.16);
    if (pred.speed < 0.045) return;
    const vx = Math.max(-2.8, Math.min(2.8, pred.vx * 0.95));
    const vy = Math.max(-2.6, Math.min(2.6, pred.vy * 0.8 - Math.abs(pred.vx) * 0.25));
    triggerDropletImpulse(pred.x, pred.y, vx, vy, false);
  };

  return (
    <div ref={boxRef} className="flex flex-col items-center shrink-0">
      <canvas
        ref={canvasRef}
        width={DROPLET_W}
        height={DROPLET_H}
        onPointerDown={(e) => handleDropletPointer(e, true)}
        onPointerEnter={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const nx = rect.width > 0 ? (e.clientX - rect.left) / rect.width : 0.5;
          const ny = rect.height > 0 ? (e.clientY - rect.top) / rect.height : 0.5;
          kalmanRef.current.update(nx, ny, e.timeStamp);
          triggerDropletImpulse(nx, ny, 0.35, -2.0, false);
          onTiltTarget?.((nx - 0.5) * 0.20, (ny - 0.5) * 0.12);
        }}
        onPointerMove={(e) => handleDropletPointer(e, false)}
        onPointerUp={() => {
          kalmanRef.current.reset();
          onTiltTarget?.(0, 0);
        }}
        onPointerCancel={() => {
          kalmanRef.current.reset();
          onTiltTarget?.(0, 0);
        }}
        onPointerLeave={() => {
          kalmanRef.current.reset();
          onTiltTarget?.(0, 0);
        }}
        className="w-[84px] h-[100px] block cursor-pointer touch-pan-y"
        aria-hidden="true"
      />
      <AnimatedPercentBadge
        percent={percent}
        hasValidGoal={hasValidGoal}
        percentBumpKey={percentBumpKey}
      />
    </div>
  );
});

interface CrystalWaterTankProps {
  percent: number;
  barPercent: number;
  currentMl: number;
  goalMl: number;
  tiltRef: { current: [number, number] };
  boxRef?: { current: HTMLDivElement | null };
  onTiltTarget?: (tx: number, ty: number) => void;
}

function paintTankTypographySprite(
  canvas: HTMLCanvasElement,
  tankWidth: number,
  tankHeight: number,
  label: string,
): [number, number] {
  const dpr = Math.min(typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1, 2.5);
  const safeTankW = Math.max(120, tankWidth);
  const measureCtx = canvas.getContext('2d');
  const fontSize = Math.round(tankHeight * 0.42);
  const fontSpec = `700 ${fontSize}px "JetBrains Mono", ui-monospace, SFMono-Regular, monospace`;

  let labelWidthPx = 38;
  if (measureCtx) {
    measureCtx.font = fontSpec;
    labelWidthPx = Math.max(22, measureCtx.measureText(label).width);
  }

  const spriteWidth = Math.max(82, Math.ceil(labelWidthPx + 24));
  const pxW = Math.max(4, Math.round(spriteWidth * dpr));
  const pxH = Math.max(4, Math.round(tankHeight * dpr));
  if (canvas.width !== pxW) canvas.width = pxW;
  if (canvas.height !== pxH) canvas.height = pxH;

  const ctx = canvas.getContext('2d');
  if (!ctx) return [labelWidthPx / safeTankW, spriteWidth / safeTankW];

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, spriteWidth, tankHeight);
  ctx.font = fontSpec;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffffff';
  ctx.fillText(label, spriteWidth * 0.5, tankHeight * 0.50);

  return [labelWidthPx / safeTankW, spriteWidth / safeTankW];
}

const CrystalWaterTank = memo(function CrystalWaterTank({
  percent,
  barPercent,
  currentMl,
  goalMl,
  tiltRef,
  boxRef,
  onTiltTarget,
}: CrystalWaterTankProps) {
  const normalizedPercent = Number.isFinite(barPercent)
    ? Math.min(100, Math.max(0, barPercent))
    : 0;
  const hasValidGoal = Number.isFinite(goalMl) && goalMl > 0;
  const accessiblePercent = normalizedPercent;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const textCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const textVersionRef = useRef(0);
  const textDimsRef = useRef<[number, number]>([0.15, 0.34]);
  const targetRatioRef = useRef(normalizedPercent / 100);
  const currentRatioRef = useRef(targetRatioRef.current);
  const lastInterpolationAtRef = useRef(0);
  const lastSolverStepAtRef = useRef(0);
  const sizeRef = useRef({ w: 220, h: TANK_HEIGHT });
  const isVisibleRef = useRef(true);
  const isPointerDownRef = useRef(false);
  const waveRef = useRef(createSpringArray(24));
  const fluidGridRef = useRef(new FluidVorticityGrid(48, 24));
  const solitonRef = useRef<[number, number, number, number]>([0.5, 0.5, 0, 0]);
  const kalmanRef = useRef(new KalmanTouchPredictor());
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  const tankTextLabel = hasValidGoal ? `${Math.round(percent)}%` : '—';
  const tankTextLabelRef = useRef(tankTextLabel);
  tankTextLabelRef.current = tankTextLabel;

  const setContainerNode = useCallback(
    (node: HTMLDivElement | null) => {
      containerRef.current = node;
      if (boxRef) boxRef.current = node;
    },
    [boxRef],
  );

  useEffect(() => {
    if (typeof document === 'undefined') return;
    if (!textCanvasRef.current) {
      textCanvasRef.current = document.createElement('canvas');
    }
    textDimsRef.current = paintTankTypographySprite(
      textCanvasRef.current,
      sizeRef.current.w,
      sizeRef.current.h,
      tankTextLabel,
    );
    textVersionRef.current += 1;
    if (providerRef.current) {
      getSharedFluidEngine().renderSinglePass(providerRef.current);
    }
  }, [tankTextLabel]);

  useEffect(() => {
    const nextRatio = normalizedPercent / 100;
    const delta = nextRatio - targetRatioRef.current;
    targetRatioRef.current = nextRatio;
    if (typeof window !== 'undefined' && prefersReducedMotion()) {
      currentRatioRef.current = nextRatio;
      solitonRef.current = [0.5, 0.5, 0, 0];
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackTank(canvasRef.current, sizeRef.current.w, sizeRef.current.h, nextRatio, tankTextLabel);
      }
      return;
    }
    if (Math.abs(delta) > 0.005) {
      const wave = waveRef.current;
      const idx = Math.min(23, Math.max(0, Math.round(nextRatio * 23)));
      const node = wave[idx];
      if (node) node.velocity += delta > 0 ? -3.8 : 2.3;
      solitonRef.current = [nextRatio, 0.5, 0.015, Math.min(1.25, 0.72 + Math.abs(delta) * 2.5)];
      fluidGridRef.current.injectImpulse(nextRatio, 0.5, delta > 0 ? 1.8 : -1.2, -0.8, 0.9);
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackTank(canvasRef.current, sizeRef.current.w, sizeRef.current.h, nextRatio, tankTextLabel);
      }
      getSharedFluidEngine().wake();
    }
  }, [normalizedPercent, tankTextLabel]);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    const engine = getSharedFluidEngine();
    const drawFallback = () =>
      drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current, tankTextLabelRef.current);
    const onEngineFallback = () => drawFallback();
    const onEngineRestored = () => {
      if (providerRef.current) engine.renderSinglePass(providerRef.current);
    };
    const onExternalImpulse = (event: Event) => {
      if (prefersReducedMotion()) return;
      const custom = event as CustomEvent<HydrationImpulseDetail>;
      const detail = custom.detail;
      if (!detail || (detail.target && detail.target !== 'tank' && detail.target !== 'both')) return;
      const normX = Math.min(1, Math.max(0, detail.normX ?? targetRatioRef.current));
      const strength = detail.strength ?? -2.2;
      const idx = Math.min(23, Math.max(0, Math.round(normX * 23)));
      const wave = waveRef.current;
      if (wave[idx - 1]) wave[idx - 1]!.velocity += strength * 0.48;
      if (wave[idx]) wave[idx]!.velocity += strength;
      if (wave[idx + 1]) wave[idx + 1]!.velocity += strength * 0.48;
      if (detail.soliton) {
        solitonRef.current = [normX, 0.5, 0.015, Math.min(1.25, Math.max(0.65, Math.abs(strength) * 0.28))];
      }
      fluidGridRef.current.injectImpulse(normX, 0.55, (normX - 0.5) * 1.4, strength * 0.55, 0.8);
      engine.wake();
    };
    window.addEventListener('fluid-engine-fallback', onEngineFallback);
    window.addEventListener('fluid-engine-restored', onEngineRestored);
    window.addEventListener('titan-hydration-impulse', onExternalImpulse);

    sizeRef.current.w = Math.max(120, container.clientWidth);
    if (!textCanvasRef.current && typeof document !== 'undefined') {
      textCanvasRef.current = document.createElement('canvas');
    }
    if (textCanvasRef.current) {
      textDimsRef.current = paintTankTypographySprite(
        textCanvasRef.current,
        sizeRef.current.w,
        sizeRef.current.h,
        tankTextLabelRef.current,
      );
      textVersionRef.current += 1;
    }

    const provider = (): FluidDrawJob | null => {
      if (prefersReducedMotion()) {
        currentRatioRef.current = targetRatioRef.current;
        solitonRef.current = [0.5, 0.5, 0, 0];
        lastInterpolationAtRef.current = 0;
        lastSolverStepAtRef.current = 0;
      }
      const now = performance.now();
      const diff = targetRatioRef.current - currentRatioRef.current;
      const isInterpolating = Math.abs(diff) > 0.0005;
      if (isInterpolating) {
        const dt = lastInterpolationAtRef.current
          ? Math.min(0.05, Math.max(0, (now - lastInterpolationAtRef.current) / 1000))
          : 1 / 60;
        currentRatioRef.current = interpolateRatio(
          currentRatioRef.current,
          targetRatioRef.current,
          dt,
          1 / 10.5,
        );
        lastInterpolationAtRef.current = now;
      } else {
        currentRatioRef.current = targetRatioRef.current;
        lastInterpolationAtRef.current = 0;
      }
      const motionAllowed = typeof window === 'undefined' ? false : !prefersReducedMotion();
      const grid = fluidGridRef.current;
      const solverDt = lastSolverStepAtRef.current
        ? Math.min(0.033, Math.max(0.004, (now - lastSolverStepAtRef.current) / 1000))
        : 1 / 60;
      lastSolverStepAtRef.current = now;

      if (motionAllowed && isVisibleRef.current && currentRatioRef.current > 0.004) {
        if (grid.isActive() || isInterpolating || Math.abs(tiltRef.current[0]) > 0.03) {
          grid.step(solverDt, tiltRef.current[0], tiltRef.current[1]);
        }
      }

      let hasSoliton = false;
      const sol = solitonRef.current;
      if (motionAllowed && sol[3] > 0.001) {
        const nextAge = sol[2] + solverDt;
        if (nextAge > 1.85) {
          sol[2] = 0;
          sol[3] = 0;
        } else {
          sol[2] = nextAge;
          hasSoliton = true;
        }
      }

      const isFlowActive = isVisibleRef.current && motionAllowed && currentRatioRef.current > 0.004;
      const isInteractive = isInterpolating || grid.isActive() || hasSoliton || Math.abs(tiltRef.current[0]) > 0.03;
      return {
        kind: 'tank',
        targetCanvas: canvas,
        width: sizeRef.current.w,
        height: sizeRef.current.h,
        fill: currentRatioRef.current,
        isAnimating: isInterpolating || isFlowActive || grid.isActive() || hasSoliton,
        idleFrameIntervalMs: isInteractive ? undefined : 33,
        wave: waveRef.current,
        fluidGrid: grid,
        soliton: sol,
        textCanvas: textCanvasRef.current ?? undefined,
        textVersion: textVersionRef.current,
        textDims: textDimsRef.current,
        tilt: tiltRef.current,
        opticalConfig: DEFAULT_WATER_OPTICAL_CONFIG,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const ro =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            sizeRef.current.w = Math.max(120, container.clientWidth);
            if (textCanvasRef.current) {
              textDimsRef.current = paintTankTypographySprite(
                textCanvasRef.current,
                sizeRef.current.w,
                sizeRef.current.h,
                tankTextLabelRef.current,
              );
              textVersionRef.current += 1;
            }
            const rendered = engine.renderSinglePass(provider);
            if (!rendered) {
              drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current, tankTextLabelRef.current);
            }
          })
        : null;
    ro?.observe(container);

    const io =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                const rendered = engine.renderSinglePass(provider);
                if (!rendered) {
                  drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current, tankTextLabelRef.current);
                }
                engine.wake();
              }
            },
            { threshold: 0.05 },
          )
        : null;
    io?.observe(container);

    const rendered = engine.renderSinglePass(provider);
    if (!rendered) {
      drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current, tankTextLabelRef.current);
    }

    const unsubscribe = engine.subscribe(provider, true);
    if (!prefersReducedMotion() && currentRatioRef.current > 0.004) {
      engine.wake();
    }
    return () => {
      providerRef.current = null;
      unsubscribe();
      ro?.disconnect();
      io?.disconnect();
      window.removeEventListener('fluid-engine-fallback', onEngineFallback);
      window.removeEventListener('fluid-engine-restored', onEngineRestored);
      window.removeEventListener('titan-hydration-impulse', onExternalImpulse);
    };
  }, [tiltRef]);

  const triggerTankImpulse = (
    normX = targetRatioRef.current,
    normY = 0.5,
    vx = 0,
    vy = -3.4,
    spawnSoliton = false,
  ) => {
    if (prefersReducedMotion()) return;
    const wave = waveRef.current;
    const clampedX = Math.min(1, Math.max(0, normX));
    const clampedY = Math.min(1, Math.max(0, normY));
    const idx = Math.min(23, Math.max(0, Math.round(clampedX * 23)));
    const prev2 = wave[idx - 2];
    const prev = wave[idx - 1];
    const curr = wave[idx];
    const next = wave[idx + 1];
    const next2 = wave[idx + 2];
    if (prev2) prev2.velocity += vy * 0.25;
    if (prev) prev.velocity += vy * 0.58;
    if (curr) curr.velocity += vy;
    if (next) next.velocity += vy * 0.58;
    if (next2) next2.velocity += vy * 0.25;

    const meniscusIdx = Math.min(23, Math.max(0, Math.round(targetRatioRef.current * 23)));
    if (wave[meniscusIdx]) wave[meniscusIdx]!.velocity += (vx * 0.5 + vy * 0.45);
    if (spawnSoliton) {
      solitonRef.current = [clampedX, clampedY, 0.015, 0.95];
    }

    fluidGridRef.current.injectImpulse(
      clampedX,
      clampedY,
      vx + (clampedX - 0.5) * 2.2,
      vy * 0.7,
      0.95,
    );
    getSharedFluidEngine().wake();
  };

  const handleTankPointer = (
    event: ReactPointerEvent<HTMLCanvasElement>,
    isDown: boolean,
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const samples = extractCoalescedSamples(
      event.nativeEvent,
      event.clientX,
      event.clientY,
      rect,
    );
    let pred = kalmanRef.current.update(
      samples[0]?.x ?? targetRatioRef.current,
      samples[0]?.y ?? 0.5,
      samples[0]?.t ?? performance.now(),
    );
    for (let i = 1; i < samples.length; i++) {
      const s = samples[i];
      if (!s) continue;
      pred = kalmanRef.current.update(s.x, s.y, s.t);
    }

    if (isDown) {
      isPointerDownRef.current = true;
      playCrystalGlassTap(pred.x, 1.0);
      triggerTankImpulse(pred.x, pred.y, 0.8, -4.4, true);
      dispatchHydrationFluidImpulse({ target: 'droplet', normX: 0.5, strength: -2.6, soliton: true });
      onTiltTarget?.((pred.x - 0.5) * 0.30, (pred.y - 0.5) * 0.16);
      return;
    }
    onTiltTarget?.((pred.x - 0.5) * 0.28, (pred.y - 0.5) * 0.15);
    const moveThreshold = isPointerDownRef.current ? 0.025 : 0.045;
    if (pred.speed < moveThreshold) return;
    const vx = Math.max(-3.0, Math.min(3.0, pred.vx * 1.12));
    const vy = Math.max(-2.4, Math.min(2.4, pred.vy * 0.75 - Math.abs(pred.vx) * 0.35));
    triggerTankImpulse(pred.x, pred.y, vx, vy, false);
  };

  return (
    <div
      ref={setContainerNode}
      className="relative h-[34px] w-full rounded-full overflow-visible"
      role={hasValidGoal ? 'progressbar' : 'group'}
      aria-valuenow={hasValidGoal ? accessiblePercent : undefined}
      aria-valuemin={hasValidGoal ? 0 : undefined}
      aria-valuemax={hasValidGoal ? 100 : undefined}
      aria-valuetext={
        hasValidGoal ? `${currentMl} ml de ${goalMl} ml (${accessiblePercent}%)` : undefined
      }
      aria-label={
        hasValidGoal
          ? `Hidratação diária: ${currentMl} ml de ${goalMl} ml`
          : `Hidratação registrada: ${currentMl} ml; meta não definida`
      }
    >
      <canvas
        ref={canvasRef}
        onPointerDown={(e) => handleTankPointer(e, true)}
        onPointerEnter={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const nx = rect.width > 0 ? (e.clientX - rect.left) / rect.width : targetRatioRef.current;
          const ny = rect.height > 0 ? (e.clientY - rect.top) / rect.height : 0.5;
          kalmanRef.current.update(nx, ny, e.timeStamp);
          triggerTankImpulse(nx, ny, 0.4, -2.1, false);
          onTiltTarget?.((nx - 0.5) * 0.22, (ny - 0.5) * 0.12);
        }}
        onPointerMove={(e) => handleTankPointer(e, false)}
        onPointerUp={() => {
          isPointerDownRef.current = false;
          kalmanRef.current.reset();
          onTiltTarget?.(0, 0);
        }}
        onPointerCancel={() => {
          isPointerDownRef.current = false;
          kalmanRef.current.reset();
          onTiltTarget?.(0, 0);
        }}
        onPointerLeave={() => {
          isPointerDownRef.current = false;
          kalmanRef.current.reset();
          onTiltTarget?.(0, 0);
        }}
        className="relative z-[1] block w-full h-full touch-pan-y cursor-pointer drop-shadow-[0_5px_12px_rgba(0,0,0,0.44)] focus:outline-none"
        aria-hidden="true"
      />
    </div>
  );
});

interface CardDropletOverlayProps {
  hostRef: { current: HTMLDivElement | null };
  simRef: { current: CardDropletSim | null };
  tiltRef: { current: [number, number] };
  targetTiltRef: { current: [number, number] };
  pointerRef: { current: [number, number, number, number] };
  ripplesRef: { current: Float32Array };
  solitonRef: { current: [number, number, number, number] };
  fillRatio: number;
  burstTrigger: number;
  colliderMeasureDeps: unknown[];
  colliderRefs: {
    undoBtn: { current: HTMLButtonElement | null };
    registerBtn: { current: HTMLButtonElement | null };
    dropletBox: { current: HTMLDivElement | null };
    tankBox: { current: HTMLDivElement | null };
    volumeLabel: { current: HTMLDivElement | null };
  };
  onPoolImpact?: (impact: { target: 'droplet' | 'tank'; normX: number; strength: number }) => void;
}

const CardDropletOverlay = memo(function CardDropletOverlay({
  hostRef,
  simRef,
  tiltRef,
  targetTiltRef,
  pointerRef,
  ripplesRef,
  solitonRef,
  fillRatio,
  burstTrigger,
  colliderMeasureDeps,
  colliderRefs,
  onPoolImpact,
}: CardDropletOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sizeRef = useRef({ w: 320, h: 170 });
  const isVisibleRef = useRef(true);
  const lastStepAtRef = useRef(0);
  const fillRatioRef = useRef(fillRatio);
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);
  const colliderRafRef = useRef(0);
  const onPoolImpactRef = useRef(onPoolImpact);
  onPoolImpactRef.current = onPoolImpact;

  useEffect(() => {
    fillRatioRef.current = fillRatio;
  }, [fillRatio]);

  const measureColliders = useCallback(() => {
    const host = hostRef.current;
    const sim = simRef.current;
    if (!host || !sim) return;
    const hostRect = host.getBoundingClientRect();
    if (hostRect.width <= 0 || hostRect.height <= 0) return;

    const toNormRect = (
      id: string,
      kind: CardColliderRect['kind'],
      el: HTMLElement | null,
    ): CardColliderRect | null => {
      if (!el) return null;
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return null;
      return {
        id,
        kind,
        xMin: Math.max(0, Math.min(1, (r.left - hostRect.left) / hostRect.width)),
        yMin: Math.max(0, Math.min(1, (r.top - hostRect.top) / hostRect.height)),
        xMax: Math.max(0, Math.min(1, (r.right - hostRect.left) / hostRect.width)),
        yMax: Math.max(0, Math.min(1, (r.bottom - hostRect.top) / hostRect.height)),
      };
    };

    const next: CardColliderRect[] = [];
    const items: Array<[string, CardColliderRect['kind'], HTMLElement | null]> = [
      ['btn-undo', 'ledge', colliderRefs.undoBtn.current],
      ['btn-register', 'ledge', colliderRefs.registerBtn.current],
      ['droplet-gauge', 'droplet-pool', colliderRefs.dropletBox.current],
      ['water-tank', 'tank-pool', colliderRefs.tankBox.current],
      ['volume-label', 'label', colliderRefs.volumeLabel.current],
    ];
    for (const [id, kind, el] of items) {
      const rect = toNormRect(id, kind, el);
      if (rect) next.push(rect);
    }
    sim.setColliders(next);
  }, [hostRef, simRef, colliderRefs]);

  const scheduleMeasureColliders = useCallback(() => {
    if (typeof window === 'undefined' || typeof window.requestAnimationFrame !== 'function') {
      measureColliders();
      return;
    }
    if (colliderRafRef.current) return;
    colliderRafRef.current = window.requestAnimationFrame(() => {
      colliderRafRef.current = 0;
      measureColliders();
    });
  }, [measureColliders]);

  useEffect(() => {
    scheduleMeasureColliders();
    return () => {
      if (colliderRafRef.current) {
        window.cancelAnimationFrame(colliderRafRef.current);
        colliderRafRef.current = 0;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scheduleMeasureColliders, ...colliderMeasureDeps]);

  useEffect(() => {
    if (!simRef.current) {
      simRef.current = new CardDropletSim();
    }
    if (burstTrigger > 0 && !prefersReducedMotion()) {
      simRef.current.triggerCondensationBurst(1.0);
      if (providerRef.current) {
        getSharedFluidEngine().renderSinglePass(providerRef.current);
        getSharedFluidEngine().wake();
      }
    }
  }, [burstTrigger, simRef]);

  useEffect(() => {
    const host = hostRef.current;
    const canvas = canvasRef.current;
    if (!host || !canvas) return;
    if (!simRef.current) simRef.current = new CardDropletSim();
    const sim = simRef.current;
    const engine = getSharedFluidEngine();

    sizeRef.current = {
      w: Math.max(160, host.clientWidth),
      h: Math.max(120, host.clientHeight),
    };
    measureColliders();

    if (!prefersReducedMotion()) {
      sim.setAmbientCondensation(true);
    }

    const clearCanvasOnFallback = () => {
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    };
    window.addEventListener('fluid-engine-fallback', clearCanvasOnFallback);

    const provider = (): FluidDrawJob | null => {
      if (prefersReducedMotion()) {
        sim.resetCalmDew();
        ripplesRef.current.fill(0);
        solitonRef.current = [0.5, 0.5, 0, 0];
        lastStepAtRef.current = 0;
        return {
          kind: 'card-droplets',
          targetCanvas: canvas,
          width: sizeRef.current.w,
          height: sizeRef.current.h,
          fill: fillRatioRef.current,
          isAnimating: false,
          cardDroplets: sim.gpu,
          cardPointer: [0.5, 0.5, 0, 0],
          cardRipples: ripplesRef.current,
          soliton: solitonRef.current,
          tilt: [0, 0],
          isVisible: isVisibleRef.current,
        };
      }
      const now = performance.now();
      const dt = lastStepAtRef.current
        ? Math.min(0.033, Math.max(0.002, (now - lastStepAtRef.current) / 1000))
        : 1 / 60;
      lastStepAtRef.current = now;

      // Amortecimento viscoso suave da inclinação do card (inércia líquida real)
      const tx = interpolateRatio(tiltRef.current[0], targetTiltRef.current[0], dt, 0.10);
      const ty = interpolateRatio(tiltRef.current[1], targetTiltRef.current[1], dt, 0.10);
      tiltRef.current[0] = tx;
      tiltRef.current[1] = ty;
      const isTilting =
        Math.abs(targetTiltRef.current[0] - tx) > 0.001 ||
        Math.abs(targetTiltRef.current[1] - ty) > 0.001;

      let hasActiveRipple = false;
      const ripples = ripplesRef.current;
      for (let i = 0; i < MAX_GLASS_RIPPLES; i++) {
        const ageIdx = i * 4 + 2;
        const strIdx = i * 4 + 3;
        const str = ripples[strIdx] ?? 0;
        const age = ripples[ageIdx] ?? 0;
        if (str > 0.001) {
          const nextAge = age + dt;
          if (nextAge > 1.75) {
            ripples[strIdx] = 0;
            ripples[ageIdx] = 0;
          } else {
            ripples[ageIdx] = nextAge;
            hasActiveRipple = true;
          }
        }
      }

      let hasActiveSoliton = false;
      const sol = solitonRef.current;
      if (sol[3] > 0.001) {
        const nextAge = sol[2] + dt;
        if (nextAge > 1.85) {
          sol[2] = 0;
          sol[3] = 0;
        } else {
          sol[2] = nextAge;
          hasActiveSoliton = true;
        }
      }

      if (sim.isActive()) {
        sim.step(dt, tiltRef.current[0], (impact) => {
          dispatchHydrationFluidImpulse({
            target: impact.target,
            normX: impact.normX,
            strength: -impact.strength,
          });
          onPoolImpactRef.current?.(impact);
        });
      }

      const hasInteractiveOverlay = hasActiveRipple || hasActiveSoliton || isTilting || pointerRef.current[2] > 0.5;
      return {
        kind: 'card-droplets',
        targetCanvas: canvas,
        width: sizeRef.current.w,
        height: sizeRef.current.h,
        fill: fillRatioRef.current,
        isAnimating:
          isVisibleRef.current &&
          (sim.isActive() || hasInteractiveOverlay),
        idleFrameIntervalMs: hasInteractiveOverlay ? undefined : 33,
        cardDroplets: sim.gpu,
        cardPointer: pointerRef.current,
        cardRipples: ripples,
        soliton: sol,
        tilt: tiltRef.current,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const ro =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            sizeRef.current = {
              w: Math.max(160, host.clientWidth),
              h: Math.max(120, host.clientHeight),
            };
            scheduleMeasureColliders();
            engine.renderSinglePass(provider);
          })
        : null;
    ro?.observe(host);

    const io =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                engine.renderSinglePass(provider);
                if (sim.isActive()) engine.wake();
              }
            },
            { threshold: 0.05 },
          )
        : null;
    io?.observe(host);

    engine.renderSinglePass(provider);
    const unsubscribe = engine.subscribe(provider, true);
    if (!prefersReducedMotion()) {
      engine.wake();
    }
    return () => {
      providerRef.current = null;
      unsubscribe();
      ro?.disconnect();
      io?.disconnect();
      if (colliderRafRef.current) {
        window.cancelAnimationFrame(colliderRafRef.current);
        colliderRafRef.current = 0;
      }
      window.removeEventListener('fluid-engine-fallback', clearCanvasOnFallback);
    };
  }, [hostRef, simRef, tiltRef, targetTiltRef, pointerRef, ripplesRef, solitonRef, measureColliders, scheduleMeasureColliders]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 z-[5] block w-full h-full rounded-[inherit]"
    />
  );
});

interface HydrationSummaryProps {
  isEstimatedGoal?: boolean;
  onOpenGoals?: () => void;
}

export const HydrationSummary = memo(function HydrationSummary({
  isEstimatedGoal = false,
  onOpenGoals,
}: HydrationSummaryProps) {
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const entries = useHydrationStore((s) => s.entries);
  const dailyGoalMl = useHydrationStore((s) => s.dailyGoalMl);
  const logWater = useHydrationStore((s) => s.logWater);
  const removeEntry = useHydrationStore((s) => s.removeEntry);

  const summary = useMemo(
    () => getHydrationSummary(entries, dailyGoalMl, activeDateKey),
    [entries, dailyGoalMl, activeDateKey],
  );

  const [sheetOpen, setSheetOpen] = useState(false);
  const [sheetOriginRect, setSheetOriginRect] = useState<SheetOriginRect | null>(null);
  const [customMl, setCustomMl] = useState('');
  const [correctionMl, setCorrectionMl] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [inlineFeedback, setInlineFeedback] = useState<string | null>(null);
  const [feedbackSeq, setFeedbackSeq] = useState(0);
  const [dropletBurstCount, setDropletBurstCount] = useState(0);
  const prevMlRef = useRef(summary.currentMl);
  const [volumeBumpKey, setVolumeBumpKey] = useState(0);

  useEffect(() => {
    if (prevMlRef.current !== summary.currentMl) {
      prevMlRef.current = summary.currentMl;
      if (!prefersReducedMotion()) {
        setVolumeBumpKey((k) => k + 1);
      }
    }
  }, [summary.currentMl]);

  const showFeedback = useCallback((label: string) => {
    setInlineFeedback(label);
    setFeedbackSeq((s) => s + 1);
  }, []);

  const cardSurfaceRef = useRef<HTMLDivElement | null>(null);
  const cardSimRef = useRef<CardDropletSim | null>(null);
  const tiltRef = useRef<[number, number]>([0, 0]);
  const targetTiltRef = useRef<[number, number]>([0, 0]);
  const hasGyroRef = useRef(false);
  const pointerRef = useRef<[number, number, number, number]>([0.35, 0.25, 0, 0]);
  const cardKalmanRef = useRef(new KalmanTouchPredictor());
  const ripplesRef = useRef<Float32Array>(new Float32Array(MAX_GLASS_RIPPLES * 4));
  const cardSolitonRef = useRef<[number, number, number, number]>([0.5, 0.5, 0, 0]);
  const nextRippleIdxRef = useRef(0);
  const lastPoolRippleAtRef = useRef(0);

  const undoBtnRef = useRef<HTMLButtonElement | null>(null);
  const registerBtnRef = useRef<HTMLButtonElement | null>(null);
  const dropletBoxRef = useRef<HTMLDivElement | null>(null);
  const tankBoxRef = useRef<HTMLDivElement | null>(null);
  const volumeLabelRef = useRef<HTMLDivElement | null>(null);

  const colliderRefs = useMemo(
    () => ({
      undoBtn: undoBtnRef,
      registerBtn: registerBtnRef,
      dropletBox: dropletBoxRef,
      tankBox: tankBoxRef,
      volumeLabel: volumeLabelRef,
    }),
    [],
  );

  const spawnGlassRipple = useCallback((normX: number, normY: number, strength = 0.85) => {
    if (prefersReducedMotion()) return;
    const slot = nextRippleIdxRef.current % MAX_GLASS_RIPPLES;
    nextRippleIdxRef.current += 1;
    const o = slot * 4;
    ripplesRef.current[o] = Math.min(1, Math.max(0, normX));
    ripplesRef.current[o + 1] = Math.min(1, Math.max(0, normY));
    ripplesRef.current[o + 2] = 0.015;
    ripplesRef.current[o + 3] = strength;
    getSharedFluidEngine().wake();
  }, []);

  const handleCardPoolImpact = useCallback(
    (impact: { target: 'droplet' | 'tank'; normX: number; strength: number }) => {
      const now = performance.now();
      if (now - lastPoolRippleAtRef.current < 110) return;
      lastPoolRippleAtRef.current = now;
      if (impact.target === 'droplet') {
        spawnGlassRipple(0.08 + impact.normX * 0.16, 0.44, Math.min(0.62, 0.34 + impact.strength * 0.08));
      } else {
        spawnGlassRipple(0.32 + impact.normX * 0.62, 0.56, Math.min(0.62, 0.34 + impact.strength * 0.08));
      }
    },
    [spawnGlassRipple],
  );

  const handleGaugeTiltTarget = useCallback((tx: number, ty: number) => {
    if (hasGyroRef.current || prefersReducedMotion()) return;
    targetTiltRef.current = [tx, ty];
    getSharedFluidEngine().wake();
  }, []);

  const launchCardSoliton = useCallback((normX: number, normY: number, strength = 1.0) => {
    if (prefersReducedMotion()) return;
    cardSolitonRef.current = [
      Math.min(1, Math.max(0, normX)),
      Math.min(1, Math.max(0, normY)),
      0.015,
      strength,
    ];
    getSharedFluidEngine().wake();
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || prefersReducedMotion()) return;
    const onOrientation = (event: DeviceOrientationEvent) => {
      if (event.gamma === null && event.beta === null) return;
      hasGyroRef.current = true;
      const gx = Math.max(-0.35, Math.min(0.35, ((event.gamma ?? 0) / 45) * 0.35));
      const gy = Math.max(-0.35, Math.min(0.35, (((event.beta ?? 35) - 35) / 45) * 0.25));
      const prev = targetTiltRef.current;
      if (Math.abs(gx - prev[0]) > 0.025 || Math.abs(gy - prev[1]) > 0.025) {
        targetTiltRef.current = [gx, gy];
        getSharedFluidEngine().wake();
      }
    };
    window.addEventListener('deviceorientation', onOrientation, { passive: true });
    return () => window.removeEventListener('deviceorientation', onOrientation);
  }, []);

  const handleCardPointerEvent = (event: ReactPointerEvent<HTMLDivElement>, isDown: boolean) => {
    const host = cardSurfaceRef.current;
    if (!host) return;
    const rect = host.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const samples = extractCoalescedSamples(
      event.nativeEvent,
      event.clientX,
      event.clientY,
      rect,
    );
    let pred = cardKalmanRef.current.update(
      samples[0]?.x ?? 0.5,
      samples[0]?.y ?? 0.5,
      samples[0]?.t ?? performance.now(),
    );
    for (let i = 1; i < samples.length; i++) {
      const s = samples[i];
      if (!s) continue;
      pred = cardKalmanRef.current.update(s.x, s.y, s.t);
    }

    host.style.setProperty('--glass-px', `${(pred.x * 100).toFixed(1)}%`);
    host.style.setProperty('--glass-py', `${(pred.y * 100).toFixed(1)}%`);

    const vx = Math.max(-1.4, Math.min(1.4, pred.vx));
    const vy = Math.max(-1.4, Math.min(1.4, pred.vy));
    const speed = Math.min(1, pred.speed);
    pointerRef.current = [pred.x, pred.y, 1, speed];

    if (!hasGyroRef.current && !prefersReducedMotion()) {
      targetTiltRef.current = [(pred.x - 0.5) * 0.24, (pred.y - 0.5) * 0.16];
    }

    if (!prefersReducedMotion()) {
      if (isDown) {
        spawnGlassRipple(pred.x, pred.y, 1.0);
        cardSimRef.current?.applyPointerSweep(pred.x, pred.y, vx, vy, true);
      } else if (speed > 0.05) {
        cardSimRef.current?.applyPointerSweep(pred.x, pred.y, vx, vy, false);
      }
      getSharedFluidEngine().wake();
    }
  };

  const handleQuickAdd = (ml: number) => {
    logWater(ml, activeDateKey);
    const nextRatio = summary.goalMl > 0 ? Math.min(1, (summary.currentMl + ml) / summary.goalMl) : 0.65;
    playDropletPlop(nextRatio, Math.min(1.15, 0.8 + ml / 700));
    const label = `+${ml} ml`;
    setFormError(null);
    showFeedback(label);
    setDropletBurstCount((c) => c + 1);
    cardSimRef.current?.shakeCollider('btn-register');
    spawnGlassRipple(0.88, 0.16, 1.15);
    launchCardSoliton(0.22, 0.65, 1.15);
    dispatchHydrationFluidImpulse({ target: 'both', normX: 0.5, strength: -4.2, soliton: true });
    showHydrationToast(label, 'add');
    setSheetOpen(false);
  };

  const handleCustomSubmit = () => {
    const res = logValidatedWater(customMl, activeDateKey);
    if (!res.ok) {
      setFormError(res.error);
      return;
    }
    const addedMl = Math.round(parseLocaleNumber(customMl));
    const nextRatio = summary.goalMl > 0 ? Math.min(1, (summary.currentMl + addedMl) / summary.goalMl) : 0.65;
    playDropletPlop(nextRatio, Math.min(1.15, 0.8 + addedMl / 700));
    const label = `+${addedMl} ml`;
    setCustomMl('');
    setFormError(null);
    showFeedback(label);
    setDropletBurstCount((c) => c + 1);
    spawnGlassRipple(0.84, 0.20, 1.15);
    launchCardSoliton(0.22, 0.65, 1.15);
    dispatchHydrationFluidImpulse({ target: 'both', normX: 0.5, strength: -4.2, soliton: true });
    showHydrationToast(label, 'add');
    setSheetOpen(false);
  };

  const handleCorrectLast = () => {
    const prevMl = lastEntry?.amountMl ?? 0;
    const res = correctValidatedLastWater(correctionMl, activeDateKey);
    if (!res.ok) {
      setFormError(res.error);
      return;
    }
    const nextMl = Math.round(parseLocaleNumber(correctionMl));
    const diffMl = nextMl - prevMl;
    setCorrectionMl('');
    setFormError(null);
    if (diffMl !== 0) {
      const label = `${diffMl > 0 ? '+' : '-'}${Math.abs(diffMl)} ml`;
      showFeedback(label);
      if (diffMl > 0) {
        playDropletPlop(summary.barPercent / 100, 0.95);
        setDropletBurstCount((c) => c + 1);
        spawnGlassRipple(0.84, 0.20, 1.0);
        launchCardSoliton(0.25, 0.62, 1.0);
        dispatchHydrationFluidImpulse({ target: 'both', normX: 0.5, strength: -3.2, soliton: true });
      } else {
        playCrystalGlassTap(0.5, 0.85);
        launchCardSoliton(0.75, 0.62, 0.78);
        dispatchHydrationFluidImpulse({ target: 'both', normX: 0.5, strength: 2.0, soliton: true });
      }
      showHydrationToast(label, diffMl > 0 ? 'add' : 'remove');
    }
  };

  const lastEntry = summary.dayEntries[summary.dayEntries.length - 1] ?? null;
  const formattedVolume = formatMilliliters(summary.currentMl);

  useEffect(() => {
    if (!inlineFeedback) return;
    const timer = window.setTimeout(() => setInlineFeedback(null), 2400);
    return () => window.clearTimeout(timer);
  }, [inlineFeedback, feedbackSeq]);

  return (
    <>
      <div id="cockpit-hydration" className="relative rounded-[24px]">
        {/* Ambient refraction depth lights behind the translucent Liquid Glass slab */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -inset-px rounded-[inherit] overflow-hidden opacity-90"
        >
          <div className="absolute -top-8 -left-6 h-36 w-48 rounded-full bg-[radial-gradient(circle,rgba(104,205,235,0.28),transparent_68%)] blur-xl" />
          <div className="absolute -bottom-10 right-2 h-40 w-56 rounded-full bg-[radial-gradient(circle,rgba(56,162,196,0.24),transparent_70%)] blur-xl" />
          <div className="absolute inset-0 bg-[linear-gradient(155deg,rgba(14,32,38,0.64),rgba(7,16,20,0.82))]" />
        </div>

        <div
          ref={cardSurfaceRef}
          onPointerDown={(e) => handleCardPointerEvent(e, true)}
          onPointerMove={(e) => handleCardPointerEvent(e, false)}
          onPointerLeave={() => {
            cardKalmanRef.current.reset();
            pointerRef.current = [0.35, 0.25, 0, 0];
            if (!hasGyroRef.current) {
              targetTiltRef.current = [0, 0];
              if (!prefersReducedMotion()) getSharedFluidEngine().wake();
            }
          }}
          className="titan-liquid-glass-card p-4 sm:p-5 select-none focus:outline-none"
        >
          <CardDropletOverlay
            hostRef={cardSurfaceRef}
            simRef={cardSimRef}
            tiltRef={tiltRef}
            targetTiltRef={targetTiltRef}
            pointerRef={pointerRef}
            ripplesRef={ripplesRef}
            solitonRef={cardSolitonRef}
            fillRatio={summary.barPercent / 100}
            burstTrigger={dropletBurstCount}
            colliderMeasureDeps={[Boolean(lastEntry), summary.currentMl, summary.goalMl]}
            colliderRefs={colliderRefs}
            onPoolImpact={handleCardPoolImpact}
          />

          {/* Ações compactas em Liquid Glass fixadas no canto superior direito */}
          <div className="absolute top-3.5 right-3.5 sm:top-4 sm:right-4 z-[3] flex items-center gap-1.5">
            {lastEntry && (
              <button
                ref={undoBtnRef}
                type="button"
                onPointerEnter={() => cardSimRef.current?.shakeCollider('btn-undo')}
                onClick={() => {
                  cardSimRef.current?.shakeCollider('btn-undo');
                  playCrystalGlassTap(0.76, 0.88);
                  const removedLabel = `-${lastEntry.amountMl} ml`;
                  removeEntry(lastEntry.id);
                  showFeedback(removedLabel);
                  spawnGlassRipple(0.76, 0.16, 0.85);
                  launchCardSoliton(0.76, 0.16, 0.85);
                  dispatchHydrationFluidImpulse({ target: 'both', normX: 0.5, strength: 2.4, soliton: true });
                  showHydrationToast(removedLabel, 'remove');
                }}
                aria-label={`Desfazer último registro de ${lastEntry.amountMl} ml`}
                title={`Desfazer (${lastEntry.amountMl} ml)`}
                className="titan-button titan-liquid-glass-pill animate-hydration-pill !min-h-[44px] !min-w-[44px] !w-[44px] !h-[44px] !p-0 !rounded-[15px] !text-[var(--titan-text-secondary)]"
              >
                <RotateCcw className="w-4 h-4 transition-transform duration-200 active:-rotate-45" aria-hidden="true" />
              </button>
            )}
            <button
              ref={registerBtnRef}
              type="button"
              onPointerEnter={() => cardSimRef.current?.shakeCollider('btn-register')}
              onClick={(e) => {
                const r = e.currentTarget.getBoundingClientRect();
                if (r.width > 0 && r.height > 0) {
                  setSheetOriginRect({ left: r.left, top: r.top, width: r.width, height: r.height });
                } else {
                  setSheetOriginRect(null);
                }
                playLiquidGlassOpenCue(1.0);
                cardSimRef.current?.shakeCollider('btn-register');
                spawnGlassRipple(0.88, 0.16, 1.12);
                launchCardSoliton(0.88, 0.16, 1.25);
                setCorrectionMl(lastEntry ? String(lastEntry.amountMl) : '');
                setFormError(null);
                setSheetOpen(true);
              }}
              aria-label="Registrar água"
              title="Registrar água"
              className={`titan-button titan-liquid-glass-pill !min-h-[44px] !min-w-[44px] !w-[44px] !h-[44px] !p-0 !rounded-[15px] !text-[#DDF6FF] ${
                sheetOpen ? 'scale-90 opacity-80' : ''
              }`}
            >
              <Plus
                className={`w-[18px] h-[18px] stroke-[2.25] transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] ${
                  sheetOpen ? 'rotate-45' : 'rotate-0'
                }`}
                aria-hidden="true"
              />
            </button>
          </div>

          {/* Cabeçalho editorial Liquid Glass com respiro para o canto superior direito */}
          <div className="relative z-[2] flex items-baseline gap-2.5 pr-[104px] mb-2.5">
            <h2 className="font-display text-[13px] font-semibold tracking-[0.04em] text-[#ECF8FD]/94 drop-shadow-[0_1px_2px_rgba(0,0,0,0.45)]">
              Hidratação
            </h2>
            {inlineFeedback && (
              <span
                key={`fb-${feedbackSeq}`}
                role="status"
                className="text-[11px] font-mono-metric font-medium tracking-[0.01em] text-[#9EE3FA] animate-hydration-feedback"
              >
                {inlineFeedback}
              </span>
            )}
          </div>

          {/* Gota 3D + Barra de cristal com porcentagem navegando na água */}
          <div className="relative z-[2] grid grid-cols-[84px_minmax(0,1fr)] gap-x-3.5 items-center">
            <WaterDropletGauge
              percent={summary.percent}
              barPercent={summary.barPercent}
              hasRecords={summary.hasRecords}
              hasValidGoal={summary.goalMl > 0}
              tiltRef={tiltRef}
              boxRef={dropletBoxRef}
              onTiltTarget={handleGaugeTiltTarget}
            />

            <div className="min-w-0 flex flex-col justify-center">
              <div className="flex items-baseline justify-between gap-2 mb-1.5">
                <div
                  ref={volumeLabelRef}
                  aria-label={formattedVolume}
                  className="flex items-baseline drop-shadow-[0_2px_6px_rgba(0,0,0,0.45)]"
                >
                  <AnimatedVolumeDisplay
                    targetMl={summary.currentMl}
                    volumeBumpKey={volumeBumpKey}
                    variant="hero"
                  />
                </div>

                <div className="flex items-baseline gap-1.5 shrink-0 text-right">
                  <span className="font-mono-metric text-[12px] sm:text-[12.5px] font-medium tracking-[0.02em] text-[#A2D4E8]/92 tabular-nums drop-shadow-[0_1px_3px_rgba(0,0,0,0.45)]">
                    {summary.goalMl > 0
                      ? formatMilliliters(summary.goalMl)
                      : 'Meta não definida'}
                  </span>
                  {isEstimatedGoal && onOpenGoals && (
                    <button
                      type="button"
                      onClick={onOpenGoals}
                      className="text-[11px] text-[#9EE3FA] hover:underline font-sans font-medium"
                    >
                      Ajustar
                    </button>
                  )}
                </div>
              </div>

              <div className="relative">
                {summary.goalMl > 0 && summary.currentMl >= summary.goalMl && (
                  <div
                    aria-hidden="true"
                    className="pointer-events-none -inset-1 absolute rounded-full bg-[radial-gradient(60%_140%_at_50%_50%,rgba(122,226,255,0.28),transparent_72%)] blur-md animate-hydration-goal-aura"
                  />
                )}
                <CrystalWaterTank
                  percent={summary.percent}
                  barPercent={summary.barPercent}
                  currentMl={summary.currentMl}
                  goalMl={summary.goalMl}
                  tiltRef={tiltRef}
                  boxRef={tankBoxRef}
                  onTiltTarget={handleGaugeTiltTarget}
                />
              </div>

              {summary.goalMl > 0 && (
                <div className="mt-1.5 flex items-center justify-between gap-2 text-[11px] leading-tight">
                  <AnimatedRemainingLabel
                    currentMl={summary.currentMl}
                    goalMl={summary.goalMl}
                    volumeBumpKey={volumeBumpKey}
                    keyPrefix="goal"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <BottomSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title="Registrar hidratação"
        variant="liquid-glass"
        originRect={sheetOriginRect}
        subtitle={
          summary.goalMl > 0
            ? `${formatMilliliters(summary.goalMl)} · ${activeDateKey}`
            : `Meta não definida · ${activeDateKey}`
        }
      >
        <div className="space-y-4">
          <div className="titan-liquid-glass-group p-3.5 sm:p-4">
            <div className="grid grid-cols-[84px_minmax(0,1fr)] gap-x-3.5 items-center">
              <WaterDropletGauge
                percent={summary.percent}
                barPercent={summary.barPercent}
                hasRecords={summary.hasRecords}
                hasValidGoal={summary.goalMl > 0}
                tiltRef={tiltRef}
                onTiltTarget={handleGaugeTiltTarget}
              />

              <div className="min-w-0 flex flex-col justify-center">
                <div className="flex items-baseline justify-between gap-2 mb-1.5">
                  <div
                    aria-label={formattedVolume}
                    className="flex items-baseline drop-shadow-[0_2px_6px_rgba(0,0,0,0.45)]"
                  >
                    <AnimatedVolumeDisplay
                      targetMl={summary.currentMl}
                      volumeBumpKey={volumeBumpKey}
                      variant="modal"
                    />
                  </div>
                  <span className="font-mono-metric text-[12px] font-medium tracking-[0.02em] text-[#A2D4E8]/92 tabular-nums shrink-0 text-right">
                    {summary.goalMl > 0
                      ? formatMilliliters(summary.goalMl)
                      : 'Meta não definida'}
                  </span>
                </div>

                <div className="relative">
                  {summary.goalMl > 0 && summary.currentMl >= summary.goalMl && (
                    <div
                      aria-hidden="true"
                      className="pointer-events-none -inset-1 absolute rounded-full bg-[radial-gradient(60%_140%_at_50%_50%,rgba(122,226,255,0.28),transparent_72%)] blur-md animate-hydration-goal-aura"
                    />
                  )}
                  <CrystalWaterTank
                    percent={summary.percent}
                    barPercent={summary.barPercent}
                    currentMl={summary.currentMl}
                    goalMl={summary.goalMl}
                    tiltRef={tiltRef}
                    onTiltTarget={handleGaugeTiltTarget}
                  />
                </div>

                {summary.goalMl > 0 && (
                  <div className="mt-1.5 flex items-center justify-between gap-2 text-[11px] leading-tight">
                    <AnimatedRemainingLabel
                      currentMl={summary.currentMl}
                      goalMl={summary.goalMl}
                      volumeBumpKey={volumeBumpKey}
                      keyPrefix="modal-goal"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            {([
              { ml: 150, ratioWidth: 'w-[30%]', primary: false },
              { ml: 250, ratioWidth: 'w-[50%]', primary: true },
              { ml: 500, ratioWidth: 'w-full', primary: false },
            ] as const).map(({ ml, ratioWidth, primary }) => (
              <button
                key={ml}
                type="button"
                data-primary={primary ? 'true' : undefined}
                aria-label={`Adicionar ${ml} ml`}
                className="titan-liquid-glass-tile !flex-col !gap-1.5 !py-2.5 !px-3 !min-h-[54px] font-mono-metric tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                onPointerMove={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  if (r.width <= 0 || r.height <= 0) return;
                  const px = Math.min(100, Math.max(0, ((e.clientX - r.left) / r.width) * 100));
                  const py = Math.min(100, Math.max(0, ((e.clientY - r.top) / r.height) * 100));
                  e.currentTarget.style.setProperty('--tile-px', `${px.toFixed(0)}%`);
                  e.currentTarget.style.setProperty('--tile-py', `${py.toFixed(0)}%`);
                }}
                onPointerLeave={(e) => {
                  e.currentTarget.style.removeProperty('--tile-px');
                  e.currentTarget.style.removeProperty('--tile-py');
                }}
                onClick={() => handleQuickAdd(ml)}
              >
                <span className="inline-flex items-baseline gap-1 leading-none">
                  <span className="text-[15px] font-semibold text-[#F4FCFF]">+{ml}</span>
                  <span className="text-[11px] font-medium text-[#95CBE0]">ml</span>
                </span>
                <span
                  aria-hidden="true"
                  className="relative h-[3.5px] w-full overflow-hidden rounded-full bg-[rgba(10,28,38,0.68)] shadow-[inset_0_1px_2px_rgba(0,0,0,0.45)]"
                >
                  <span
                    className={`relative block h-full ${ratioWidth} rounded-full bg-[linear-gradient(90deg,rgba(78,188,232,0.72),rgba(232,252,255,0.96))]`}
                  >
                    <span className="absolute right-0 top-1/2 -translate-y-1/2 h-1.5 w-1.5 rounded-full bg-white shadow-[0_0_6px_rgba(206,248,255,0.95)]" />
                  </span>
                </span>
              </button>
            ))}
          </div>

          <form
            className="flex items-end gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              handleCustomSubmit();
            }}
          >
            <label className="flex-1 block min-w-0">
              <span className="text-xs font-medium text-[#9EC5D5]">Quantidade personalizada</span>
              <div className="relative mt-1">
                <input
                  type="number"
                  inputMode="numeric"
                  min={10}
                  max={5000}
                  step={1}
                  placeholder="Ex.: 350"
                  value={customMl}
                  onChange={(e) => setCustomMl(e.target.value)}
                  aria-invalid={Boolean(formError)}
                  aria-describedby={formError ? 'hydration-form-error' : undefined}
                  className="titan-liquid-glass-input w-full min-h-[44px] pl-3 pr-10 rounded-xl text-sm font-mono-metric tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                />
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 font-mono-metric text-xs text-[#7DA8BB]"
                >
                  ml
                </span>
              </div>
            </label>
            <button
              type="submit"
              className="titan-liquid-glass-tile shrink-0 !min-h-[44px] !px-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
            >
              Registrar
            </button>
          </form>

          {formError && (
            <p id="hydration-form-error" className="text-xs text-[var(--titan-status-error)]" role="alert">
              {formError}
            </p>
          )}

          {lastEntry && (
            <div className="titan-liquid-glass-group p-3.5 space-y-2">
              <div className="text-xs font-medium text-[#9EC5D5] tabular-nums">
                Corrigir último registro ({lastEntry.timeLabel} · {lastEntry.amountMl} ml)
              </div>
              <form
                className="flex items-center gap-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  handleCorrectLast();
                }}
              >
                <div className="relative flex-1 min-w-0">
                  <input
                    type="number"
                    inputMode="numeric"
                    min={0}
                    max={5000}
                    step={1}
                    value={correctionMl}
                    onChange={(e) => setCorrectionMl(e.target.value)}
                    aria-label="Corrigir volume do último registro em ml"
                    aria-invalid={Boolean(formError)}
                    aria-describedby={formError ? 'hydration-form-error' : undefined}
                    className="titan-liquid-glass-input w-full min-h-[44px] pl-3 pr-10 rounded-xl text-sm font-mono-metric tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 font-mono-metric text-xs text-[#7DA8BB]"
                  >
                    ml
                  </span>
                </div>
                <button
                  type="submit"
                  className="titan-liquid-glass-tile shrink-0 !min-h-[44px] !px-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                >
                  Corrigir
                </button>
              </form>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-baseline justify-between text-xs font-medium text-[#9EC5D5]">
              <span>Histórico do dia</span>
              <span className="font-mono-metric text-[#B6E4F6] tabular-nums">
                {formatMilliliters(summary.currentMl)}
              </span>
            </div>
            {summary.dayEntries.length === 0 ? (
              <p className="text-xs text-[#7FA5B5]">Nenhum registro para esta data.</p>
            ) : (
              <div className="titan-liquid-glass-group max-h-40 overflow-y-auto divide-y divide-[rgba(200,235,248,0.10)] px-3">
                {[...summary.dayEntries].reverse().map((entry) => (
                  <div
                    key={entry.id}
                    className="py-1.5 flex items-center justify-between text-xs transition-colors"
                  >
                    <span className="font-mono-metric text-[#E6F6FC] tabular-nums">
                      {entry.timeLabel} · {formatMilliliters(entry.amountMl)}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        playCrystalGlassTap(0.5, 0.78);
                        const removedLabel = `-${entry.amountMl} ml`;
                        removeEntry(entry.id);
                        showFeedback(removedLabel);
                        launchCardSoliton(0.5, 0.72, 0.75);
                        dispatchHydrationFluidImpulse({ target: 'both', normX: 0.5, strength: 2.0, soliton: true });
                        showHydrationToast(removedLabel, 'remove');
                      }}
                      aria-label={`Remover registro de ${entry.amountMl} ml às ${entry.timeLabel}`}
                      className="min-h-[44px] min-w-[44px] -mr-1.5 flex items-center justify-center rounded-xl text-[#8CB5C7] hover:bg-[rgba(140,214,242,0.10)] hover:text-[#F2FBFF] active:scale-90 transition-[color,background-color,transform] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </BottomSheet>
    </>
  );
});
