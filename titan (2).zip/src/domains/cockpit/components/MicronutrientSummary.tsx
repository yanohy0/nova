import { memo, startTransition, useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import {
  getDailyMicronutrientDisplays,
  getNutrientChemistry,
  type NutrientId,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import { AnimatePresence, motion, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import { Surface } from '@/src/shared/ui/Surface';
import { formatNutrientAmount } from '@/src/shared/utils/formatters';
import { MolecularStructure } from './MolecularStructure';

type MicroFilterMode = 'principais' | 'vitaminas' | 'minerais' | 'todos';

const PRIORITY_NUTRIENT_IDS = new Set<NutrientId>([
  'vitamin_c',
  'vitamin_d',
  'calcium',
  'iron',
  'magnesium',
  'sodium',
]);

const FILTER_OPTIONS: Array<{ id: MicroFilterMode; label: string }> = [
  { id: 'principais', label: 'Principais' },
  { id: 'vitaminas', label: 'Vitaminas' },
  { id: 'minerais', label: 'Minerais' },
  { id: 'todos', label: 'Todos' },
];

const SOURCE_LABELS: Record<string, string> = {
  TBCA: 'TBCA',
  OPEN_FOOD_FACTS: 'Open Food Facts',
};

function resolveExplicitStateLabel(item: {
  dataStatus: 'quantified' | 'trace' | 'not_analyzed' | 'missing';
  hasUnquantifiedSources: boolean;
  displayMode: string;
}): string {
  if (item.displayMode === 'no_reference') return 'Não aplicável';
  if (item.dataStatus === 'trace') return 'Traço (tr)';
  if (item.dataStatus === 'not_analyzed') return 'Não analisado';
  if (item.dataStatus === 'missing') return 'Não informado';
  return item.hasUnquantifiedSources ? 'Parcial' : 'Disponível';
}

interface MicronutrientSummaryProps {
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

export const MicronutrientSummary = memo(function MicronutrientSummary({
  onOpenNutrition,
}: MicronutrientSummaryProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const referenceProfileId = useNutritionStore((s) => s.referenceProfileId);

  const [expandedId, setExpandedId] = useState<NutrientId | null>(null);
  const [filterMode, setFilterMode] = useState<MicroFilterMode>('principais');
  const [searchQuery, setSearchQuery] = useState('');

  const items = useMemo(
    () =>
      getDailyMicronutrientDisplays(
        meals,
        activeDateKey,
        referenceProfileId,
      ),
    [meals, activeDateKey, referenceProfileId],
  );

  const filteredItems = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return items.filter((item) => {
      const chem = getNutrientChemistry(item.nutrientId);
      if (filterMode === 'principais' && !PRIORITY_NUTRIENT_IDS.has(item.nutrientId)) {
        return false;
      }
      if (filterMode === 'vitaminas' && chem.family !== 'vitamin') {
        return false;
      }
      if (filterMode === 'minerais' && chem.family !== 'mineral') {
        return false;
      }
      if (query.length > 0) {
        const haystack = `${chem.shortLabel} ${chem.fullName} ${chem.compoundName}`.toLowerCase();
        if (!haystack.includes(query)) return false;
      }
      return true;
    });
  }, [items, filterMode, searchQuery]);

  const { vitamins, minerals } = useMemo(() => {
    const vit: typeof filteredItems = [];
    const min: typeof filteredItems = [];
    for (const item of filteredItems) {
      const chem = getNutrientChemistry(item.nutrientId);
      if (chem.family === 'vitamin') {
        vit.push(item);
      } else {
        min.push(item);
      }
    }
    return { vitamins: vit, minerals: min };
  }, [filteredItems]);

  const renderGroup = (groupTitle: string, groupItems: typeof filteredItems) => {
    if (groupItems.length === 0) return null;
    return (
      <div className="space-y-1">
        <div className="px-2 pt-2.5 pb-1 text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
          {groupTitle}
        </div>

        {groupItems.map((item) => {
          const chem = getNutrientChemistry(item.nutrientId);
          const isExpanded = expandedId === item.nutrientId;
          const stateLabel = resolveExplicitStateLabel(item);

          const fillColor =
            chem.family === 'vitamin'
              ? item.isExceeded
                ? 'var(--titan-accent-strong)'
                : 'var(--titan-accent)'
              : item.isLimitMetric
              ? item.isExceeded
                ? 'var(--titan-status-error)'
                : 'var(--titan-status-warning)'
              : 'var(--titan-info)';

          const valueText =
            item.dataStatus === 'trace'
              ? 'tr'
              : item.dataStatus === 'not_analyzed' || item.dataStatus === 'missing'
              ? '—'
              : item.consumedValue !== null
              ? formatNutrientAmount(item.consumedValue, item.unit)
              : '—';

          const percentText =
            item.dataStatus === 'trace'
              ? 'tr'
              : item.displayMode === 'not_analyzed'
              ? 's/ dado'
              : item.displayMode === 'no_reference'
              ? 'N/A'
              : item.rawPercent !== null
              ? `${item.rawPercent}%`
              : '—';

          const remainingDiff =
            item.referenceValue !== null && item.consumedValue !== null
              ? item.referenceValue - item.consumedValue
              : item.referenceValue;

          const remainingText =
            item.referenceValue === null
              ? 'Não aplicável (sem meta diária definida na DRI)'
              : item.isLimitMetric
              ? remainingDiff !== null && remainingDiff < 0
                ? `Excedeu o limite em ${formatNutrientAmount(Math.abs(remainingDiff), item.referenceUnit)}`
                : `Margem restante de ${formatNutrientAmount(Math.max(0, remainingDiff ?? item.referenceValue), item.referenceUnit)}`
              : remainingDiff !== null && remainingDiff <= 0
              ? 'Meta diária atingida'
              : `Faltam ${formatNutrientAmount(Math.max(0, remainingDiff ?? item.referenceValue), item.referenceUnit)} para a meta`;

          return (
            <div
              key={item.nutrientId}
              className={`rounded-2xl transition-colors ${
                isExpanded
                  ? 'bg-[linear-gradient(170deg,rgba(32,42,38,0.85),rgba(18,24,21,0.94))] border border-[rgba(193,204,196,0.12)] shadow-[inset_0_1px_0_rgba(241,240,232,0.05)] my-1.5'
                  : 'hover:bg-[rgba(241,240,232,0.025)]'
              }`}
            >
              <button
                type="button"
                onClick={() =>
                  startTransition(() =>
                    setExpandedId((prev) =>
                      prev === item.nutrientId ? null : item.nutrientId,
                    ),
                  )
                }
                aria-expanded={isExpanded}
                className="w-full min-h-[44px] px-2 py-1.5 flex items-center gap-2.5 text-left rounded-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
              >
                <MolecularStructure nutrientId={item.nutrientId} size="mini" />

                <div className="min-w-0 flex-1">
                  <div className="text-xs sm:text-[13px] font-medium text-[var(--titan-text-primary)] truncate">
                    {chem.shortLabel}
                  </div>
                  <div className="text-xs font-mono-metric text-[var(--titan-text-muted)] truncate">
                    {valueText}
                    {stateLabel !== 'Disponível' && (
                      <span
                        className={
                          stateLabel === 'Parcial'
                            ? ' text-[var(--titan-status-warning)]'
                            : ' text-[var(--titan-text-muted)]/85'
                        }
                      >
                        {' · '}
                        {stateLabel}
                      </span>
                    )}
                    {item.isLimitMetric && item.referenceValue ? (
                      <span className="text-[var(--titan-text-muted)]/80">
                        {' '}
                        · limite {item.referenceValue} {item.referenceUnit}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="w-[64px] sm:w-[88px] shrink-0">
                  {item.displayMode !== 'no_reference' &&
                  item.displayMode !== 'not_analyzed' &&
                  item.referenceValue !== null ? (
                    <div
                      className="relative h-[5px] w-full rounded-full bg-[var(--titan-track)] border border-[var(--titan-border)]/45 overflow-hidden"
                      aria-hidden="true"
                    >
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${item.barPercent}%`,
                          backgroundColor: fillColor,
                        }}
                      />
                    </div>
                  ) : (
                    <div className="h-[5px] w-full rounded-full bg-[var(--titan-track)]/60" />
                  )}
                </div>

                <div
                  className={`w-[42px] shrink-0 text-right text-xs font-mono-metric ${
                    item.isLimitMetric && item.isExceeded
                      ? 'text-[var(--titan-status-error)]'
                      : item.rawPercent !== null
                      ? 'text-[var(--titan-text-primary)]'
                      : 'text-[var(--titan-text-muted)]'
                  }`}
                >
                  {percentText}
                </div>
              </button>

              <AnimatePresence initial={false}>
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
                    className="overflow-hidden"
                  >
                    <div className="px-3 pb-3 pt-2.5 border-t border-[rgba(193,204,196,0.08)] space-y-2.5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1 text-xs min-w-0 flex-1">
                          <div className="flex flex-wrap items-baseline gap-2">
                            <span className="text-sm font-semibold text-[var(--titan-text-primary)]">
                              {chem.fullName}
                            </span>
                            <span className="text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
                              {item.referenceKind ?? 'DRI'} · {stateLabel}
                            </span>
                          </div>

                          <div className="text-[var(--titan-text-secondary)]">
                            Consumido:{' '}
                            <span className="font-mono-metric text-[var(--titan-text-primary)]">{valueText}</span>
                            {item.referenceValue !== null && (
                              <>
                                {' · '}Meta:{' '}
                                <span className="font-mono-metric text-[var(--titan-text-primary)]">
                                  {formatNutrientAmount(item.referenceValue, item.referenceUnit)}
                                </span>
                              </>
                            )}
                          </div>

                          <div className="text-[11px] text-[var(--titan-text-muted)]">
                            Referência: {item.profileLabel} ({item.referenceSystem} {item.referenceVersion})
                          </div>

                          {item.hasUnquantifiedSources && item.dataStatus === 'quantified' && (
                            <p className="text-[11px] text-[var(--titan-status-warning)]">
                              Soma parcial: parte dos alimentos registrados não possui valor analisado para este nutriente.
                            </p>
                          )}

                          <div
                            className={`text-xs font-medium ${
                              item.isLimitMetric && item.isExceeded
                                ? 'text-[var(--titan-status-error)]'
                                : remainingDiff !== null && remainingDiff <= 0 && !item.isLimitMetric
                                ? 'text-[var(--titan-status-success)]'
                                : 'text-[var(--titan-accent)]'
                            }`}
                          >
                            {remainingText}
                          </div>
                        </div>

                        <MolecularStructure nutrientId={item.nutrientId} size="expanded" />
                      </div>

                      <div className="space-y-1.5">
                        <div className="text-xs font-medium text-[var(--titan-text-secondary)]">
                          Contribuição por refeição e alimento
                        </div>
                        {item.contributions.length === 0 ? (
                          <p className="text-xs text-[var(--titan-text-muted)]">
                            {item.dataStatus === 'trace'
                              ? 'Apenas quantidades em traço (tr) nos alimentos consumidos nesta data.'
                              : item.dataStatus === 'missing'
                              ? 'Os alimentos registrados nesta data não informaram este nutriente na tabela de origem.'
                              : item.dataStatus === 'not_analyzed'
                              ? 'Este nutriente consta como não analisado nos alimentos registrados nesta data.'
                              : 'Nenhum alimento consumido nesta data possui quantificação registrada.'}
                          </p>
                        ) : (
                          <div className="divide-y divide-[var(--titan-border)]/45 rounded-xl bg-[var(--titan-track)]/90 border border-[var(--titan-border)]/60 px-2.5">
                            {item.contributions.map((c, idx) => (
                              <div
                                key={`${c.foodId}-${c.mealTitle}-${idx}`}
                                className="py-2 text-xs flex items-center justify-between gap-2"
                              >
                                <div className="min-w-0">
                                  <div className="font-medium text-[var(--titan-text-primary)] truncate">
                                    {c.foodName}
                                  </div>
                                  <div className="text-[var(--titan-text-muted)] truncate">
                                    {c.mealTime} · {c.mealTitle} · {c.quantityG} g · {SOURCE_LABELS[c.sourceId] ?? c.sourceId}
                                  </div>
                                </div>
                                <span className="font-mono-metric text-[var(--titan-accent)] shrink-0">
                                  {c.dataStatus === 'trace'
                                    ? 'tr'
                                    : c.amount !== null
                                    ? formatNutrientAmount(c.amount, c.unit)
                                    : '—'}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    );
  };

  const hasAnyConsumedData = items.some(
    (item) =>
      item.contributions.length > 0 ||
      item.dataStatus === 'quantified' ||
      item.dataStatus === 'trace',
  );

  return (
    <Surface className="p-4 sm:p-5">
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-[rgba(193,204,196,0.08)]">
        <h2 className="text-base font-semibold text-[var(--titan-text-primary)]">
          Micronutrientes
        </h2>

        <span className="text-xs font-medium text-[var(--titan-accent)] whitespace-nowrap">
          TBCA · DRI
        </span>
      </div>

      <div className="mt-3 space-y-2">
        <div
          className="titan-segmented w-full grid grid-cols-4"
          role="group"
          aria-label="Filtrar micronutrientes"
        >
          {FILTER_OPTIONS.map((option) => (
            <button
              key={option.id}
              type="button"
              aria-pressed={filterMode === option.id}
              onClick={() =>
                startTransition(() => {
                  setFilterMode(option.id);
                  if (option.id !== 'todos') setSearchQuery('');
                })
              }
              className="titan-segment text-[11px] px-1.5"
            >
              {option.label}
            </button>
          ))}
        </div>

        {filterMode === 'todos' && (
          <div className="relative">
            <Search
              className="w-3.5 h-3.5 text-[var(--titan-text-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar vitamina ou mineral..."
              aria-label="Buscar micronutriente"
              className="w-full min-h-[40px] pl-8 pr-3 rounded-xl bg-[var(--titan-surface-inset)] border border-[rgba(193,204,196,0.12)] text-xs text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
            />
          </div>
        )}
      </div>

      {!hasAnyConsumedData && (
        <div className="mt-3 titan-luxury-group p-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-[var(--titan-text-secondary)]">
            Nenhuma refeição registrada nesta data. Os valores permanecem vazios até o consumo ser confirmado.
          </p>
          {onOpenNutrition && (
            <button
              type="button"
              onClick={() => onOpenNutrition('cardapio')}
              className="text-xs font-medium text-[var(--titan-accent)] hover:underline shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
            >
              Abrir Cardápio
            </button>
          )}
        </div>
      )}

      <div className="pt-1 space-y-3">
        {vitamins.length === 0 && minerals.length === 0 ? (
          <p className="py-4 text-center text-xs text-[var(--titan-text-muted)]">
            Nenhum micronutriente encontrado para &ldquo;{searchQuery}&rdquo;.
          </p>
        ) : (
          <>
            {renderGroup('Vitaminas', vitamins)}
            {vitamins.length > 0 && minerals.length > 0 && (
              <div className="border-t border-[rgba(193,204,196,0.08)] pt-1">
                {renderGroup('Minerais', minerals)}
              </div>
            )}
            {vitamins.length === 0 && renderGroup('Minerais', minerals)}
          </>
        )}
      </div>
    </Surface>
  );
});
