import * as THREE from 'three';

function hash2d(ix: number, iy: number, seed: number): number {
  const n = Math.sin(ix * 127.1 + iy * 311.7 + seed * 74.7) * 43758.5453123;
  return n - Math.floor(n);
}

function periodicValueNoise(u: number, v: number, freq: number, seed: number): number {
  const x = u * freq;
  const y = v * freq;
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const sx = fx * fx * (3 - 2 * fx);
  const sy = fy * fy * (3 - 2 * fy);

  const ix0 = ((x0 % freq) + freq) % freq;
  const ix1 = (ix0 + 1) % freq;
  const iy0 = ((y0 % freq) + freq) % freq;
  const iy1 = (iy0 + 1) % freq;

  const n00 = hash2d(ix0, iy0, seed);
  const n10 = hash2d(ix1, iy0, seed);
  const n01 = hash2d(ix0, iy1, seed);
  const n11 = hash2d(ix1, iy1, seed);

  const nx0 = n00 + (n10 - n00) * sx;
  const nx1 = n01 + (n11 - n01) * sx;
  return nx0 + (nx1 - nx0) * sy;
}

/**
 * Generates a subtle dermal albedo map with warm biological variation
 * so the PBR skin surface never reads as flat uniform plastic.
 */
export function createSkinAlbedoTexture(size = 256): THREE.DataTexture {
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) {
      const u = x / size;
      const macro = periodicValueNoise(u, v, 6, 1.3);
      const mid = periodicValueNoise(u, v, 18, 4.7);
      const fine = periodicValueNoise(u, v, 38, 6.9);
      const pore = periodicValueNoise(u, v, 84, 9.1);
      const capillary = Math.max(0, 0.54 - Math.abs(fine - 0.5)) * 0.052;
      const poreShade = (pore - 0.5) * 0.055;
      const fasciaVein = Math.max(0, 0.48 - Math.abs(macro - 0.48)) * 0.028;
      const tone = 0.87 + macro * 0.095 + (mid - 0.5) * 0.062 + poreShade - fasciaVein;

      const idx = (y * size + x) * 4;
      data[idx] = Math.min(255, Math.max(0, Math.round(222 * (tone + capillary))));
      data[idx + 1] = Math.min(255, Math.max(0, Math.round(201 * (tone - (1 - mid) * 0.028))));
      data[idx + 2] = Math.min(255, Math.max(0, Math.round(189 * (tone - (1 - mid) * 0.046 + fasciaVein * 0.5))));
      data[idx + 3] = 255;
    }
  }

  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
  texture.name = 'titan-skin-albedo-pbr';
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Generates a calibrated dermal roughness map (linear space) to vary
 * specular response across pores and muscular ridges.
 */
export function createSkinRoughnessTexture(size = 256): THREE.DataTexture {
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) {
      const u = x / size;
      const macro = periodicValueNoise(u, v, 8, 2.9);
      const mid = periodicValueNoise(u, v, 24, 7.3);
      const pore = periodicValueNoise(u, v, 76, 11.4);
      const microRidge = Math.sin((u * 18 + v * 6 + macro * 0.9) * Math.PI * 2) * 0.072;
      const roughnessVal = 0.48 + (macro - 0.5) * 0.24 + (mid - 0.5) * 0.16 + (pore - 0.5) * 0.18 + microRidge;
      const byte = Math.min(255, Math.max(0, Math.round(roughnessVal * 255)));
      const idx = (y * size + x) * 4;
      data[idx] = byte;
      data[idx + 1] = byte;
      data[idx + 2] = byte;
      data[idx + 3] = 255;
    }
  }

  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
  texture.name = 'titan-skin-roughness-pbr';
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.colorSpace = THREE.NoColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Generates a periodic 2D dermal + subtle fiber micro-normal map.
 */
export function createSkinMicroNormalTexture(size = 256): THREE.DataTexture {
  const heights = new Float32Array(size * size);
  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) {
      const u = x / size;
      const poreRaw = periodicValueNoise(u, v, 82, 5.2);
      const poreDimple = -Math.pow(Math.max(0, poreRaw - 0.56) / 0.44, 1.75) * 0.66;
      const grain = periodicValueNoise(u, v, 32, 13.7) * 0.44;
      const striation = Math.sin((u * 16 + periodicValueNoise(u, v, 8, 3.1) * 0.7) * Math.PI * 2) * 0.22;
      const cleavage = Math.sin((u * 12 + v * 8 + grain * 0.6) * Math.PI * 2) * 0.16;
      heights[y * size + x] = poreDimple + grain + striation + cleavage;
    }
  }

  const data = new Uint8Array(size * size * 4);
  const strength = 3.45;
  for (let y = 0; y < size; y += 1) {
    const ym = (y - 1 + size) % size;
    const yp = (y + 1) % size;
    for (let x = 0; x < size; x += 1) {
      const xm = (x - 1 + size) % size;
      const xp = (x + 1) % size;

      const dhdu = (heights[y * size + xp]! - heights[y * size + xm]!) * strength;
      const dhdv = (heights[yp * size + x]! - heights[ym * size + x]!) * strength;
      let nx = -dhdu;
      let ny = -dhdv;
      let nz = 1;
      const len = Math.hypot(nx, ny, nz) || 1;
      nx /= len;
      ny /= len;
      nz /= len;

      const idx = (y * size + x) * 4;
      data[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      data[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[idx + 3] = 255;
    }
  }

  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
  texture.name = 'titan-skin-micro-normal-pbr';
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.colorSpace = THREE.NoColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Human Atlas-inspired 16x1 GPU state texture encoding per-muscle flags:
 * R = primary, G = secondary, B = selected, A = active.
 */
export function createAnatomyStateDataTexture(): THREE.DataTexture {
  const data = new Uint8Array(16 * 4);
  const texture = new THREE.DataTexture(data, 16, 1, THREE.RGBAFormat, THREE.UnsignedByteType);
  texture.name = 'titan-anatomy-state-lut';
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.colorSpace = THREE.NoColorSpace;
  texture.needsUpdate = true;
  return texture;
}
