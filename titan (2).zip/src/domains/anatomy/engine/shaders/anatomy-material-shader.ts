import type * as THREE from 'three';

export interface AnatomyShaderUniforms {
  uActiveMusclesMask: { value: number };
  uPrimaryMusclesMask: { value: number };
  uSecondaryMusclesMask: { value: number };
  uSelectedMuscleIndex: { value: number };
  uSelectedMuscleSide: { value: number };
  uSelectedSideAny: { value: number };
  uHasSelection: { value: number };
  uMuscleRestingColor: { value: THREE.Color };
  uMuscleDimmedColor: { value: THREE.Color };
  uMusclePrimaryColor: { value: THREE.Color };
  uMuscleSecondaryColor: { value: THREE.Color };
  uMuscleSelectedColor: { value: THREE.Color };
  uSweepY: { value: number };
  uHologramMode: { value: number };
  uHologramTint: { value: THREE.Color };
  uHologramAccent: { value: THREE.Color };
  uScanPhase?: { value: number };
  uTime?: { value: number };
  uBodyRole?: { value: number }; // 0 = current, 1 = goal
  uBacklightOrigin?: { value: THREE.Vector3 };
}

type AnatomyMaterialRole = 'body' | 'muscle';

function replaceShaderChunk(source: string, chunkName: string, replacement: string, stage: 'vertex' | 'fragment'): string {
  const token = `#include <${chunkName}>`;
  const occurrences = source.split(token).length - 1;
  if (occurrences !== 1) {
    throw new Error(`TITAN anatomy shader patch expected exactly one ${stage} <${chunkName}> chunk; found ${occurrences}`);
  }
  return source.replace(token, replacement);
}

/**
 * Adds anatomy-specific PBR + SSS wrap + holographic character shading to Three.js MeshStandardMaterial.
 * Preserves workout primary/secondary highlights when a muscle is manually selected by layering
 * the selection contour additively instead of dimming or overwriting workout colors.
 */
export function applyAnatomyMaterialEnhancements(
  material: THREE.MeshStandardMaterial,
  uniforms: AnatomyShaderUniforms,
  role: AnatomyMaterialRole,
): void {
  const scanPhase = uniforms.uScanPhase ?? { value: 0 };
  const timeUniform = uniforms.uTime ?? { value: 0 };
  const bodyRole = uniforms.uBodyRole ?? { value: 0 };
  const backlightOrigin = uniforms.uBacklightOrigin ?? {
    value: { x: 0, y: 0.14, z: -0.65 } as unknown as THREE.Vector3,
  };

  material.onBeforeCompile = (shader) => {
    shader.uniforms.uSweepY = uniforms.uSweepY;
    shader.uniforms.uHologramMode = uniforms.uHologramMode;
    shader.uniforms.uHologramTint = uniforms.uHologramTint;
    shader.uniforms.uHologramAccent = uniforms.uHologramAccent;
    shader.uniforms.uScanPhase = scanPhase;
    shader.uniforms.uTime = timeUniform;
    shader.uniforms.uBodyRole = bodyRole;
    shader.uniforms.uBacklightOrigin = backlightOrigin;

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'common',
      `#include <common>
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;
${role === 'muscle' ? `
attribute float aMuscleId;
attribute float aMuscleSide;
uniform int uActiveMusclesMask;
uniform int uPrimaryMusclesMask;
uniform int uSecondaryMusclesMask;
uniform int uSelectedMuscleIndex;
uniform float uSelectedMuscleSide;
uniform float uSelectedSideAny;
uniform float uHasSelection;
uniform vec3 uMuscleRestingColor;
uniform vec3 uMuscleDimmedColor;
uniform vec3 uMusclePrimaryColor;
uniform vec3 uMuscleSecondaryColor;
uniform vec3 uMuscleSelectedColor;
varying vec3 vMuscleColor;
varying float vMuscleActive;
varying float vMuscleSelected;
varying float vMusclePrimary;
varying float vMuscleSecondary;
varying float vIsMuscleZone;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'begin_vertex',
      `#include <begin_vertex>
${role === 'muscle' ? `
int titanMuscleId = int(aMuscleId + 0.5);
float titanIsActive = float((uActiveMusclesMask >> titanMuscleId) & 1);
float titanIsPrimary = float((uPrimaryMusclesMask >> titanMuscleId) & 1);
float titanIsSecondary = float((uSecondaryMusclesMask >> titanMuscleId) & 1);
float titanIsSelected = (titanMuscleId > 0 && titanMuscleId == uSelectedMuscleIndex) ? 1.0 : 0.0;
float titanSideMatch = 1.0 - step(0.5, abs(aMuscleSide - uSelectedMuscleSide));
titanSideMatch = mix(titanSideMatch, 1.0, uSelectedSideAny);
titanIsSelected *= titanSideMatch * uHasSelection;
vec3 titanWorkoutColor = mix(uMuscleRestingColor, uMuscleSecondaryColor, titanIsSecondary);
titanWorkoutColor = mix(titanWorkoutColor, uMusclePrimaryColor, titanIsPrimary);
// Selection never erases workout colors: workout highlight remains primary/secondary,
// while selection adds a dedicated contour & rim highlight in the fragment stage.
vMuscleColor = titanWorkoutColor;
vMuscleActive = max(titanIsPrimary, titanIsSecondary);
vMuscleSelected = titanIsSelected;
vMusclePrimary = titanIsPrimary;
vMuscleSecondary = titanIsSecondary;
vIsMuscleZone = titanMuscleId > 0 ? 1.0 : 0.0;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'project_vertex',
      `vec4 titanWorldPos4 = modelMatrix * vec4(transformed, 1.0);
vAnatomyWorldY = titanWorldPos4.y;
vAnatomyWorldPos = titanWorldPos4.xyz;
vAnatomyWorldNormal = normalize(mat3(modelMatrix) * objectNormal);
#include <project_vertex>`,
      'vertex',
    );

    if (role === 'muscle') {
      shader.uniforms.uActiveMusclesMask = uniforms.uActiveMusclesMask;
      shader.uniforms.uPrimaryMusclesMask = uniforms.uPrimaryMusclesMask;
      shader.uniforms.uSecondaryMusclesMask = uniforms.uSecondaryMusclesMask;
      shader.uniforms.uSelectedMuscleIndex = uniforms.uSelectedMuscleIndex;
      shader.uniforms.uSelectedMuscleSide = uniforms.uSelectedMuscleSide;
      shader.uniforms.uSelectedSideAny = uniforms.uSelectedSideAny;
      shader.uniforms.uHasSelection = uniforms.uHasSelection;
      shader.uniforms.uMuscleRestingColor = uniforms.uMuscleRestingColor;
      shader.uniforms.uMuscleDimmedColor = uniforms.uMuscleDimmedColor;
      shader.uniforms.uMusclePrimaryColor = uniforms.uMusclePrimaryColor;
      shader.uniforms.uMuscleSecondaryColor = uniforms.uMuscleSecondaryColor;
      shader.uniforms.uMuscleSelectedColor = uniforms.uMuscleSelectedColor;

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>
uniform float uSweepY;
uniform float uHologramMode;
uniform vec3 uHologramTint;
uniform vec3 uHologramAccent;
uniform vec3 uMuscleSelectedColor;
uniform float uScanPhase;
uniform float uTime;
uniform float uBodyRole;
uniform vec3 uBacklightOrigin;
varying vec3 vMuscleColor;
varying float vMuscleActive;
varying float vMuscleSelected;
varying float vMusclePrimary;
varying float vMuscleSecondary;
varying float vIsMuscleZone;
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>
float titanSweepGate = smoothstep(-0.08, 0.02, uSweepY) * (1.0 - smoothstep(1.82, 1.92, uSweepY));
float titanSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 10.0, 2.0)) * titanSweepGate;
vec3 titanNormalW = normalize(vAnatomyWorldNormal);
vec3 titanNormalStep = fwidth(titanNormalW);
float titanPosStep = max(0.0011, length(fwidth(vAnatomyWorldPos)));
float titanCurvature = smoothstep(0.06, 0.84, clamp(length(titanNormalStep) / titanPosStep * 0.056, 0.0, 1.0));
float titanCavityAO = mix(0.30, 1.16, 1.0 - titanCurvature * 0.78);
vec3 titanKeyDir = normalize(vec3(-0.56, 0.70, 0.44));
float titanRawDot = dot(titanNormalW, titanKeyDir);
float titanKeyNdotL = clamp(titanRawDot * 0.5 + 0.5, 0.0, 1.0);
// Penner pre-integrated wrap lighting + studio ridge catchlight & hemoglobin subsurface scatter
float titanWrapDiffuse = clamp((titanRawDot + 0.36) / 1.36, 0.0, 1.0);
float titanTerminatorSSS = pow(clamp(1.0 - abs(titanRawDot - 0.06), 0.0, 1.0), 2.3);
float titanChiaroscuro = mix(0.32, 1.38, pow(titanWrapDiffuse, 1.48));
float titanRidgeCatch = pow(max(dot(titanNormalW, normalize(vec3(0.46, 0.54, -0.70))), 0.0), 3.6) * 0.34;
float titanGroundAO = mix(0.68, 1.08, smoothstep(0.03, 0.88, vAnatomyWorldY));
// Feather linear vertex muscle masks into organic anatomical bellies and fascial septa
float titanSmoothActive = smoothstep(0.14, 0.86, vMuscleActive);
float titanSmoothZone = smoothstep(0.16, 0.84, vIsMuscleZone);
float titanMaskEdge = clamp((abs(dFdx(vMuscleActive)) + abs(dFdy(vMuscleActive))) * 1.15, 0.0, 1.0);
float titanZoneEdge = clamp((abs(dFdx(vIsMuscleZone)) + abs(dFdy(vIsMuscleZone))) * 0.95, 0.0, 1.0);
float titanFasciaSeptum = exp(-pow((titanSmoothActive - 0.50) * 4.4, 2.0)) * 0.30 + exp(-pow((titanSmoothZone - 0.50) * 4.6, 2.0)) * 0.22;
// Longitudinal myofibril striation relief localized strictly to anatomical muscle zones
float titanFiberMicro = sin(vAnatomyWorldY * 275.0 + vAnatomyWorldPos.x * 118.0) * 0.052 * titanSmoothZone;
vec3 titanSkinBase = diffuseColor.rgb;
float titanMuscleRestBlend = titanSmoothZone * 0.34;
vec3 titanDermalSSS = vec3(0.105, 0.028, 0.018) * titanTerminatorSSS * mix(1.0, 0.55, uHologramMode);
vec3 titanSculptedBase = mix(
  titanSkinBase * (0.60 - titanMuscleRestBlend * 0.36) * titanCavityAO * titanChiaroscuro * titanGroundAO + titanDermalSSS + uHologramTint * (0.024 * titanKeyNdotL + titanRidgeCatch * 0.055),
  vMuscleColor * (1.0 + titanFiberMicro) * titanCavityAO * mix(0.62, 1.28, pow(titanWrapDiffuse, 1.20)),
  titanSmoothActive * 0.96
);
diffuseColor.rgb = titanSculptedBase * (1.0 - titanMaskEdge * 0.24 - titanZoneEdge * 0.14 - titanFasciaSeptum) + vec3(0.020, 0.017, 0.013) * titanSweep;
if (uHologramMode > 0.5) {
  float titanMuscleLift = mix(0.68, 1.16, titanSmoothActive);
  vec3 titanObsidianHolo = diffuseColor.rgb * mix(0.56, 0.42, titanSmoothZone) * titanCavityAO * titanChiaroscuro * titanGroundAO + uHologramTint * (0.026 + 0.054 * titanWrapDiffuse + 0.044 * titanSmoothZone * titanWrapDiffuse + titanRidgeCatch * 0.09);
  vec3 titanHoloSurface = mix(
    titanObsidianHolo,
    vMuscleColor * (1.0 + titanFiberMicro * 1.5) * titanMuscleLift * titanCavityAO * mix(0.66, 1.28, titanWrapDiffuse) + uHologramTint * (0.036 * titanWrapDiffuse),
    titanSmoothActive
  );
  diffuseColor.rgb = titanHoloSurface * (1.0 - titanMaskEdge * 0.20 - titanFasciaSeptum * 0.78);
}
`,
        'fragment',
      );

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>
vec3 titanViewDir = normalize(vViewPosition);
vec3 titanNormal = normalize(normal);
float titanNdotV = max(dot(titanNormal, titanViewDir), 0.0);
float titanHoloCoreRim = pow(1.0 - titanNdotV, 2.05);
float titanHoloFresnel = pow(1.0 - titanNdotV, 3.15);
float titanHoloSharpRim = pow(1.0 - titanNdotV, 5.2);
vec3 titanBackDir = normalize(uBacklightOrigin - vAnatomyWorldPos);
float titanBackWrap = pow(clamp(dot(titanViewDir, -titanBackDir + vAnatomyWorldNormal * 0.48), 0.0, 1.0), 2.3);
float titanLowerProximity = exp(-max(0.0, vAnatomyWorldY) * 0.95);
float titanRimDirectional = 0.48 + 0.52 * smoothstep(-0.35, 0.78, dot(normalize(vAnatomyWorldNormal), normalize(vec3(0.45, 0.48, -0.75))));
float titanDepthAtten = mix(0.72, 1.16, smoothstep(0.10, 1.45, vAnatomyWorldY));
float titanSmoothActiveE = smoothstep(0.14, 0.86, vMuscleActive);
float titanSmoothPrimaryE = smoothstep(0.16, 0.84, vMusclePrimary);
float titanSmoothSecondaryE = smoothstep(0.16, 0.84, vMuscleSecondary);
vec3 titanBioSSS = mix(uHologramTint, uHologramAccent, 0.34) * titanBackWrap * (0.088 + titanLowerProximity * 0.165);
vec3 titanDermalBounce = vec3(0.068, 0.025, 0.018) * pow(1.0 - titanNdotV, 2.3) * (1.0 - uHologramMode) * 0.42;
vec3 titanSSS = titanBioSSS + titanDermalBounce;
totalEmissiveRadiance += titanSSS;
if (uHologramMode > 0.5) {
  float titanScanCoord = vAnatomyWorldY * 360.0 - uTime * 1.55 + uScanPhase;
  float titanHoloScanSignal = 0.5 + 0.5 * cos(titanScanCoord);
  float titanHoloBand = pow(titanHoloScanSignal, 15.0);
  float titanTopoLine = pow(0.5 + 0.5 * cos(vAnatomyWorldPos.x * 210.0 + vAnatomyWorldPos.z * 88.0), 20.0);
  float titanScanWave = pow(0.5 + 0.5 * cos(vAnatomyWorldY * 5.2 - uTime * 0.85 + uScanPhase), 16.0);
  float titanEdgeGate = 0.08 + 0.92 * smoothstep(0.10, 0.68, titanHoloCoreRim);
  float titanHoloScan = (titanHoloBand * 0.46 + titanTopoLine * 0.32 + titanScanWave * 0.22) * titanEdgeGate;
  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 26.0, 2.0));
  vec3 titanHoloBaseEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.22, 0.86, titanHoloFresnel));
  vec3 titanLineColor = mix(uHologramTint * 1.12, vMuscleColor, titanSmoothActiveE * 0.78);
  float titanFasciaGlow = exp(-pow((titanSmoothActiveE - 0.52) * 4.5, 2.0)) * titanSmoothActiveE;
  vec3 titanWorkoutGlow = vMuscleColor * (
    titanSmoothPrimaryE * (0.34 + titanHoloCoreRim * 0.72) +
    titanSmoothSecondaryE * (0.22 + titanHoloCoreRim * 0.52) +
    titanFasciaGlow * 0.28
  );
  vec3 titanHoloEdge = mix(titanHoloBaseEdge, vMuscleColor, titanSmoothActiveE * 0.62);
  float titanRoleRimBoost = mix(0.84, 1.02, uBodyRole);
  totalEmissiveRadiance += titanHoloEdge * (
    titanHoloCoreRim * 0.072 +
    titanHoloFresnel * titanRoleRimBoost * titanRimDirectional * titanDepthAtten +
    titanHoloSharpRim * 0.74 * titanRimDirectional +
    titanHoloSweep * 0.58
  ) + titanLineColor * (titanHoloScan * (0.20 + titanSmoothActiveE * 0.16))
    + titanWorkoutGlow;
  // Selection adds a crisp champagne/white contour without erasing primary/secondary workout colors.
  float titanSelectionContour = smoothstep(0.16, 0.84, titanHoloFresnel) * 1.38 + 0.24;
  totalEmissiveRadiance += uMuscleSelectedColor * (smoothstep(0.18, 0.82, vMuscleSelected) * titanSelectionContour);
}`,
        'fragment',
      );
    } else {
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>
uniform float uHologramMode;
uniform float uSweepY;
uniform vec3 uHologramTint;
uniform vec3 uHologramAccent;
uniform float uScanPhase;
uniform float uTime;
uniform float uBodyRole;
uniform vec3 uBacklightOrigin;
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>
vec3 titanNormalW = normalize(vAnatomyWorldNormal);
vec3 titanNormalStep = fwidth(titanNormalW);
float titanPosStep = max(0.0011, length(fwidth(vAnatomyWorldPos)));
float titanCurvature = smoothstep(0.06, 0.84, clamp(length(titanNormalStep) / titanPosStep * 0.056, 0.0, 1.0));
float titanCavityAO = mix(0.30, 1.16, 1.0 - titanCurvature * 0.78);
vec3 titanKeyDir = normalize(vec3(-0.56, 0.70, 0.44));
float titanRawDot = dot(titanNormalW, titanKeyDir);
float titanKeyNdotL = clamp(titanRawDot * 0.5 + 0.5, 0.0, 1.0);
float titanWrapDiffuse = clamp((titanRawDot + 0.36) / 1.36, 0.0, 1.0);
float titanTerminatorSSS = pow(clamp(1.0 - abs(titanRawDot - 0.06), 0.0, 1.0), 2.3);
float titanChiaroscuro = mix(0.32, 1.38, pow(titanWrapDiffuse, 1.48));
float titanRidgeCatch = pow(max(dot(titanNormalW, normalize(vec3(0.46, 0.54, -0.70))), 0.0), 3.6) * 0.34;
float titanGroundAO = mix(0.68, 1.08, smoothstep(0.03, 0.88, vAnatomyWorldY));
if (uHologramMode > 0.5) {
  vec3 titanHoloSurface = diffuseColor.rgb * 0.48 * titanCavityAO * titanChiaroscuro * titanGroundAO + uHologramTint * (0.024 + 0.050 * titanWrapDiffuse + titanRidgeCatch * 0.08);
  diffuseColor.rgb = titanHoloSurface;
} else {
  diffuseColor.rgb = diffuseColor.rgb * titanCavityAO * titanChiaroscuro * titanGroundAO + vec3(0.105, 0.028, 0.018) * titanTerminatorSSS;
}`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>
vec3 titanViewDir = normalize(vViewPosition);
vec3 titanNormal = normalize(normal);
float titanNdotV = max(dot(titanNormal, titanViewDir), 0.0);
float titanHoloCoreRim = pow(1.0 - titanNdotV, 2.05);
float titanHoloFresnel = pow(1.0 - titanNdotV, 3.15);
float titanHoloSharpRim = pow(1.0 - titanNdotV, 5.2);
vec3 titanBackDir = normalize(uBacklightOrigin - vAnatomyWorldPos);
float titanBackWrap = pow(clamp(dot(titanViewDir, -titanBackDir + vAnatomyWorldNormal * 0.48), 0.0, 1.0), 2.3);
float titanLowerProximity = exp(-max(0.0, vAnatomyWorldY) * 0.95);
float titanRimDirectional = 0.48 + 0.52 * smoothstep(-0.35, 0.78, dot(normalize(vAnatomyWorldNormal), normalize(vec3(0.45, 0.48, -0.75))));
float titanDepthAtten = mix(0.72, 1.16, smoothstep(0.10, 1.45, vAnatomyWorldY));
totalEmissiveRadiance += mix(uHologramTint, uHologramAccent, 0.34) * titanBackWrap * (0.088 + titanLowerProximity * 0.165);
if (uHologramMode > 0.5) {
  float titanScanCoord = vAnatomyWorldY * 360.0 - uTime * 1.55 + uScanPhase;
  float titanHoloScanSignal = 0.5 + 0.5 * cos(titanScanCoord);
  float titanHoloBand = pow(titanHoloScanSignal, 15.0);
  float titanTopoLine = pow(0.5 + 0.5 * cos(vAnatomyWorldPos.x * 210.0 + vAnatomyWorldPos.z * 88.0), 20.0);
  float titanScanWave = pow(0.5 + 0.5 * cos(vAnatomyWorldY * 5.2 - uTime * 0.85 + uScanPhase), 16.0);
  float titanEdgeGate = 0.08 + 0.92 * smoothstep(0.10, 0.68, titanHoloCoreRim);
  float titanHoloScan = (titanHoloBand * 0.46 + titanTopoLine * 0.32 + titanScanWave * 0.22) * titanEdgeGate;
  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 26.0, 2.0));
  vec3 titanHoloEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.22, 0.86, titanHoloFresnel));
  float titanRoleRimBoost = mix(0.84, 1.02, uBodyRole);
  totalEmissiveRadiance += titanHoloEdge * (
    titanHoloCoreRim * 0.072 +
    titanHoloFresnel * titanRoleRimBoost * titanRimDirectional * titanDepthAtten +
    titanHoloSharpRim * 0.70 * titanRimDirectional +
    titanHoloSweep * 0.54
  ) + uHologramTint * (titanHoloScan * 0.20);
}`,
        'fragment',
      );
    }
  };

  material.customProgramCacheKey = () => `titan-anatomy-${role}-pbr-v11.3-single-pass-worldy`;
}
