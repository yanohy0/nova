import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type {
  MuscleGroupId,
  MuscleHighlightPayload,
  MuscleSide,
} from '@/src/shared/types/common';
import {
  computeBodyIdentitySignature,
  createDefaultDualBodyInput,
  type BodyComparisonMode,
  type DualBodyInput,
} from '../../domain/body-identity';
import type { AnatomicalView } from '../../mapping/muscle-registry';
import {
  computeActiveMusclesMask,
  MUSCLE_ID_TO_SHADER_INDEX,
} from '../../mapping/anatomy-identifiers';
import type { AnatomyLayerMode, FocusRegion } from '../../state/anatomy.store';
import { getAnatomyCameraPreset } from '../camera/anatomy-camera';
import { detectSoftwareWebGL } from '../lifecycle/webgl-guard';
import {
  createAnatomyMaterials,
  type AnatomyMaterialSet,
  type AnatomyShaderUniforms,
} from '../materials/anatomy-materials';
import { buildAnatomyBody, type AnatomyBodyRig } from '../scene/build-anatomy-body';
import { MusclePicker } from '../picking/muscle-picking';
import { DualBodyCompositor } from './dual-body-compositor';

export interface AnatomyEngineCallbacks {
  onStatusChange: (status: 'initializing' | 'ready' | 'fallback') => void;
  onMusclePick: (muscleId: MuscleGroupId, side: MuscleSide) => void;
}

export interface AnatomyVisualInput {
  selectedMuscleId: MuscleGroupId | null;
  selectedMuscleSide: MuscleSide | null;
  workoutHighlights: MuscleHighlightPayload;
  cameraView: AnatomicalView;
  focusRegion: FocusRegion;
  layerMode: AnatomyLayerMode;
  zoomScale: number;
  hologramMode: boolean;
  dualBody?: DualBodyInput;
  comparisonMode?: BodyComparisonMode;
}

export interface AnatomyPerformanceSnapshot {
  drawCalls: number;
  triangles: number;
  geometries: number;
  textures: number;
  pixelRatio: number;
}

export class AnatomyRendererController {
  private renderer: THREE.WebGLRenderer | null = null;
  private controls: OrbitControls | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  // Heavy geometry/material construction is deferred until the actual WebGL2 renderer exists.
  // Unsupported browsers and offscreen viewers never pay the anatomy build cost.
  private materials: AnatomyMaterialSet | null = null;
  private bodyRig: AnatomyBodyRig | null = null;
  private goalBodyRig: AnatomyBodyRig | null = null;
  private compositor: DualBodyCompositor | null = null;
  private environmentTarget: THREE.WebGLRenderTarget | null = null;
  private readonly musclePicker = new MusclePicker();
  private pointerDown: { x: number; y: number; pointerId: number } | null = null;
  private emitterResources: Array<{ dispose: () => void }> = [];
  private backdropObjects: THREE.Object3D[] = [];
  private backlightHalo: THREE.Mesh | null = null;
  private rearEmitterCircle: THREE.Mesh | null = null;
  private volumetricBeam: THREE.Mesh | null = null;
  private rearBelowLight: THREE.SpotLight | null = null;
  private readonly emitterTimeUniform = { value: 0 };
  private readonly floorEmitterCenterUniform = { value: new THREE.Vector2(0, -0.34) };
  private readonly floorLightDirUniform = { value: new THREE.Vector2(0, 1) };
  private lastAmbientTickAt = 0;
  private resizeObserver: ResizeObserver | null = null;
  private intersectionObserver: IntersectionObserver | null = null;

  private isSoftwareGl = false;
  private isTouchDevice = false;
  private isVisible = true;
  private pageVisible = typeof document === 'undefined' || !document.hidden;
  private contextLost = false;
  private contextGeneration = 0;
  private shaderPreparationPending = false;
  private prefersReducedMotion = false;
  private motionQuery: MediaQueryList | null = null;
  private lastCameraKey = '';
  private lastWidth = 0;
  private lastHeight = 0;
  private lastPixelRatio = 0;
  private lastSelectionKey = '';
  private lastCurrentSignature = '';
  private lastGoalSignature = '';
  private comparisonMode: BodyComparisonMode = 'dual';
  private isInteracting = false;
  private interactionRestoreTimer = 0;
  private selectionSweepStartedAt = 0;
  private rafId = 0;
  private renderDirty = false;
  private disposed = false;
  private mountStarted = false;
  private initializationAttempted = false;
  private pendingVisualInput: AnatomyVisualInput | null = null;
  private cameraTransition: {
    startedAt: number;
    durationMs: number;
    fromPos: THREE.Vector3;
    toPos: THREE.Vector3;
    fromTarget: THREE.Vector3;
    toTarget: THREE.Vector3;
  } | null = null;

  constructor(
    private readonly container: HTMLElement,
    private readonly callbacks: AnatomyEngineCallbacks,
  ) {
    this.scene = new THREE.Scene();
    this.scene.background = null;

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(35, width / height, 0.1, 40);
    const preset = getAnatomyCameraPreset('frontal', 'full', 1);
    this.camera.position.copy(preset.position);
    this.camera.lookAt(preset.target);
  }

  mount(): boolean {
    if (this.disposed || this.mountStarted) return false;
    this.mountStarted = true;
    this.callbacks.onStatusChange('initializing');
    document.addEventListener('visibilitychange', this.handleDocumentVisibilityChange);
    if (typeof IntersectionObserver === 'undefined') {
      this.isVisible = true;
      this.initializeRenderer();
      return true;
    }

    this.isVisible = false;
    this.intersectionObserver = new IntersectionObserver(
      (entries) => {
        const nextVisible = entries[0]?.isIntersecting ?? false;
        const becameVisible = !this.isVisible && nextVisible;
        this.isVisible = nextVisible;
        if (!nextVisible) {
          cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          return;
        }
        if (this.pageVisible && becameVisible) {
          if (!this.renderer) this.initializeRenderer();
          else this.requestRender();
        }
      },
      { rootMargin: '120px 0px', threshold: 0.01 },
    );
    this.intersectionObserver.observe(this.container);
    return true;
  }

  private initializeRenderer(): void {
    if (
      this.disposed ||
      this.initializationAttempted ||
      this.renderer ||
      !this.isVisible ||
      !this.pageVisible
    ) return;
    this.initializationAttempted = true;

    this.isTouchDevice = window.matchMedia('(pointer: coarse)').matches;
    this.motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    this.prefersReducedMotion = this.motionQuery.matches;
    this.motionQuery.addEventListener('change', this.handleMotionPreferenceChange);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !this.isTouchDevice,
        powerPreference: 'high-performance',
        alpha: true,
        depth: true,
        stencil: false,
        preserveDrawingBuffer: false,
      });
    } catch {
      this.releaseViewportObservers();
      this.callbacks.onStatusChange('fallback');
      return;
    }
    this.isSoftwareGl = detectSoftwareWebGL(renderer.getContext());

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.setClearColor(0x000000, 0);

    this.lastWidth = Math.max(1, this.container.clientWidth);
    this.lastHeight = Math.max(1, this.container.clientHeight);
    this.lastPixelRatio = this.getEffectivePixelRatio(this.lastWidth, this.lastHeight);
    renderer.setPixelRatio(this.lastPixelRatio);
    renderer.setSize(this.lastWidth, this.lastHeight);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.touchAction = 'pan-y';
    renderer.domElement.style.pointerEvents = 'auto';
    renderer.domElement.style.cursor = 'grab';
    renderer.domElement.setAttribute(
      'aria-label',
      'Modelo anatômico tridimensional interativo com comparação entre físico atual e meta. Arraste para girar e toque em um músculo para selecionar.',
    );

    const initialDual = this.pendingVisualInput?.dualBody ?? createDefaultDualBodyInput();
    this.lastCurrentSignature = computeBodyIdentitySignature(initialDual.current);
    this.lastGoalSignature = computeBodyIdentitySignature(initialDual.goal);
    const lod = this.isTouchDevice || this.isSoftwareGl ? 'mid' : 'high';

    try {
      const maxAniso = this.isSoftwareGl ? 1 : Math.min(4, renderer.capabilities.getMaxAnisotropy());
      const materials = createAnatomyMaterials(maxAniso);
      this.materials = materials;
      this.bodyRig = buildAnatomyBody(materials, {
        role: 'current',
        identity: initialDual.current,
        lod,
      });
      this.goalBodyRig = buildAnatomyBody(materials, {
        role: 'goal',
        identity: initialDual.goal,
        lod,
      });
    } catch {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
      return;
    }

    const bodyRig = this.bodyRig;
    const goalBodyRig = this.goalBodyRig;
    if (!bodyRig || !goalBodyRig) {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
      return;
    }

    try {
      this.compositor = new DualBodyCompositor(
        this.lastWidth,
        this.lastHeight,
        this.lastPixelRatio,
      );
    } catch {
      this.compositor = null;
    }

    this.container.appendChild(renderer.domElement);
    this.renderer = renderer;

    this.buildStudioLighting();
    try {
      this.buildStudioEnvironment(renderer);
    } catch {
      this.scene.environment = null;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
    }

    const controls = new OrbitControls(this.camera, renderer.domElement);
    controls.target.set(0, 0.82, 0);
    controls.enableRotate = true;
    controls.enableZoom = false;
    controls.enablePan = false;
    controls.minPolarAngle = Math.PI * 0.40;
    controls.maxPolarAngle = Math.PI * 0.51;
    controls.enableDamping = !this.isSoftwareGl && !this.prefersReducedMotion;
    controls.dampingFactor = 0.065;
    controls.rotateSpeed = 0.72;
    controls.update();
    renderer.domElement.style.touchAction = 'pan-y';
    controls.addEventListener('start', this.handleControlsStart);
    controls.addEventListener('change', this.handleControlsChange);
    this.controls = controls;

    this.buildProjectorPlinth();
    // Both bodies occupy exact same center, axis, pose, and scale (zero displacement).
    this.scene.add(bodyRig.root);
    this.scene.add(goalBodyRig.root);

    this.bindEvents(renderer.domElement);

    const pendingVisualInput = this.pendingVisualInput;
    this.pendingVisualInput = null;
    if (pendingVisualInput) this.syncVisualState(pendingVisualInput);

    this.shaderPreparationPending = true;
    const compileGeneration = this.contextGeneration;
    void renderer.compileAsync(this.scene, this.camera).then(() => {
      if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
      this.shaderPreparationPending = false;
      if (this.contextLost) return;
      this.callbacks.onStatusChange('ready');
      this.requestRender();
    }).catch(() => {
      if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
    });
  }

  /** Release page/viewport listeners whether or not a WebGL context was created. */
  private releaseViewportObservers(): void {
    window.removeEventListener('resize', this.handleResize);
    document.removeEventListener('visibilitychange', this.handleDocumentVisibilityChange);
    this.motionQuery?.removeEventListener('change', this.handleMotionPreferenceChange);
    this.motionQuery = null;
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    this.intersectionObserver?.disconnect();
    this.intersectionObserver = null;
  }

  /** Release every resource after an unrecoverable WebGL or shader failure. */
  private releaseRendererToFallback(renderer: THREE.WebGLRenderer): void {
    cancelAnimationFrame(this.rafId);
    window.clearTimeout(this.interactionRestoreTimer);
    this.rafId = 0;
    this.renderDirty = false;
    this.shaderPreparationPending = false;
    this.contextLost = false;
    this.pointerDown = null;
    this.pendingVisualInput = null;

    if (this.controls) {
      this.controls.removeEventListener('start', this.handleControlsStart);
      this.controls.removeEventListener('change', this.handleControlsChange);
      this.controls.dispose();
      this.controls = null;
    }

    this.releaseViewportObservers();

    const canvas = renderer.domElement;
    canvas.removeEventListener('webglcontextlost', this.handleContextLost);
    canvas.removeEventListener('pointerdown', this.handlePointerDown);
    canvas.removeEventListener('pointerup', this.handlePointerUp);
    canvas.removeEventListener('pointercancel', this.handlePointerCancel);
    canvas.removeEventListener('webglcontextrestored', this.handleContextRestored);
    if (canvas.parentElement === this.container) this.container.removeChild(canvas);

    if (this.bodyRig) this.bodyRig.dispose();
    this.bodyRig = null;
    if (this.goalBodyRig) this.goalBodyRig.dispose();
    this.goalBodyRig = null;
    if (this.compositor) this.compositor.dispose();
    this.compositor = null;
    if (this.materials) this.materials.dispose();
    this.materials = null;
    this.emitterResources.forEach((resource) => resource.dispose());
    this.emitterResources = [];
    this.backdropObjects = [];
    this.backlightHalo = null;
    this.rearEmitterCircle = null;
    this.volumetricBeam = null;
    this.rearBelowLight = null;

    this.scene.environment = null;
    this.environmentTarget?.dispose();
    this.environmentTarget = null;
    this.scene.clear();

    if (this.renderer === renderer) this.renderer = null;
    renderer.dispose();
    renderer.forceContextLoss();
  }

  private getEffectivePixelRatio(width: number, height: number): number {
    const deviceRatio = Math.max(0.1, window.devicePixelRatio || 1);
    const maxRatio = this.isSoftwareGl ? 1 : this.isTouchDevice ? 1.35 : 1.55;
    const pixelBudget = this.isSoftwareGl
      ? 520_000
      : this.isTouchDevice
        ? 1_050_000
        : 1_850_000;
    const budgetRatio = Math.sqrt(pixelBudget / Math.max(1, width * height));
    return Math.min(deviceRatio, maxRatio, budgetRatio);
  }

  private buildStudioLighting(): void {
    // Sculptural chiaroscuro anatomical lighting: crisp overhead key + restrained cool fill + raking rim/kicker separation.
    const ambient = new THREE.HemisphereLight('#C8E0E0', '#050908', 0.24);
    const key = new THREE.DirectionalLight('#FFF9EE', 3.40);
    key.position.set(-2.05, 3.55, 2.15);
    const fill = new THREE.DirectionalLight('#4B7288', 0.34);
    fill.position.set(2.75, 1.05, 1.65);
    const rim = new THREE.DirectionalLight('#9CF6F0', 1.90);
    rim.position.set(1.85, 2.45, -2.35);
    const kicker = new THREE.DirectionalLight('#E8CA94', 1.05);
    kicker.position.set(-2.15, 1.60, -2.20);

    // Upward volumetric catchlight originating below and behind the bodies.
    const rearBelowLight = new THREE.SpotLight('#6CEBE4', 2.45, 5.2, Math.PI * 0.46, 0.92, 1.6);
    rearBelowLight.position.set(0, 0.14, -0.65);
    rearBelowLight.target.position.set(0, 1.05, 0);

    this.rearBelowLight = rearBelowLight;
    this.scene.add(ambient, key, fill, rim, kicker, rearBelowLight, rearBelowLight.target);
  }

  private buildStudioEnvironment(renderer: THREE.WebGLRenderer): void {
    if (this.isSoftwareGl) return;
    const generator = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    try {
      this.environmentTarget = generator.fromScene(room, 0.04);
      this.scene.environment = this.environmentTarget.texture;
      this.scene.environmentIntensity = 0.68;
    } finally {
      room.dispose();
      generator.dispose();
    }
  }

  private buildProjectorPlinth(): void {
    // Pure volumetric studio light stage blending seamlessly into #0E1412 (zero circles or geometric rings):
    // perspective inverse-square floor pool + grazing specular floor sheen + crisp grounded forward silhouette shadow.
    const floorGeo = new THREE.PlaneGeometry(10.0, 10.0, 1, 1);
    floorGeo.rotateX(-Math.PI / 2);
    const floorMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: this.emitterTimeUniform,
        uEmitterCenter: this.floorEmitterCenterUniform,
        uLightDirXZ: this.floorLightDirUniform,
      },
      vertexShader: `
        varying vec2 vUv;
        varying vec2 vWorldXZ;
        void main() {
          vUv = uv;
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldXZ = wp.xz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec2 uEmitterCenter;
        uniform vec2 uLightDirXZ;
        varying vec2 vUv;
        varying vec2 vWorldXZ;

        void main() {
          // Strict plane-local UV radial fade so quad edges never appear
          float planeDist = length((vUv - 0.5) * 2.0);
          float planeGuard = 1.0 - smoothstep(0.42, 0.85, planeDist);
          if (planeGuard <= 0.001) discard;

          float rBody = length(vWorldXZ);
          float stageMask = (1.0 - smoothstep(1.15, 1.95, rBody)) * planeGuard;
          if (stageMask <= 0.001) discard;

          vec2 perpXZ = vec2(-uLightDirXZ.y, uLightDirXZ.x);
          vec2 fromEmitter = vWorldXZ - uEmitterCenter * 1.15;
          float dEmit = length(fromEmitter);
          float emitFwd = dot(fromEmitter, uLightDirXZ);
          float emitLat = dot(fromEmitter, perpXZ);

          // Perspective cone projection across the dark obsidian floor toward the camera
          float spreadWidth = 0.24 + max(0.0, emitFwd) * 0.44;
          float coneLat = exp(-pow(emitLat / spreadWidth, 2.0) * 1.45);
          float coneBack = smoothstep(-0.34, 0.14, emitFwd);
          float invSqFalloff = 1.0 / (1.0 + dEmit * dEmit * 2.15);
          float nearCore = exp(-dEmit * dEmit * 5.2);
          float grazingSheen = exp(-pow(emitLat / (spreadWidth * 0.72), 2.0) * 2.4) * smoothstep(-0.18, 0.22, emitFwd) * exp(-max(0.0, emitFwd) * 1.05);

          float diffusedFloorLight = (invSqFalloff * coneLat * coneBack * 0.22 + nearCore * 0.16 + grazingSheen * 0.14);

          // Grounded foot contact occlusion + crisp forward cast shadow carving silhouette depth into the light pool
          vec2 leftAnkle = vWorldXZ - perpXZ * 0.104 - uLightDirXZ * 0.025;
          vec2 rightAnkle = vWorldXZ + perpXZ * 0.104 - uLightDirXZ * 0.025;
          float footOcc = exp(-dot(leftAnkle * vec2(1.25, 0.70), leftAnkle * vec2(1.25, 0.70)) * 84.0)
                        + exp(-dot(rightAnkle * vec2(1.25, 0.70), rightAnkle * vec2(1.25, 0.70)) * 84.0);

          float fwdDist = dot(vWorldXZ, uLightDirXZ);
          float latCoord = dot(vWorldXZ, perpXZ);
          float inFront = smoothstep(-0.04, 0.12, fwdDist) * exp(-max(0.0, fwdDist) * 1.15);
          float legShadowL = exp(-pow((latCoord + mix(0.105, 0.155, clamp(fwdDist, 0.0, 1.0))) * 11.2, 2.0));
          float legShadowR = exp(-pow((latCoord - mix(0.105, 0.155, clamp(fwdDist, 0.0, 1.0))) * 11.2, 2.0));
          float torsoShadow = exp(-pow(latCoord * 4.4, 2.0)) * smoothstep(0.16, 0.45, fwdDist) * exp(-max(0.0, fwdDist - 0.35) * 1.35);
          float castShadow = inFront * clamp((legShadowL + legShadowR) * 0.56 + torsoShadow * 0.44, 0.0, 0.84);
          float shadowFactor = clamp(footOcc * 0.54 + castShadow * 0.72, 0.0, 0.88);

          vec3 lightTint = mix(
            vec3(0.24, 0.86, 0.82),
            vec3(0.46, 0.42, 0.78),
            smoothstep(0.18, 0.95, dEmit)
          );
          float lightIntensity = clamp(diffusedFloorLight * (1.0 - shadowFactor * 0.90), 0.0, 0.42);
          float shadowAlpha = shadowFactor * 0.56;
          float totalAlpha = clamp(lightIntensity + shadowAlpha * (1.0 - lightIntensity), 0.0, 0.62) * stageMask;
          if (totalAlpha <= 0.001) discard;

          vec3 shadowTint = vec3(0.006, 0.012, 0.011);
          float lightShare = lightIntensity / max(0.0001, lightIntensity + shadowAlpha);
          vec3 finalCol = mix(shadowTint, lightTint, lightShare);
          gl_FragColor = vec4(finalCol, totalAlpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.NormalBlending,
    });
    const floorStage = new THREE.Mesh(floorGeo, floorMat);
    floorStage.position.y = 0.0;
    floorStage.renderOrder = 0;
    this.scene.add(floorStage);
    this.backdropObjects.push(floorStage);
    this.emitterResources.push(floorGeo, floorMat);

    // Subtle procedural foot contact shadow grounding the stance onto the floor
    const shadowGeo = new THREE.PlaneGeometry(0.88, 0.30, 1, 1);
    const shadowMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        void main() {
          vec2 p = (vUv - 0.5) * 2.0;
          float r2 = dot(p, p);
          float broad = exp(-r2 * 4.0);
          float contact = exp(-r2 * 18.0);
          float edge = 1.0 - smoothstep(0.72, 1.0, r2);
          float alpha = (broad * 0.22 + contact * 0.30) * edge;
          vec3 shadowColor = vec3(0.006, 0.012, 0.011);
          gl_FragColor = vec4(shadowColor, alpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.NormalBlending,
    });
    const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.set(0, 0.001, 0.025);
    contactShadow.renderOrder = 1;
    this.scene.add(contactShadow);
    this.backdropObjects.push(contactShadow);
    this.emitterResources.push(shadowGeo, shadowMat);

    // Feathered Gaussian floor emitter bloom behind and below the body (zero ring lines).
    const rearCircleGeo = new THREE.PlaneGeometry(3.2, 3.2, 1, 1);
    const rearCircleMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: this.emitterTimeUniform,
        uLightDirXZ: this.floorLightDirUniform,
      },
      vertexShader: `
        varying vec2 vUv;
        varying vec2 vWorldXZ;
        void main() {
          vUv = uv;
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldXZ = wp.xz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec2 uLightDirXZ;
        varying vec2 vUv;
        varying vec2 vWorldXZ;

        void main() {
          float localDist = length((vUv - 0.5) * 2.0);
          float planeMask = 1.0 - smoothstep(0.36, 0.84, localDist);
          if (planeMask <= 0.001) discard;

          float r = length(vWorldXZ) / 1.45;
          vec2 dir = vWorldXZ / max(0.0001, length(vWorldXZ));
          float rearSide = dot(dir, -uLightDirXZ);
          float rearMask = smoothstep(-0.35, 0.42, rearSide);

          float core = exp(-r * r * 3.1) * 0.14;
          float outerCutoff = 1.0 - smoothstep(0.46, 0.94, r);
          float alpha = clamp(core * rearMask * outerCutoff * planeMask, 0.0, 0.15);
          if (alpha <= 0.002) discard;

          vec3 tint = mix(vec3(0.22, 0.80, 0.78), vec3(0.44, 0.40, 0.74), smoothstep(0.18, 0.88, r));
          gl_FragColor = vec4(tint, alpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.OneFactor,
      blendDstAlpha: THREE.OneMinusSrcAlphaFactor,
    });
    const rearEmitterCircle = new THREE.Mesh(rearCircleGeo, rearCircleMat);
    rearEmitterCircle.rotation.x = -Math.PI / 2;
    rearEmitterCircle.position.set(0, 0.004, -0.34);
    rearEmitterCircle.renderOrder = 2;
    this.scene.add(rearEmitterCircle);
    this.rearEmitterCircle = rearEmitterCircle;
    this.backdropObjects.push(rearEmitterCircle);
    this.emitterResources.push(rearCircleGeo, rearCircleMat);

    // 3D volumetric upward light cone rising behind the figures for genuine spatial stage depth
    const beamGeo = new THREE.CylinderGeometry(0.98, 0.42, 2.05, 40, 1, true);
    const beamMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: this.emitterTimeUniform,
      },
      vertexShader: `
        varying vec2 vUv;
        varying vec3 vNormalView;
        varying vec3 vViewPos;
        void main() {
          vUv = uv;
          vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
          vViewPos = -mvPos.xyz;
          vNormalView = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * mvPos;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        varying vec2 vUv;
        varying vec3 vNormalView;
        varying vec3 vViewPos;

        void main() {
          vec3 vDir = normalize(vViewPos);
          float viewEdgeFade = pow(abs(dot(normalize(vNormalView), vDir)), 1.65);
          float bottomFade = smoothstep(0.0, 0.14, vUv.y);
          float topFade = 1.0 - smoothstep(0.32, 0.96, vUv.y);
          float verticalFalloff = exp(-vUv.y * 1.85);
          float shaftWave = 0.86 + 0.14 * sin(vUv.x * 18.84955 + uTime * 0.25);

          float intensity = clamp(viewEdgeFade * bottomFade * topFade * verticalFalloff * shaftWave * 0.135, 0.0, 0.14);
          if (intensity <= 0.002) discard;

          vec3 col = mix(vec3(0.22, 0.84, 0.80), vec3(0.46, 0.42, 0.78), smoothstep(0.12, 0.78, vUv.y));
          gl_FragColor = vec4(col, intensity);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.OneFactor,
      blendDstAlpha: THREE.OneMinusSrcAlphaFactor,
    });
    const volumetricBeam = new THREE.Mesh(beamGeo, beamMat);
    volumetricBeam.position.set(0, 1.02, -0.34);
    volumetricBeam.renderOrder = -2;
    this.scene.add(volumetricBeam);
    this.volumetricBeam = volumetricBeam;
    this.backdropObjects.push(volumetricBeam);
    this.emitterResources.push(beamGeo, beamMat);

    // Wide, ultra-feathered atmospheric horizon depth gradient rising behind the stage (zero quad edges).
    const haloGeo = new THREE.PlaneGeometry(4.2, 2.4, 1, 1);
    const haloMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: this.emitterTimeUniform,
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        varying vec2 vUv;
        void main() {
          float x = (vUv.x - 0.5) * 2.0;
          float y = clamp(vUv.y, 0.0, 1.0);

          float bottomSoftFade = smoothstep(0.02, 0.22, y);
          float topSoftFade = 1.0 - smoothstep(0.40, 0.92, y);
          float sideSoftFade = 1.0 - smoothstep(0.30, 0.82, abs(x));
          float quadFade = bottomSoftFade * topSoftFade * sideSoftFade;
          if (quadFade <= 0.001) discard;

          float radial = length(vec2(x * 1.12, (y - 0.18) * 1.30));
          float dome = exp(-radial * radial * 2.75);
          float intensity = clamp(dome * 0.145 * quadFade, 0.0, 0.15);
          if (intensity <= 0.002) discard;

          vec3 glowColor = mix(vec3(0.20, 0.72, 0.70), vec3(0.44, 0.40, 0.74), smoothstep(0.14, 0.76, y));
          gl_FragColor = vec4(glowColor, intensity);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.OneFactor,
      blendDstAlpha: THREE.OneMinusSrcAlphaFactor,
    });
    const backlightHalo = new THREE.Mesh(haloGeo, haloMat);
    backlightHalo.position.set(0, 1.05, -0.58);
    backlightHalo.renderOrder = -1;
    this.scene.add(backlightHalo);
    this.backlightHalo = backlightHalo;
    this.backdropObjects.push(backlightHalo);
    this.emitterResources.push(haloGeo, haloMat);
  }

  private updateRearBelowLightTransform(): void {
    const cx = this.camera.position.x;
    const cz = this.camera.position.z;
    const len = Math.hypot(cx, cz) || 1;
    const nx = cx / len;
    const nz = cz / len;
    const yaw = Math.atan2(nx, nz);

    // Light originates below (y ~ 0.004..0.14) and behind (-nx, -nz) the 3D bodies
    if (this.rearEmitterCircle) {
      this.rearEmitterCircle.position.set(-nx * 0.34, 0.004, -nz * 0.34);
    }
    if (this.volumetricBeam) {
      this.volumetricBeam.position.set(-nx * 0.34, 1.02, -nz * 0.34);
    }
    this.floorEmitterCenterUniform.value.set(-nx * 0.34, -nz * 0.34);
    this.floorLightDirUniform.value.set(nx, nz);
    if (this.backlightHalo) {
      this.backlightHalo.position.set(-nx * 0.58, 1.05, -nz * 0.58);
      this.backlightHalo.rotation.set(0, yaw, 0);
    }
    if (this.rearBelowLight) {
      this.rearBelowLight.position.set(-nx * 0.65, 0.14, -nz * 0.65);
    }
    if (this.materials) {
      this.materials.uniforms.uBacklightOrigin?.value.set(-nx * 0.65, 0.14, -nz * 0.65);
      this.materials.goalUniforms.uBacklightOrigin?.value.set(-nx * 0.65, 0.14, -nz * 0.65);
    }
  }

  private bindEvents(canvas: HTMLCanvasElement): void {
    canvas.addEventListener('webglcontextlost', this.handleContextLost);
    canvas.addEventListener('pointerdown', this.handlePointerDown);
    canvas.addEventListener('pointerup', this.handlePointerUp);
    canvas.addEventListener('pointercancel', this.handlePointerCancel);
    canvas.addEventListener('webglcontextrestored', this.handleContextRestored);
    window.addEventListener('resize', this.handleResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.handleResize());
      this.resizeObserver.observe(this.container);
    }
  }

  private handleDocumentVisibilityChange = (): void => {
    this.pageVisible = !document.hidden;
    if (!this.pageVisible) {
      cancelAnimationFrame(this.rafId);
      this.rafId = 0;
      return;
    }
    if (this.isVisible && !this.renderer) {
      this.initializeRenderer();
      return;
    }
    this.requestRender();
  };

  private handleControlsStart = (): void => {
    this.cameraTransition = null;
    if (!this.isSoftwareGl && this.renderer && this.lastWidth > 0 && this.lastHeight > 0) {
      this.isInteracting = true;
      window.clearTimeout(this.interactionRestoreTimer);
      const interactiveDpr = Math.max(0.85, this.lastPixelRatio * 0.85);
      this.renderer.setPixelRatio(interactiveDpr);
      this.compositor?.resize(this.lastWidth, this.lastHeight, interactiveDpr);
    }
  };

  private handleControlsChange = (): void => {
    if (this.isInteracting && !this.isSoftwareGl && this.renderer) {
      window.clearTimeout(this.interactionRestoreTimer);
      this.interactionRestoreTimer = window.setTimeout(() => {
        if (this.disposed || !this.renderer || this.lastWidth <= 0 || this.lastHeight <= 0) return;
        this.isInteracting = false;
        this.renderer.setPixelRatio(this.lastPixelRatio);
        this.compositor?.resize(this.lastWidth, this.lastHeight, this.lastPixelRatio);
        this.requestRender();
      }, 130);
    }
    this.requestRender();
  };

  private handlePointerDown = (event: PointerEvent): void => {
    if (event.button !== 0) return;
    this.pointerDown = { x: event.clientX, y: event.clientY, pointerId: event.pointerId };
  };

  private handlePointerCancel = (): void => {
    this.pointerDown = null;
  };

  private handlePointerUp = (event: PointerEvent): void => {
    const start = this.pointerDown;
    this.pointerDown = null;
    if (!start || start.pointerId !== event.pointerId) return;
    if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > 6) return;
    const renderer = this.renderer;
    const bodyRig = this.bodyRig;
    const goalBodyRig = this.goalBodyRig;
    if (!renderer || !bodyRig || this.disposed || this.contextLost) return;

    const pickables: THREE.Mesh[] = [];
    const occluders: THREE.Mesh[] = [];
    if (this.comparisonMode !== 'goal') {
      pickables.push(...bodyRig.pickableMeshes);
      occluders.push(...bodyRig.occlusionMeshes);
    }
    if (this.comparisonMode !== 'current' && goalBodyRig) {
      pickables.push(...goalBodyRig.pickableMeshes);
      occluders.push(...goalBodyRig.occlusionMeshes);
    }

    const hit = this.musclePicker.pick(
      event.clientX,
      event.clientY,
      renderer.domElement,
      this.camera,
      pickables,
      occluders,
    );
    if (hit) {
      this.callbacks.onMusclePick(hit.muscleId, hit.side);
      this.requestRender();
    }
  };

  private handleContextLost = (event: Event): void => {
    event.preventDefault();
    this.contextLost = true;
    this.contextGeneration += 1;
    cancelAnimationFrame(this.rafId);
    this.rafId = 0;
    this.callbacks.onStatusChange('fallback');
  };

  private handleContextRestored = (): void => {
    const renderer = this.renderer;
    if (!renderer || this.disposed) return;
    try {
      this.contextLost = true;
      this.shaderPreparationPending = true;
      const compileGeneration = ++this.contextGeneration;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
      this.scene.environment = null;
      try {
        this.buildStudioEnvironment(renderer);
      } catch {
        this.scene.environment = null;
      }
      void renderer.compileAsync(this.scene, this.camera).then(() => {
        if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
        this.shaderPreparationPending = false;
        this.contextLost = false;
        this.callbacks.onStatusChange('ready');
        this.requestRender();
      }).catch(() => {
        if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
        this.releaseRendererToFallback(renderer);
        this.callbacks.onStatusChange('fallback');
      });
    } catch {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
    }
  };

  private handleMotionPreferenceChange = (event: MediaQueryListEvent): void => {
    this.prefersReducedMotion = event.matches;
    if (this.controls) this.controls.enableDamping = !this.isSoftwareGl && !event.matches;
    if (event.matches) {
      this.selectionSweepStartedAt = 0;
      if (this.materials) {
        this.materials.uniforms.uSweepY.value = 2.05;
        this.materials.goalUniforms.uSweepY.value = 2.05;
      }
    }
    this.requestRender();
  };

  handleResize = (): void => {
    if (!this.renderer || this.disposed) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (width <= 0 || height <= 0) return;

    const nextPixelRatio = this.getEffectivePixelRatio(width, height);
    const sizeChanged = width !== this.lastWidth || height !== this.lastHeight;
    const densityChanged = Math.abs(nextPixelRatio - this.lastPixelRatio) > 0.001;
    if (!sizeChanged && !densityChanged) return;

    this.lastWidth = width;
    this.lastHeight = height;
    if (densityChanged) {
      this.lastPixelRatio = nextPixelRatio;
      this.renderer.setPixelRatio(nextPixelRatio);
    }
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.compositor?.resize(width, height, this.lastPixelRatio);
    this.requestRender();
  };

  private applyUniformMaskState(
    uniforms: AnatomyShaderUniforms,
    primaryMask: number,
    secondaryMask: number,
    activeMask: number,
    selectedIndex: number,
    selectedSide: number,
    selectedSideAny: number,
    hasSelection: number,
  ): void {
    if (uniforms.uPrimaryMusclesMask.value !== primaryMask) uniforms.uPrimaryMusclesMask.value = primaryMask;
    if (uniforms.uSecondaryMusclesMask.value !== secondaryMask) uniforms.uSecondaryMusclesMask.value = secondaryMask;
    if (uniforms.uActiveMusclesMask.value !== activeMask) uniforms.uActiveMusclesMask.value = activeMask;
    if (uniforms.uSelectedMuscleIndex.value !== selectedIndex) uniforms.uSelectedMuscleIndex.value = selectedIndex;
    if (uniforms.uSelectedMuscleSide.value !== selectedSide) uniforms.uSelectedMuscleSide.value = selectedSide;
    if (uniforms.uSelectedSideAny.value !== selectedSideAny) uniforms.uSelectedSideAny.value = selectedSideAny;
    if (uniforms.uHasSelection.value !== hasSelection) uniforms.uHasSelection.value = hasSelection;
  }

  private syncMuscleShaderState(next: AnatomyVisualInput): void {
    if (!this.materials) return;
    const primaryMask = computeActiveMusclesMask(next.workoutHighlights.primary);
    const secondaryMask = computeActiveMusclesMask(next.workoutHighlights.secondary);
    const activeIds: MuscleGroupId[] = [
      ...next.workoutHighlights.primary,
      ...next.workoutHighlights.secondary,
      ...(next.selectedMuscleId ? [next.selectedMuscleId] : []),
    ];
    const activeMask = computeActiveMusclesMask(activeIds);
    const selectedIndex = next.selectedMuscleId
      ? MUSCLE_ID_TO_SHADER_INDEX[next.selectedMuscleId]
      : 0;
    const selectedSide = next.selectedMuscleSide === 'left'
      ? 1
      : next.selectedMuscleSide === 'right'
        ? -1
        : 0;
    const selectedSideAny = next.selectedMuscleId && next.selectedMuscleSide && next.selectedMuscleSide !== 'center' ? 0 : 1;
    const hasSelection = next.selectedMuscleId ? 1 : 0;

    this.applyUniformMaskState(
      this.materials.uniforms,
      primaryMask,
      secondaryMask,
      activeMask,
      selectedIndex,
      selectedSide,
      selectedSideAny,
      hasSelection,
    );
    this.applyUniformMaskState(
      this.materials.goalUniforms,
      primaryMask,
      secondaryMask,
      activeMask,
      selectedIndex,
      selectedSide,
      selectedSideAny,
      hasSelection,
    );

    // Sync Human Atlas-inspired 16x1 GPU state texture
    const lut = this.materials.stateDataTexture.image.data as Uint8Array;
    if (lut) {
      for (let i = 1; i <= 14; i += 1) {
        const bit = 1 << i;
        const idx = i * 4;
        lut[idx] = (primaryMask & bit) !== 0 ? 255 : 0;
        lut[idx + 1] = (secondaryMask & bit) !== 0 ? 255 : 0;
        lut[idx + 2] = hasSelection && selectedIndex === i ? 255 : 0;
        lut[idx + 3] = (activeMask & bit) !== 0 ? 255 : 0;
      }
      this.materials.stateDataTexture.needsUpdate = true;
    }
  }

  private syncDualBodyMorphs(dualBody: DualBodyInput): void {
    if (!this.materials || !this.bodyRig || !this.goalBodyRig) return;
    const lod = this.isTouchDevice || this.isSoftwareGl ? 'mid' : 'high';

    const nextCurrentSig = computeBodyIdentitySignature(dualBody.current);
    if (nextCurrentSig !== this.lastCurrentSignature) {
      this.lastCurrentSignature = nextCurrentSig;
      this.scene.remove(this.bodyRig.root);
      this.bodyRig.dispose();
      this.bodyRig = buildAnatomyBody(this.materials, {
        role: 'current',
        identity: dualBody.current,
        lod,
      });
      this.scene.add(this.bodyRig.root);
    }

    const nextGoalSig = computeBodyIdentitySignature(dualBody.goal);
    if (nextGoalSig !== this.lastGoalSignature) {
      this.lastGoalSignature = nextGoalSig;
      this.scene.remove(this.goalBodyRig.root);
      this.goalBodyRig.dispose();
      this.goalBodyRig = buildAnatomyBody(this.materials, {
        role: 'goal',
        identity: dualBody.goal,
        lod,
      });
      this.scene.add(this.goalBodyRig.root);
    }
  }

  syncVisualState(next: AnatomyVisualInput): void {
    if (this.disposed) return;
    const renderer = this.renderer;
    const materials = this.materials;
    const bodyRig = this.bodyRig;
    if (!renderer || !materials || !bodyRig) {
      if (!this.initializationAttempted) this.pendingVisualInput = next;
      return;
    }

    if (next.dualBody) {
      this.syncDualBodyMorphs(next.dualBody);
    }
    this.comparisonMode = next.comparisonMode ?? 'dual';

    this.syncMuscleShaderState(next);
    const holoVal = next.hologramMode ? 1 : 0;
    materials.uniforms.uHologramMode.value = holoVal;
    materials.goalUniforms.uHologramMode.value = holoVal;

    const selectionKey = next.selectedMuscleId
      ? `${next.selectedMuscleId}:${next.selectedMuscleSide ?? 'all'}`
      : '';
    if (selectionKey && selectionKey !== this.lastSelectionKey) {
      this.selectionSweepStartedAt = this.prefersReducedMotion ? 0 : performance.now();
      const startY = this.prefersReducedMotion ? 2.05 : -0.08;
      materials.uniforms.uSweepY.value = startY;
      materials.goalUniforms.uSweepY.value = startY;
    } else if (!selectionKey) {
      this.selectionSweepStartedAt = 0;
      materials.uniforms.uSweepY.value = 2.05;
      materials.goalUniforms.uSweepY.value = 2.05;
    }
    this.lastSelectionKey = selectionKey;

    const isDeep = next.layerMode === 'deep';
    const activeRigs = [this.bodyRig, this.goalBodyRig].filter(Boolean) as AnatomyBodyRig[];
    for (const rig of activeRigs) {
      rig.shellGroup.visible = true;
      rig.superficialGroup.visible = !isDeep;
      rig.deepGroup.visible = isDeep;
      rig.skeletonGroup.visible = false;
    }
    if (this.bodyRig) {
      this.bodyRig.root.visible = this.comparisonMode !== 'goal';
    }
    if (this.goalBodyRig) {
      this.goalBodyRig.root.visible = this.comparisonMode !== 'current';
    }

    // With isolated offscreen compositor, each body renders with opaque depth self-occlusion
    // unless viewing deep internal layers where shell becomes translucent.
    const useDeepAlpha = isDeep || !this.compositor;
    materials.bodySurface.transparent = isDeep;
    materials.bodySurface.opacity = isDeep ? 0.16 : 1;
    materials.bodySurface.depthWrite = !isDeep;
    materials.goalBodySurface.transparent = useDeepAlpha;
    materials.goalBodySurface.opacity = isDeep ? 0.16 : !this.compositor && this.comparisonMode === 'dual' ? 0.45 : 1;
    materials.goalBodySurface.depthWrite = !isDeep && Boolean(this.compositor);

    const cameraKey = `${next.cameraView}:${next.focusRegion}:${next.zoomScale}`;
    if (cameraKey !== this.lastCameraKey) {
      const hadPreviousCamera = this.lastCameraKey !== '';
      this.lastCameraKey = cameraKey;
      const preset = getAnatomyCameraPreset(
        next.cameraView,
        next.focusRegion,
        next.zoomScale,
      );
      if (!hadPreviousCamera || this.prefersReducedMotion || this.isSoftwareGl) {
        this.cameraTransition = null;
        this.camera.position.copy(preset.position);
        if (this.controls) {
          this.controls.target.copy(preset.target);
          this.controls.update();
        } else {
          this.camera.lookAt(preset.target);
        }
      } else {
        this.cameraTransition = {
          startedAt: performance.now(),
          durationMs: 360,
          fromPos: this.camera.position.clone(),
          toPos: preset.position.clone(),
          fromTarget: (this.controls ? this.controls.target : preset.target).clone(),
          toTarget: preset.target.clone(),
        };
      }
    }

    this.requestRender();
  }

  private updateCameraTransition(now: number): boolean {
    const transition = this.cameraTransition;
    if (!transition || this.prefersReducedMotion) {
      this.cameraTransition = null;
      return false;
    }
    const progress = Math.min(1, Math.max(0, (now - transition.startedAt) / transition.durationMs));
    const eased = 1 - Math.pow(1 - progress, 3);
    this.camera.position.lerpVectors(transition.fromPos, transition.toPos, eased);
    if (this.controls) {
      this.controls.target.lerpVectors(transition.fromTarget, transition.toTarget, eased);
      this.controls.update();
    } else {
      this.camera.lookAt(transition.toTarget);
    }
    if (progress >= 1) {
      this.cameraTransition = null;
      return false;
    }
    return true;
  }

  private updateSelectionSweep(now: number): boolean {
    if (!this.materials || !this.selectionSweepStartedAt || this.prefersReducedMotion) return false;
    const progress = Math.min(1, Math.max(0, (now - this.selectionSweepStartedAt) / 420));
    const eased = 1 - Math.pow(1 - progress, 3);
    const sweepVal = -0.08 + eased * 1.95;
    this.materials.uniforms.uSweepY.value = sweepVal;
    this.materials.goalUniforms.uSweepY.value = sweepVal;
    if (progress >= 1) {
      this.materials.uniforms.uSweepY.value = 2.05;
      this.materials.goalUniforms.uSweepY.value = 2.05;
      this.selectionSweepStartedAt = 0;
      return false;
    }
    return true;
  }

  requestRender = (): void => {
    const renderer = this.renderer;
    const bodyRig = this.bodyRig;
    const materials = this.materials;
    if (
      this.disposed ||
      !renderer ||
      !bodyRig ||
      !materials ||
      !this.isVisible ||
      !this.pageVisible ||
      this.contextLost ||
      this.shaderPreparationPending
    ) return;

    this.renderDirty = true;
    if (this.rafId) return;

    this.rafId = requestAnimationFrame(() => {
      this.rafId = 0;
      if (
        this.renderer !== renderer ||
        this.bodyRig !== bodyRig ||
        this.materials !== materials ||
        this.disposed ||
        !this.isVisible ||
        !this.pageVisible ||
        this.contextLost ||
        this.shaderPreparationPending
      ) return;

      const wasDirty = this.renderDirty;
      this.renderDirty = false;
      const now = performance.now();
      const cameraAnimating = this.updateCameraTransition(now);
      const dampingActive = this.controls?.update() ?? false;
      const sweepActive = this.updateSelectionSweep(now);
      const timeSec = this.prefersReducedMotion ? 0 : now * 0.001;
      this.emitterTimeUniform.value = timeSec;
      if (materials.uniforms.uTime) materials.uniforms.uTime.value = timeSec;
      if (materials.goalUniforms.uTime) materials.goalUniforms.uTime.value = timeSec;
      this.updateRearBelowLightTransform();

      const highPriorityMotion =
        wasDirty ||
        cameraAnimating ||
        sweepActive ||
        (dampingActive && !this.isSoftwareGl);

      const ambientHoloActive =
        !this.prefersReducedMotion &&
        !this.isSoftwareGl &&
        materials.uniforms.uHologramMode.value > 0.5;

      if (highPriorityMotion || !ambientHoloActive || now - this.lastAmbientTickAt >= 33) {
        this.lastAmbientTickAt = now;
        if (this.compositor && this.goalBodyRig) {
          this.compositor.render(
            renderer,
            this.scene,
            this.camera,
            this.bodyRig.root,
            this.goalBodyRig.root,
            this.backdropObjects,
            this.comparisonMode,
          );
        } else {
          renderer.render(this.scene, this.camera);
        }
      }

      if (highPriorityMotion || ambientHoloActive) {
        this.requestRender();
      }
    });
  };

  getPerformanceSnapshot(): AnatomyPerformanceSnapshot {
    const info = this.renderer?.info;
    return {
      drawCalls: info?.render.calls ?? 0,
      triangles: info?.render.triangles ?? 0,
      geometries: info?.memory.geometries ?? 0,
      textures: info?.memory.textures ?? 0,
      pixelRatio: this.lastPixelRatio,
    };
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    window.clearTimeout(this.interactionRestoreTimer);
    this.rafId = 0;
    this.cameraTransition = null;

    if (this.controls) {
      this.controls.removeEventListener('start', this.handleControlsStart);
      this.controls.removeEventListener('change', this.handleControlsChange);
      this.controls.dispose();
      this.controls = null;
    }

    this.releaseViewportObservers();

    if (this.bodyRig) this.bodyRig.dispose();
    this.bodyRig = null;
    if (this.goalBodyRig) this.goalBodyRig.dispose();
    this.goalBodyRig = null;
    if (this.compositor) this.compositor.dispose();
    this.compositor = null;
    if (this.materials) this.materials.dispose();
    this.materials = null;
    this.emitterResources.forEach((resource) => resource.dispose());
    this.emitterResources = [];
    this.backdropObjects = [];
    this.backlightHalo = null;
    this.rearEmitterCircle = null;
    this.volumetricBeam = null;
    this.rearBelowLight = null;

    if (this.renderer) {
      const renderer = this.renderer;
      const canvas = renderer.domElement;
      canvas.removeEventListener('webglcontextlost', this.handleContextLost);
      canvas.removeEventListener('pointerdown', this.handlePointerDown);
      canvas.removeEventListener('pointerup', this.handlePointerUp);
      canvas.removeEventListener('pointercancel', this.handlePointerCancel);
      canvas.removeEventListener('webglcontextrestored', this.handleContextRestored);
      if (canvas.parentElement === this.container) this.container.removeChild(canvas);
      this.scene.environment = null;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
      this.scene.clear();
      renderer.dispose();
      renderer.forceContextLoss();
      this.renderer = null;
    }

    this.pointerDown = null;
    this.pendingVisualInput = null;
    this.shaderPreparationPending = false;
  }
}
