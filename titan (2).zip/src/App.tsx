/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Toaster } from 'sonner';
import { MotionConfig } from './shared/motion/titan-motion';
import { AppProviders } from './app-core/providers/AppProviders';
import { AppShell } from './app-core/navigation/AppShell';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <AppProviders>
        <AppShell />
        <Toaster
          position="top-center"
          theme="dark"
          offset={16}
          mobileOffset={{ top: 'max(12px, env(safe-area-inset-top))' }}
          toastOptions={{
            duration: 2200,
            className: 'titan-liquid-glass-toast',
            style: {
              fontSize: '13px',
              fontWeight: 600,
              fontFamily: 'var(--font-mono)',
            },
          }}
        />
      </AppProviders>
    </MotionConfig>
  );
}
