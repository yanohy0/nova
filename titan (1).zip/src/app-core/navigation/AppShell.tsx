import { lazy, Profiler, Suspense, useEffect, useState, type ComponentType } from 'react';
import { Activity, Dumbbell, Home, Plus, Utensils } from 'lucide-react';
import type { MainDestination } from '@/src/shared/types/common';
import { CockpitScreen } from '@/src/domains/cockpit/screens/CockpitScreen';
import { startWorkoutSession } from '@/src/domains/training/application/start-workout';
import { useTrainingSessionStore } from '@/src/domains/training/state/training-session.store';
import { useNavigationStore } from './navigation.store';

function lazyWithRetry<T extends ComponentType<any>>(
  loader: () => Promise<{ default: T }>,
) {
  return lazy(async () => {
    try {
      return await loader();
    } catch (error) {
      await new Promise((resolve) => setTimeout(resolve, 180));
      try {
        return await loader();
      } catch (retryError) {
        if (typeof window !== 'undefined' && typeof sessionStorage !== 'undefined') {
          const msg = retryError instanceof Error ? retryError.message : String(retryError);
          const isChunkFetch =
            /Failed to fetch dynamically imported module|Importing a module script failed|Outdated Optimize Dep/i.test(
              msg,
            );
          const lastReload = Number(sessionStorage.getItem('titan_chunk_reload_at') ?? '0');
          if (isChunkFetch && Date.now() - lastReload > 10_000) {
            sessionStorage.setItem('titan_chunk_reload_at', String(Date.now()));
            window.location.reload();
          }
        }
        throw retryError;
      }
    }
  });
}

const ActionSheet = lazyWithRetry(() =>
  import('./ActionSheet').then((m) => ({
    default: m.ActionSheet,
  })),
);

const CardapioScreen = lazyWithRetry(() =>
  import('@/src/domains/nutrition/screens/CardapioScreen').then((m) => ({
    default: m.CardapioScreen,
  })),
);
const TrainingHomeScreen = lazyWithRetry(() =>
  import('@/src/domains/training/screens/TrainingHomeScreen').then((m) => ({
    default: m.TrainingHomeScreen,
  })),
);
const ActiveWorkoutScreen = lazyWithRetry(() =>
  import('@/src/domains/training/screens/ActiveWorkoutScreen').then((m) => ({
    default: m.ActiveWorkoutScreen,
  })),
);
const ExerciseLibraryScreen = lazyWithRetry(() =>
  import('@/src/domains/exercise-library/screens/ExerciseLibraryScreen').then((m) => ({
    default: m.ExerciseLibraryScreen,
  })),
);
const EvolutionScreen = lazyWithRetry(() =>
  import('@/src/domains/evolution/screens/EvolutionScreen').then((m) => ({
    default: m.EvolutionScreen,
  })),
);

function reportSlowScreenRender(id: string, phase: 'mount' | 'update' | 'nested-update', actualDuration: number): void {
  if (import.meta.env.DEV && actualDuration >= 16.7) {
    console.warn(`[TITAN performance] ${id} ${phase}: ${actualDuration.toFixed(1)} ms (render acima do orçamento aproximado de 60 Hz).`, { actualDurationMs: actualDuration });
  }
}

const NAV_TABS: Array<{ id: MainDestination; label: string; icon: typeof Home }> = [
  { id: 'cockpit', label: 'Início', icon: Home },
  { id: 'cardapio', label: 'Cardápio', icon: Utensils },
  { id: 'treino', label: 'Treino', icon: Dumbbell },
  { id: 'evolucao', label: 'Evolução', icon: Activity },
];

export function AppShell() {
  const activeTab = useNavigationStore((s) => s.activeTab);
  const subView = useNavigationStore((s) => s.subView);
  const nutritionSection = useNavigationStore((s) => s.nutritionSection);
  const libraryMuscleFilter = useNavigationStore((s) => s.libraryMuscleFilter);
  const setTab = useNavigationStore((s) => s.setTab);
  const openNutrition = useNavigationStore((s) => s.openNutrition);
  const setNutritionSection = useNavigationStore((s) => s.setNutritionSection);
  const openExerciseLibrary = useNavigationStore((s) => s.openExerciseLibrary);
  const setLibraryMuscleFilter = useNavigationStore((s) => s.setLibraryMuscleFilter);
  const openSubView = useNavigationStore((s) => s.openSubView);
  const closeSubView = useNavigationStore((s) => s.closeSubView);
  const setActionSheetOpen = useNavigationStore((s) => s.setActionSheetOpen);
  const actionSheetOpen = useNavigationStore((s) => s.actionSheetOpen);
  const activePlanId = useTrainingSessionStore((s) => s.activePlanId);
  const [actionSheetMounted, setActionSheetMounted] = useState(false);

  useEffect(() => {
    if (actionSheetOpen) {
      setActionSheetMounted(true);
    }
  }, [actionSheetOpen]);

  const openActiveWorkout = () => {
    startWorkoutSession(activePlanId);
    setTab('treino');
    openSubView('active-workout');
  };

  const renderScreen = () => {
    if (subView === 'active-workout') {
      return <ActiveWorkoutScreen onBack={closeSubView} />;
    }
    if (subView === 'exercise-library') {
      return (
        <ExerciseLibraryScreen
          onBack={closeSubView}
          onInspectIn3D={() => setTab('cockpit')}
          muscleFilter={libraryMuscleFilter}
          onMuscleFilterChange={setLibraryMuscleFilter}
        />
      );
    }

    switch (activeTab) {
      case 'cockpit':
        return (
          <CockpitScreen
            onOpenTraining={openActiveWorkout}
            onOpenTrainingPlans={() => setTab('treino')}
            onOpenExerciseLibrary={(muscle) => openExerciseLibrary(muscle ?? 'all')}
            onOpenNutrition={(section) => openNutrition(section ?? 'cardapio')}
          />
        );
      case 'cardapio':
        return (
          <CardapioScreen
            section={nutritionSection}
            onSectionChange={setNutritionSection}
          />
        );
      case 'treino':
        return (
          <TrainingHomeScreen
            onStartActiveWorkout={() => openSubView('active-workout')}
            onOpenLibrary={() => openExerciseLibrary('all')}
          />
        );
      case 'evolucao':
        return <EvolutionScreen />;
    }
  };

  return (
    <div className="titan-app-shell flex flex-col">
      <header className="titan-topbar hidden md:block">
        <div className="titan-topbar-inner">
          <div className="flex items-center gap-3">
            <span className="titan-brand-wordmark">TITAN</span>
            <span className="h-5 w-px bg-[var(--titan-border)]" aria-hidden="true" />
            <span className="titan-eyebrow">Performance system</span>
          </div>

          <nav className="titan-top-nav" aria-label="Navegação principal">
            {NAV_TABS.map((tab) => {
              const active = activeTab === tab.id && !subView;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setTab(tab.id)}
                  aria-current={active ? 'page' : undefined}
                  className="titan-top-nav-link"
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            <p className="titan-topbar-note">Strength · Nutrition · Recovery</p>
            <button
              type="button"
              onClick={() => setActionSheetOpen(true)}
              className="titan-top-nav-link"
              aria-label="Abrir ações rápidas"
            >
              <Plus size={15} aria-hidden="true" />
              <span>Ações</span>
            </button>
          </div>
        </div>
      </header>

      <main className="titan-main flex-1">
        <Suspense
          fallback={
            <div className="py-16 text-center">
              <span className="titan-eyebrow">TITAN</span>
              <p className="mt-2 text-sm text-[var(--titan-text-muted)]">Preparando sua experiência...</p>
            </div>
          }
        >
          <Profiler id={subView ?? activeTab} onRender={reportSlowScreenRender}>
            {renderScreen()}
          </Profiler>
        </Suspense>
      </main>

      <nav className="md:hidden titan-bottom-nav" aria-label="Navegação mobile">
        <div className="titan-bottom-nav-inner">
          {NAV_TABS.slice(0, 2).map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id && !subView;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setTab(tab.id)}
                aria-current={active ? 'page' : undefined}
                className="titan-mobile-nav-item"
              >
                <Icon size={19} strokeWidth={active ? 2 : 1.7} />
                <span>{tab.label}</span>
              </button>
            );
          })}

          <div className="flex items-center justify-center">
            <button
              type="button"
              onClick={() => setActionSheetOpen(true)}
              aria-label="Abrir ações rápidas"
              className="titan-action-fab"
            >
              <Plus size={22} strokeWidth={1.8} />
            </button>
          </div>

          {NAV_TABS.slice(2).map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id && !subView;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setTab(tab.id)}
                aria-current={active ? 'page' : undefined}
                className="titan-mobile-nav-item"
              >
                <Icon size={19} strokeWidth={active ? 2 : 1.7} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {actionSheetMounted && (
        <Suspense fallback={null}>
          <ActionSheet />
        </Suspense>
      )}
    </div>
  );
}
