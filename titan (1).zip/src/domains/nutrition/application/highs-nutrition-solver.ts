import loadHighs, { type Highs } from 'highs';
import {
  buildHighsQPModelLP,
  buildHighsRecipeScaleQPModelLP,
  formatLinearTerms,
  formatLpNum,
} from './highs-lp-builder.ts';
import {
  extractValidatedBinarySlotSelections,
  extractValidatedContinuousPrimalValues,
  extractValidatedScalePrimalValues,
} from './highs-solution-validation.ts';
export { buildHighsQPModelLP, buildHighsRecipeScaleQPModelLP } from './highs-lp-builder.ts';
import { RECIPE_CATALOG } from '../data/recipes/recipe-catalog.ts';
import { isEligibleRecipeTemplate } from '../domain/rules/recipe-engine.ts';
import type {
  ComposerDayPlan,
  ComposerMacroTotals,
  DiscreteCombinationProposal,
  DiscreteSubstitutionProposal,
  NutritionTargets,
  OptimizationProposal,
} from '../domain/entities/nutrient.ts';
import {
  buildOptimizationProposalFromSolution,
  computeDayNutrition,
  computeRecipeNutrition,
  createRecipeInstanceFromCatalog,
  prepareQPModel,
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
  type PreparedQPModel,
} from '../domain/rules/cardapio-composer-engine.ts';
import {
  attachRecipeScaleProposalMetadata,
  solveMacroTargetFitQP,
  wrapFlexibleProposalAsResult,
  type MacroTargetFitOptions,
} from '../domain/rules/macro-target-fit.ts';
import { buildRecipeScaleModel } from '../domain/rules/recipe-scale-model.ts';
import {
  quantizeAndValidateRecipeScaleProposal,
  type RecipeScaleQuantizationResult,
} from '../domain/rules/recipe-scale-quantization.ts';

let highsPromise: Promise<Highs> | null = null;
let loadedWasmUrl: string | undefined;

export async function getHighsInstance(wasmUrl?: string): Promise<Highs> {
  if (highsPromise && loadedWasmUrl === wasmUrl) {
    return highsPromise;
  }
  loadedWasmUrl = wasmUrl;
  highsPromise = loadHighs(
    wasmUrl
      ? {
          locateFile: (file: string) => (file.endsWith('.wasm') ? wasmUrl : file),
        }
      : undefined,
  ).catch((err) => {
    highsPromise = null;
    throw err;
  });
  return highsPromise;
}

export async function solveNutritionalBalanceWithHighsQP(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions = {},
  wasmUrl?: string,
): Promise<OptimizationProposal> {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const model = prepareQPModel(dayPlan, targets, options);
  if (model.vars.length === 0) {
    return solveNutritionalBalanceQP(dayPlan, targets, options);
  }

  try {
    const highs = await getHighsInstance(wasmUrl);
    const { lpText, hasActiveCorridors } = buildHighsQPModelLP(model, targets, true);
    let solution = highs.solve(lpText, { time_limit: 2, output_flag: false, log_to_console: false });
    let corridorRelaxedWarning = false;

    if (solution.Status !== 'Optimal' && hasActiveCorridors) {
      const relaxed = buildHighsQPModelLP(model, targets, false);
      const retrySolution = highs.solve(relaxed.lpText, {
        time_limit: 2,
        output_flag: false,
        log_to_console: false,
      });
      if (retrySolution.Status === 'Optimal') {
        solution = retrySolution;
        corridorRelaxedWarning = true;
      }
    }

    if (solution.Status !== 'Optimal') {
      return solveNutritionalBalanceQP(dayPlan, targets, options);
    }

    const solvedGrams = extractValidatedContinuousPrimalValues(
      solution.Columns as unknown as Record<string, unknown>,
      model.vars,
    );
    if (!solvedGrams) return solveNutritionalBalanceQP(dayPlan, targets, options);

    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
    return buildOptimizationProposalFromSolution(
      dayPlan,
      targets,
      model,
      solvedGrams,
      t1 - t0,
      {
        solverEngine: 'HiGHS QP (WASM)',
        hasSolverWarning: corridorRelaxedWarning,
        warningReason: corridorRelaxedWarning
          ? 'As faixas mín/máx configuradas são inviáveis com os limites atuais de porção; o HiGHS encontrou o melhor equilíbrio contínuo relaxando apenas os corredores externos.'
          : undefined,
      },
    );
  } catch {
    return solveNutritionalBalanceQP(dayPlan, targets, options);
  }
}

export async function solveMacroTargetFitWithHighsQP(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: MacroTargetFitOptions = {},
  wasmUrl?: string,
): Promise<RecipeScaleQuantizationResult> {
  const scaleMode = options.scaleMode ?? 'preserve_recipe_ratios';
  if (scaleMode === 'ingredient_flexible') {
    const proposal = await solveNutritionalBalanceWithHighsQP(dayPlan, targets, options, wasmUrl);
    return wrapFlexibleProposalAsResult(dayPlan, targets, proposal);
  }

  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const model = buildRecipeScaleModel(dayPlan, targets, options);
  if (model.vars.length === 0 || model.hasContradictoryBounds) {
    return solveMacroTargetFitQP(dayPlan, targets, options);
  }

  try {
    const highs = await getHighsInstance(wasmUrl);
    const { lpText, hasActiveCorridors } = buildHighsRecipeScaleQPModelLP(model, targets, true);
    let solution = highs.solve(lpText, { time_limit: 2, output_flag: false, log_to_console: false });
    let corridorRelaxedWarning = false;

    if (solution.Status !== 'Optimal' && hasActiveCorridors) {
      const relaxed = buildHighsRecipeScaleQPModelLP(model, targets, false);
      const retrySolution = highs.solve(relaxed.lpText, {
        time_limit: 2,
        output_flag: false,
        log_to_console: false,
      });
      if (retrySolution.Status === 'Optimal') {
        solution = retrySolution;
        corridorRelaxedWarning = true;
      }
    }

    if (solution.Status !== 'Optimal') {
      return solveMacroTargetFitQP(dayPlan, targets, options);
    }

    const solvedScales = extractValidatedScalePrimalValues(
      solution.Columns as unknown as Record<string, unknown>,
      model.vars,
    );
    if (!solvedScales) {
      return solveMacroTargetFitQP(dayPlan, targets, options);
    }

    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
    return attachRecipeScaleProposalMetadata(
      quantizeAndValidateRecipeScaleProposal(dayPlan, targets, model, solvedScales, t1 - t0, {
        solverEngine: 'HiGHS QP (Escala por Receita WASM)',
        hasSolverWarning: corridorRelaxedWarning,
        warningReason: corridorRelaxedWarning
          ? 'As faixas mín/máx configuradas são inviáveis preservando as proporções das receitas; o HiGHS ajustou relaxando apenas os corredores externos.'
          : undefined,
      }),
      'preserve_recipe_ratios',
    );
  } catch {
    return solveMacroTargetFitQP(dayPlan, targets, options);
  }
}

function normalizedL1Gap(macros: ComposerMacroTotals, targets: NutritionTargets): number {
  const e = Math.abs(macros.kcal - targets.kcal) / Math.max(400, targets.kcal);
  const p = Math.abs(macros.proteinG - targets.proteinG) / Math.max(30, targets.proteinG);
  const c = Math.abs(macros.carbsG - targets.carbsG) / Math.max(40, targets.carbsG);
  const f = Math.abs(macros.fatG - targets.fatG) / Math.max(15, targets.fatG);
  return 1.45 * e + 1.35 * p + 0.9 * c + 0.9 * f;
}

export async function solveDiscreteSubstitutionsWithHighsMIP(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions = {},
  wasmUrl?: string,
): Promise<{
  singleSlotSwaps: DiscreteSubstitutionProposal[];
  jointProposal: DiscreteCombinationProposal | null;
}> {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const singleSlotSwaps = proposeDiscreteSubstitutions(dayPlan, targets, 5);
  const currentDaySummary = computeDayNutrition(dayPlan);
  const targetGapBefore = normalizedL1Gap(currentDaySummary.macros, targets);

  interface SlotChoiceOption {
    slotId: string;
    slotTitle: string;
    currentRecipeId: string;
    currentRecipeName: string;
    currentMacros: ComposerMacroTotals;
    candidateRecipeId: string | null;
    candidateRecipeName: string;
    sourceSummary: string;
    macros: ComposerMacroTotals;
    isCurrent: boolean;
  }

  const slotOptionsList: SlotChoiceOption[][] = [];
  let fixedNonPrimaryMacros: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };

  for (const slot of dayPlan.slots) {
    const primary = slot.recipes[0];
    if (!primary) continue;

    for (let rIdx = 1; rIdx < slot.recipes.length; rIdx += 1) {
      const extraSum = computeRecipeNutrition(slot.recipes[rIdx]!);
      fixedNonPrimaryMacros.kcal += extraSum.macros.kcal;
      fixedNonPrimaryMacros.proteinG += extraSum.macros.proteinG;
      fixedNonPrimaryMacros.carbsG += extraSum.macros.carbsG;
      fixedNonPrimaryMacros.fatG += extraSum.macros.fatG;
    }

    const currentSum = computeRecipeNutrition(primary);
    const currentOpt: SlotChoiceOption = {
      slotId: slot.id,
      slotTitle: slot.title,
      currentRecipeId: primary.id,
      currentRecipeName: primary.name,
      currentMacros: currentSum.macros,
      candidateRecipeId: primary.sourceRecipeId ?? null,
      candidateRecipeName: primary.name,
      sourceSummary: currentSum.sources.join(' · ') || 'TBCA',
      macros: currentSum.macros,
      isCurrent: true,
    };

    // Rank candidates matching category first, keeping branch-and-bound size compact
    const catalogCandidates = RECIPE_CATALOG
      .filter((r) => isEligibleRecipeTemplate(r) && r.id !== primary.sourceRecipeId)
      .map((catalogRecipe) => {
        const inst = createRecipeInstanceFromCatalog(
          catalogRecipe,
          `${slot.id}-mip-${catalogRecipe.id}`,
          1,
          'balanced',
        );
        const sum = computeRecipeNutrition(inst);
        const categoryScore = catalogRecipe.category === primary.category ? 0 : 1;
        return {
          catalogRecipe,
          sum,
          categoryScore,
        };
      })
      .sort((a, b) => a.categoryScore - b.categoryScore)
      .slice(0, 6);

    const optionsForSlot: SlotChoiceOption[] = [
      currentOpt,
      ...catalogCandidates.map(({ catalogRecipe, sum }) => ({
        slotId: slot.id,
        slotTitle: slot.title,
        currentRecipeId: primary.id,
        currentRecipeName: primary.name,
        currentMacros: currentSum.macros,
        candidateRecipeId: catalogRecipe.id,
        candidateRecipeName: catalogRecipe.name,
        sourceSummary: sum.sources.join(' · ') || 'TBCA',
        macros: sum.macros,
        isCurrent: false,
      })),
    ];
    slotOptionsList.push(optionsForSlot);
  }

  if (slotOptionsList.length === 0) {
    return { singleSlotSwaps, jointProposal: null };
  }

  try {
    const highs = await getHighsInstance(wasmUrl);
    const scaleK = Math.max(400, targets.kcal);
    const scaleP = Math.max(30, targets.proteinG);
    const scaleC = Math.max(40, targets.carbsG);
    const scaleF = Math.max(15, targets.fatG);
    const focus = options.goalFocus ?? 'balanced';
    const wK = focus === 'energy' ? 2.1 : focus === 'protein' ? 1.2 : 1.45;
    const wP = focus === 'protein' ? 2.1 : 1.35;
    const wC = 0.9;
    const wF = 0.9;

    const objTerms: Array<{ coeff: number; name: string }> = [
      { coeff: wK / scaleK, name: 'ekp' },
      { coeff: wK / scaleK, name: 'ekm' },
      { coeff: wP / scaleP, name: 'epp' },
      { coeff: wP / scaleP, name: 'epm' },
      { coeff: wC / scaleC, name: 'ecp' },
      { coeff: wC / scaleC, name: 'ecm' },
      { coeff: wF / scaleF, name: 'efp' },
      { coeff: wF / scaleF, name: 'efm' },
    ];

    const constraints: string[] = [];
    const binaries: string[] = [];

    const kcalTerms: Array<{ coeff: number; name: string }> = [
      { coeff: -1, name: 'ekp' },
      { coeff: 1, name: 'ekm' },
    ];
    const pTerms: Array<{ coeff: number; name: string }> = [
      { coeff: -1, name: 'epp' },
      { coeff: 1, name: 'epm' },
    ];
    const cTerms: Array<{ coeff: number; name: string }> = [
      { coeff: -1, name: 'ecp' },
      { coeff: 1, name: 'ecm' },
    ];
    const fTerms: Array<{ coeff: number; name: string }> = [
      { coeff: -1, name: 'efp' },
      { coeff: 1, name: 'efm' },
    ];

    slotOptionsList.forEach((opts, sIdx) => {
      const choiceTerms: Array<{ coeff: number; name: string }> = [];
      opts.forEach((opt, kIdx) => {
        const varName = `b_${sIdx}_${kIdx}`;
        binaries.push(varName);
        choiceTerms.push({ coeff: 1, name: varName });
        kcalTerms.push({ coeff: opt.macros.kcal, name: varName });
        pTerms.push({ coeff: opt.macros.proteinG, name: varName });
        cTerms.push({ coeff: opt.macros.carbsG, name: varName });
        fTerms.push({ coeff: opt.macros.fatG, name: varName });
        if (!opt.isCurrent) {
          // Small parsimony tie-breaker to avoid unnecessary recipe churn
          objTerms.push({ coeff: 0.015, name: varName });
        }
      });
      constraints.push(` choose_${sIdx}: ${formatLinearTerms(choiceTerms)} = 1`);
    });

    constraints.push(
      ` bal_kcal: ${formatLinearTerms(kcalTerms)} = ${formatLpNum(targets.kcal - fixedNonPrimaryMacros.kcal)}`,
    );
    constraints.push(
      ` bal_p: ${formatLinearTerms(pTerms)} = ${formatLpNum(targets.proteinG - fixedNonPrimaryMacros.proteinG)}`,
    );
    constraints.push(
      ` bal_c: ${formatLinearTerms(cTerms)} = ${formatLpNum(targets.carbsG - fixedNonPrimaryMacros.carbsG)}`,
    );
    constraints.push(
      ` bal_f: ${formatLinearTerms(fTerms)} = ${formatLpNum(targets.fatG - fixedNonPrimaryMacros.fatG)}`,
    );

    const lpText = [
      'Minimize',
      ` obj: ${formatLinearTerms(objTerms)}`,
      'Subject To',
      ...constraints,
      'Binary',
      ` ${binaries.join(' ')}`,
      'End',
    ].join('\n');

    const solution = highs.solve(lpText, {
      time_limit: 2,
      mip_rel_gap: 0.005,
      output_flag: false,
      log_to_console: false,
    });

    if (solution.Status !== 'Optimal') {
      return { singleSlotSwaps, jointProposal: null };
    }

    const selectedOptionIndexes = extractValidatedBinarySlotSelections(
      solution.Columns as unknown as Record<string, unknown>,
      slotOptionsList.map((optionsForSlot) => optionsForSlot.length),
    );
    if (!selectedOptionIndexes) return { singleSlotSwaps, jointProposal: null };
    const chosenOptions: SlotChoiceOption[] = slotOptionsList.map((optionsForSlot, index) => {
      const selectedIndex = selectedOptionIndexes[index];
      return selectedIndex === undefined ? optionsForSlot[0]! : optionsForSlot[selectedIndex]!;
    });

    const projectedMacros: ComposerMacroTotals = chosenOptions.reduce(
      (acc, opt) => ({
        kcal: acc.kcal + opt.macros.kcal,
        proteinG: acc.proteinG + opt.macros.proteinG,
        carbsG: acc.carbsG + opt.macros.carbsG,
        fatG: acc.fatG + opt.macros.fatG,
      }),
      { ...fixedNonPrimaryMacros },
    );

    const targetGapAfter = normalizedL1Gap(projectedMacros, targets);
    const swaps: DiscreteSubstitutionProposal[] = chosenOptions
      .filter((opt) => !opt.isCurrent && opt.candidateRecipeId !== null)
      .map((opt) => ({
        id: `mip-${opt.slotId}-${opt.candidateRecipeId}`,
        slotId: opt.slotId,
        slotTitle: opt.slotTitle,
        currentRecipeId: opt.currentRecipeId,
        currentRecipeName: opt.currentRecipeName,
        candidateRecipeId: opt.candidateRecipeId!,
        candidateRecipeName: opt.candidateRecipeName,
        sourceSummary: opt.sourceSummary,
        deltaMacros: {
          kcal: opt.macros.kcal - opt.currentMacros.kcal,
          proteinG: opt.macros.proteinG - opt.currentMacros.proteinG,
          carbsG: opt.macros.carbsG - opt.currentMacros.carbsG,
          fatG: opt.macros.fatG - opt.currentMacros.fatG,
        },
        projectedDayMacros: projectedMacros,
        targetGapAfter: Number(targetGapAfter.toFixed(4)),
      }));

    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
    const jointProposal: DiscreteCombinationProposal | null =
      swaps.length > 0 && targetGapAfter < targetGapBefore - 0.01
        ? {
            id: `mip-combo-${Date.now().toString(36)}`,
            solverEngine: 'HiGHS MILP (WASM)',
            swaps,
            projectedDayMacros: projectedMacros,
            targetGapBefore: Number(targetGapBefore.toFixed(4)),
            targetGapAfter: Number(targetGapAfter.toFixed(4)),
            solveDurationMs: Number((t1 - t0).toFixed(2)),
          }
        : null;

    return {
      singleSlotSwaps,
      jointProposal,
    };
  } catch {
    return {
      singleSlotSwaps,
      jointProposal: null,
    };
  }
}
