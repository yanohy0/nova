import type {
  ComposerDayPlan,
  DiscreteCombinationProposal,
  DiscreteSubstitutionProposal,
  NutritionTargets,
  OptimizationProposal,
} from '../domain/entities/nutrient.ts';
import {
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
} from '../domain/rules/cardapio-composer-engine.ts';
import {
  solveMacroTargetFitQP,
  type MacroTargetFitOptions,
} from '../domain/rules/macro-target-fit.ts';
import type { RecipeScaleQuantizationResult } from '../domain/rules/recipe-scale-quantization.ts';
import {
  solveDiscreteSubstitutionsWithHighsMIP,
  solveMacroTargetFitWithHighsQP,
  solveNutritionalBalanceWithHighsQP,
} from './highs-nutrition-solver.ts';
import { ensureTbcaCatalogLoaded } from '../data/sources/tbca-adapter.ts';

export type OptimizerWorkerRequest =
  | {
      requestId: number;
      kind?: 'legacy_composer';
      dayPlan: ComposerDayPlan;
      targets: NutritionTargets;
      options?: OptimizeBalanceOptions;
      includeSubstitutions?: boolean;
    }
  | {
      requestId: number;
      kind: 'macro_target_fit';
      dayPlan: ComposerDayPlan;
      targets: NutritionTargets;
      options?: MacroTargetFitOptions;
    };

export type OptimizerWorkerResponse =
  | {
      requestId: number;
      kind?: 'legacy_composer';
      proposal: OptimizationProposal;
      substitutions: DiscreteSubstitutionProposal[];
      jointCombination: DiscreteCombinationProposal | null;
    }
  | {
      requestId: number;
      kind: 'macro_target_fit';
      result: RecipeScaleQuantizationResult;
    };

const HIGHS_WASM_URL = '/wasm/highs.wasm';

const workerScope = globalThis as unknown as {
  onmessage: ((event: MessageEvent<OptimizerWorkerRequest>) => void) | null;
  postMessage: (message: OptimizerWorkerResponse) => void;
};

if (typeof workerScope.postMessage === 'function') {
  workerScope.onmessage = async (event: MessageEvent<OptimizerWorkerRequest>) => {
    const req = event.data;
    if (!req || typeof req.requestId !== 'number') return;

    try {
      await ensureTbcaCatalogLoaded();
    } catch {
      // Proceed with cached/legacy rows if compact catalog fetch fails in worker context
    }

    if (req.kind === 'macro_target_fit') {
      let result: RecipeScaleQuantizationResult;
      try {
        result = await solveMacroTargetFitWithHighsQP(
          req.dayPlan,
          req.targets,
          req.options,
          HIGHS_WASM_URL,
        );
      } catch {
        result = solveMacroTargetFitQP(req.dayPlan, req.targets, req.options);
      }
      workerScope.postMessage({
        requestId: req.requestId,
        kind: 'macro_target_fit',
        result,
      });
      return;
    }

    const { requestId, dayPlan, targets, options, includeSubstitutions } = req;

    let proposal: OptimizationProposal;
    try {
      proposal = await solveNutritionalBalanceWithHighsQP(
        dayPlan,
        targets,
        options,
        HIGHS_WASM_URL,
      );
    } catch {
      proposal = solveNutritionalBalanceQP(dayPlan, targets, options);
    }

    let substitutions: DiscreteSubstitutionProposal[] = [];
    let jointCombination: DiscreteCombinationProposal | null = null;

    if (includeSubstitutions) {
      try {
        const discrete = await solveDiscreteSubstitutionsWithHighsMIP(
          dayPlan,
          targets,
          options,
          HIGHS_WASM_URL,
        );
        substitutions = discrete.singleSlotSwaps;
        jointCombination = discrete.jointProposal;
      } catch {
        substitutions = proposeDiscreteSubstitutions(dayPlan, targets, 4);
      }
    }

    workerScope.postMessage({
      requestId,
      kind: 'legacy_composer',
      proposal,
      substitutions,
      jointCombination,
    });
  };
}
