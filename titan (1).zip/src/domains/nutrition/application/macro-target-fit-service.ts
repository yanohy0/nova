import type { ComposerDayPlan, NutritionTargets } from '../domain/entities/nutrient.ts';
import type {
  MacroFitScaleMode,
  MacroTargetFitOptions,
} from '../domain/rules/macro-target-fit.ts';
import type { RecipeScaleQuantizationResult } from '../domain/rules/recipe-scale-quantization.ts';
import { runMacroTargetFitAsync } from './composer-optimizer-client.ts';

export type MacroFitPipelineStatus =
  | 'idle'
  | 'scheduled'
  | 'calculating'
  | 'ready'
  | 'stale'
  | 'infeasible'
  | 'failed';

export interface MacroFitProposalSnapshot {
  status: MacroFitPipelineStatus;
  requestId: number;
  planId: string;
  dateKey: string;
  planRevision: number;
  inputsRevision: number;
  scaleMode: MacroFitScaleMode;
  result: RecipeScaleQuantizationResult | null;
  errorMessage: string | null;
}

export interface MacroFitScheduleRequest {
  planId: string;
  dateKey: string;
  planRevision: number;
  inputsRevision: number;
  dayPlan: ComposerDayPlan;
  targets: NutritionTargets;
  options?: MacroTargetFitOptions & { timeoutMs?: number };
}

export type MacroFitRunner = (
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options?: MacroTargetFitOptions & { timeoutMs?: number },
) => Promise<RecipeScaleQuantizationResult>;

export interface MacroTargetFitScheduler {
  schedule: (req: MacroFitScheduleRequest) => void;
  invalidateToStale: (planRevision: number, inputsRevision: number) => void;
  dismiss: () => void;
  reset: () => void;
  dispose: () => void;
  getSnapshot: () => MacroFitProposalSnapshot;
  subscribe: (listener: (snapshot: MacroFitProposalSnapshot) => void) => () => void;
}

const INITIAL_SNAPSHOT: MacroFitProposalSnapshot = {
  status: 'idle',
  requestId: 0,
  planId: '',
  dateKey: '',
  planRevision: 0,
  inputsRevision: 0,
  scaleMode: 'preserve_recipe_ratios',
  result: null,
  errorMessage: null,
};

export function createMacroTargetFitScheduler(deps?: {
  debounceMs?: number;
  runner?: MacroFitRunner;
}): MacroTargetFitScheduler {
  const debounceMs =
    typeof deps?.debounceMs === 'number' && Number.isFinite(deps.debounceMs) && deps.debounceMs >= 0
      ? deps.debounceMs
      : 300;
  const runner: MacroFitRunner = deps?.runner ?? runMacroTargetFitAsync;

  let snapshot: MacroFitProposalSnapshot = { ...INITIAL_SNAPSHOT };
  let latestRequestId = 0;
  let latestPlanRevision = 0;
  let latestInputsRevision = 0;
  let pendingTimer: ReturnType<typeof setTimeout> | null = null;
  let disposed = false;
  const listeners = new Set<(snap: MacroFitProposalSnapshot) => void>();

  const emit = (next: MacroFitProposalSnapshot) => {
    snapshot = next;
    for (const listener of listeners) {
      listener(snapshot);
    }
  };

  const clearTimer = () => {
    if (pendingTimer !== null) {
      clearTimeout(pendingTimer);
      pendingTimer = null;
    }
  };

  return {
    schedule: (req) => {
      if (disposed) return;
      clearTimer();

      latestPlanRevision = req.planRevision;
      latestInputsRevision = req.inputsRevision;
      const scaleMode: MacroFitScaleMode = req.options?.scaleMode ?? 'preserve_recipe_ratios';

      emit({
        status: 'scheduled',
        requestId: latestRequestId,
        planId: req.planId,
        dateKey: req.dateKey,
        planRevision: req.planRevision,
        inputsRevision: req.inputsRevision,
        scaleMode,
        result: snapshot.planId === req.planId && snapshot.dateKey === req.dateKey ? snapshot.result : null,
        errorMessage: null,
      });

      const dispatch = () => {
        if (disposed) return;
        pendingTimer = null;
        const dispatchRequestId = ++latestRequestId;
        const expectedPlanRevision = req.planRevision;
        const expectedInputsRevision = req.inputsRevision;

        emit({
          status: 'calculating',
          requestId: dispatchRequestId,
          planId: req.planId,
          dateKey: req.dateKey,
          planRevision: expectedPlanRevision,
          inputsRevision: expectedInputsRevision,
          scaleMode,
          result: snapshot.planId === req.planId && snapshot.dateKey === req.dateKey ? snapshot.result : null,
          errorMessage: null,
        });

        void runner(req.dayPlan, req.targets, req.options)
          .then((result) => {
            if (disposed) return;
            // Stale-guard: ignore out-of-order or superseded optimization runs
            if (
              dispatchRequestId !== latestRequestId ||
              expectedPlanRevision !== latestPlanRevision ||
              expectedInputsRevision !== latestInputsRevision
            ) {
              return;
            }
            emit({
              status: result.status === 'infeasible' ? 'infeasible' : 'ready',
              requestId: dispatchRequestId,
              planId: req.planId,
              dateKey: req.dateKey,
              planRevision: expectedPlanRevision,
              inputsRevision: expectedInputsRevision,
              scaleMode,
              result,
              errorMessage: result.status === 'infeasible' ? (result.blockReason ?? result.proposal.explanation) : null,
            });
          })
          .catch((error: unknown) => {
            if (disposed) return;
            if (
              dispatchRequestId !== latestRequestId ||
              expectedPlanRevision !== latestPlanRevision ||
              expectedInputsRevision !== latestInputsRevision
            ) {
              return;
            }
            emit({
              status: 'failed',
              requestId: dispatchRequestId,
              planId: req.planId,
              dateKey: req.dateKey,
              planRevision: expectedPlanRevision,
              inputsRevision: expectedInputsRevision,
              scaleMode,
              result: null,
              errorMessage:
                error instanceof Error && error.message
                  ? error.message
                  : 'Não foi possível calcular o ajuste automático do cardápio.',
            });
          });
      };

      if (debounceMs === 0) {
        dispatch();
      } else {
        pendingTimer = setTimeout(dispatch, debounceMs);
      }
    },

    invalidateToStale: (planRevision, inputsRevision) => {
      if (disposed) return;
      clearTimer();
      latestPlanRevision = planRevision;
      latestInputsRevision = inputsRevision;
      latestRequestId += 1;
      if (snapshot.status === 'idle') return;
      emit({
        ...snapshot,
        status: 'stale',
        planRevision,
        inputsRevision,
      });
    },

    dismiss: () => {
      if (disposed) return;
      clearTimer();
      latestRequestId += 1;
      emit({
        ...snapshot,
        status: 'idle',
        result: null,
        errorMessage: null,
      });
    },

    reset: () => {
      if (disposed) return;
      clearTimer();
      latestRequestId += 1;
      emit({ ...INITIAL_SNAPSHOT });
    },

    dispose: () => {
      disposed = true;
      clearTimer();
      listeners.clear();
    },

    getSnapshot: () => snapshot,

    subscribe: (listener) => {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
  };
}
