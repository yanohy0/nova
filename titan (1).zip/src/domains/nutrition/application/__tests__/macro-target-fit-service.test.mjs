import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import esbuild from 'esbuild';
import { ensureTbcaCatalogLoaded } from '../../data/sources/tbca-adapter.ts';
import { buildComposerDayFromMeals } from '../../domain/rules/cardapio-composer-engine.ts';

await ensureTbcaCatalogLoaded();

const tmpRoot = path.resolve('node_modules');
await fs.mkdir(tmpRoot, { recursive: true });
const tmpDir = await fs.mkdtemp(path.join(tmpRoot, '.tmp-macro-service-'));

try {
  await esbuild.build({
    entryPoints: [
      path.resolve('src/domains/nutrition/application/macro-target-fit-service.ts'),
      path.resolve('src/domains/nutrition/application/composer-optimizer-client.ts'),
      path.resolve('src/domains/nutrition/domain/rules/macro-target-fit.ts'),
    ],
    outdir: tmpDir,
    bundle: true,
    format: 'esm',
    platform: 'node',
    outExtension: { '.js': '.mjs' },
  });

  const { createMacroTargetFitScheduler } = await import(
    pathToFileURL(path.join(tmpDir, 'application/macro-target-fit-service.mjs')).href
  );
  const { resetComposerOptimizerClientForTests, runMacroTargetFitAsync } = await import(
    pathToFileURL(path.join(tmpDir, 'application/composer-optimizer-client.mjs')).href
  );
  const { solveMacroTargetFitQP } = await import(
    pathToFileURL(path.join(tmpDir, 'domain/rules/macro-target-fit.mjs')).href
  );

  const dayPlan = buildComposerDayFromMeals('2026-11-26', []);
  dayPlan.slots = [
    {
      id: 'slot-1',
      time: '12:00',
      title: 'Almoço',
      recipes: [
        {
          id: 'rec-1',
          name: 'Ovo Mexido Simples',
          category: 'almoco',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'balanced',
          ingredients: [
            {
              id: 'i-egg',
              foodId: 'tbca-ovo-mexido',
              displayName: 'Ovo mexido',
              baseQuantityG: 140,
              currentQuantityG: 140,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 60,
              maxQuantityG: 320,
            },
          ],
        },
      ],
    },
  ];
  const targets = { kcal: 300, proteinG: 20, carbsG: 3, fatG: 22 };

  // 1. Debounced coalescing: rapid burst triggers only ONE execution for the latest revision
  let runCount = 0;
  let capturedRevs = [];
  const scheduler = createMacroTargetFitScheduler({
    debounceMs: 35,
    runner: async (plan, t, opts) => {
      runCount += 1;
      capturedRevs.push(opts?.requestTag);
      return solveMacroTargetFitQP(plan, t, opts);
    },
  });

  const statuses = [];
  const unsub = scheduler.subscribe((snap) => statuses.push(`${snap.status}:${snap.planRevision}`));

  scheduler.schedule({
    planId: 'p1',
    dateKey: '2026-11-26',
    planRevision: 1,
    inputsRevision: 1,
    dayPlan,
    targets,
    options: { requestTag: 'rev1' },
  });
  scheduler.schedule({
    planId: 'p1',
    dateKey: '2026-11-26',
    planRevision: 2,
    inputsRevision: 2,
    dayPlan,
    targets,
    options: { requestTag: 'rev2' },
  });
  scheduler.schedule({
    planId: 'p1',
    dateKey: '2026-11-26',
    planRevision: 3,
    inputsRevision: 3,
    dayPlan,
    targets,
    options: { requestTag: 'rev3' },
  });

  assert.equal(scheduler.getSnapshot().status, 'scheduled');
  await new Promise((r) => setTimeout(r, 85));
  assert.equal(runCount, 1, 'rapid edits must coalesce into single optimizer invocation');
  assert.deepEqual(capturedRevs, ['rev3']);
  assert.equal(scheduler.getSnapshot().status, 'ready');
  assert.equal(scheduler.getSnapshot().planRevision, 3);
  assert.ok(statuses.includes('calculating:3'));
  assert.ok(statuses.includes('ready:3'));
  unsub();
  scheduler.dispose();

  // 2. Out-of-order response discard: rev 10 takes 70ms, rev 11 takes 15ms; rev 10 resolving later MUST be discarded
  const deferredResolvers = {};
  const raceScheduler = createMacroTargetFitScheduler({
    debounceMs: 5,
    runner: (plan, t, opts) =>
      new Promise((resolve) => {
        const tag = opts?.requestTag ?? 'x';
        deferredResolvers[tag] = () => resolve(solveMacroTargetFitQP(plan, t, opts));
      }),
  });

  raceScheduler.schedule({
    planId: 'p1',
    dateKey: '2026-11-26',
    planRevision: 10,
    inputsRevision: 10,
    dayPlan,
    targets,
    options: { requestTag: 'r10' },
  });
  await new Promise((r) => setTimeout(r, 20)); // r10 dispatched

  raceScheduler.schedule({
    planId: 'p1',
    dateKey: '2026-11-26',
    planRevision: 11,
    inputsRevision: 11,
    dayPlan,
    targets,
    options: { requestTag: 'r11' },
  });
  await new Promise((r) => setTimeout(r, 20)); // r11 dispatched

  // Resolve newer r11 first
  deferredResolvers.r11();
  await new Promise((r) => setTimeout(r, 10));
  assert.equal(raceScheduler.getSnapshot().status, 'ready');
  assert.equal(raceScheduler.getSnapshot().planRevision, 11);

  // Now old r10 resolves late — MUST be silently discarded!
  deferredResolvers.r10();
  await new Promise((r) => setTimeout(r, 10));
  assert.equal(raceScheduler.getSnapshot().status, 'ready');
  assert.equal(raceScheduler.getSnapshot().planRevision, 11, 'stale out-of-order response must never overwrite newer revision');
  raceScheduler.dispose();

  // 3. Zod strict worker boundary: malformed worker response falls back safely to deterministic TS solver
  const origWorker = globalThis.Worker;
  try {
    class MalformedWorker {
      onmessage = null;
      onerror = null;
      onmessageerror = null;
      postMessage(payload) {
        setTimeout(() => {
          this.onmessage?.({
            data: {
              requestId: payload.requestId,
              kind: 'macro_target_fit',
              result: { status: 'NOT_A_VALID_STATUS', broken: true },
            },
          });
        }, 5);
      }
      terminate() {}
    }
    globalThis.Worker = MalformedWorker;
    resetComposerOptimizerClientForTests();
    const fallbackResult = await runMacroTargetFitAsync(dayPlan, targets, { timeoutMs: 100 });
    assert.ok(fallbackResult.proposal.afterMacros.kcal > 0, 'invalid worker payload rejected by Zod must trigger safe TS fallback');
    assert.equal(fallbackResult.proposal.scaleMode, 'preserve_recipe_ratios');
  } finally {
    globalThis.Worker = origWorker;
  }

  console.log('macro-target-fit-service.test.mjs: PASS');
} finally {
  await fs.rm(tmpDir, { recursive: true, force: true });
}
