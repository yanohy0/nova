import type {
  ComposerDayPlan,
  NutritionTargets,
  OptimizationProposal,
} from '../entities/nutrient.ts';
import {
  computeDayNutrition,
  getOptimizationProposalBlockReason,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
  type PreparedMicronutrientConstraint,
} from './cardapio-composer-engine.ts';
import { resolveMicronutrientResidualScales } from './micronutrient-optimization-scales.ts';
import {
  buildRecipeScaleModel,
  type RecipeScaleBaselineSource,
} from './recipe-scale-model.ts';
import {
  quantizeAndValidateRecipeScaleProposal,
  type MacroFitStatus,
  type RecipeScaleQuantizationResult,
} from './recipe-scale-quantization.ts';

export type MacroFitScaleMode = 'preserve_recipe_ratios' | 'ingredient_flexible';

export interface MacroTargetFitOptions extends OptimizeBalanceOptions {
  scaleMode?: MacroFitScaleMode;
  baselineSource?: RecipeScaleBaselineSource;
}

export function wrapFlexibleProposalAsResult(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  proposal: OptimizationProposal,
): RecipeScaleQuantizationResult {
  const beforeSummary = computeDayNutrition(dayPlan);
  const afterSummary = computeDayNutrition(proposal.proposedDayPlan);
  const blockReason = getOptimizationProposalBlockReason(proposal);

  const hasIncompleteData =
    afterSummary.unresolvedFoodIds.length > 0 ||
    afterSummary.lowConfidenceFoodIds.length > 0 ||
    afterSummary.missingIngredientsCount > 0 ||
    afterSummary.toTasteIngredientsCount > 0 ||
    afterSummary.coveragePercent < 99.99 ||
    (proposal.micronutrientResults ?? []).some((r) => r.status === 'insufficient_data');

  let status: MacroFitStatus = 'target_met';
  if (blockReason !== null) {
    status = 'infeasible';
  } else if (hasIncompleteData) {
    status = 'insufficient_data';
  } else if (proposal.certificate !== 'optimal') {
    status = 'approximate_feasible';
  }

  proposal.scaleMode = 'ingredient_flexible';
  proposal.macroFitStatus = status;
  proposal.recipeScales = [];

  return {
    status,
    proposal,
    beforeSummary,
    afterSummary,
    beforeGaps: {
      kcalDiff: Number((beforeSummary.macros.kcal - targets.kcal).toFixed(1)),
      proteinDiffG: Number((beforeSummary.macros.proteinG - targets.proteinG).toFixed(1)),
      carbsDiffG: Number((beforeSummary.macros.carbsG - targets.carbsG).toFixed(1)),
      fatDiffG: Number((beforeSummary.macros.fatG - targets.fatG).toFixed(1)),
    },
    afterGaps: {
      kcalDiff: Number((afterSummary.macros.kcal - targets.kcal).toFixed(1)),
      proteinDiffG: Number((afterSummary.macros.proteinG - targets.proteinG).toFixed(1)),
      carbsDiffG: Number((afterSummary.macros.carbsG - targets.carbsG).toFixed(1)),
      fatDiffG: Number((afterSummary.macros.fatG - targets.fatG).toFixed(1)),
    },
    recipeScales: [],
    blockReason,
  };
}

export function attachRecipeScaleProposalMetadata(
  result: RecipeScaleQuantizationResult,
  scaleMode: MacroFitScaleMode = 'preserve_recipe_ratios',
): RecipeScaleQuantizationResult {
  result.proposal.scaleMode = scaleMode;
  result.proposal.macroFitStatus = result.status;
  result.proposal.recipeScales = result.recipeScales;
  return result;
}

/**
 * Deterministic multi-macro QP optimizer over per-recipe scale factors s_0..s_{m-1}.
 * Default mode (`preserve_recipe_ratios`) scales unlocked known ingredients within each
 * recipe jointly so internal culinary ratios remain intact.
 */
export function solveMacroTargetFitQP(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: MacroTargetFitOptions = {},
): RecipeScaleQuantizationResult {
  const scaleMode: MacroFitScaleMode = options.scaleMode ?? 'preserve_recipe_ratios';
  if (scaleMode === 'ingredient_flexible') {
    const flexibleProposal = solveNutritionalBalanceQP(dayPlan, targets, options);
    return wrapFlexibleProposalAsResult(dayPlan, targets, flexibleProposal);
  }

  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const model = buildRecipeScaleModel(dayPlan, targets, options);
  const { lambda, weights, scales, fixedTotals, vars, slotTargets } = model;
  const m = vars.length;

  if (m === 0) {
    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
    return attachRecipeScaleProposalMetadata(
      quantizeAndValidateRecipeScaleProposal(dayPlan, targets, model, [], t1 - t0, {
        solverEngine: 'Escala Proporcional por Receita (QP FISTA)',
        hasSolverWarning: true,
        warningReason:
          'Nenhuma receita possui ingredientes escaláveis e quantificados disponíveis. Destrave ao menos um ingrediente ou ajuste manualmente.',
      }),
    );
  }

  const invScale2 = {
    kcal: (2 * weights.kcal) / (scales.kcal * scales.kcal),
    proteinG: (2 * weights.proteinG) / (scales.proteinG * scales.proteinG),
    carbsG: (2 * weights.carbsG) / (scales.carbsG * scales.carbsG),
    fatG: (2 * weights.fatG) / (scales.fatG * scales.fatG),
  };

  const MICRO_SOFT_WEIGHT = 0.08;
  const activeMicronutrients = model.micronutrientConstraints.filter((c) => c.status === 'applied');
  const microResidualScales = activeMicronutrients.map((c) => resolveMicronutrientResidualScales(c));
  const microMinimumInvScale2 = microResidualScales.map(
    ({ minimum }) => (2 * MICRO_SOFT_WEIGHT) / (minimum * minimum),
  );
  const microPreferredMaximumInvScale2 = microResidualScales.map(
    ({ preferredMaximum }) => (2 * MICRO_SOFT_WEIGHT) / (preferredMaximum * preferredMaximum),
  );

  const slotIndexMap = new Map<string, number>();
  slotTargets.forEach((st, idx) => slotIndexMap.set(st.slotId, idx));
  const varSlotIdx = new Int32Array(m);
  const slotInv2Kcal = new Float64Array(slotTargets.length);
  const slotInv2P = new Float64Array(slotTargets.length);
  const slotInv2C = new Float64Array(slotTargets.length);
  const slotInv2F = new Float64Array(slotTargets.length);
  const slotMacroWeight = 0.28;

  for (let s = 0; s < slotTargets.length; s += 1) {
    const st = slotTargets[s]!;
    slotInv2Kcal[s] = (2 * st.weightKcal) / (st.scaleKcal * st.scaleKcal);
    slotInv2P[s] =
      st.targetProteinG !== null ? (2 * slotMacroWeight) / (st.scaleProteinG * st.scaleProteinG) : 0;
    slotInv2C[s] =
      st.targetCarbsG !== null ? (2 * slotMacroWeight) / (st.scaleCarbsG * st.scaleCarbsG) : 0;
    slotInv2F[s] =
      st.targetFatG !== null ? (2 * slotMacroWeight) / (st.scaleFatG * st.scaleFatG) : 0;
  }

  let sumA2Kcal = 0;
  let sumA2P = 0;
  let sumA2C = 0;
  let sumA2F = 0;
  let maxSlotHessian = 0;
  const proxCoeff = (2 * lambda) / (1.25 * 1.25);

  for (let r = 0; r < m; r += 1) {
    const v = vars[r]!;
    const sIdx = slotIndexMap.get(v.slotId) ?? -1;
    varSlotIdx[r] = sIdx;
    sumA2Kcal += v.kcalPerUnitScale * v.kcalPerUnitScale;
    sumA2P += v.proteinPerUnitScale * v.proteinPerUnitScale;
    sumA2C += v.carbsPerUnitScale * v.carbsPerUnitScale;
    sumA2F += v.fatPerUnitScale * v.fatPerUnitScale;
    if (sIdx >= 0) {
      maxSlotHessian +=
        slotInv2Kcal[sIdx]! * v.kcalPerUnitScale * v.kcalPerUnitScale +
        slotInv2P[sIdx]! * v.proteinPerUnitScale * v.proteinPerUnitScale +
        slotInv2C[sIdx]! * v.carbsPerUnitScale * v.carbsPerUnitScale +
        slotInv2F[sIdx]! * v.fatPerUnitScale * v.fatPerUnitScale;
    }
  }

  const lipschitz =
    invScale2.kcal * sumA2Kcal +
    invScale2.proteinG * sumA2P +
    invScale2.carbsG * sumA2C +
    invScale2.fatG * sumA2F +
    maxSlotHessian +
    proxCoeff +
    activeMicronutrients.reduce((sum, constraint, cIdx) => {
      const coeffNorm = constraint.coefficients.reduce((norm, c) => norm + c * c, 0);
      return (
        sum +
        Math.max(microMinimumInvScale2[cIdx]!, microPreferredMaximumInvScale2[cIdx]!) * coeffNorm
      );
    }, 0) +
    1e-9;
  const stepSize = 1 / lipschitz;

  const s = new Float64Array(m);
  const y = new Float64Array(m);
  const sPrev = new Float64Array(m);
  const grad = new Float64Array(m);
  const slotKcal = new Float64Array(slotTargets.length);
  const slotP = new Float64Array(slotTargets.length);
  const slotC = new Float64Array(slotTargets.length);
  const slotF = new Float64Array(slotTargets.length);

  for (let r = 0; r < m; r += 1) {
    const v = vars[r]!;
    const init = Math.max(v.minScale, Math.min(v.maxScale, v.refScale));
    s[r] = init;
    y[r] = init;
    sPrev[r] = init;
  }

  const computeTotals = (vec: Float64Array) => {
    let kcal = fixedTotals.kcal;
    let proteinG = fixedTotals.proteinG;
    let carbsG = fixedTotals.carbsG;
    let fatG = fixedTotals.fatG;
    for (let k = 0; k < slotTargets.length; k += 1) {
      const st = slotTargets[k]!;
      slotKcal[k] = st.fixedKcal;
      slotP[k] = st.fixedProteinG;
      slotC[k] = st.fixedCarbsG;
      slotF[k] = st.fixedFatG;
    }
    for (let r = 0; r < m; r += 1) {
      const v = vars[r]!;
      const scale = vec[r]!;
      const dK = v.kcalPerUnitScale * scale;
      const dP = v.proteinPerUnitScale * scale;
      const dC = v.carbsPerUnitScale * scale;
      const dF = v.fatPerUnitScale * scale;
      kcal += dK;
      proteinG += dP;
      carbsG += dC;
      fatG += dF;
      const sIdx = varSlotIdx[r]!;
      if (sIdx >= 0) {
        slotKcal[sIdx]! += dK;
        slotP[sIdx]! += dP;
        slotC[sIdx]! += dC;
        slotF[sIdx]! += dF;
      }
    }
    return { kcal, proteinG, carbsG, fatG };
  };

  const getMicroTotal = (vec: Float64Array, c: PreparedMicronutrientConstraint) =>
    c.fixedValue + c.coefficients.reduce((acc, coeff, idx) => acc + coeff * vec[idx]!, 0);

  const microResidual = (value: number, c: PreparedMicronutrientConstraint) => {
    if (c.minimum !== null && value < c.minimum) return value - c.minimum;
    if (c.preferredMaximum !== null && value > c.preferredMaximum) return value - c.preferredMaximum;
    return 0;
  };

  const ulConstraints = activeMicronutrients.filter((c) => c.upperLimit !== null);
  const projectHardUpperLimits = (vec: Float64Array): boolean => {
    for (let iter = 0; iter < 100; iter += 1) {
      for (let r = 0; r < m; r += 1) {
        const v = vars[r]!;
        vec[r] = Math.max(v.minScale, Math.min(v.maxScale, vec[r]!));
      }
      for (const constraint of ulConstraints) {
        const limit = constraint.upperLimit!;
        const violation = getMicroTotal(vec, constraint) - limit;
        if (violation <= 1e-7) continue;
        const normSq = constraint.coefficients.reduce((sum, c) => sum + c * c, 0);
        if (normSq <= 1e-16) continue;
        const mult = violation / normSq;
        for (let r = 0; r < m; r += 1) {
          const v = vars[r]!;
          vec[r] = Math.max(
            v.minScale,
            Math.min(v.maxScale, vec[r]! - mult * (constraint.coefficients[r] ?? 0)),
          );
        }
      }
      const maxViol = ulConstraints.reduce(
        (mx, c) => Math.max(mx, getMicroTotal(vec, c) - c.upperLimit!),
        0,
      );
      if (maxViol <= 1e-6) return true;
    }
    return ulConstraints.every((c) => getMicroTotal(vec, c) <= c.upperLimit! + 1e-6);
  };

  const initialUlOk = projectHardUpperLimits(s);
  y.set(s);
  sPrev.set(s);

  const computeGradAt = (vec: Float64Array, outGrad: Float64Array) => {
    const totals = computeTotals(vec);
    const resKcal = (totals.kcal - targets.kcal) * invScale2.kcal;
    const resP = (totals.proteinG - targets.proteinG) * invScale2.proteinG;
    const resC = (totals.carbsG - targets.carbsG) * invScale2.carbsG;
    const resF = (totals.fatG - targets.fatG) * invScale2.fatG;

    for (let r = 0; r < m; r += 1) {
      const v = vars[r]!;
      let g =
        resKcal * v.kcalPerUnitScale +
        resP * v.proteinPerUnitScale +
        resC * v.carbsPerUnitScale +
        resF * v.fatPerUnitScale +
        proxCoeff * (vec[r]! - v.refScale);
      const sIdx = varSlotIdx[r]!;
      if (sIdx >= 0) {
        const st = slotTargets[sIdx]!;
        g += (slotKcal[sIdx]! - st.targetKcal) * slotInv2Kcal[sIdx]! * v.kcalPerUnitScale;
        if (st.targetProteinG !== null) {
          g += (slotP[sIdx]! - st.targetProteinG) * slotInv2P[sIdx]! * v.proteinPerUnitScale;
        }
        if (st.targetCarbsG !== null) {
          g += (slotC[sIdx]! - st.targetCarbsG) * slotInv2C[sIdx]! * v.carbsPerUnitScale;
        }
        if (st.targetFatG !== null) {
          g += (slotF[sIdx]! - st.targetFatG) * slotInv2F[sIdx]! * v.fatPerUnitScale;
        }
      }
      for (let cIdx = 0; cIdx < activeMicronutrients.length; cIdx += 1) {
        const c = activeMicronutrients[cIdx]!;
        const residual = microResidual(getMicroTotal(vec, c), c);
        if (residual !== 0) {
          const rScale2 =
            residual < 0 ? microMinimumInvScale2[cIdx]! : microPreferredMaximumInvScale2[cIdx]!;
          g += residual * rScale2 * (c.coefficients[r] ?? 0);
        }
      }
      outGrad[r] = g;
    }
  };

  let tMomentum = 1;
  for (let iter = 0; iter < 320; iter += 1) {
    computeGradAt(y, grad);
    let restartDot = 0;
    let maxMove = 0;
    for (let r = 0; r < m; r += 1) {
      const v = vars[r]!;
      const rawNext = y[r]! - stepSize * grad[r]!;
      const clamped = Math.max(v.minScale, Math.min(v.maxScale, rawNext));
      sPrev[r] = s[r]!;
      s[r] = clamped;
      restartDot += (y[r]! - clamped) * (clamped - sPrev[r]!);
      const diff = Math.abs(clamped - sPrev[r]!);
      if (diff > maxMove) maxMove = diff;
    }
    projectHardUpperLimits(s);

    if (restartDot > 0) {
      tMomentum = 1;
      y.set(s);
    } else {
      const tNext = 0.5 * (1 + Math.sqrt(1 + 4 * tMomentum * tMomentum));
      const beta = (tMomentum - 1) / tNext;
      for (let r = 0; r < m; r += 1) {
        const v = vars[r]!;
        const extrapolated = s[r]! + beta * (s[r]! - sPrev[r]!);
        y[r] = Math.max(v.minScale, Math.min(v.maxScale, extrapolated));
      }
      projectHardUpperLimits(y);
      tMomentum = tNext;
    }

    if (maxMove < 1e-6 && iter > 20) break;
  }

  // Coordinate descent polish
  for (let sweep = 0; sweep < 40; sweep += 1) {
    let sweepDelta = 0;
    const totals = computeTotals(s);
    let curKcal = totals.kcal;
    let curP = totals.proteinG;
    let curC = totals.carbsG;
    let curF = totals.fatG;

    for (let r = 0; r < m; r += 1) {
      const v = vars[r]!;
      const oldSr = s[r]!;
      const sIdx = varSlotIdx[r]!;
      let hDiag =
        invScale2.kcal * v.kcalPerUnitScale * v.kcalPerUnitScale +
        invScale2.proteinG * v.proteinPerUnitScale * v.proteinPerUnitScale +
        invScale2.carbsG * v.carbsPerUnitScale * v.carbsPerUnitScale +
        invScale2.fatG * v.fatPerUnitScale * v.fatPerUnitScale +
        proxCoeff;

      let gCoord =
        (curKcal - targets.kcal) * invScale2.kcal * v.kcalPerUnitScale +
        (curP - targets.proteinG) * invScale2.proteinG * v.proteinPerUnitScale +
        (curC - targets.carbsG) * invScale2.carbsG * v.carbsPerUnitScale +
        (curF - targets.fatG) * invScale2.fatG * v.fatPerUnitScale +
        proxCoeff * (oldSr - v.refScale);

      if (sIdx >= 0) {
        const st = slotTargets[sIdx]!;
        hDiag +=
          slotInv2Kcal[sIdx]! * v.kcalPerUnitScale * v.kcalPerUnitScale +
          slotInv2P[sIdx]! * v.proteinPerUnitScale * v.proteinPerUnitScale +
          slotInv2C[sIdx]! * v.carbsPerUnitScale * v.carbsPerUnitScale +
          slotInv2F[sIdx]! * v.fatPerUnitScale * v.fatPerUnitScale;
        gCoord += (slotKcal[sIdx]! - st.targetKcal) * slotInv2Kcal[sIdx]! * v.kcalPerUnitScale;
        if (st.targetProteinG !== null) {
          gCoord += (slotP[sIdx]! - st.targetProteinG) * slotInv2P[sIdx]! * v.proteinPerUnitScale;
        }
        if (st.targetCarbsG !== null) {
          gCoord += (slotC[sIdx]! - st.targetCarbsG) * slotInv2C[sIdx]! * v.carbsPerUnitScale;
        }
        if (st.targetFatG !== null) {
          gCoord += (slotF[sIdx]! - st.targetFatG) * slotInv2F[sIdx]! * v.fatPerUnitScale;
        }
      }

      for (let cIdx = 0; cIdx < activeMicronutrients.length; cIdx += 1) {
        const c = activeMicronutrients[cIdx]!;
        const coeff = c.coefficients[r] ?? 0;
        if (coeff === 0) continue;
        const val = getMicroTotal(s, c);
        const residual = microResidual(val, c);
        if (residual !== 0) {
          const rScale2 =
            residual < 0 ? microMinimumInvScale2[cIdx]! : microPreferredMaximumInvScale2[cIdx]!;
          hDiag += rScale2 * coeff * coeff;
          gCoord += residual * rScale2 * coeff;
        }
      }

      if (hDiag <= 1e-12) continue;
      let upperBoundByUL = v.maxScale;
      for (const c of ulConstraints) {
        const coeff = c.coefficients[r] ?? 0;
        if (coeff <= 1e-12) continue;
        const currentTotal = getMicroTotal(s, c);
        const slack = c.upperLimit! - (currentTotal - coeff * oldSr);
        upperBoundByUL = Math.min(upperBoundByUL, slack / coeff);
      }
      if (upperBoundByUL < v.minScale - 1e-6) continue;
      const effUpper = Math.max(v.minScale, upperBoundByUL);
      const nextSr = Math.max(v.minScale, Math.min(effUpper, oldSr - gCoord / hDiag));
      const dS = nextSr - oldSr;
      if (Math.abs(dS) > 1e-6) {
        s[r] = nextSr;
        curKcal += v.kcalPerUnitScale * dS;
        curP += v.proteinPerUnitScale * dS;
        curC += v.carbsPerUnitScale * dS;
        curF += v.fatPerUnitScale * dS;
        if (sIdx >= 0) {
          slotKcal[sIdx]! += v.kcalPerUnitScale * dS;
          slotP[sIdx]! += v.proteinPerUnitScale * dS;
          slotC[sIdx]! += v.carbsPerUnitScale * dS;
          slotF[sIdx]! += v.fatPerUnitScale * dS;
        }
        sweepDelta += Math.abs(dS);
      }
    }
    if (sweepDelta < 1e-6) break;
  }

  const finalUlOk = projectHardUpperLimits(s);
  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const hasInfeasibleError =
    model.hasContradictoryBounds ||
    model.micronutrientConstraints.some((c) => c.status === 'infeasible_upper_limit') ||
    !initialUlOk ||
    !finalUlOk;

  return attachRecipeScaleProposalMetadata(
    quantizeAndValidateRecipeScaleProposal(dayPlan, targets, model, Array.from(s), t1 - t0, {
      solverEngine: 'Escala Proporcional por Receita (QP FISTA)',
      hasInfeasibleError,
    }),
    'preserve_recipe_ratios',
  );
}
