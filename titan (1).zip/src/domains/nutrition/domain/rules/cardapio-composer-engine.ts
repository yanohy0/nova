import { RECIPE_CATALOG, findRecipeById } from '../../data/recipes/recipe-catalog.ts';
import { shiftLocalDateKey } from '../../../../shared/utils/local-date.ts';
import {
  MICRONUTRIENT_ORDER,
  type CardapioPlan,
  type ComposerAdjustmentMode,
  type ComposerDayPlan,
  type ComposerMacroTotals,
  type ComposerMealSlot,
  type DailyMicronutrientOptimizationTarget,
  type DiscreteSubstitutionProposal,
  type FoodSourceId,
  type IngredientAdjustment,
  type MealFoodPortion,
  type MealItem,
  type MealTargetAllocation,
  type NutrientDataStatus,
  type NutrientId,
  type MicronutrientOptimizationResult,
  type MicronutrientOptimizationStatus,
  type NutritionTargets,
  type OptimizationProposal,
  type ProposedIngredientChange,
  type RecipeInstance,
  type RecipeItem,
  type SolverCertificate,
} from '../entities/nutrient.ts';
import { normalizeNutrientEntry, resolveFoodById } from './nutrition-calculator.ts';
import { validateFoodMacroComposition } from './food-data-quality.ts';
import { isCompositeFood } from './food-ingredient-policy.ts';
import { isEligibleRecipeTemplate } from './recipe-engine.ts';
import { resolveMicronutrientResidualScales } from './micronutrient-optimization-scales.ts';

const COMPOSITE_DISH_FOOD_IDS = new Set([
  'tbca-frango-arroz-legumes',
  'tbca-salmao-batata-doce',
  'tbca-mamao-aveia',
]);

const DEFAULT_MEAL_SHARE_PERCENTS: readonly number[] = [22, 33, 18, 27];

export const KEY_COMPOSER_MICRONUTRIENTS: readonly NutrientId[] = [
  'iron',
  'calcium',
  'potassium',
  'sodium',
  'vitamin_c',
  'magnesium',
];

export const MICRONUTRIENT_PT_LABELS: Record<NutrientId, { label: string; unit: string }> = {
  vitamin_a: { label: 'Vitamina A', unit: 'µg RAE' },
  vitamin_c: { label: 'Vitamina C', unit: 'mg' },
  vitamin_d: { label: 'Vitamina D', unit: 'µg' },
  vitamin_e: { label: 'Vitamina E', unit: 'mg' },
  vitamin_k: { label: 'Vitamina K', unit: 'µg' },
  vitamin_b1: { label: 'Tiamina (B1)', unit: 'mg' },
  vitamin_b2: { label: 'Riboflavina (B2)', unit: 'mg' },
  vitamin_b3: { label: 'Niacina (B3)', unit: 'mg NE' },
  vitamin_b5: { label: 'Ác. Pantotênico (B5)', unit: 'mg' },
  vitamin_b6: { label: 'Piridoxina (B6)', unit: 'mg' },
  vitamin_b7: { label: 'Biotina (B7)', unit: 'µg' },
  vitamin_b9: { label: 'Folato (B9)', unit: 'µg DFE' },
  vitamin_b12: { label: 'Vitamina B12', unit: 'µg' },
  calcium: { label: 'Cálcio', unit: 'mg' },
  copper: { label: 'Cobre', unit: 'µg' },
  iron: { label: 'Ferro', unit: 'mg' },
  phosphorus: { label: 'Fósforo', unit: 'mg' },
  magnesium: { label: 'Magnésio', unit: 'mg' },
  manganese: { label: 'Manganês', unit: 'mg' },
  potassium: { label: 'Potássio', unit: 'mg' },
  selenium: { label: 'Selênio', unit: 'µg' },
  sodium: { label: 'Sódio', unit: 'mg' },
  zinc: { label: 'Zinco', unit: 'mg' },
  choline: { label: 'Colina', unit: 'mg' },
  iodine: { label: 'Iodo', unit: 'µg' },
  chloride: { label: 'Cloreto', unit: 'mg' },
  molybdenum: { label: 'Molibdênio', unit: 'µg' },
  chromium: { label: 'Cromo', unit: 'µg' },
  fluoride: { label: 'Flúor', unit: 'mg' },
};

export function isCompositeFoodId(foodId: string): boolean {
  if (COMPOSITE_DISH_FOOD_IDS.has(foodId)) return true;
  return isCompositeFood(resolveFoodById(foodId));
}

export function roundGramsHalf(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round(value * 2) / 2;
}

export function cloneDayPlan(dayPlan: ComposerDayPlan): ComposerDayPlan {
  return {
    dateKey: dayPlan.dateKey,
    slots: dayPlan.slots.map((slot) => ({
      ...slot,
      recipes: slot.recipes.map((recipe) => ({
        ...recipe,
        ingredients: recipe.ingredients.map((ingredient) => ({ ...ingredient })),
      })),
    })),
  };
}

export function cloneCardapioPlan(plan: CardapioPlan): CardapioPlan {
  const days: Record<string, ComposerDayPlan> = {};
  for (const [dateKey, day] of Object.entries(plan.days)) {
    days[dateKey] = cloneDayPlan(day);
  }
  return {
    ...plan,
    targets: { ...plan.targets },
    mealAllocations: plan.mealAllocations.map((allocation) => ({ ...allocation })),
    days,
    variants: plan.variants.map((variant) => ({
      ...variant,
      macros: { ...variant.macros },
      dayPlan: cloneDayPlan(variant.dayPlan),
    })),
  };
}

export function createRecipeInstanceFromCatalog(
  recipe: RecipeItem,
  instanceId: string,
  targetServings = 1,
  adjustmentMode: ComposerAdjustmentMode = 'balanced',
): RecipeInstance {
  const safeTarget = Number.isFinite(targetServings)
    ? Math.max(0.25, Math.min(4, targetServings))
    : 1;
  return {
    id: instanceId,
    sourceRecipeId: recipe.id,
    name: recipe.name,
    description: recipe.description,
    category: recipe.category,
    imageUrl: recipe.imageUrl,
    baseServings: 1,
    targetServings: safeTarget,
    adjustmentMode,
    ingredients: recipe.ingredients.map((line, index) => {
      const scaled = roundGramsHalf(line.quantityG * safeTarget);
      const isComposite = isCompositeFoodId(line.ingredientId);
      return {
        id: `${instanceId}-ing-${index + 1}`,
        foodId: line.ingredientId,
        displayName: resolveFoodById(line.ingredientId)?.name ?? line.ingredientId,
        baseQuantityG: line.quantityG,
        currentQuantityG: scaled,
        quantityStatus: 'known',
        mode: adjustmentMode === 'proportional' ? 'proportional' : 'flexible',
        minQuantityG: Math.max(5, roundGramsHalf(scaled * 0.45)),
        maxQuantityG: Math.min(2000, Math.max(10, roundGramsHalf(scaled * 1.85))),
        isCompositeDish: isComposite,
      };
    }),
  };
}

export function createRecipeInstanceFromMeal(
  meal: MealItem,
  slotId: string,
): RecipeInstance {
  const catalogRecipe = meal.recipeId ? findRecipeById(meal.recipeId) : undefined;
  const inferredCategory: RecipeItem['category'] =
    catalogRecipe?.category ??
    (meal.time < '11:00'
      ? 'cafe'
      : meal.time < '15:00'
        ? 'almoco'
        : meal.time < '19:00'
          ? 'lanche'
          : 'jantar');

  const portions = meal.planned_foods.length > 0 ? meal.planned_foods : [];
  const ingredients: IngredientAdjustment[] = portions.map((portion, index) => {
    const baseFromRecipe =
      catalogRecipe?.ingredients.find((line) => line.ingredientId === portion.foodId)?.quantityG ??
      portion.quantityG;
    const isComposite = isCompositeFoodId(portion.foodId);
    const currentG = roundGramsHalf(portion.quantityG);
    const minG = Math.max(5, roundGramsHalf(baseFromRecipe * 0.45));
    const maxG = Math.min(2000, Math.max(minG + 10, roundGramsHalf(baseFromRecipe * 1.85)));
    return {
      id: `${slotId}-ing-${index + 1}`,
      foodId: portion.foodId,
      displayName: resolveFoodById(portion.foodId)?.name ?? portion.foodId,
      baseQuantityG: baseFromRecipe,
      currentQuantityG: currentG,
      quantityStatus: 'known',
      mode: 'flexible',
      minQuantityG: minG,
      maxQuantityG: maxG,
      isCompositeDish: isComposite,
    };
  });

  return {
    id: `${slotId}-rec-1`,
    sourceRecipeId: catalogRecipe?.id ?? meal.recipeId,
    name: catalogRecipe?.name ?? meal.title,
    description: catalogRecipe?.description ?? meal.description,
    category: inferredCategory,
    imageUrl: meal.imageUrl ?? catalogRecipe?.imageUrl,
    baseServings: 1,
    targetServings: 1,
    adjustmentMode: 'balanced',
    ingredients,
  };
}

export function buildComposerDayFromMeals(
  dateKey: string,
  dayMeals: readonly MealItem[],
): ComposerDayPlan {
  if (dayMeals.length > 0) {
    const sorted = [...dayMeals].sort((a, b) => a.time.localeCompare(b.time));
    return {
      dateKey,
      slots: sorted.map((meal, index) => {
        const slotId = meal.id || `slot-${dateKey}-${index + 1}`;
        return {
          id: slotId,
          time: meal.time,
          title: meal.title,
          linkedMealId: meal.id,
          recipes: [createRecipeInstanceFromMeal(meal, slotId)],
        };
      }),
    };
  }

  const defaults: Array<{
    id: string;
    time: string;
    title: string;
    recipeId: string;
  }> = [
    { id: 'slot-cafe', time: '07:30', title: 'Café da manhã', recipeId: 'rec-cafe-completo' },
    { id: 'slot-almoco', time: '12:30', title: 'Almoço', recipeId: 'rec-almoco-frango' },
    { id: 'slot-lanche', time: '16:00', title: 'Lanche da tarde', recipeId: 'rec-lanche-iogurte' },
    { id: 'slot-jantar', time: '20:30', title: 'Jantar', recipeId: 'rec-jantar-salmao' },
  ];

  return {
    dateKey,
    slots: defaults.map((item) => {
      const recipe = findRecipeById(item.recipeId) ?? RECIPE_CATALOG[0]!;
      return {
        id: item.id,
        time: item.time,
        title: item.title,
        recipes: [createRecipeInstanceFromCatalog(recipe, `${item.id}-rec-1`, 1, 'balanced')],
      };
    }),
  };
}

export function buildDefaultMealAllocations(slots: readonly ComposerMealSlot[]): MealTargetAllocation[] {
  if (slots.length === 0) return [];
  if (slots.length === DEFAULT_MEAL_SHARE_PERCENTS.length) {
    return slots.map((slot, index) => ({
      slotId: slot.id,
      energySharePercent: DEFAULT_MEAL_SHARE_PERCENTS[index] ?? 25,
    }));
  }
  const base = Math.floor((100 / slots.length) * 10) / 10;
  let running = 0;
  return slots.map((slot, index) => {
    if (index === slots.length - 1) {
      return {
        slotId: slot.id,
        energySharePercent: Math.max(0, Number((100 - running).toFixed(1))),
      };
    }
    running += base;
    return {
      slotId: slot.id,
      energySharePercent: base,
    };
  });
}

export function buildPlanDateRange(anchorDateKey: string, length = 7): string[] {
  const keys: string[] = [];
  for (let offset = -2; offset < length - 2; offset += 1) {
    const shifted = shiftLocalDateKey(anchorDateKey, offset);
    if (shifted) keys.push(shifted);
  }
  return keys.length > 0 ? keys : [anchorDateKey];
}

export function buildInitialComposerPlans(
  anchorDateKey: string,
  dailyGoals: { kcal: number; proteinG: number; carbsG: number; fatG: number },
  allMeals: readonly MealItem[],
): CardapioPlan[] {
  const dateRange = buildPlanDateRange(anchorDateKey, 7);
  const startDateKey = dateRange[0] ?? anchorDateKey;
  const endDateKey = dateRange[dateRange.length - 1] ?? anchorDateKey;

  const primaryDays: Record<string, ComposerDayPlan> = {};
  for (const dateKey of dateRange) {
    const dayMeals = allMeals.filter((meal) => meal.dateKey === dateKey);
    primaryDays[dateKey] = buildComposerDayFromMeals(dateKey, dayMeals);
  }

  const anchorDay = primaryDays[anchorDateKey] ?? buildComposerDayFromMeals(anchorDateKey, []);
  const primaryAllocations = buildDefaultMealAllocations(anchorDay.slots);

  const primaryPlan: CardapioPlan = {
    id: 'plan-principal',
    name: 'Plano principal · Equilíbrio ativo',
    revision: 4,
    status: 'active',
    startDateKey,
    endDateKey,
    targets: {
      kcal: dailyGoals.kcal,
      proteinG: dailyGoals.proteinG,
      carbsG: dailyGoals.carbsG,
      fatG: dailyGoals.fatG,
      kcalMin: Math.max(500, dailyGoals.kcal - 90),
      kcalMax: dailyGoals.kcal + 90,
      proteinMinG: Math.max(40, dailyGoals.proteinG - 10),
      proteinMaxG: dailyGoals.proteinG + 15,
      sourceLabel: 'Metas diárias TITAN',
    },
    mealAllocations: primaryAllocations,
    days: primaryDays,
    variants: [],
    activeVariantId: null,
  };

  // Secondary independent plan so side-by-side plan switching & comparison work out of the box
  const secondaryDays: Record<string, ComposerDayPlan> = {};
  for (const dateKey of dateRange) {
    const slots: ComposerMealSlot[] = [
      {
        id: 'sec-cafe',
        time: '07:30',
        title: 'Café da manhã',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-sanduiche-ovos') ?? RECIPE_CATALOG[0]!,
            'sec-cafe-rec-1',
            1,
            'balanced',
          ),
        ],
      },
      {
        id: 'sec-almoco',
        time: '12:30',
        title: 'Almoço',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-frango-leve') ?? RECIPE_CATALOG[1]!,
            'sec-almoco-rec-1',
            1,
            'balanced',
          ),
        ],
      },
      {
        id: 'sec-lanche',
        time: '16:00',
        title: 'Lanche da tarde',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-iogurte-leve') ?? RECIPE_CATALOG[2]!,
            'sec-lanche-rec-1',
            1,
            'balanced',
          ),
        ],
      },
      {
        id: 'sec-jantar',
        time: '20:30',
        title: 'Jantar',
        recipes: [
          createRecipeInstanceFromCatalog(
            findRecipeById('rec-sub-salmao-power') ?? RECIPE_CATALOG[3]!,
            'sec-jantar-rec-1',
            1,
            'balanced',
          ),
        ],
      },
    ];
    secondaryDays[dateKey] = { dateKey, slots };
  }

  const secondaryTargets: NutritionTargets = {
    kcal: Math.max(1400, Math.round(dailyGoals.kcal * 0.86)),
    proteinG: Math.max(100, Math.round(dailyGoals.proteinG * 1.02)),
    carbsG: Math.max(100, Math.round(dailyGoals.carbsG * 0.78)),
    fatG: Math.max(40, Math.round(dailyGoals.fatG * 0.85)),
    sourceLabel: 'Cenário de déficit controlado',
  };

  const secondaryPlan: CardapioPlan = {
    id: 'plan-cutting-controlado',
    name: 'Déficit técnico · Alta saciedade',
    revision: 2,
    status: 'draft',
    startDateKey,
    endDateKey,
    targets: secondaryTargets,
    mealAllocations: buildDefaultMealAllocations(secondaryDays[anchorDateKey]?.slots ?? []),
    days: secondaryDays,
    variants: [],
    activeVariantId: null,
  };

  return [primaryPlan, secondaryPlan];
}

export function getRecipeScaleFactor(recipe: Pick<RecipeInstance, 'baseServings' | 'targetServings'>): number {
  const base = Number.isFinite(recipe.baseServings) && recipe.baseServings > 0 ? recipe.baseServings : 1;
  const target = Number.isFinite(recipe.targetServings) && recipe.targetServings > 0 ? recipe.targetServings : 1;
  return Math.max(0.25, Math.min(4, target / base));
}

export function getScaledReferenceGrams(
  ingredient: Pick<IngredientAdjustment, 'baseQuantityG' | 'quantityStatus'>,
  scaleFactor: number,
): number | null {
  if (ingredient.quantityStatus !== 'known' || ingredient.baseQuantityG === null) {
    return null;
  }
  if (!Number.isFinite(ingredient.baseQuantityG) || ingredient.baseQuantityG <= 0) {
    return null;
  }
  return roundGramsHalf(ingredient.baseQuantityG * scaleFactor);
}

export function getEffectiveIngredientBounds(
  ingredient: IngredientAdjustment,
  scaleFactor: number,
): { minG: number; maxG: number } {
  const ref = getScaledReferenceGrams(ingredient, scaleFactor) ?? ingredient.currentQuantityG ?? 100;
  const rawMin =
    ingredient.minQuantityG !== null &&
    ingredient.minQuantityG !== undefined &&
    Number.isFinite(ingredient.minQuantityG) &&
    ingredient.minQuantityG > 0
      ? ingredient.minQuantityG
      : Math.max(5, roundGramsHalf(ref * 0.45));
  const rawMax =
    ingredient.maxQuantityG !== null &&
    ingredient.maxQuantityG !== undefined &&
    Number.isFinite(ingredient.maxQuantityG) &&
    ingredient.maxQuantityG > 0
      ? ingredient.maxQuantityG
      : Math.min(2000, Math.max(rawMin + 10, roundGramsHalf(ref * 1.85)));

  const minG = Math.max(1, Math.min(2000, rawMin));
  const maxG = Math.max(minG, Math.min(2000, rawMax));
  return { minG, maxG };
}

export function applyYieldScaleToRecipe(
  recipe: RecipeInstance,
  nextTargetServings: number,
): RecipeInstance {
  const safeTarget = Number.isFinite(nextTargetServings)
    ? Math.max(0.25, Math.min(4, Number(nextTargetServings.toFixed(2))))
    : recipe.targetServings;
  const prevScale = getRecipeScaleFactor(recipe);
  const nextScale = getRecipeScaleFactor({ baseServings: recipe.baseServings, targetServings: safeTarget });

  return {
    ...recipe,
    targetServings: safeTarget,
    ingredients: recipe.ingredients.map((ingredient) => {
      if (ingredient.quantityStatus !== 'known' || ingredient.baseQuantityG === null) {
        return ingredient;
      }
      const nextRef = roundGramsHalf(ingredient.baseQuantityG * nextScale);
      const nextMin = Math.max(1, roundGramsHalf(nextRef * 0.45));
      const nextMax = Math.min(2000, Math.max(nextMin + 10, roundGramsHalf(nextRef * 1.85)));

      if (ingredient.mode === 'locked') {
        return {
          ...ingredient,
          minQuantityG: nextMin,
          maxQuantityG: nextMax,
        };
      }
      if (ingredient.mode === 'proportional' || recipe.adjustmentMode === 'proportional') {
        return {
          ...ingredient,
          currentQuantityG: Math.max(1, Math.min(2000, nextRef)),
          minQuantityG: nextMin,
          maxQuantityG: nextMax,
        };
      }
      // Flexible keeps manual relative proportion when scaling recipe yield, clamped within updated corridor
      const ratioToPrev = prevScale > 0 && ingredient.currentQuantityG !== null
        ? ingredient.currentQuantityG / (ingredient.baseQuantityG * prevScale)
        : 1;
      const adjusted = roundGramsHalf(nextRef * ratioToPrev);
      return {
        ...ingredient,
        currentQuantityG: Math.max(nextMin, Math.min(nextMax, adjusted)),
        minQuantityG: nextMin,
        maxQuantityG: nextMax,
      };
    }),
  };
}

/**
 * Exact weighted quantity deviation metric:
 * D = (sum_i |x_i - q_i^{ref}| / sum_i q_i^{ref}) * 100
 */
export function computeWeightedDeviationPercent(
  ingredients: readonly IngredientAdjustment[],
  scaleFactor: number,
): number {
  let numerator = 0;
  let denominator = 0;
  for (const ingredient of ingredients) {
    if (ingredient.quantityStatus !== 'known') continue;
    const refG = getScaledReferenceGrams(ingredient, scaleFactor);
    if (refG === null || refG <= 0) continue;
    const currentG =
      ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
        ? Math.max(0, ingredient.currentQuantityG)
        : refG;
    numerator += Math.abs(currentG - refG);
    denominator += refG;
  }
  if (denominator <= 0) return 0;
  return Number(((numerator / denominator) * 100).toFixed(1));
}

export function computeDayWeightedDeviationPercent(dayPlan: ComposerDayPlan): number {
  let numerator = 0;
  let denominator = 0;
  for (const slot of dayPlan.slots) {
    for (const recipe of slot.recipes) {
      const scale = getRecipeScaleFactor(recipe);
      for (const ingredient of recipe.ingredients) {
        if (ingredient.quantityStatus !== 'known') continue;
        const refG = getScaledReferenceGrams(ingredient, scale);
        if (refG === null || refG <= 0) continue;
        const currentG =
          ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
            ? Math.max(0, ingredient.currentQuantityG)
            : refG;
        numerator += Math.abs(currentG - refG);
        denominator += refG;
      }
    }
  }
  if (denominator <= 0) return 0;
  return Number(((numerator / denominator) * 100).toFixed(1));
}

export type IngredientNutritionImpact =
  | {
      calculable: true;
      foodName: string;
      sourceId: FoodSourceId;
      sourceRecordId: string;
      sourceVersion: string;
      qualityStatus: string;
      activeQuantityG: number;
      referenceQuantityG: number;
      activeMacros: ComposerMacroTotals;
      deltaMacros: ComposerMacroTotals;
    }
  | {
      calculable: false;
      foodName: string;
      sourceId?: FoodSourceId;
      reason: string;
    };

export function computeIngredientNutritionImpact(
  ingredient: IngredientAdjustment,
  scaleFactor: number,
): IngredientNutritionImpact {
  const food = resolveFoodById(ingredient.foodId);
  const foodName = food?.name ?? ingredient.displayName ?? ingredient.foodId;

  if (ingredient.quantityStatus === 'to_taste') {
    return {
      calculable: false,
      foodName,
      sourceId: food?.source_id,
      reason: 'A gosto · peso não quantificado',
    };
  }
  if (ingredient.quantityStatus === 'missing') {
    return {
      calculable: false,
      foodName,
      sourceId: food?.source_id,
      reason: 'Quantidade pendente',
    };
  }
  if (!food) {
    return {
      calculable: false,
      foodName,
      reason: 'Impacto não calculável',
    };
  }

  const macros = food.macros;
  const macroValidation = validateFoodMacroComposition(food);
  if (!macroValidation.valid) {
    return {
      calculable: false,
      foodName,
      sourceId: food.source_id,
      reason: `Composição nutricional inconsistente: ${macroValidation.errors.join(', ')}`,
    };
  }

  const refG = getScaledReferenceGrams(ingredient, scaleFactor);
  const activeG =
    ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
      ? Math.max(0, ingredient.currentQuantityG)
      : (refG ?? 0);

  if (refG === null || activeG <= 0) {
    return {
      calculable: false,
      foodName,
      sourceId: food.source_id,
      reason: 'Impacto não calculável',
    };
  }

  const activeRatio = activeG / macros.basisQuantityG;
  const refRatio = refG / macros.basisQuantityG;

  const activeMacros: ComposerMacroTotals = {
    kcal: macros.kcalPerBasis * activeRatio,
    proteinG: macros.proteinGPerBasis * activeRatio,
    carbsG: macros.carbsGPerBasis * activeRatio,
    fatG: macros.fatGPerBasis * activeRatio,
  };

  const deltaMacros: ComposerMacroTotals = {
    kcal: macros.kcalPerBasis * (activeRatio - refRatio),
    proteinG: macros.proteinGPerBasis * (activeRatio - refRatio),
    carbsG: macros.carbsGPerBasis * (activeRatio - refRatio),
    fatG: macros.fatGPerBasis * (activeRatio - refRatio),
  };

  return {
    calculable: true,
    foodName,
    sourceId: food.source_id,
    sourceRecordId: food.source_record_id,
    sourceVersion: food.source_version,
    qualityStatus: food.quality_status,
    activeQuantityG: activeG,
    referenceQuantityG: refG,
    activeMacros,
    deltaMacros,
  };
}

export type ComposerDietaryMetricStatus = 'quantified' | 'not_analyzed' | 'missing' | 'invalid_value';

export interface ComposerDietaryMetricValue {
  value: number | null;
  quantifiedCount: number;
  sourceCount: number;
  dataStatus: ComposerDietaryMetricStatus;
}

export interface ComposerDietaryMetricTotals {
  fiberG: ComposerDietaryMetricValue;
  saturatedFatG: ComposerDietaryMetricValue;
  cholesterolMg: ComposerDietaryMetricValue;
}

export interface ComposerNutritionSummary {
  macros: ComposerMacroTotals;
  dietaryMetrics: ComposerDietaryMetricTotals;
  totalGrams: number;
  knownIngredientsCount: number;
  missingIngredientsCount: number;
  toTasteIngredientsCount: number;
  unresolvedFoodIds: string[];
  lowConfidenceFoodIds: string[];
  coveragePercent: number;
  weightedDeviationPercent: number;
  sources: FoodSourceId[];
  micronutrients: Record<NutrientId, { value: number | null; unit: string; quantifiedCount: number; sourceCount: number; dataStatus: NutrientDataStatus }>;
}

function emptyDietaryMetricTotals(): ComposerDietaryMetricTotals {
  const empty = (): ComposerDietaryMetricValue => ({
    value: null,
    quantifiedCount: 0,
    sourceCount: 0,
    dataStatus: 'missing',
  });
  return { fiberG: empty(), saturatedFatG: empty(), cholesterolMg: empty() };
}

function addDietaryMetric(
  current: ComposerDietaryMetricValue,
  valuePerBasis: number | null | undefined,
  basisQuantityG: number,
  quantityG: number,
): ComposerDietaryMetricValue {
  const sourceCount = current.sourceCount + 1;
  const hasValue = typeof valuePerBasis === 'number';
  const valid = hasValue && Number.isFinite(valuePerBasis) && valuePerBasis >= 0 &&
    Number.isFinite(basisQuantityG) && basisQuantityG > 0 &&
    Number.isFinite(quantityG) && quantityG >= 0;
  if (!valid) {
    const status: ComposerDietaryMetricStatus = hasValue ? 'invalid_value' : 'not_analyzed';
    return {
      value: null,
      quantifiedCount: current.quantifiedCount,
      sourceCount,
      dataStatus: current.dataStatus === 'invalid_value' || status === 'invalid_value' ? 'invalid_value' : status,
    };
  }
  const quantifiedCount = current.quantifiedCount + 1;
  if (current.sourceCount > current.quantifiedCount || (current.dataStatus !== 'missing' && current.dataStatus !== 'quantified')) {
    return {
      value: null,
      quantifiedCount,
      sourceCount,
      dataStatus: current.dataStatus === 'quantified' ? 'not_analyzed' : current.dataStatus,
    };
  }
  const contribution = (valuePerBasis / basisQuantityG) * quantityG;
  return {
    value: (current.value ?? 0) + contribution,
    quantifiedCount,
    sourceCount,
    dataStatus: 'quantified',
  };
}

function markDietaryMetricsIncomplete(
  totals: ComposerDietaryMetricTotals,
  status: ComposerDietaryMetricStatus,
): void {
  for (const key of ['fiberG', 'saturatedFatG', 'cholesterolMg'] as const) {
    const current = totals[key];
    current.value = null;
    current.sourceCount += 1;
    current.dataStatus = current.dataStatus === 'invalid_value' || status === 'invalid_value'
      ? 'invalid_value'
      : current.dataStatus === 'not_analyzed' || status === 'not_analyzed'
        ? 'not_analyzed'
        : 'missing';
  }
}

function mergeDietaryMetricValue(
  a: ComposerDietaryMetricValue,
  b: ComposerDietaryMetricValue,
): ComposerDietaryMetricValue {
  if (b.sourceCount === 0) return a;
  if (a.sourceCount === 0) return b;
  const quantifiedCount = a.quantifiedCount + b.quantifiedCount;
  const sourceCount = a.sourceCount + b.sourceCount;
  if (a.dataStatus === 'quantified' && b.dataStatus === 'quantified' && a.value !== null && b.value !== null) {
    return { value: a.value + b.value, quantifiedCount, sourceCount, dataStatus: 'quantified' };
  }
  const dataStatus: ComposerDietaryMetricStatus = a.dataStatus === 'invalid_value' || b.dataStatus === 'invalid_value'
    ? 'invalid_value'
    : a.dataStatus === 'not_analyzed' || b.dataStatus === 'not_analyzed'
      ? 'not_analyzed'
      : 'missing';
  return { value: null, quantifiedCount, sourceCount, dataStatus };
}

function mergeDietaryMetricTotals(
  current: ComposerDietaryMetricTotals,
  incoming: ComposerDietaryMetricTotals,
): ComposerDietaryMetricTotals {
  return {
    fiberG: mergeDietaryMetricValue(current.fiberG, incoming.fiberG),
    saturatedFatG: mergeDietaryMetricValue(current.saturatedFatG, incoming.saturatedFatG),
    cholesterolMg: mergeDietaryMetricValue(current.cholesterolMg, incoming.cholesterolMg),
  };
}

function emptyMicronutrientTotals(): Record<
  NutrientId,
  { value: number | null; unit: string; quantifiedCount: number; sourceCount: number; dataStatus: NutrientDataStatus }
> {
  const out = {} as Record<NutrientId, { value: number | null; unit: string; quantifiedCount: number; sourceCount: number; dataStatus: NutrientDataStatus }>;
  for (const id of MICRONUTRIENT_ORDER) {
    out[id] = {
      value: null,
      unit: MICRONUTRIENT_PT_LABELS[id].unit,
      quantifiedCount: 0,
      sourceCount: 0,
      dataStatus: 'missing',
    };
  }
  return out;
}

function mergeMicronutrientTotals(
  current: { value: number | null; unit: string; quantifiedCount: number; sourceCount: number; dataStatus: NutrientDataStatus },
  incoming: { value: number | null; unit: string; quantifiedCount: number; sourceCount: number; dataStatus: NutrientDataStatus },
) {
  if (incoming.sourceCount === 0) return current;
  if (current.sourceCount === 0) return incoming;

  const incompatible = current.dataStatus === 'unit_mismatch' || incoming.dataStatus === 'unit_mismatch' ||
    (current.unit !== incoming.unit && current.quantifiedCount > 0 && incoming.quantifiedCount > 0);
  if (incompatible) {
    return {
      value: null,
      unit: current.unit || incoming.unit,
      quantifiedCount: current.quantifiedCount + incoming.quantifiedCount,
      sourceCount: current.sourceCount + incoming.sourceCount,
      dataStatus: 'unit_mismatch' as const,
    };
  }

  const incompleteStatus = [current.dataStatus, incoming.dataStatus].find((status) => status === 'invalid_value') ??
    [current.dataStatus, incoming.dataStatus].find((status) => status === 'not_analyzed') ??
    [current.dataStatus, incoming.dataStatus].find((status) => status === 'trace') ??
    [current.dataStatus, incoming.dataStatus].find((status) => status === 'missing');
  if (incompleteStatus) {
    return {
      value: null,
      unit: current.unit || incoming.unit,
      quantifiedCount: current.quantifiedCount + incoming.quantifiedCount,
      sourceCount: current.sourceCount + incoming.sourceCount,
      dataStatus: incompleteStatus,
    };
  }

  return {
    value: (current.value ?? 0) + (incoming.value ?? 0),
    unit: current.unit || incoming.unit,
    quantifiedCount: current.quantifiedCount + incoming.quantifiedCount,
    sourceCount: current.sourceCount + incoming.sourceCount,
    dataStatus: 'quantified' as const,
  };
}

function markMicronutrientsIncomplete(
  totals: ReturnType<typeof emptyMicronutrientTotals>,
  status: NutrientDataStatus = 'missing',
): void {
  for (const nutrientId of MICRONUTRIENT_ORDER) {
    const current = totals[nutrientId];
    current.value = null;
    current.sourceCount += 1;
    current.dataStatus = current.dataStatus === 'unit_mismatch'
      ? 'unit_mismatch'
      : current.dataStatus === 'invalid_value' || status === 'invalid_value'
        ? 'invalid_value'
        : current.dataStatus === 'not_analyzed' || status === 'not_analyzed'
        ? 'not_analyzed'
        : current.dataStatus === 'trace' || status === 'trace'
          ? 'trace'
          : status;
  }
}

export function computeRecipeNutrition(recipe: RecipeInstance): ComposerNutritionSummary {
  const scale = getRecipeScaleFactor(recipe);
  const macros: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const micronutrients = emptyMicronutrientTotals();
  const dietaryMetrics = emptyDietaryMetricTotals();
  let totalGrams = 0;
  let quantifiedGrams = 0;
  let knownIngredientsCount = 0;
  let missingIngredientsCount = 0;
  let toTasteIngredientsCount = 0;
  const unresolvedSet = new Set<string>();
  const lowConfidenceSet = new Set<string>();
  const sourceSet = new Set<FoodSourceId>();

  for (const ingredient of recipe.ingredients) {
    if (ingredient.quantityStatus === 'to_taste') {
      toTasteIngredientsCount += 1;
      markMicronutrientsIncomplete(micronutrients, 'missing');
      markDietaryMetricsIncomplete(dietaryMetrics, 'missing');
      const food = resolveFoodById(ingredient.foodId);
      if (food) sourceSet.add(food.source_id);
      continue;
    }
    if (
      ingredient.quantityStatus === 'missing' ||
      ingredient.currentQuantityG === null ||
      !Number.isFinite(ingredient.currentQuantityG) ||
      ingredient.currentQuantityG <= 0
    ) {
      missingIngredientsCount += 1;
      markMicronutrientsIncomplete(micronutrients, 'missing');
      markDietaryMetricsIncomplete(dietaryMetrics, 'missing');
      continue;
    }

    knownIngredientsCount += 1;
    totalGrams += ingredient.currentQuantityG;

    const food = resolveFoodById(ingredient.foodId);
    if (!food) {
      unresolvedSet.add(ingredient.foodId);
      markMicronutrientsIncomplete(micronutrients, 'missing');
      markDietaryMetricsIncomplete(dietaryMetrics, 'missing');
      continue;
    }
    sourceSet.add(food.source_id);
    if (food.quality_status === 'unverified' || food.quality_status === 'label_partial') {
      lowConfidenceSet.add(ingredient.foodId);
    }

    const basis = food.macros.basisQuantityG;
    const macroQuality = validateFoodMacroComposition(food);
    if (!macroQuality.valid) {
      unresolvedSet.add(ingredient.foodId);
      lowConfidenceSet.add(ingredient.foodId);
      markMicronutrientsIncomplete(micronutrients, 'not_analyzed');
      markDietaryMetricsIncomplete(dietaryMetrics, macroQuality.errors.length > 0 ? 'invalid_value' : 'not_analyzed');
      continue;
    }

    const ratio = ingredient.currentQuantityG / basis;
    macros.kcal += food.macros.kcalPerBasis * ratio;
    macros.proteinG += food.macros.proteinGPerBasis * ratio;
    macros.carbsG += food.macros.carbsGPerBasis * ratio;
    macros.fatG += food.macros.fatGPerBasis * ratio;
    dietaryMetrics.fiberG = addDietaryMetric(dietaryMetrics.fiberG, food.macros.fiberGPerBasis, basis, ingredient.currentQuantityG);
    dietaryMetrics.saturatedFatG = addDietaryMetric(dietaryMetrics.saturatedFatG, food.macros.saturatedFatGPerBasis, basis, ingredient.currentQuantityG);
    dietaryMetrics.cholesterolMg = addDietaryMetric(dietaryMetrics.cholesterolMg, food.macros.cholesterolMgPerBasis, basis, ingredient.currentQuantityG);
    quantifiedGrams += ingredient.currentQuantityG;

    for (const nutrientId of MICRONUTRIENT_ORDER) {
      const record = normalizeNutrientEntry(food, nutrientId);
      const current = micronutrients[nutrientId];
      const isQuantified = record.data_status === 'quantified' &&
        record.normalized_value !== null && Number.isFinite(record.normalized_value) &&
        Number.isFinite(record.basis_quantity) && record.basis_quantity > 0;
      const requiresDriUnit = MICRONUTRIENT_PT_LABELS[nutrientId].unit;
      const unitMismatch = isQuantified && (
        !record.normalized_unit ||
        record.normalized_unit !== requiresDriUnit ||
        (nutrientId === 'vitamin_b3' && record.conversion_method === 'preformed_niacin_only') ||
        (current.quantifiedCount > 0 && current.unit !== record.normalized_unit)
      );
      const nextSourceCount = current.sourceCount + 1;
      if (unitMismatch || current.dataStatus === 'unit_mismatch') {
        micronutrients[nutrientId] = {
          value: null,
          unit: current.quantifiedCount > 0 ? current.unit : (record.normalized_unit || current.unit),
          quantifiedCount: current.quantifiedCount + (isQuantified ? 1 : 0),
          sourceCount: nextSourceCount,
          dataStatus: 'unit_mismatch',
        };
      } else if (isQuantified && (current.sourceCount === current.quantifiedCount)) {
        micronutrients[nutrientId] = {
          value: (current.value ?? 0) + (record.normalized_value! / record.basis_quantity) * ingredient.currentQuantityG,
          unit: record.normalized_unit,
          quantifiedCount: current.quantifiedCount + 1,
          sourceCount: nextSourceCount,
          dataStatus: 'quantified',
        };
      } else if (isQuantified) {
        micronutrients[nutrientId] = {
          ...current,
          value: null,
          quantifiedCount: current.quantifiedCount + 1,
          sourceCount: nextSourceCount,
        };
      } else {
        const status = record.data_status === 'unit_mismatch' ? 'unit_mismatch' : record.data_status;
        micronutrients[nutrientId] = {
          value: null,
          unit: current.unit || record.normalized_unit,
          quantifiedCount: current.quantifiedCount,
          sourceCount: nextSourceCount,
          dataStatus: status === 'unit_mismatch'
            ? 'unit_mismatch'
            : current.dataStatus === 'invalid_value' || status === 'invalid_value'
              ? 'invalid_value'
              : current.dataStatus === 'not_analyzed' || status === 'not_analyzed'
                ? 'not_analyzed'
              : current.dataStatus === 'trace' || status === 'trace'
                ? 'trace'
                : 'missing',
        };
      }
    }
  }

  return {
    macros,
    dietaryMetrics,
    totalGrams,
    knownIngredientsCount,
    missingIngredientsCount,
    toTasteIngredientsCount,
    unresolvedFoodIds: [...unresolvedSet],
    lowConfidenceFoodIds: [...lowConfidenceSet],
    coveragePercent: totalGrams > 0 ? Number(((quantifiedGrams / totalGrams) * 100).toFixed(1)) : 0,
    weightedDeviationPercent: computeWeightedDeviationPercent(recipe.ingredients, scale),
    sources: [...sourceSet],
    micronutrients,
  };
}

export function computeSlotNutrition(slot: ComposerMealSlot): ComposerNutritionSummary {
  const macros: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const micronutrients = emptyMicronutrientTotals();
  const dietaryMetrics = emptyDietaryMetricTotals();
  let totalGrams = 0;
  let quantifiedGrams = 0;
  let knownIngredientsCount = 0;
  let missingIngredientsCount = 0;
  let toTasteIngredientsCount = 0;
  const unresolvedSet = new Set<string>();
  const lowConfidenceSet = new Set<string>();
  const sourceSet = new Set<FoodSourceId>();

  for (const recipe of slot.recipes) {
    const recSummary = computeRecipeNutrition(recipe);
    macros.kcal += recSummary.macros.kcal;
    macros.proteinG += recSummary.macros.proteinG;
    macros.carbsG += recSummary.macros.carbsG;
    macros.fatG += recSummary.macros.fatG;
    const mergedDietaryMetrics = mergeDietaryMetricTotals(dietaryMetrics, recSummary.dietaryMetrics);
    dietaryMetrics.fiberG = mergedDietaryMetrics.fiberG;
    dietaryMetrics.saturatedFatG = mergedDietaryMetrics.saturatedFatG;
    dietaryMetrics.cholesterolMg = mergedDietaryMetrics.cholesterolMg;
    totalGrams += recSummary.totalGrams;
    quantifiedGrams += (recSummary.totalGrams * recSummary.coveragePercent) / 100;
    knownIngredientsCount += recSummary.knownIngredientsCount;
    missingIngredientsCount += recSummary.missingIngredientsCount;
    toTasteIngredientsCount += recSummary.toTasteIngredientsCount;
    recSummary.unresolvedFoodIds.forEach((id) => unresolvedSet.add(id));
    recSummary.lowConfidenceFoodIds.forEach((id) => lowConfidenceSet.add(id));
    recSummary.sources.forEach((src) => sourceSet.add(src));
    for (const nutrientId of MICRONUTRIENT_ORDER) {
      micronutrients[nutrientId] = mergeMicronutrientTotals(
        micronutrients[nutrientId],
        recSummary.micronutrients[nutrientId],
      );
    }
  }

  // Exact weighted deviation across all recipes inside the slot
  let devNum = 0;
  let devDen = 0;
  for (const recipe of slot.recipes) {
    const scale = getRecipeScaleFactor(recipe);
    for (const ingredient of recipe.ingredients) {
      if (ingredient.quantityStatus !== 'known') continue;
      const refG = getScaledReferenceGrams(ingredient, scale);
      if (refG === null || refG <= 0) continue;
      const curG = ingredient.currentQuantityG ?? refG;
      devNum += Math.abs(curG - refG);
      devDen += refG;
    }
  }

  return {
    macros,
    dietaryMetrics,
    totalGrams,
    knownIngredientsCount,
    missingIngredientsCount,
    toTasteIngredientsCount,
    unresolvedFoodIds: [...unresolvedSet],
    lowConfidenceFoodIds: [...lowConfidenceSet],
    coveragePercent: totalGrams > 0 ? Number(((quantifiedGrams / totalGrams) * 100).toFixed(1)) : 0,
    weightedDeviationPercent: devDen > 0 ? Number(((devNum / devDen) * 100).toFixed(1)) : 0,
    sources: [...sourceSet],
    micronutrients,
  };
}

export function computeDayNutrition(dayPlan: ComposerDayPlan): ComposerNutritionSummary {
  const macros: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const micronutrients = emptyMicronutrientTotals();
  const dietaryMetrics = emptyDietaryMetricTotals();
  let totalGrams = 0;
  let quantifiedGrams = 0;
  let knownIngredientsCount = 0;
  let missingIngredientsCount = 0;
  let toTasteIngredientsCount = 0;
  const unresolvedSet = new Set<string>();
  const lowConfidenceSet = new Set<string>();
  const sourceSet = new Set<FoodSourceId>();

  for (const slot of dayPlan.slots) {
    const slotSummary = computeSlotNutrition(slot);
    macros.kcal += slotSummary.macros.kcal;
    macros.proteinG += slotSummary.macros.proteinG;
    macros.carbsG += slotSummary.macros.carbsG;
    macros.fatG += slotSummary.macros.fatG;
    const mergedDietaryMetrics = mergeDietaryMetricTotals(dietaryMetrics, slotSummary.dietaryMetrics);
    dietaryMetrics.fiberG = mergedDietaryMetrics.fiberG;
    dietaryMetrics.saturatedFatG = mergedDietaryMetrics.saturatedFatG;
    dietaryMetrics.cholesterolMg = mergedDietaryMetrics.cholesterolMg;
    totalGrams += slotSummary.totalGrams;
    quantifiedGrams += (slotSummary.totalGrams * slotSummary.coveragePercent) / 100;
    knownIngredientsCount += slotSummary.knownIngredientsCount;
    missingIngredientsCount += slotSummary.missingIngredientsCount;
    toTasteIngredientsCount += slotSummary.toTasteIngredientsCount;
    slotSummary.unresolvedFoodIds.forEach((id) => unresolvedSet.add(id));
    slotSummary.lowConfidenceFoodIds.forEach((id) => lowConfidenceSet.add(id));
    slotSummary.sources.forEach((src) => sourceSet.add(src));
    for (const nutrientId of MICRONUTRIENT_ORDER) {
      micronutrients[nutrientId] = mergeMicronutrientTotals(
        micronutrients[nutrientId],
        slotSummary.micronutrients[nutrientId],
      );
    }
  }

  return {
    macros,
    dietaryMetrics,
    totalGrams,
    knownIngredientsCount,
    missingIngredientsCount,
    toTasteIngredientsCount,
    unresolvedFoodIds: [...unresolvedSet],
    lowConfidenceFoodIds: [...lowConfidenceSet],
    coveragePercent: totalGrams > 0 ? Number(((quantifiedGrams / totalGrams) * 100).toFixed(1)) : 0,
    weightedDeviationPercent: computeDayWeightedDeviationPercent(dayPlan),
    sources: [...sourceSet],
    micronutrients,
  };
}

export function extractMealPortionsFromSlot(slot: ComposerMealSlot): MealFoodPortion[] {
  const portions: MealFoodPortion[] = [];
  for (const recipe of slot.recipes) {
    for (const ingredient of recipe.ingredients) {
      if (
        ingredient.quantityStatus === 'known' &&
        ingredient.currentQuantityG !== null &&
        Number.isFinite(ingredient.currentQuantityG) &&
        ingredient.currentQuantityG > 0
      ) {
        const existing = portions.find((p) => p.foodId === ingredient.foodId);
        if (existing) {
          existing.quantityG = Number((existing.quantityG + ingredient.currentQuantityG).toFixed(2));
        } else {
          portions.push({
            foodId: ingredient.foodId,
            quantityG: Number(ingredient.currentQuantityG.toFixed(2)),
          });
        }
      }
    }
  }
  return portions;
}

export interface SlotAllocationEvaluation {
  slotId: string;
  slotTitle: string;
  slotTime: string;
  sharePercent: number;
  proteinSharePercent: number | null;
  carbsSharePercent: number | null;
  fatSharePercent: number | null;
  targetKcal: number;
  actualKcal: number;
  deltaKcal: number;
  targetProteinG: number | null;
  actualProteinG: number;
  targetCarbsG: number | null;
  actualCarbsG: number;
  targetFatG: number | null;
  actualFatG: number;
}

export interface MealAllocationSummary {
  totalSharePercent: number;
  unallocatedPercent: number;
  isBalanced: boolean;
  hasMacroDistribution: boolean;
  totalProteinSharePercent: number | null;
  totalCarbsSharePercent: number | null;
  totalFatSharePercent: number | null;
  slots: SlotAllocationEvaluation[];
}

export function evaluateMealAllocations(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  allocations: readonly MealTargetAllocation[],
): MealAllocationSummary {
  const allocationById = new Map(allocations.map((a) => [a.slotId, a]));
  const fallbackShare = dayPlan.slots.length > 0 ? Number((100 / dayPlan.slots.length).toFixed(1)) : 0;

  let totalSharePercent = 0;
  let proteinShareSum = 0;
  let carbsShareSum = 0;
  let fatShareSum = 0;
  let hasProteinShares = false;
  let hasCarbsShares = false;
  let hasFatShares = false;

  const slots: SlotAllocationEvaluation[] = dayPlan.slots.map((slot) => {
    const config = allocationById.get(slot.id);
    const sharePercent =
      config && Number.isFinite(config.energySharePercent)
        ? Math.max(0, Math.min(100, config.energySharePercent))
        : fallbackShare;
    totalSharePercent += sharePercent;

    const pShare =
      config?.proteinSharePercent !== null &&
      config?.proteinSharePercent !== undefined &&
      Number.isFinite(config.proteinSharePercent)
        ? Math.max(0, Math.min(100, config.proteinSharePercent))
        : null;
    const cShare =
      config?.carbsSharePercent !== null &&
      config?.carbsSharePercent !== undefined &&
      Number.isFinite(config.carbsSharePercent)
        ? Math.max(0, Math.min(100, config.carbsSharePercent))
        : null;
    const fShare =
      config?.fatSharePercent !== null &&
      config?.fatSharePercent !== undefined &&
      Number.isFinite(config.fatSharePercent)
        ? Math.max(0, Math.min(100, config.fatSharePercent))
        : null;

    if (pShare !== null) {
      hasProteinShares = true;
      proteinShareSum += pShare;
    }
    if (cShare !== null) {
      hasCarbsShares = true;
      carbsShareSum += cShare;
    }
    if (fShare !== null) {
      hasFatShares = true;
      fatShareSum += fShare;
    }

    const summary = computeSlotNutrition(slot);
    const targetKcal = Math.round((targets.kcal * sharePercent) / 100);
    return {
      slotId: slot.id,
      slotTitle: slot.title,
      slotTime: slot.time,
      sharePercent: Number(sharePercent.toFixed(1)),
      proteinSharePercent: pShare !== null ? Number(pShare.toFixed(1)) : null,
      carbsSharePercent: cShare !== null ? Number(cShare.toFixed(1)) : null,
      fatSharePercent: fShare !== null ? Number(fShare.toFixed(1)) : null,
      targetKcal,
      actualKcal: Math.round(summary.macros.kcal),
      deltaKcal: Math.round(summary.macros.kcal - targetKcal),
      targetProteinG: pShare !== null ? Math.round((targets.proteinG * pShare) / 100) : null,
      actualProteinG: Math.round(summary.macros.proteinG),
      targetCarbsG: cShare !== null ? Math.round((targets.carbsG * cShare) / 100) : null,
      actualCarbsG: Math.round(summary.macros.carbsG),
      targetFatG: fShare !== null ? Math.round((targets.fatG * fShare) / 100) : null,
      actualFatG: Math.round(summary.macros.fatG),
    };
  });

  const roundedTotal = Number(totalSharePercent.toFixed(1));
  const unallocatedPercent = Number((100 - roundedTotal).toFixed(1));
  return {
    totalSharePercent: roundedTotal,
    unallocatedPercent,
    isBalanced: Math.abs(unallocatedPercent) <= 0.2,
    hasMacroDistribution: hasProteinShares || hasCarbsShares || hasFatShares,
    totalProteinSharePercent: hasProteinShares ? Number(proteinShareSum.toFixed(1)) : null,
    totalCarbsSharePercent: hasCarbsShares ? Number(carbsShareSum.toFixed(1)) : null,
    totalFatSharePercent: hasFatShares ? Number(fatShareSum.toFixed(1)) : null,
    slots,
  };
}

export interface ProportionalMealScaleSlotResult {
  slotId: string;
  slotTitle: string;
  targetKcal: number;
  beforeKcal: number;
  afterKcal: number;
  energyTargetGapKcal: number;
  scaleFactor: number;
  lockedIngredientCount: number;
  unquantifiedIngredientCount: number;
  lowConfidenceIngredientCount: number;
  hasIncompleteNutritionData: boolean;
  nutritionCoveragePercent: number;
  status: 'scaled' | 'limited_by_serving_or_mass_bounds' | 'no_scalable_energy';
}

export interface ProportionalMealScaleProposal {
  proposedDayPlan: ComposerDayPlan;
  beforeMacros: ComposerMacroTotals;
  afterMacros: ComposerMacroTotals;
  slots: ProportionalMealScaleSlotResult[];
}

/**
 * Scale every quantifiable, unlocked ingredient in a meal by one shared factor.
 * This is deliberately separate from the nutrient optimizer: it changes portion
 * size/yield while preserving the meal's food ratios, instead of changing foods
 * independently to chase protein/carbohydrate/fat targets.
 */
export function scaleDayPlanProportionallyToMealTargets(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  allocations: readonly MealTargetAllocation[],
): ProportionalMealScaleProposal {
  if (!Number.isFinite(targets.kcal) || targets.kcal <= 0) {
    throw new RangeError('A meta diária de energia precisa ser maior que zero.');
  }

  const allocationSummary = evaluateMealAllocations(dayPlan, targets, allocations);
  if (!allocationSummary.isBalanced) {
    throw new RangeError('A distribuição de energia entre refeições precisa somar 100% antes de aplicar o cálculo proporcional.');
  }

  const proposedDayPlan = cloneDayPlan(dayPlan);
  const slotResults: ProportionalMealScaleSlotResult[] = [];

  for (const allocation of allocationSummary.slots) {
    const slot = proposedDayPlan.slots.find((candidate) => candidate.id === allocation.slotId);
    if (!slot) continue;

    const before = computeSlotNutrition(slot);
    const targetKcal = (targets.kcal * allocation.sharePercent) / 100;
    let fixedKcal = 0;
    let scalableKcal = 0;
    let lockedIngredientCount = 0;
    let unquantifiedIngredientCount = 0;
    let lowConfidenceIngredientCount = 0;
    let scalableEnergyIngredientCount = 0;
    let minFactor = 0;
    let maxFactor = Number.POSITIVE_INFINITY;

    for (const recipe of slot.recipes) {
      const hasScalableIngredient = recipe.ingredients.some((ingredient) =>
        ingredient.mode !== 'locked' && ingredient.quantityStatus === 'known' &&
        ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG) &&
        ingredient.currentQuantityG > 0,
      );
      if (hasScalableIngredient) {
        const servings = Number.isFinite(recipe.targetServings) && recipe.targetServings > 0
          ? recipe.targetServings
          : 1;
        minFactor = Math.max(minFactor, 0.25 / servings);
        maxFactor = Math.min(maxFactor, 4 / servings);
      }

      for (const ingredient of recipe.ingredients) {
        if (ingredient.quantityStatus !== 'known' || ingredient.currentQuantityG === null ||
            !Number.isFinite(ingredient.currentQuantityG) || ingredient.currentQuantityG <= 0) {
          unquantifiedIngredientCount += 1;
          continue;
        }
        const food = resolveFoodById(ingredient.foodId);
        const foodMacroValid = food ? validateFoodMacroComposition(food).valid : false;
        if (food && (!foodMacroValid || food.quality_status === 'unverified' || food.quality_status === 'label_partial')) {
          lowConfidenceIngredientCount += 1;
        }
        const basis = foodMacroValid ? food!.macros.basisQuantityG : undefined;
        const kcalPerGram = food && foodMacroValid && typeof basis === 'number' && Number.isFinite(basis) && basis > 0
          ? food.macros.kcalPerBasis / basis
          : null;
        if (kcalPerGram !== null && Number.isFinite(kcalPerGram)) scalableEnergyIngredientCount += 1;
        const ingredientKcal = kcalPerGram === null ? 0 : kcalPerGram * ingredient.currentQuantityG;
        if (kcalPerGram === null) unquantifiedIngredientCount += 1;

        if (ingredient.mode === 'locked') {
          lockedIngredientCount += 1;
          fixedKcal += ingredientKcal;
          continue;
        }

        scalableKcal += ingredientKcal;
        minFactor = Math.max(minFactor, 1 / ingredient.currentQuantityG);
        maxFactor = Math.min(maxFactor, 2000 / ingredient.currentQuantityG);
      }
    }

    if (!Number.isFinite(minFactor) || minFactor <= 0) minFactor = 0.25;
    if (!Number.isFinite(maxFactor)) maxFactor = 4;

    let scaleFactor = 1;
    let status: ProportionalMealScaleSlotResult['status'] = 'scaled';
    if (scalableEnergyIngredientCount === 0 || scalableKcal <= 0) {
      status = 'no_scalable_energy';
    } else if (maxFactor < minFactor) {
      status = 'limited_by_serving_or_mass_bounds';
    } else {
      const requestedFactor = (targetKcal - fixedKcal) / scalableKcal;
      const safeRequestedFactor = Number.isFinite(requestedFactor) ? requestedFactor : 1;
      scaleFactor = Math.max(minFactor, Math.min(maxFactor, safeRequestedFactor));
      if (Math.abs(scaleFactor - safeRequestedFactor) > 0.0001) {
        status = 'limited_by_serving_or_mass_bounds';
      }

      const slotHasScalableEnergy = scalableEnergyIngredientCount > 0 && scalableKcal > 0;
      for (const recipe of slot.recipes) {
        const hasScalableIngredient = recipe.ingredients.some((ingredient) =>
          ingredient.mode !== 'locked' && ingredient.quantityStatus === 'known' &&
          ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG) &&
          ingredient.currentQuantityG > 0,
        );
        if (slotHasScalableEnergy && hasScalableIngredient) {
          const currentTargetServings = recipe.targetServings;
          recipe.baseServings = currentTargetServings;
          recipe.targetServings = Number((currentTargetServings * scaleFactor).toFixed(4));
        }
        for (const ingredient of recipe.ingredients) {
          if (!slotHasScalableEnergy || ingredient.quantityStatus !== 'known' || ingredient.currentQuantityG === null ||
              !Number.isFinite(ingredient.currentQuantityG) || ingredient.currentQuantityG <= 0) {
            continue;
          }
          if (hasScalableIngredient && ingredient.minQuantityG !== null && ingredient.minQuantityG !== undefined && Number.isFinite(ingredient.minQuantityG)) {
            ingredient.minQuantityG = Math.max(1, Math.min(2000, roundGramsHalf(ingredient.minQuantityG * scaleFactor)));
          }
          if (hasScalableIngredient && ingredient.maxQuantityG !== null && ingredient.maxQuantityG !== undefined && Number.isFinite(ingredient.maxQuantityG)) {
            ingredient.maxQuantityG = Math.max(1, Math.min(2000, roundGramsHalf(ingredient.maxQuantityG * scaleFactor)));
          }
          if (ingredient.mode !== 'locked') {
            const previousQuantityG = ingredient.currentQuantityG;
            ingredient.baseQuantityG = previousQuantityG;
            ingredient.currentQuantityG = Math.max(1, Math.min(2000, roundGramsHalf(previousQuantityG * scaleFactor)));
            ingredient.mode = 'proportional';
          }
        }
      }
    }

    const after = computeSlotNutrition(slot);
    slotResults.push({
      slotId: slot.id,
      slotTitle: slot.title,
      targetKcal: Number(targetKcal.toFixed(1)),
      beforeKcal: Number(before.macros.kcal.toFixed(1)),
      afterKcal: Number(after.macros.kcal.toFixed(1)),
      energyTargetGapKcal: Number((after.macros.kcal - targetKcal).toFixed(1)),
      scaleFactor: Number(scaleFactor.toFixed(4)),
      lockedIngredientCount,
      unquantifiedIngredientCount,
      lowConfidenceIngredientCount,
      hasIncompleteNutritionData: after.unresolvedFoodIds.length > 0 || after.lowConfidenceFoodIds.length > 0 ||
        after.missingIngredientsCount > 0 || after.toTasteIngredientsCount > 0 || after.coveragePercent < 99.99,
      nutritionCoveragePercent: after.coveragePercent,
      status,
    });
  }

  return {
    proposedDayPlan,
    beforeMacros: computeDayNutrition(dayPlan).macros,
    afterMacros: computeDayNutrition(proposedDayPlan).macros,
    slots: slotResults,
  };
}

export interface OptimizeBalanceOptions {
  scopeSlotId?: string;
  lambda?: number;
  goalFocus?: 'balanced' | 'energy' | 'protein';
  mealAllocations?: readonly MealTargetAllocation[];
  micronutrientTargets?: readonly DailyMicronutrientOptimizationTarget[];
}

export interface QPDecisionVar {
  slotId: string;
  slotTitle: string;
  recipeId: string;
  recipeName: string;
  ingredientId: string;
  foodId: string;
  foodName: string;
  currentG: number;
  refG: number;
  minG: number;
  maxG: number;
  kcalPerG: number;
  proteinPerG: number;
  carbsPerG: number;
  fatPerG: number;
  micronutrientsPerG: Partial<Record<NutrientId, number>>;
}

export interface PreparedMicronutrientConstraint {
  nutrientId: NutrientId;
  unit: string;
  minimum: number | null;
  minimumKind: 'RDA' | 'AI' | null;
  preferredMaximum: number | null;
  upperLimit: number | null;
  fixedValue: number;
  coefficients: number[];
  status: MicronutrientOptimizationStatus;
  reason?: string;
}

export interface QPSlotAllocationTarget {
  slotId: string;
  slotTitle: string;
  targetKcal: number;
  fixedKcal: number;
  scaleKcal: number;
  weightKcal: number;
  targetProteinG: number | null;
  fixedProteinG: number;
  scaleProteinG: number;
  targetCarbsG: number | null;
  fixedCarbsG: number;
  scaleCarbsG: number;
  targetFatG: number | null;
  fixedFatG: number;
  scaleFatG: number;
}

export interface PreparedQPModel {
  beforeSummary: ComposerNutritionSummary;
  lambda: number;
  weights: { kcal: number; proteinG: number; carbsG: number; fatG: number };
  scales: { kcal: number; proteinG: number; carbsG: number; fatG: number };
  fixedTotals: ComposerMacroTotals;
  vars: QPDecisionVar[];
  micronutrientConstraints: PreparedMicronutrientConstraint[];
  slotTargets: QPSlotAllocationTarget[];
  lockedCount: number;
  proportionalCount: number;
}

export function prepareQPModel(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions = {},
): PreparedQPModel {
  const beforeSummary = computeDayNutrition(dayPlan);
  const lambda = Number.isFinite(options.lambda) ? Math.max(0.01, options.lambda!) : 0.08;
  const focus = options.goalFocus ?? 'balanced';

  const weights =
    focus === 'protein'
      ? { kcal: 1.15, proteinG: 2.1, carbsG: 0.7, fatG: 0.75 }
      : focus === 'energy'
        ? { kcal: 2.2, proteinG: 1.1, carbsG: 0.85, fatG: 0.85 }
        : { kcal: 1.45, proteinG: 1.35, carbsG: 0.9, fatG: 0.9 };

  const scales = {
    kcal: Math.max(400, targets.kcal),
    proteinG: Math.max(30, targets.proteinG),
    carbsG: Math.max(40, targets.carbsG),
    fatG: Math.max(15, targets.fatG),
  };

  const fixedTotals: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const fixedBySlot = new Map<string, ComposerMacroTotals>();
  const vars: QPDecisionVar[] = [];
  const micronutrientConstraints: PreparedMicronutrientConstraint[] = (options.micronutrientTargets ?? []).map((target) => {
    const upperLimit = target.upperLimitScope === 'total_intake' &&
      (target.upperLimitUnit ?? target.unit) === target.unit
      ? target.upperLimit
      : null;
    const hasReference = target.minimum !== null || target.preferredMaximum !== null || upperLimit !== null;
    return {
      nutrientId: target.nutrientId,
      unit: target.unit,
      minimum: target.minimum,
      minimumKind: target.minimumKind,
      preferredMaximum: target.preferredMaximum,
      upperLimit,
      fixedValue: 0,
      coefficients: [],
      status: !hasReference ? 'no_reference' : options.scopeSlotId ? 'not_applicable_scope' : 'applied',
      reason: !hasReference
        ? 'O perfil DRI ativo não define RDA, AI, CDRR ou UL compatível com a unidade deste nutriente.'
        : options.scopeSlotId ? 'As referências DRI são metas do dia; não são aplicadas a uma única refeição.' : undefined,
    };
  });
  const invalidateMicronutrients = (reason: string) => {
    for (const constraint of micronutrientConstraints) {
      if (constraint.status === 'applied') {
        constraint.status = 'insufficient_data';
        constraint.reason = reason;
      }
    }
  };
  let lockedCount = 0;
  let proportionalCount = 0;

  for (const slot of dayPlan.slots) {
    const slotFixed: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
    const inScope = !options.scopeSlotId || slot.id === options.scopeSlotId;
    for (const recipe of slot.recipes) {
      const scaleFactor = getRecipeScaleFactor(recipe);
      for (const ingredient of recipe.ingredients) {
        if (ingredient.quantityStatus !== 'known') {
          if (!options.scopeSlotId) invalidateMicronutrients(
            ingredient.quantityStatus === 'to_taste'
              ? 'Há ingrediente sem quantidade definida (a gosto).'
              : 'Há ingrediente sem quantidade definida.',
          );
          continue;
        }
        const food = resolveFoodById(ingredient.foodId);
        const refG = getScaledReferenceGrams(ingredient, scaleFactor);
        const curG =
          ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
            ? ingredient.currentQuantityG
            : (refG ?? 0);

        if (!food) {
          if (!options.scopeSlotId) invalidateMicronutrients(`Alimento não resolvido: ${ingredient.foodId}.`);
          continue;
        }
        if (!validateFoodMacroComposition(food).valid) {
          if (!options.scopeSlotId) invalidateMicronutrients(`Composição básica inválida: ${food.name}.`);
          continue;
        }
        if (curG <= 0) {
          if (!options.scopeSlotId && (refG ?? 0) > 0) invalidateMicronutrients(`Quantidade não utilizável: ${food.name}.`);
          continue;
        }

        const microPerG: Partial<Record<NutrientId, number>> = {};
        if (!options.scopeSlotId) {
          for (const constraint of micronutrientConstraints) {
            const record = normalizeNutrientEntry(food, constraint.nutrientId);
            const isNiacinEquivalent = constraint.nutrientId === 'vitamin_b3';
            if (record.normalized_unit !== constraint.unit) {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: unidade ${record.normalized_unit || 'ausente'} não corresponde à unidade DRI ${constraint.unit} para ${constraint.nutrientId}.`;
              }
              continue;
            }
            if (isNiacinEquivalent && record.conversion_method === 'preformed_niacin_only') {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: apenas niacina pré-formada está disponível; faltam os equivalentes totais de niacina (mg NE).`;
              }
              continue;
            }
            if (
              record.data_status !== 'quantified' ||
              record.normalized_value === null ||
              !Number.isFinite(record.normalized_value) ||
              record.normalized_value < 0 ||
              !Number.isFinite(record.basis_quantity) ||
              record.basis_quantity <= 0
            ) {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: ${record.data_status === 'trace' ? 'valor em traço' : record.data_status === 'invalid_value' ? 'registro numérico inválido' : 'valor não quantificado'} para ${constraint.nutrientId}.`;
              }
              continue;
            }
            const perGram = record.normalized_value / record.basis_quantity;
            if (!Number.isFinite(perGram) || perGram < 0) {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: base de conversão inválida para ${constraint.nutrientId}.`;
              }
              continue;
            }
            microPerG[constraint.nutrientId] = perGram;
          }
        }

        const basis = food.macros.basisQuantityG;
        const kcalPerG = food.macros.kcalPerBasis / basis;
        const proteinPerG = food.macros.proteinGPerBasis / basis;
        const carbsPerG = food.macros.carbsGPerBasis / basis;
        const fatPerG = food.macros.fatGPerBasis / basis;

        if (!inScope || ingredient.mode === 'locked' || ingredient.mode === 'proportional') {
          if (ingredient.mode === 'locked') lockedCount += 1;
          else proportionalCount += 1;

          const effectiveG =
            ingredient.mode === 'proportional' && refG !== null ? refG : curG;
          fixedTotals.kcal += kcalPerG * effectiveG;
          fixedTotals.proteinG += proteinPerG * effectiveG;
          fixedTotals.carbsG += carbsPerG * effectiveG;
          fixedTotals.fatG += fatPerG * effectiveG;

          slotFixed.kcal += kcalPerG * effectiveG;
          slotFixed.proteinG += proteinPerG * effectiveG;
          slotFixed.carbsG += carbsPerG * effectiveG;
          slotFixed.fatG += fatPerG * effectiveG;
          if (!options.scopeSlotId) {
            for (const constraint of micronutrientConstraints) {
              const perGram = microPerG[constraint.nutrientId];
              if (perGram !== undefined) constraint.fixedValue += perGram * effectiveG;
            }
          }
          continue;
        }

        const bounds = getEffectiveIngredientBounds(ingredient, scaleFactor);
        vars.push({
          slotId: slot.id,
          slotTitle: slot.title,
          recipeId: recipe.id,
          recipeName: recipe.name,
          ingredientId: ingredient.id,
          foodId: ingredient.foodId,
          foodName: food.name,
          currentG: Math.max(bounds.minG, Math.min(bounds.maxG, curG)),
          refG: refG ?? curG,
          minG: bounds.minG,
          maxG: bounds.maxG,
          kcalPerG,
          proteinPerG,
          carbsPerG,
          fatPerG,
          micronutrientsPerG: microPerG,
        });
        if (!options.scopeSlotId) {
          for (const constraint of micronutrientConstraints) {
            constraint.coefficients.push(microPerG[constraint.nutrientId] ?? 0);
          }
        }
      }
    }
    fixedBySlot.set(slot.id, slotFixed);
  }

  for (const constraint of micronutrientConstraints) {
    if (constraint.status !== 'applied' || constraint.upperLimit === null) continue;
    const minimumPossible = constraint.fixedValue + vars.reduce(
      (sum, variable, index) => sum + (constraint.coefficients[index] ?? 0) * variable.minG,
      0,
    );
    if (minimumPossible > constraint.upperLimit + 1e-6) {
      constraint.status = 'infeasible_upper_limit';
      constraint.reason = 'Ingredientes fixos e porções mínimas já ultrapassam o limite superior aplicável.';
    }
  }

  const slotTargets: QPSlotAllocationTarget[] = [];
  if (!options.scopeSlotId && options.mealAllocations && options.mealAllocations.length > 0) {
    const evalSummary = evaluateMealAllocations(dayPlan, targets, options.mealAllocations);
    if (evalSummary.isBalanced) {
      const proteinAllocationBalanced = evalSummary.totalProteinSharePercent !== null &&
        Math.abs(evalSummary.totalProteinSharePercent - 100) <= 0.2;
      const carbsAllocationBalanced = evalSummary.totalCarbsSharePercent !== null &&
        Math.abs(evalSummary.totalCarbsSharePercent - 100) <= 0.2;
      const fatAllocationBalanced = evalSummary.totalFatSharePercent !== null &&
        Math.abs(evalSummary.totalFatSharePercent - 100) <= 0.2;
      for (const sEval of evalSummary.slots) {
        if (sEval.sharePercent <= 0) continue;
        const hasVarsInSlot = vars.some((v) => v.slotId === sEval.slotId);
        if (!hasVarsInSlot) continue;
        const slotFixed = fixedBySlot.get(sEval.slotId) ?? { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
        const proteinShare = proteinAllocationBalanced ? sEval.proteinSharePercent : null;
        const carbsShare = carbsAllocationBalanced ? sEval.carbsSharePercent : null;
        const fatShare = fatAllocationBalanced ? sEval.fatSharePercent : null;
        slotTargets.push({
          slotId: sEval.slotId,
          slotTitle: sEval.slotTitle,
          targetKcal: (targets.kcal * sEval.sharePercent) / 100,
          fixedKcal: slotFixed.kcal,
          scaleKcal: Math.max(150, (targets.kcal * sEval.sharePercent) / 100),
          weightKcal: 0.42,
          targetProteinG: proteinShare !== null ? (targets.proteinG * proteinShare) / 100 : null,
          fixedProteinG: slotFixed.proteinG,
          scaleProteinG: Math.max(10, proteinShare !== null ? (targets.proteinG * proteinShare) / 100 : 25),
          targetCarbsG: carbsShare !== null ? (targets.carbsG * carbsShare) / 100 : null,
          fixedCarbsG: slotFixed.carbsG,
          scaleCarbsG: Math.max(15, carbsShare !== null ? (targets.carbsG * carbsShare) / 100 : 35),
          targetFatG: fatShare !== null ? (targets.fatG * fatShare) / 100 : null,
          fixedFatG: slotFixed.fatG,
          scaleFatG: Math.max(6, fatShare !== null ? (targets.fatG * fatShare) / 100 : 12),
        });
      }
    }
  }

  return {
    beforeSummary,
    lambda,
    weights,
    scales,
    fixedTotals,
    vars,
    micronutrientConstraints,
    slotTargets,
    lockedCount,
    proportionalCount,
  };
}

/** Prevents a hard UL violation from being applied as an ordinary approximate proposal. */
export function getOptimizationProposalBlockReason(
  proposal: Pick<OptimizationProposal, 'micronutrientResults'>,
): string | null {
  const violation = (proposal.micronutrientResults ?? []).find((result) =>
    result.upperLimit !== null && (
      result.withinUpperLimit === false || result.status === 'infeasible_upper_limit'
    ),
  );
  if (!violation) return null;
  const label = MICRONUTRIENT_PT_LABELS[violation.nutrientId]?.label ?? violation.nutrientId;
  return `${label}: a proposta ultrapassa um limite superior aplicável (${violation.upperLimit} ${violation.unit}) e não pode ser aplicada.`;
}

export function buildOptimizationProposalFromSolution(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  model: PreparedQPModel,
  solvedGrams: readonly number[],
  solveDurationMs: number,
  options: {
    solverEngine: string;
    hasSolverWarning?: boolean;
    warningReason?: string;
  },
): OptimizationProposal {
  const { beforeSummary, vars, lockedCount, proportionalCount } = model;
  const proposedMap = new Map<string, number>();
  const changes: ProposedIngredientChange[] = [];
  let atBoundCount = 0;

  const roundedGrams = vars.map((v, index) => {
    const raw = solvedGrams[index] ?? v.currentG;
    return Math.max(v.minG, Math.min(v.maxG, roundGramsHalf(raw)));
  });
  // Repair half-gram rounding against actual total-intake ULs without touching locked items.
  for (const constraint of model.micronutrientConstraints) {
    if (constraint.status !== 'applied' || constraint.upperLimit === null) continue;
    let total = constraint.fixedValue + roundedGrams.reduce(
      (sum, grams, index) => sum + (constraint.coefficients[index] ?? 0) * grams,
      0,
    );
    if (total <= constraint.upperLimit + 1e-6) continue;
    const candidates = vars.map((variable, index) => ({
      index,
      coefficient: constraint.coefficients[index] ?? 0,
      available: roundedGrams[index]! - variable.minG,
    })).filter((candidate) => candidate.coefficient > 0 && candidate.available > 1e-6)
      .sort((a, b) => b.coefficient - a.coefficient);
    for (const candidate of candidates) {
      const excess = total - constraint.upperLimit;
      const required = Math.ceil((excess / candidate.coefficient) * 2) / 2;
      const reduction = Math.min(candidate.available, required);
      roundedGrams[candidate.index] = Math.max(
        vars[candidate.index]!.minG,
        roundGramsHalf(roundedGrams[candidate.index]! - reduction),
      );
      total = constraint.fixedValue + roundedGrams.reduce(
        (sum, grams, index) => sum + (constraint.coefficients[index] ?? 0) * grams,
        0,
      );
      if (total <= constraint.upperLimit + 1e-6) break;
    }
    if (total > constraint.upperLimit + 1e-6) {
      constraint.status = 'infeasible_upper_limit';
      constraint.reason = 'Não foi possível manter o UL após arredondar as porções sem violar limites mínimos.';
    }
  }

  for (let i = 0; i < vars.length; i += 1) {
    const v = vars[i]!;
    const rounded = roundedGrams[i]!;
    const key = `${v.slotId}::${v.recipeId}::${v.ingredientId}`;
    proposedMap.set(key, rounded);

    const atLowerBound = Math.abs(rounded - v.minG) <= 0.5;
    const atUpperBound = Math.abs(rounded - v.maxG) <= 0.5;
    if (atLowerBound || atUpperBound) atBoundCount += 1;

    changes.push({
      slotId: v.slotId,
      slotTitle: v.slotTitle,
      recipeId: v.recipeId,
      recipeName: v.recipeName,
      ingredientId: v.ingredientId,
      foodId: v.foodId,
      foodName: v.foodName,
      currentQuantityG: v.currentG,
      proposedQuantityG: rounded,
      referenceQuantityG: v.refG,
      deltaG: Number((rounded - v.currentG).toFixed(1)),
      atLowerBound,
      atUpperBound,
    });
  }

  const proposedDayPlan = cloneDayPlan(dayPlan);
  for (const slot of proposedDayPlan.slots) {
    for (const recipe of slot.recipes) {
      for (const ingredient of recipe.ingredients) {
        const key = `${slot.id}::${recipe.id}::${ingredient.id}`;
        const nextQ = proposedMap.get(key);
        if (nextQ !== undefined) {
          ingredient.currentQuantityG = nextQ;
        }
      }
    }
  }

  const afterSummary = computeDayNutrition(proposedDayPlan);
  const micronutrientResults: MicronutrientOptimizationResult[] = model.micronutrientConstraints.map((constraint) => {
    const beforeMetric = beforeSummary.micronutrients[constraint.nutrientId];
    const afterMetric = afterSummary.micronutrients[constraint.nutrientId];
    const canReportValues = constraint.status !== 'insufficient_data' &&
      constraint.status !== 'not_applicable_scope' &&
      beforeMetric.dataStatus === 'quantified' && afterMetric.dataStatus === 'quantified';
    const beforeValue = canReportValues ? beforeMetric.value : null;
    const afterValue = canReportValues ? afterMetric.value : null;
    const withinUpperLimit = constraint.upperLimit !== null && afterValue !== null
      ? afterValue <= constraint.upperLimit + 1e-6
      : null;
    const status: MicronutrientOptimizationStatus = constraint.status === 'applied' && withinUpperLimit === false
      ? 'infeasible_upper_limit'
      : constraint.status;
    return {
      nutrientId: constraint.nutrientId,
      unit: constraint.unit,
      status,
      reason: status === 'infeasible_upper_limit' && !constraint.reason
        ? 'A porção final ultrapassou o limite superior após a otimização.'
        : constraint.reason,
      minimum: constraint.minimum,
      minimumKind: constraint.minimumKind,
      preferredMaximum: constraint.preferredMaximum,
      upperLimit: constraint.upperLimit,
      beforeValue,
      afterValue,
      meetsMinimum: constraint.minimum !== null && afterValue !== null ? afterValue >= constraint.minimum : null,
      withinPreferredMaximum: constraint.preferredMaximum !== null && afterValue !== null
        ? afterValue <= constraint.preferredMaximum
        : null,
      withinUpperLimit,
    };
  });
  const hasIncompleteNutritionData = afterSummary.unresolvedFoodIds.length > 0 ||
    afterSummary.lowConfidenceFoodIds.length > 0 || afterSummary.missingIngredientsCount > 0 || afterSummary.toTasteIngredientsCount > 0 ||
    afterSummary.coveragePercent < 99.99;
  const hasUnappliedMicronutrients = micronutrientResults.some((result) =>
    result.status === 'insufficient_data' || result.status === 'infeasible_upper_limit',
  );
  const hasUnmetMicronutrientPreferences = micronutrientResults.some((result) =>
    result.status === 'applied' && (result.meetsMinimum === false || result.withinPreferredMaximum === false),
  );
  const kcalGap = Math.abs(afterSummary.macros.kcal - targets.kcal);
  const pGap = Math.abs(afterSummary.macros.proteinG - targets.proteinG);
  const cGap = Math.abs(afterSummary.macros.carbsG - targets.carbsG);
  const fGap = Math.abs(afterSummary.macros.fatG - targets.fatG);

  const kcalTol = Math.max(55, targets.kcal * 0.03);
  const pTol = Math.max(8, targets.proteinG * 0.06);
  const cTol = Math.max(12, targets.carbsG * 0.07);
  const fTol = Math.max(6, targets.fatG * 0.08);
  const targetsCloselyMet = kcalGap <= kcalTol && pGap <= pTol && cGap <= cTol && fGap <= fTol;

  let certificate: SolverCertificate = 'optimal';
  let explanation =
    model.slotTargets.length > 0
      ? 'Ótimo convexo alcançado respeitando metas diárias, distribuição por refeição e limites culinários.'
      : 'Ótimo convexo alcançado dentro dos limites culinários e com menor desvio ponderado possível.';

  if (hasIncompleteNutritionData || hasUnappliedMicronutrients) {
    certificate = 'approximate';
    explanation = hasUnappliedMicronutrients
      ? 'Resultado aproximado: uma ou mais metas de micronutrientes não puderam ser aplicadas com segurança por falta de dados completos ou por conflito com limite superior. Confira a cobertura antes de aplicar.'
      : 'Resultado aproximado: existem alimentos sem composição/quantidade completa. O otimizador só consegue equilibrar a parcela quantificada; confira a cobertura antes de aplicar.';
  } else if (options.hasSolverWarning) {
    certificate = 'approximate';
    explanation =
      options.warningReason ??
      'Aproximação numérica gerada; refine limites mínimos/máximos ou desbloqueie mais ingredientes para convergência exata.';
  } else if (!targetsCloselyMet) {
    certificate = 'feasible';
    const reasons: string[] = [];
    if (atBoundCount > 0) {
      reasons.push(`${atBoundCount} ingrediente(s) atingiram limite mínimo/máximo de porção`);
    }
    if (lockedCount > 0) {
      reasons.push(`${lockedCount} item(ns) estão fixados`);
    }
    explanation =
      reasons.length > 0
        ? `Melhor solução viável encontrada (${reasons.join(' · ')}). Para fechar o restante da meta, avalie trocas discretas de receita.`
        : 'Melhor equilíbrio contínuo encontrado preservando as proporções das receitas. Use substituições discretas se quiser alterar o perfil dos alimentos.';
  } else if (hasUnmetMicronutrientPreferences) {
    certificate = 'feasible';
    explanation = 'Metas de macronutrientes atingidas dentro das tolerâncias, mas uma ou mais preferências DRI de micronutrientes permanecem fora do alvo por limites de porção ou pela composição disponível.';
  }

  const adjustedCount = changes.filter((c) => Math.abs(c.deltaG) >= 0.5).length;

  return {
    id: `opt-${Date.now().toString(36)}`,
    certificate,
    solverEngine: options.solverEngine,
    explanation,
    beforeMacros: beforeSummary.macros,
    afterMacros: afterSummary.macros,
    targets: { ...targets },
    weightedDeviationBeforePercent: beforeSummary.weightedDeviationPercent,
    weightedDeviationAfterPercent: afterSummary.weightedDeviationPercent,
    adjustedCount,
    lockedCount,
    proportionalCount,
    micronutrientResults,
    changes,
    proposedDayPlan,
    solveDurationMs: Number(solveDurationMs.toFixed(2)),
  };
}

/**
 * Deterministic Strictly Convex Quadratic Programming Solver (Projected FISTA + Coordinate Polish)
 *
 * Minimizes:
 *   sum_k w_k * ((N_k(x) - T_k) / S_k)^2 + slot_allocation_terms + lambda * sum_i ((x_i - q_i^{ref}) / (q_i^{ref} + eps))^2
 * subject to l_i <= x_i <= u_i over `flexible` ingredients.
 */
export function solveNutritionalBalanceQP(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions = {},
): OptimizationProposal {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const model = prepareQPModel(dayPlan, targets, options);
  const { beforeSummary, lambda, weights, scales, fixedTotals, vars, slotTargets, lockedCount, proportionalCount } = model;

  const n = vars.length;
  if (n === 0) {
    const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
    return buildOptimizationProposalFromSolution(dayPlan, targets, model, [], t1 - t0, {
      solverEngine: 'Nenhuma variável flexível',
      hasSolverWarning: true,
      warningReason: 'Nenhum ingrediente flexível com composição calculável está desbloqueado. Libere ao menos um ingrediente para o modo Flexível.',
    });
  }

  const invScale2 = {
    kcal: (2 * weights.kcal) / (scales.kcal * scales.kcal),
    proteinG: (2 * weights.proteinG) / (scales.proteinG * scales.proteinG),
    carbsG: (2 * weights.carbsG) / (scales.carbsG * scales.carbsG),
    fatG: (2 * weights.fatG) / (scales.fatG * scales.fatG),
  };
  const MICRO_SOFT_WEIGHT = 0.08;
  const activeMicronutrients = model.micronutrientConstraints.filter((constraint) => constraint.status === 'applied');
  const microResidualScales = activeMicronutrients.map((constraint) =>
    resolveMicronutrientResidualScales(constraint),
  );
  const microMinimumInvScale2 = microResidualScales.map(({ minimum }) =>
    (2 * MICRO_SOFT_WEIGHT) / (minimum * minimum),
  );
  const microPreferredMaximumInvScale2 = microResidualScales.map(({ preferredMaximum }) =>
    (2 * MICRO_SOFT_WEIGHT) / (preferredMaximum * preferredMaximum),
  );

  const slotIndexMap = new Map<string, number>();
  slotTargets.forEach((st, idx) => slotIndexMap.set(st.slotId, idx));
  const varSlotIdx = new Int32Array(n);
  const slotInv2Kcal = new Float64Array(slotTargets.length);
  const slotInv2P = new Float64Array(slotTargets.length);
  const slotInv2C = new Float64Array(slotTargets.length);
  const slotInv2F = new Float64Array(slotTargets.length);
  const slotMacroWeight = 0.28;

  for (let s = 0; s < slotTargets.length; s += 1) {
    const st = slotTargets[s]!;
    slotInv2Kcal[s] = (2 * st.weightKcal) / (st.scaleKcal * st.scaleKcal);
    slotInv2P[s] = st.targetProteinG !== null ? (2 * slotMacroWeight) / (st.scaleProteinG * st.scaleProteinG) : 0;
    slotInv2C[s] = st.targetCarbsG !== null ? (2 * slotMacroWeight) / (st.scaleCarbsG * st.scaleCarbsG) : 0;
    slotInv2F[s] = st.targetFatG !== null ? (2 * slotMacroWeight) / (st.scaleFatG * st.scaleFatG) : 0;
  }

  // Compute global Lipschitz constant L for exact projected gradient step 1/L
  let sumA2Kcal = 0;
  let sumA2P = 0;
  let sumA2C = 0;
  let sumA2F = 0;
  let maxSlotHessian = 0;
  let maxProxHessian = 0;
  const proxCoeff = new Float64Array(n);

  for (let i = 0; i < n; i += 1) {
    const v = vars[i]!;
    const sIdx = slotIndexMap.get(v.slotId) ?? -1;
    varSlotIdx[i] = sIdx;

    sumA2Kcal += v.kcalPerG * v.kcalPerG;
    sumA2P += v.proteinPerG * v.proteinPerG;
    sumA2C += v.carbsPerG * v.carbsPerG;
    sumA2F += v.fatPerG * v.fatPerG;
    if (sIdx >= 0) {
      const slotH =
        slotInv2Kcal[sIdx]! * v.kcalPerG * v.kcalPerG +
        slotInv2P[sIdx]! * v.proteinPerG * v.proteinPerG +
        slotInv2C[sIdx]! * v.carbsPerG * v.carbsPerG +
        slotInv2F[sIdx]! * v.fatPerG * v.fatPerG;
      maxSlotHessian += slotH;
    }
    const denom = v.refG + 25;
    const pCoeff = (2 * lambda) / (denom * denom);
    proxCoeff[i] = pCoeff;
    if (pCoeff > maxProxHessian) maxProxHessian = pCoeff;
  }

  const lipschitz =
    invScale2.kcal * sumA2Kcal +
    invScale2.proteinG * sumA2P +
    invScale2.carbsG * sumA2C +
    invScale2.fatG * sumA2F +
    maxSlotHessian +
    maxProxHessian +
    activeMicronutrients.reduce((sum, constraint, cIdx) => {
      const coefficientNorm = constraint.coefficients.reduce((norm, coefficient) => norm + coefficient * coefficient, 0);
      return sum + Math.max(microMinimumInvScale2[cIdx]!, microPreferredMaximumInvScale2[cIdx]!) * coefficientNorm;
    }, 0) +
    1e-9;
  const stepSize = 1 / lipschitz;

  const x = new Float64Array(n);
  const y = new Float64Array(n);
  const xPrev = new Float64Array(n);
  const grad = new Float64Array(n);
  const slotKcal = new Float64Array(slotTargets.length);
  const slotP = new Float64Array(slotTargets.length);
  const slotC = new Float64Array(slotTargets.length);
  const slotF = new Float64Array(slotTargets.length);

  for (let i = 0; i < n; i += 1) {
    const v = vars[i]!;
    x[i] = v.currentG;
    y[i] = v.currentG;
    xPrev[i] = v.currentG;
  }
  const computeTotalsFromVec = (vec: Float64Array) => {
    let kcal = fixedTotals.kcal;
    let proteinG = fixedTotals.proteinG;
    let carbsG = fixedTotals.carbsG;
    let fatG = fixedTotals.fatG;
    for (let s = 0; s < slotTargets.length; s += 1) {
      const st = slotTargets[s]!;
      slotKcal[s] = st.fixedKcal;
      slotP[s] = st.fixedProteinG;
      slotC[s] = st.fixedCarbsG;
      slotF[s] = st.fixedFatG;
    }
    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      const q = vec[i]!;
      const dK = v.kcalPerG * q;
      const dP = v.proteinPerG * q;
      const dC = v.carbsPerG * q;
      const dF = v.fatPerG * q;
      kcal += dK;
      proteinG += dP;
      carbsG += dC;
      fatG += dF;
      const sIdx = varSlotIdx[i]!;
      if (sIdx >= 0) {
        slotKcal[sIdx]! += dK;
        slotP[sIdx]! += dP;
        slotC[sIdx]! += dC;
        slotF[sIdx]! += dF;
      }
    }
    return { kcal, proteinG, carbsG, fatG };
  };

  const getMicronutrientTotal = (vec: Float64Array, constraint: PreparedMicronutrientConstraint) =>
    constraint.fixedValue + constraint.coefficients.reduce(
      (sum, coefficient, index) => sum + coefficient * vec[index]!,
      0,
    );
  const micronutrientResidual = (value: number, constraint: PreparedMicronutrientConstraint) => {
    if (constraint.minimum !== null && value < constraint.minimum) return value - constraint.minimum;
    if (constraint.preferredMaximum !== null && value > constraint.preferredMaximum) return value - constraint.preferredMaximum;
    return 0;
  };

  const projectHardUpperLimits = (vec: Float64Array): boolean => {
    const constraints = activeMicronutrients.filter((constraint) => constraint.upperLimit !== null);
    for (let iteration = 0; iteration < 100; iteration += 1) {
      for (let i = 0; i < n; i += 1) {
        const variable = vars[i]!;
        vec[i] = Math.max(variable.minG, Math.min(variable.maxG, vec[i]!));
      }
      for (const constraint of constraints) {
        const limit = constraint.upperLimit!;
        const violation = getMicronutrientTotal(vec, constraint) - limit;
        if (violation <= 1e-7) continue;
        const normSquared = constraint.coefficients.reduce((sum, value) => sum + value * value, 0);
        if (normSquared <= 1e-16) continue;
        const multiplier = violation / normSquared;
        for (let index = 0; index < n; index += 1) {
          const variable = vars[index]!;
          vec[index] = Math.max(
            variable.minG,
            Math.min(variable.maxG, vec[index]! - multiplier * (constraint.coefficients[index] ?? 0)),
          );
        }
      }
      const maximumViolation = constraints.reduce(
        (maximum, constraint) => Math.max(maximum, getMicronutrientTotal(vec, constraint) - constraint.upperLimit!),
        0,
      );
      if (maximumViolation <= 1e-6) return true;
    }
    return constraints.every((constraint) =>
      getMicronutrientTotal(vec, constraint) <= constraint.upperLimit! + 1e-6,
    );
  };

  const initialUpperLimitProjectionSucceeded = projectHardUpperLimits(x);
  y.set(x);
  xPrev.set(x);

  const computeGradAt = (vec: Float64Array, outGrad: Float64Array) => {
    const totals = computeTotalsFromVec(vec);
    const resKcal = (totals.kcal - targets.kcal) * invScale2.kcal;
    const resP = (totals.proteinG - targets.proteinG) * invScale2.proteinG;
    const resC = (totals.carbsG - targets.carbsG) * invScale2.carbsG;
    const resF = (totals.fatG - targets.fatG) * invScale2.fatG;

    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      let g =
        resKcal * v.kcalPerG +
        resP * v.proteinPerG +
        resC * v.carbsPerG +
        resF * v.fatPerG +
        proxCoeff[i]! * (vec[i]! - v.refG);
      const sIdx = varSlotIdx[i]!;
      if (sIdx >= 0) {
        const st = slotTargets[sIdx]!;
        g += (slotKcal[sIdx]! - st.targetKcal) * slotInv2Kcal[sIdx]! * v.kcalPerG;
        if (st.targetProteinG !== null) {
          g += (slotP[sIdx]! - st.targetProteinG) * slotInv2P[sIdx]! * v.proteinPerG;
        }
        if (st.targetCarbsG !== null) {
          g += (slotC[sIdx]! - st.targetCarbsG) * slotInv2C[sIdx]! * v.carbsPerG;
        }
        if (st.targetFatG !== null) {
          g += (slotF[sIdx]! - st.targetFatG) * slotInv2F[sIdx]! * v.fatPerG;
        }
      }
      for (let cIdx = 0; cIdx < activeMicronutrients.length; cIdx += 1) {
        const constraint = activeMicronutrients[cIdx]!;
        const residual = micronutrientResidual(getMicronutrientTotal(vec, constraint), constraint);
        if (residual !== 0) {
          const residualScale2 = residual < 0
            ? microMinimumInvScale2[cIdx]!
            : microPreferredMaximumInvScale2[cIdx]!;
          g += residual * residualScale2 * (constraint.coefficients[i] ?? 0);
        }
      }
      outGrad[i] = g;
    }
  };

  // Phase 1: FISTA with adaptive gradient restart
  let tMomentum = 1;
  for (let iter = 0; iter < 320; iter += 1) {
    computeGradAt(y, grad);
    let restartDot = 0;
    let maxMove = 0;
    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      const rawNext = y[i]! - stepSize * grad[i]!;
      const clamped = Math.max(v.minG, Math.min(v.maxG, rawNext));
      xPrev[i] = x[i]!;
      x[i] = clamped;
      restartDot += (y[i]! - clamped) * (clamped - xPrev[i]!);
      const diff = Math.abs(clamped - xPrev[i]!);
      if (diff > maxMove) maxMove = diff;
    }
    projectHardUpperLimits(x);

    if (restartDot > 0) {
      tMomentum = 1;
      for (let i = 0; i < n; i += 1) {
        y[i] = x[i]!;
      }
    } else {
      const tNext = 0.5 * (1 + Math.sqrt(1 + 4 * tMomentum * tMomentum));
      const beta = (tMomentum - 1) / tNext;
      for (let i = 0; i < n; i += 1) {
        const v = vars[i]!;
        const extrapolated = x[i]! + beta * (x[i]! - xPrev[i]!);
        y[i] = Math.max(v.minG, Math.min(v.maxG, extrapolated));
      }
      projectHardUpperLimits(y);
      tMomentum = tNext;
    }

    if (maxMove < 1e-5 && iter > 20) break;
  }

  // Phase 2: Exact coordinate-descent box-constrained QP polish
  for (let sweep = 0; sweep < 40; sweep += 1) {
    let sweepDelta = 0;
    const totals = computeTotalsFromVec(x);
    let curKcal = totals.kcal;
    let curP = totals.proteinG;
    let curC = totals.carbsG;
    let curF = totals.fatG;

    for (let i = 0; i < n; i += 1) {
      const v = vars[i]!;
      const oldXi = x[i]!;
      const sIdx = varSlotIdx[i]!;
      let hDiag =
        invScale2.kcal * v.kcalPerG * v.kcalPerG +
        invScale2.proteinG * v.proteinPerG * v.proteinPerG +
        invScale2.carbsG * v.carbsPerG * v.carbsPerG +
        invScale2.fatG * v.fatPerG * v.fatPerG +
        proxCoeff[i]!;

      let gCoord =
        (curKcal - targets.kcal) * invScale2.kcal * v.kcalPerG +
        (curP - targets.proteinG) * invScale2.proteinG * v.proteinPerG +
        (curC - targets.carbsG) * invScale2.carbsG * v.carbsPerG +
        (curF - targets.fatG) * invScale2.fatG * v.fatPerG +
        proxCoeff[i]! * (oldXi - v.refG);

      if (sIdx >= 0) {
        const st = slotTargets[sIdx]!;
        hDiag +=
          slotInv2Kcal[sIdx]! * v.kcalPerG * v.kcalPerG +
          slotInv2P[sIdx]! * v.proteinPerG * v.proteinPerG +
          slotInv2C[sIdx]! * v.carbsPerG * v.carbsPerG +
          slotInv2F[sIdx]! * v.fatPerG * v.fatPerG;
        gCoord += (slotKcal[sIdx]! - st.targetKcal) * slotInv2Kcal[sIdx]! * v.kcalPerG;
        if (st.targetProteinG !== null) {
          gCoord += (slotP[sIdx]! - st.targetProteinG) * slotInv2P[sIdx]! * v.proteinPerG;
        }
        if (st.targetCarbsG !== null) {
          gCoord += (slotC[sIdx]! - st.targetCarbsG) * slotInv2C[sIdx]! * v.carbsPerG;
        }
        if (st.targetFatG !== null) {
          gCoord += (slotF[sIdx]! - st.targetFatG) * slotInv2F[sIdx]! * v.fatPerG;
        }
      }

      for (let cIdx = 0; cIdx < activeMicronutrients.length; cIdx += 1) {
        const constraint = activeMicronutrients[cIdx]!;
        const coefficient = constraint.coefficients[i] ?? 0;
        if (coefficient <= 0) continue;
        const residual = micronutrientResidual(getMicronutrientTotal(x, constraint), constraint);
        if (residual !== 0) {
          const residualScale2 = residual < 0
            ? microMinimumInvScale2[cIdx]!
            : microPreferredMaximumInvScale2[cIdx]!;
          hDiag += residualScale2 * coefficient * coefficient;
          gCoord += residual * residualScale2 * coefficient;
        }
      }

      if (hDiag <= 1e-12) continue;

      const newXi = Math.max(v.minG, Math.min(v.maxG, oldXi - gCoord / hDiag));
      const delta = newXi - oldXi;
      if (Math.abs(delta) > 1e-8) {
        x[i] = newXi;
        curKcal += v.kcalPerG * delta;
        curP += v.proteinPerG * delta;
        curC += v.carbsPerG * delta;
        curF += v.fatPerG * delta;
        if (sIdx >= 0) {
          slotKcal[sIdx]! += v.kcalPerG * delta;
          slotP[sIdx]! += v.proteinPerG * delta;
          slotC[sIdx]! += v.carbsPerG * delta;
          slotF[sIdx]! += v.fatPerG * delta;
        }
        sweepDelta = Math.max(sweepDelta, Math.abs(delta));
      }
    }
    projectHardUpperLimits(x);
    if (sweepDelta < 1e-5) break;
  }

  // Projected-gradient KKT residual includes box bounds and hard micronutrient ULs.
  computeGradAt(x, grad);
  let maxKktViolation = 0;
  const kktProbe = new Float64Array(n);
  for (let i = 0; i < n; i += 1) {
    kktProbe[i] = x[i]! - stepSize * grad[i]!;
  }
  const kktProjectionSucceeded = projectHardUpperLimits(kktProbe);
  for (let i = 0; i < n; i += 1) {
    const violation = Math.abs(x[i]! - kktProbe[i]!) / stepSize;
    if (violation > maxKktViolation) maxKktViolation = violation;
  }
  const finalUpperLimitProjectionSucceeded = projectHardUpperLimits(x);
  const upperLimitProjectionFailed = !initialUpperLimitProjectionSucceeded ||
    !finalUpperLimitProjectionSucceeded || !kktProjectionSucceeded;

  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  return buildOptimizationProposalFromSolution(
    dayPlan,
    targets,
    model,
    Array.from(x),
    t1 - t0,
    {
      solverEngine: 'FISTA + Coordinate Polish (TS)',
      hasSolverWarning: maxKktViolation > 5e-3 || upperLimitProjectionFailed,
      warningReason: upperLimitProjectionFailed
        ? 'O solucionador não conseguiu certificar a projeção de todos os limites superiores dos micronutrientes.'
        : maxKktViolation > 5e-3
          ? 'A aproximação numérica não atingiu a tolerância KKT configurada.'
          : undefined,
    },
  );
}

function normalizedTargetGap(macros: ComposerMacroTotals, targets: NutritionTargets): number {
  const e = (macros.kcal - targets.kcal) / Math.max(400, targets.kcal);
  const p = (macros.proteinG - targets.proteinG) / Math.max(30, targets.proteinG);
  const c = (macros.carbsG - targets.carbsG) / Math.max(40, targets.carbsG);
  const f = (macros.fatG - targets.fatG) / Math.max(15, targets.fatG);
  return Math.sqrt(1.4 * e * e + 1.3 * p * p + 0.85 * c * c + 0.85 * f * f);
}

export function proposeDiscreteSubstitutions(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  limit = 4,
): DiscreteSubstitutionProposal[] {
  const currentSummary = computeDayNutrition(dayPlan);
  const currentGap = normalizedTargetGap(currentSummary.macros, targets);
  const candidates: DiscreteSubstitutionProposal[] = [];

  for (const slot of dayPlan.slots) {
    const primaryRecipe = slot.recipes[0];
    if (!primaryRecipe) continue;

    const currentRecipeSummary = computeRecipeNutrition(primaryRecipe);
    for (const catalogRecipe of RECIPE_CATALOG) {
      if (!isEligibleRecipeTemplate(catalogRecipe)) continue;
      if (catalogRecipe.id === primaryRecipe.sourceRecipeId) continue;

      const candidateInstance = createRecipeInstanceFromCatalog(
        catalogRecipe,
        `${slot.id}-cand-${catalogRecipe.id}`,
        1,
        'balanced',
      );
      const candidateSummary = computeRecipeNutrition(candidateInstance);
      const deltaMacros: ComposerMacroTotals = {
        kcal: candidateSummary.macros.kcal - currentRecipeSummary.macros.kcal,
        proteinG: candidateSummary.macros.proteinG - currentRecipeSummary.macros.proteinG,
        carbsG: candidateSummary.macros.carbsG - currentRecipeSummary.macros.carbsG,
        fatG: candidateSummary.macros.fatG - currentRecipeSummary.macros.fatG,
      };
      const projectedDayMacros: ComposerMacroTotals = {
        kcal: currentSummary.macros.kcal + deltaMacros.kcal,
        proteinG: currentSummary.macros.proteinG + deltaMacros.proteinG,
        carbsG: currentSummary.macros.carbsG + deltaMacros.carbsG,
        fatG: currentSummary.macros.fatG + deltaMacros.fatG,
      };
      const targetGapAfter = normalizedTargetGap(projectedDayMacros, targets);
      const sameCategoryBonus = catalogRecipe.category === primaryRecipe.category ? -0.02 : 0;

      if (targetGapAfter + sameCategoryBonus < currentGap + 0.08) {
        candidates.push({
          id: `sub-${slot.id}-${catalogRecipe.id}`,
          slotId: slot.id,
          slotTitle: slot.title,
          currentRecipeId: primaryRecipe.id,
          currentRecipeName: primaryRecipe.name,
          candidateRecipeId: catalogRecipe.id,
          candidateRecipeName: catalogRecipe.name,
          sourceSummary: candidateSummary.sources.join(' · ') || 'TBCA',
          deltaMacros,
          projectedDayMacros,
          targetGapAfter: Number((targetGapAfter + sameCategoryBonus).toFixed(4)),
        });
      }
    }
  }

  candidates.sort((a, b) => a.targetGapAfter - b.targetGapAfter);
  return candidates.slice(0, Math.max(1, limit));
}

export interface IngredientDiffRow {
  foodId: string;
  foodName: string;
  baselineGrams: number;
  candidateGrams: number;
  deltaGrams: number;
  status: 'added' | 'removed' | 'modified' | 'unchanged';
}

export interface SlotDiffRow {
  slotId: string;
  slotTitle: string;
  slotTime: string;
  baselineKcal: number;
  candidateKcal: number;
  deltaKcal: number;
  baselineProteinG: number;
  candidateProteinG: number;
  baselineRecipeNames: string[];
  candidateRecipeNames: string[];
}

export interface CompositionDiffSummary {
  baselineMacros: ComposerMacroTotals;
  candidateMacros: ComposerMacroTotals;
  deltaMacros: ComposerMacroTotals;
  baselineDeviationPercent: number;
  candidateDeviationPercent: number;
  baselineCoveragePercent: number;
  candidateCoveragePercent: number;
  addedRecipes: string[];
  removedRecipes: string[];
  slotDiffs: SlotDiffRow[];
  ingredientDiffs: IngredientDiffRow[];
  micronutrientDeltas: Array<{
    nutrientId: NutrientId;
    label: string;
    unit: string;
    baselineValue: number | null;
    candidateValue: number | null;
  }>;
  baselineSources: FoodSourceId[];
  candidateSources: FoodSourceId[];
}

export function buildOriginalBaselineDayPlan(dayPlan: ComposerDayPlan): ComposerDayPlan {
  const next = cloneDayPlan(dayPlan);
  for (const slot of next.slots) {
    for (const recipe of slot.recipes) {
      const scale = getRecipeScaleFactor(recipe);
      for (const ing of recipe.ingredients) {
        if (ing.quantityStatus !== 'known') continue;
        const refG = getScaledReferenceGrams(ing, scale);
        if (refG !== null) {
          ing.currentQuantityG = refG;
        }
      }
    }
  }
  return next;
}

export function computeWeeklyPlanSummary(plan: CardapioPlan): {
  dayCount: number;
  avgMacros: ComposerMacroTotals;
  avgDeviationPercent: number;
} {
  const days = Object.values(plan.days);
  if (days.length === 0) {
    return {
      dayCount: 0,
      avgMacros: { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 },
      avgDeviationPercent: 0,
    };
  }
  let kcal = 0;
  let proteinG = 0;
  let carbsG = 0;
  let fatG = 0;
  let dev = 0;
  for (const day of days) {
    const s = computeDayNutrition(day);
    kcal += s.macros.kcal;
    proteinG += s.macros.proteinG;
    carbsG += s.macros.carbsG;
    fatG += s.macros.fatG;
    dev += s.weightedDeviationPercent;
  }
  const n = days.length;
  return {
    dayCount: n,
    avgMacros: {
      kcal: kcal / n,
      proteinG: proteinG / n,
      carbsG: carbsG / n,
      fatG: fatG / n,
    },
    avgDeviationPercent: Number((dev / n).toFixed(1)),
  };
}

export function computeCompositionDiff(
  baselineDay: ComposerDayPlan,
  candidateDay: ComposerDayPlan,
): CompositionDiffSummary {
  const baselineSummary = computeDayNutrition(baselineDay);
  const candidateSummary = computeDayNutrition(candidateDay);

  const baselineRecipes = new Map<string, string>();
  const candidateRecipes = new Map<string, string>();
  const baselineFoods = new Map<string, { name: string; grams: number }>();
  const candidateFoods = new Map<string, { name: string; grams: number }>();

  const collect = (
    day: ComposerDayPlan,
    recipeMap: Map<string, string>,
    foodMap: Map<string, { name: string; grams: number }>,
  ) => {
    for (const slot of day.slots) {
      for (const recipe of slot.recipes) {
        const recipeKey = recipe.sourceRecipeId ?? recipe.name;
        recipeMap.set(recipeKey, recipe.name);
        for (const ing of recipe.ingredients) {
          if (ing.quantityStatus !== 'known' || ing.currentQuantityG === null) continue;
          const food = resolveFoodById(ing.foodId);
          const name = food?.name ?? ing.displayName ?? ing.foodId;
          const prev = foodMap.get(ing.foodId);
          foodMap.set(ing.foodId, {
            name,
            grams: (prev?.grams ?? 0) + ing.currentQuantityG,
          });
        }
      }
    }
  };

  collect(baselineDay, baselineRecipes, baselineFoods);
  collect(candidateDay, candidateRecipes, candidateFoods);

  const addedRecipes: string[] = [];
  const removedRecipes: string[] = [];
  for (const [key, name] of candidateRecipes.entries()) {
    if (!baselineRecipes.has(key)) addedRecipes.push(name);
  }
  for (const [key, name] of baselineRecipes.entries()) {
    if (!candidateRecipes.has(key)) removedRecipes.push(name);
  }

  // Per-slot meal breakdown (match by slot id or time+title)
  const slotDiffs: SlotDiffRow[] = [];
  const matchedCandIds = new Set<string>();
  for (const bSlot of baselineDay.slots) {
    const cSlot =
      candidateDay.slots.find((s) => s.id === bSlot.id) ??
      candidateDay.slots.find((s) => !matchedCandIds.has(s.id) && s.time === bSlot.time);
    if (cSlot) matchedCandIds.add(cSlot.id);
    const bSum = computeSlotNutrition(bSlot);
    const cSum = cSlot ? computeSlotNutrition(cSlot) : null;
    slotDiffs.push({
      slotId: bSlot.id,
      slotTitle: bSlot.title,
      slotTime: bSlot.time,
      baselineKcal: Math.round(bSum.macros.kcal),
      candidateKcal: Math.round(cSum?.macros.kcal ?? 0),
      deltaKcal: Math.round((cSum?.macros.kcal ?? 0) - bSum.macros.kcal),
      baselineProteinG: Number(bSum.macros.proteinG.toFixed(1)),
      candidateProteinG: Number((cSum?.macros.proteinG ?? 0).toFixed(1)),
      baselineRecipeNames: bSlot.recipes.map((r) => r.name),
      candidateRecipeNames: cSlot ? cSlot.recipes.map((r) => r.name) : [],
    });
  }
  for (const cSlot of candidateDay.slots) {
    if (matchedCandIds.has(cSlot.id)) continue;
    const cSum = computeSlotNutrition(cSlot);
    slotDiffs.push({
      slotId: cSlot.id,
      slotTitle: cSlot.title,
      slotTime: cSlot.time,
      baselineKcal: 0,
      candidateKcal: Math.round(cSum.macros.kcal),
      deltaKcal: Math.round(cSum.macros.kcal),
      baselineProteinG: 0,
      candidateProteinG: Number(cSum.macros.proteinG.toFixed(1)),
      baselineRecipeNames: [],
      candidateRecipeNames: cSlot.recipes.map((r) => r.name),
    });
  }
  slotDiffs.sort((a, b) => a.slotTime.localeCompare(b.slotTime));

  const allFoodIds = new Set([...baselineFoods.keys(), ...candidateFoods.keys()]);
  const ingredientDiffs: IngredientDiffRow[] = [];
  for (const foodId of allFoodIds) {
    const base = baselineFoods.get(foodId);
    const cand = candidateFoods.get(foodId);
    const baselineGrams = Number((base?.grams ?? 0).toFixed(1));
    const candidateGrams = Number((cand?.grams ?? 0).toFixed(1));
    const deltaGrams = Number((candidateGrams - baselineGrams).toFixed(1));
    const status: IngredientDiffRow['status'] = !base
      ? 'added'
      : !cand
        ? 'removed'
        : Math.abs(deltaGrams) >= 0.5
          ? 'modified'
          : 'unchanged';
    ingredientDiffs.push({
      foodId,
      foodName: cand?.name ?? base?.name ?? foodId,
      baselineGrams,
      candidateGrams,
      deltaGrams,
      status,
    });
  }

  ingredientDiffs.sort((a, b) => Math.abs(b.deltaGrams) - Math.abs(a.deltaGrams));

  const micronutrientDeltas = KEY_COMPOSER_MICRONUTRIENTS.map((nutrientId) => ({
    nutrientId,
    label: MICRONUTRIENT_PT_LABELS[nutrientId].label,
    unit: MICRONUTRIENT_PT_LABELS[nutrientId].unit,
    baselineValue: baselineSummary.micronutrients[nutrientId].value,
    candidateValue: candidateSummary.micronutrients[nutrientId].value,
  }));

  return {
    baselineMacros: baselineSummary.macros,
    candidateMacros: candidateSummary.macros,
    deltaMacros: {
      kcal: candidateSummary.macros.kcal - baselineSummary.macros.kcal,
      proteinG: candidateSummary.macros.proteinG - baselineSummary.macros.proteinG,
      carbsG: candidateSummary.macros.carbsG - baselineSummary.macros.carbsG,
      fatG: candidateSummary.macros.fatG - baselineSummary.macros.fatG,
    },
    baselineDeviationPercent: baselineSummary.weightedDeviationPercent,
    candidateDeviationPercent: candidateSummary.weightedDeviationPercent,
    baselineCoveragePercent: baselineSummary.coveragePercent,
    candidateCoveragePercent: candidateSummary.coveragePercent,
    addedRecipes,
    removedRecipes,
    slotDiffs,
    ingredientDiffs,
    micronutrientDeltas,
    baselineSources: baselineSummary.sources,
    candidateSources: candidateSummary.sources,
  };
}
