import type {
  ComposerDayPlan,
  ComposerMacroTotals,
  DailyMicronutrientOptimizationTarget,
  MealTargetAllocation,
  NutrientId,
  NutritionTargets,
} from '../entities/nutrient.ts';
import {
  computeDayNutrition,
  evaluateMealAllocations,
  getEffectiveIngredientBounds,
  getRecipeScaleFactor,
  getScaledReferenceGrams,
  type ComposerNutritionSummary,
  type PreparedMicronutrientConstraint,
  type QPSlotAllocationTarget,
} from './cardapio-composer-engine.ts';
import { validateFoodMacroComposition } from './food-data-quality.ts';
import { normalizeNutrientEntry, resolveFoodById } from './nutrition-calculator.ts';

export type RecipeScaleBaselineSource = 'workingBaseline' | 'templateBaseline';

export interface ScalableRecipeIngredientSpec {
  slotId: string;
  recipeId: string;
  ingredientId: string;
  foodId: string;
  foodName: string;
  baselineG: number;
  templateRefG: number;
  currentG: number;
  minG: number;
  maxG: number;
  kcalPerG: number;
  proteinPerG: number;
  carbsPerG: number;
  fatPerG: number;
  micronutrientsPerG: Partial<Record<NutrientId, number>>;
}

export interface RecipeScaleDecisionVar {
  slotId: string;
  slotTitle: string;
  recipeId: string;
  recipeName: string;
  currentServings: number;
  minScale: number;
  maxScale: number;
  boundsFeasible: boolean;
  refScale: number;
  kcalPerUnitScale: number;
  proteinPerUnitScale: number;
  carbsPerUnitScale: number;
  fatPerUnitScale: number;
  totalBaselineGrams: number;
  micronutrientsPerUnitScale: Partial<Record<NutrientId, number>>;
  ingredients: ScalableRecipeIngredientSpec[];
}

export interface RecipeScaleModelOptions {
  scopeSlotId?: string;
  lambda?: number;
  goalFocus?: 'balanced' | 'energy' | 'protein';
  baselineSource?: RecipeScaleBaselineSource;
  mealAllocations?: readonly MealTargetAllocation[];
  micronutrientTargets?: readonly DailyMicronutrientOptimizationTarget[];
}

export interface PreparedRecipeScaleModel {
  baselineSource: RecipeScaleBaselineSource;
  beforeSummary: ComposerNutritionSummary;
  lambda: number;
  weights: { kcal: number; proteinG: number; carbsG: number; fatG: number };
  scales: { kcal: number; proteinG: number; carbsG: number; fatG: number };
  fixedTotals: ComposerMacroTotals;
  vars: RecipeScaleDecisionVar[];
  micronutrientConstraints: PreparedMicronutrientConstraint[];
  slotTargets: QPSlotAllocationTarget[];
  lockedIngredientsCount: number;
  missingIngredientsCount: number;
  toTasteIngredientsCount: number;
  unresolvedIngredientsCount: number;
  hasIncompleteNutritionData: boolean;
  hasContradictoryBounds: boolean;
}

export function buildRecipeScaleModel(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: RecipeScaleModelOptions = {},
): PreparedRecipeScaleModel {
  const baselineSource: RecipeScaleBaselineSource = options.baselineSource ?? 'workingBaseline';
  const beforeSummary = computeDayNutrition(dayPlan);
  const lambda = Number.isFinite(options.lambda) ? Math.max(0.01, options.lambda!) : 0.08;
  const focus = options.goalFocus ?? 'balanced';

  const weights =
    focus === 'protein'
      ? { kcal: 1.15, proteinG: 2.1, carbsG: 0.7, fatG: 0.75 }
      : focus === 'energy'
        ? { kcal: 2.2, proteinG: 1.1, carbsG: 0.85, fatG: 0.85 }
        : { kcal: 1.45, proteinG: 1.35, carbsG: 0.9, fatG: 0.9 };

  const scales = {
    kcal: Math.max(400, targets.kcal),
    proteinG: Math.max(30, targets.proteinG),
    carbsG: Math.max(40, targets.carbsG),
    fatG: Math.max(15, targets.fatG),
  };

  const fixedTotals: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const fixedBySlot = new Map<string, ComposerMacroTotals>();
  const vars: RecipeScaleDecisionVar[] = [];

  const micronutrientConstraints: PreparedMicronutrientConstraint[] = (
    options.micronutrientTargets ?? []
  ).map((target) => {
    const upperLimit =
      target.upperLimitScope === 'total_intake' &&
      (target.upperLimitUnit ?? target.unit) === target.unit
        ? target.upperLimit
        : null;
    const hasReference =
      target.minimum !== null || target.preferredMaximum !== null || upperLimit !== null;
    return {
      nutrientId: target.nutrientId,
      unit: target.unit,
      minimum: target.minimum,
      minimumKind: target.minimumKind,
      preferredMaximum: target.preferredMaximum,
      upperLimit,
      fixedValue: 0,
      coefficients: [],
      status: !hasReference
        ? 'no_reference'
        : options.scopeSlotId
          ? 'not_applicable_scope'
          : 'applied',
      reason: !hasReference
        ? 'O perfil DRI ativo não define RDA, AI, CDRR ou UL compatível com a unidade deste nutriente.'
        : options.scopeSlotId
          ? 'As referências DRI são metas do dia; não são aplicadas a uma única refeição.'
          : undefined,
    };
  });

  const invalidateMicronutrients = (reason: string) => {
    for (const constraint of micronutrientConstraints) {
      if (constraint.status === 'applied') {
        constraint.status = 'insufficient_data';
        constraint.reason = reason;
      }
    }
  };

  let lockedIngredientsCount = 0;
  let missingIngredientsCount = 0;
  let toTasteIngredientsCount = 0;
  let unresolvedIngredientsCount = 0;
  let hasContradictoryBounds = false;

  for (const slot of dayPlan.slots) {
    const slotFixed: ComposerMacroTotals = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
    const inScope = !options.scopeSlotId || slot.id === options.scopeSlotId;

    for (const recipe of slot.recipes) {
      const scaleFactor = getRecipeScaleFactor(recipe);
      const baseServings =
        Number.isFinite(recipe.baseServings) && recipe.baseServings > 0
          ? recipe.baseServings
          : 1;
      const currentServings =
        Number.isFinite(recipe.targetServings) && recipe.targetServings > 0
          ? recipe.targetServings
          : baseServings;

      const scalableIngredients: ScalableRecipeIngredientSpec[] = [];
      const minServings = Math.max(0.25, 0.25 * baseServings);
      const maxServings = Math.min(12, 4 * baseServings);
      let minScale = Math.max(minServings / currentServings, 1e-3);
      let maxScale = Math.max(minScale, maxServings / currentServings);
      let kcalPerUnitScale = 0;
      let proteinPerUnitScale = 0;
      let carbsPerUnitScale = 0;
      let fatPerUnitScale = 0;
      let totalBaselineGrams = 0;
      const microsPerUnitScale: Partial<Record<NutrientId, number>> = {};

      for (const ingredient of recipe.ingredients) {
        if (ingredient.quantityStatus === 'to_taste') {
          toTasteIngredientsCount += 1;
          if (!options.scopeSlotId) {
            invalidateMicronutrients('Há ingrediente sem quantidade definida (a gosto).');
          }
          continue;
        }
        if (
          ingredient.quantityStatus !== 'known' ||
          ingredient.currentQuantityG === null ||
          !Number.isFinite(ingredient.currentQuantityG) ||
          ingredient.currentQuantityG <= 0
        ) {
          missingIngredientsCount += 1;
          if (!options.scopeSlotId) {
            invalidateMicronutrients('Há ingrediente sem quantidade definida.');
          }
          continue;
        }

        const food = resolveFoodById(ingredient.foodId);
        if (!food) {
          unresolvedIngredientsCount += 1;
          if (!options.scopeSlotId) {
            invalidateMicronutrients(`Alimento não resolvido: ${ingredient.foodId}.`);
          }
          continue;
        }
        if (!validateFoodMacroComposition(food).valid) {
          unresolvedIngredientsCount += 1;
          if (!options.scopeSlotId) {
            invalidateMicronutrients(`Composição básica inválida: ${food.name}.`);
          }
          continue;
        }

        const microPerG: Partial<Record<NutrientId, number>> = {};
        if (!options.scopeSlotId) {
          for (const constraint of micronutrientConstraints) {
            const record = normalizeNutrientEntry(food, constraint.nutrientId);
            const isNiacinEquivalent = constraint.nutrientId === 'vitamin_b3';
            if (record.normalized_unit !== constraint.unit) {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: unidade ${record.normalized_unit || 'ausente'} não corresponde à unidade DRI ${constraint.unit} para ${constraint.nutrientId}.`;
              }
              continue;
            }
            if (isNiacinEquivalent && record.conversion_method === 'preformed_niacin_only') {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: apenas niacina pré-formada está disponível; faltam os equivalentes totais de niacina (mg NE).`;
              }
              continue;
            }
            if (
              record.data_status !== 'quantified' ||
              record.normalized_value === null ||
              !Number.isFinite(record.normalized_value) ||
              record.normalized_value < 0 ||
              !Number.isFinite(record.basis_quantity) ||
              record.basis_quantity <= 0
            ) {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: ${record.data_status === 'trace' ? 'valor em traço' : record.data_status === 'invalid_value' ? 'registro numérico inválido' : 'valor não quantificado'} para ${constraint.nutrientId}.`;
              }
              continue;
            }
            const perGram = record.normalized_value / record.basis_quantity;
            if (!Number.isFinite(perGram) || perGram < 0) {
              if (constraint.status === 'applied') {
                constraint.status = 'insufficient_data';
                constraint.reason = `${food.name}: base de conversão inválida para ${constraint.nutrientId}.`;
              }
              continue;
            }
            microPerG[constraint.nutrientId] = perGram;
          }
        }

        const basis = food.macros.basisQuantityG;
        const kcalPerG = food.macros.kcalPerBasis / basis;
        const proteinPerG = food.macros.proteinGPerBasis / basis;
        const carbsPerG = food.macros.carbsGPerBasis / basis;
        const fatPerG = food.macros.fatGPerBasis / basis;
        const curG = ingredient.currentQuantityG;
        const templateRefG = getScaledReferenceGrams(ingredient, scaleFactor) ?? curG;

        if (!inScope || ingredient.mode === 'locked') {
          if (ingredient.mode === 'locked') lockedIngredientsCount += 1;
          fixedTotals.kcal += kcalPerG * curG;
          fixedTotals.proteinG += proteinPerG * curG;
          fixedTotals.carbsG += carbsPerG * curG;
          fixedTotals.fatG += fatPerG * curG;

          slotFixed.kcal += kcalPerG * curG;
          slotFixed.proteinG += proteinPerG * curG;
          slotFixed.carbsG += carbsPerG * curG;
          slotFixed.fatG += fatPerG * curG;

          if (!options.scopeSlotId) {
            for (const constraint of micronutrientConstraints) {
              const perGram = microPerG[constraint.nutrientId];
              if (perGram !== undefined) constraint.fixedValue += perGram * curG;
            }
          }
          continue;
        }

        const baselineG = baselineSource === 'templateBaseline' ? templateRefG : curG;
        if (!Number.isFinite(baselineG) || baselineG <= 0) continue;

        const bounds = getEffectiveIngredientBounds(ingredient, scaleFactor);
        const ingMinScale = bounds.minG / baselineG;
        const ingMaxScale = bounds.maxG / baselineG;
        minScale = Math.max(minScale, ingMinScale);
        maxScale = Math.min(maxScale, ingMaxScale);

        kcalPerUnitScale += kcalPerG * baselineG;
        proteinPerUnitScale += proteinPerG * baselineG;
        carbsPerUnitScale += carbsPerG * baselineG;
        fatPerUnitScale += fatPerG * baselineG;
        totalBaselineGrams += baselineG;

        if (!options.scopeSlotId) {
          for (const constraint of micronutrientConstraints) {
            const perGram = microPerG[constraint.nutrientId];
            if (perGram !== undefined) {
              microsPerUnitScale[constraint.nutrientId] =
                (microsPerUnitScale[constraint.nutrientId] ?? 0) + perGram * baselineG;
            }
          }
        }

        scalableIngredients.push({
          slotId: slot.id,
          recipeId: recipe.id,
          ingredientId: ingredient.id,
          foodId: ingredient.foodId,
          foodName: food.name,
          baselineG,
          templateRefG,
          currentG: curG,
          minG: bounds.minG,
          maxG: bounds.maxG,
          kcalPerG,
          proteinPerG,
          carbsPerG,
          fatPerG,
          micronutrientsPerG: microPerG,
        });
      }

      if (scalableIngredients.length > 0) {
        const boundsFeasible = minScale <= maxScale + 1e-9;
        if (!boundsFeasible) hasContradictoryBounds = true;
        const safeMin = boundsFeasible ? minScale : 1;
        const safeMax = boundsFeasible ? maxScale : 1;
        vars.push({
          slotId: slot.id,
          slotTitle: slot.title,
          recipeId: recipe.id,
          recipeName: recipe.name,
          currentServings,
          minScale: safeMin,
          maxScale: safeMax,
          boundsFeasible,
          refScale: 1,
          kcalPerUnitScale,
          proteinPerUnitScale,
          carbsPerUnitScale,
          fatPerUnitScale,
          totalBaselineGrams,
          micronutrientsPerUnitScale: microsPerUnitScale,
          ingredients: scalableIngredients,
        });

        if (!options.scopeSlotId) {
          for (const constraint of micronutrientConstraints) {
            constraint.coefficients.push(microsPerUnitScale[constraint.nutrientId] ?? 0);
          }
        }
      }
    }

    fixedBySlot.set(slot.id, slotFixed);
  }

  for (const constraint of micronutrientConstraints) {
    if (constraint.status !== 'applied' || constraint.upperLimit === null) continue;
    const minimumPossible =
      constraint.fixedValue +
      vars.reduce(
        (sum, variable, index) => sum + (constraint.coefficients[index] ?? 0) * variable.minScale,
        0,
      );
    if (minimumPossible > constraint.upperLimit + 1e-6) {
      constraint.status = 'infeasible_upper_limit';
      constraint.reason =
        'Ingredientes fixos e fatores de escala mínimos já ultrapassam o limite superior aplicável.';
    }
  }

  const slotTargets: QPSlotAllocationTarget[] = [];
  if (!options.scopeSlotId && options.mealAllocations && options.mealAllocations.length > 0) {
    const evalSummary = evaluateMealAllocations(dayPlan, targets, options.mealAllocations);
    if (evalSummary.isBalanced) {
      const proteinAllocationBalanced =
        evalSummary.totalProteinSharePercent !== null &&
        Math.abs(evalSummary.totalProteinSharePercent - 100) <= 0.2;
      const carbsAllocationBalanced =
        evalSummary.totalCarbsSharePercent !== null &&
        Math.abs(evalSummary.totalCarbsSharePercent - 100) <= 0.2;
      const fatAllocationBalanced =
        evalSummary.totalFatSharePercent !== null &&
        Math.abs(evalSummary.totalFatSharePercent - 100) <= 0.2;

      for (const sEval of evalSummary.slots) {
        if (sEval.sharePercent <= 0) continue;
        if (!vars.some((v) => v.slotId === sEval.slotId)) continue;
        const slotFixed = fixedBySlot.get(sEval.slotId) ?? {
          kcal: 0,
          proteinG: 0,
          carbsG: 0,
          fatG: 0,
        };
        const proteinShare = proteinAllocationBalanced ? sEval.proteinSharePercent : null;
        const carbsShare = carbsAllocationBalanced ? sEval.carbsSharePercent : null;
        const fatShare = fatAllocationBalanced ? sEval.fatSharePercent : null;
        slotTargets.push({
          slotId: sEval.slotId,
          slotTitle: sEval.slotTitle,
          targetKcal: (targets.kcal * sEval.sharePercent) / 100,
          fixedKcal: slotFixed.kcal,
          scaleKcal: Math.max(150, (targets.kcal * sEval.sharePercent) / 100),
          weightKcal: 0.42,
          targetProteinG: proteinShare !== null ? (targets.proteinG * proteinShare) / 100 : null,
          fixedProteinG: slotFixed.proteinG,
          scaleProteinG: Math.max(10, proteinShare !== null ? (targets.proteinG * proteinShare) / 100 : 25),
          targetCarbsG: carbsShare !== null ? (targets.carbsG * carbsShare) / 100 : null,
          fixedCarbsG: slotFixed.carbsG,
          scaleCarbsG: Math.max(15, carbsShare !== null ? (targets.carbsG * carbsShare) / 100 : 35),
          targetFatG: fatShare !== null ? (targets.fatG * fatShare) / 100 : null,
          fixedFatG: slotFixed.fatG,
          scaleFatG: Math.max(6, fatShare !== null ? (targets.fatG * fatShare) / 100 : 12),
        });
      }
    }
  }

  const hasIncompleteNutritionData =
    beforeSummary.unresolvedFoodIds.length > 0 ||
    beforeSummary.lowConfidenceFoodIds.length > 0 ||
    missingIngredientsCount > 0 ||
    toTasteIngredientsCount > 0 ||
    unresolvedIngredientsCount > 0 ||
    beforeSummary.coveragePercent < 99.99;

  return {
    baselineSource,
    beforeSummary,
    lambda,
    weights,
    scales,
    fixedTotals,
    vars,
    micronutrientConstraints,
    slotTargets,
    lockedIngredientsCount,
    missingIngredientsCount,
    toTasteIngredientsCount,
    unresolvedIngredientsCount,
    hasIncompleteNutritionData,
    hasContradictoryBounds,
  };
}

/**
 * Pure continuous projection from recipe scale factors s_r to gram quantities per
 * scalable ingredient key (`slotId::recipeId::ingredientId`).
 * Locked, missing, to_taste and unresolved ingredients are intentionally absent.
 */
export function projectContinuousRecipeScalesToQuantities(
  model: PreparedRecipeScaleModel,
  scales: readonly number[],
): Map<string, number> {
  const out = new Map<string, number>();
  model.vars.forEach((recipeVar, idx) => {
    const rawScale = scales[idx] ?? recipeVar.refScale;
    const safeScale = Math.max(recipeVar.minScale, Math.min(recipeVar.maxScale, rawScale));
    for (const ing of recipeVar.ingredients) {
      const key = `${ing.slotId}::${ing.recipeId}::${ing.ingredientId}`;
      out.set(key, safeScale * ing.baselineG);
    }
  });
  return out;
}
