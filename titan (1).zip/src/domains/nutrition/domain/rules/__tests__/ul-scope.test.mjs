import assert from 'node:assert/strict';
import { resolveNutrientDisplay, resolveReferenceProfile } from '../nutrition-calculator.ts';

const profile = resolveReferenceProfile('adult_male_19_50');
const quantifiedFoodExposure = {
  nutrientId: 'magnesium', consumedValue: 300, unit: 'mg', dataStatus: 'quantified',
  contributions: [], hasUnquantifiedSources: false,
};
const supplementOnlyReference = {
  nutrientId: 'magnesium', referenceValue: 420, unit: 'mg', kind: 'RDA',
  upperLimit: 350, upperLimitScope: 'supplements_only',
};
const supplementLimitDisplay = resolveNutrientDisplay(quantifiedFoodExposure, supplementOnlyReference, profile);
assert.equal(supplementLimitDisplay.limitValue, null,
  'supplement-only magnesium UL cannot be evaluated against food-only intake');
assert.equal(supplementLimitDisplay.isLimitExceeded, false);
assert.equal(supplementLimitDisplay.limitKind, null);

const preformedOnlyReference = {
  nutrientId: 'vitamin_a', referenceValue: 900, unit: 'µg RAE', kind: 'RDA',
  upperLimit: 3000, upperLimitScope: 'preformed_only',
};
const vitaminAFoodExposure = { ...quantifiedFoodExposure, nutrientId: 'vitamin_a', unit: 'µg RAE', consumedValue: 2500 };
const preformedDisplay = resolveNutrientDisplay(vitaminAFoodExposure, preformedOnlyReference, profile);
assert.equal(preformedDisplay.limitValue, null,
  'preformed retinol UL cannot be compared with an undifferentiated vitamin A RAE total');
const totalIntakeDisplay = resolveNutrientDisplay(quantifiedFoodExposure, { ...supplementOnlyReference, upperLimit: 400, upperLimitScope: 'total_intake' }, profile);
assert.equal(totalIntakeDisplay.limitValue, 400, 'total-intake UL remains visible as a food exposure floor');
console.log('UL source-scope tests passed.');

const adult = resolveReferenceProfile('adult_male_19_50');
assert.equal(adult.entries.magnesium.upperLimit, 350);
assert.equal(adult.entries.magnesium.upperLimitScope, 'supplements_and_medications');
assert.equal(adult.entries.vitamin_a.upperLimit, 3000);
assert.equal(adult.entries.vitamin_a.upperLimitScope, 'preformed_only');
assert.equal(adult.entries.vitamin_b9.upperLimit, 1000);
assert.equal(adult.entries.vitamin_b9.upperLimitUnit, 'µg');
assert.equal(adult.entries.vitamin_b9.unit, 'µg DFE', 'folic-acid UL must not inherit the DFE unit');
assert.equal(adult.entries.vitamin_b3.upperLimit, 35);
assert.equal(adult.entries.vitamin_b3.upperLimitUnit, 'mg');
assert.equal(adult.entries.vitamin_e.upperLimit, 1000);
assert.equal(adult.entries.vitamin_e.upperLimitScope, 'supplements_and_fortified_foods');
const magnesiumSupplementReference = adult.entries.magnesium;
const magnesiumFoodDisplay = resolveNutrientDisplay(quantifiedFoodExposure, magnesiumSupplementReference, profile);
assert.equal(magnesiumFoodDisplay.limitValue, null, 'supplement/medication magnesium UL cannot be evaluated against food-only intake');

// When RDA/AI referenceValue is null (e.g. adult_51_plus), total_intake UL exceedance must still be surfaced.
const legacy51Plus = resolveReferenceProfile('adult_51_plus');
const highVitCExposure = {
  nutrientId: 'vitamin_c', consumedValue: 2500, unit: 'mg', dataStatus: 'quantified',
  contributions: [], hasUnquantifiedSources: false,
};
const highVitCDisplay = resolveNutrientDisplay(highVitCExposure, legacy51Plus.entries.vitamin_c, legacy51Plus);
assert.equal(highVitCDisplay.limitKind, 'UL');
assert.equal(highVitCDisplay.limitValue, 2000);
assert.equal(highVitCDisplay.isLimitExceeded, true, 'total_intake UL violation must be reported even when RDA referenceValue is null');
assert.equal(highVitCDisplay.isExceeded, true, 'isExceeded must match total_intake UL violation even when referenceValue is null');
assert.equal(highVitCDisplay.displayMode, 'limit_cdrr');
assert.equal(highVitCDisplay.rawPercent, 125);

// Logged total_intake supplements must reduce food optimization UL headroom without altering non-total_intake scopes.
const { buildDailyMicronutrientTargets } = await import('../nutrition-calculator.ts');
const targetsWithSupp = buildDailyMicronutrientTargets('adult_male_19_50', [
  {
    id: 's-fe', dateKey: '2026-11-26', time: '08:00', productName: 'Sulfato ferroso',
    nutrientId: 'iron', amount: 30, unit: 'mg', chemicalForm: 'other',
    sourceName: 'Rótulo', sourceVersion: 'v1', sourceRecordId: 's-fe', recordedAt: '2026-11-26T08:00:00.000Z',
  },
  {
    id: 's-mg', dateKey: '2026-11-26', time: '08:00', productName: 'Magnésio',
    nutrientId: 'magnesium', amount: 200, unit: 'mg', chemicalForm: 'magnesium_salt',
    sourceName: 'Rótulo', sourceVersion: 'v1', sourceRecordId: 's-mg', recordedAt: '2026-11-26T08:00:00.000Z',
  },
], '2026-11-26');
const ironTarget = targetsWithSupp.find((t) => t.nutrientId === 'iron');
const mgTarget = targetsWithSupp.find((t) => t.nutrientId === 'magnesium');
assert.equal(ironTarget?.upperLimit, 15, 'total_intake supplement intake must reduce remaining daily food UL headroom (45 - 30 = 15 mg)');
assert.equal(mgTarget?.upperLimit, null, 'supplements_and_medications magnesium UL remains null for food-only optimizer');
