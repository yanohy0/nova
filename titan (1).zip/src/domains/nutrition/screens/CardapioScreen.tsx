import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  createMacroTargetFitScheduler,
  type MacroFitProposalSnapshot,
  type MacroTargetFitScheduler,
} from '../application/macro-target-fit-service';
import { ensureTbcaCatalogLoaded, onTbcaCatalogLoaded } from '../data/sources/tbca-adapter';
import { computeDayNutrition } from '../domain/rules/cardapio-composer-engine';
import { useNutritionStore } from '../state/nutrition.store';
import { CardapiosContent } from '../components/cardapios/components/CardapiosContent';
import { buildCardapiosViewModel } from '../components/cardapios/view-models/cardapios.mapper';

export type NutritionSection = 'cardapio' | 'receitas' | 'alimentos';

interface CardapioScreenProps {
  section?: NutritionSection;
  onSectionChange?: (section: NutritionSection) => void;
}

export function CardapioScreen(_props: CardapioScreenProps = {}) {
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const composerPlans = useNutritionStore((s) => s.composerPlans);
  const activeComposerPlanId = useNutritionStore((s) => s.activeComposerPlanId);
  const meals = useNutritionStore((s) => s.meals);
  const nutritionInputsRevision = useNutritionStore((s) => s.nutritionInputsRevision);
  const lastAppliedMacroProposalUndo = useNutritionStore((s) => s.lastAppliedMacroProposalUndo);
  const applyMacroTargetFitProposal = useNutritionStore((s) => s.applyMacroTargetFitProposal);
  const undoLastMacroProposal = useNutritionStore((s) => s.undoLastMacroProposal);

  const [tbcaRevision, setTbcaRevision] = useState(0);
  const schedulerRef = useRef<MacroTargetFitScheduler | null>(null);
  if (schedulerRef.current === null) {
    schedulerRef.current = createMacroTargetFitScheduler({ debounceMs: 300 });
  }

  const [proposalSnapshot, setProposalSnapshot] = useState<MacroFitProposalSnapshot>(() =>
    schedulerRef.current!.getSnapshot(),
  );
  const [appliedContextKey, setAppliedContextKey] = useState<string | null>(null);
  const [errorFeedback, setErrorFeedback] = useState<string | null>(null);
  const skipNextScheduleRevisionRef = useRef<number | null>(null);

  useEffect(() => {
    const scheduler = schedulerRef.current!;
    const unsub = scheduler.subscribe(setProposalSnapshot);
    return () => {
      unsub();
      scheduler.dispose();
    };
  }, []);

  useEffect(() => {
    const unsubscribe = onTbcaCatalogLoaded(() => {
      setTbcaRevision((prev) => prev + 1);
    });
    void ensureTbcaCatalogLoaded();
    return unsubscribe;
  }, []);

  const activePlan = useMemo(
    () =>
      composerPlans.find((plan) => plan.id === activeComposerPlanId) ??
      composerPlans[0] ??
      null,
    [composerPlans, activeComposerPlanId],
  );

  const activeContextKey = activePlan ? `${activePlan.id}:${activeDateKey}` : '';

  useEffect(() => {
    setErrorFeedback(null);
    const snap = schedulerRef.current?.getSnapshot();
    if (
      snap &&
      snap.status !== 'idle' &&
      (snap.planId !== activePlan?.id || snap.dateKey !== activeDateKey)
    ) {
      schedulerRef.current?.reset();
    }
  }, [activePlan?.id, activeDateKey]);

  useEffect(() => {
    if (!activePlan) return;
    if (skipNextScheduleRevisionRef.current === activePlan.revision) {
      return;
    }

    const alreadyAppliedCurrentRevision =
      lastAppliedMacroProposalUndo !== null &&
      lastAppliedMacroProposalUndo.planId === activePlan.id &&
      lastAppliedMacroProposalUndo.dateKey === activeDateKey &&
      lastAppliedMacroProposalUndo.expectedPlanRevisionAfterApply === activePlan.revision;
    if (alreadyAppliedCurrentRevision) {
      return;
    }

    const dayPlan = activePlan.days[activeDateKey];
    if (!dayPlan || dayPlan.slots.every((slot) => slot.recipes.length === 0)) {
      if (schedulerRef.current?.getSnapshot().status !== 'idle') {
        schedulerRef.current?.dismiss();
      }
      return;
    }

    // Check if the day already sits tightly within target tolerances before scheduling
    const current = computeDayNutrition(dayPlan);
    const kcalDiff = Math.abs(current.macros.kcal - activePlan.targets.kcal);
    const pDiff = Math.abs(current.macros.proteinG - activePlan.targets.proteinG);
    const cDiff = Math.abs(current.macros.carbsG - activePlan.targets.carbsG);
    const fDiff = Math.abs(current.macros.fatG - activePlan.targets.fatG);
    const needsAutoProposal =
      kcalDiff > Math.max(55, activePlan.targets.kcal * 0.03) ||
      pDiff > Math.max(8, activePlan.targets.proteinG * 0.06) ||
      cDiff > Math.max(12, activePlan.targets.carbsG * 0.07) ||
      fDiff > Math.max(6, activePlan.targets.fatG * 0.08);

    if (!needsAutoProposal) {
      if (schedulerRef.current?.getSnapshot().status !== 'idle') {
        schedulerRef.current?.dismiss();
      }
      return;
    }

    setAppliedContextKey((prev) => (prev === activeContextKey ? null : prev));
    setErrorFeedback(null);
    schedulerRef.current?.schedule({
      planId: activePlan.id,
      dateKey: activeDateKey,
      planRevision: activePlan.revision,
      inputsRevision: nutritionInputsRevision,
      dayPlan,
      targets: activePlan.targets,
      options: {
        scaleMode: 'preserve_recipe_ratios',
        baselineSource: 'workingBaseline',
        mealAllocations: activePlan.mealAllocations,
      },
    });
  }, [
    activePlan,
    activeDateKey,
    activeContextKey,
    lastAppliedMacroProposalUndo,
    nutritionInputsRevision,
    tbcaRevision,
  ]);

  const handleApplyProposal = useCallback(() => {
    const snap = schedulerRef.current?.getSnapshot();
    if (!snap || snap.status !== 'ready' || !snap.result) return;
    const outcome = applyMacroTargetFitProposal(
      snap.dateKey,
      snap.result,
      snap.planRevision,
    );
    if (!outcome.ok) {
      setErrorFeedback(outcome.error);
      if (outcome.reason === 'stale_revision' && activePlan) {
        schedulerRef.current?.invalidateToStale(activePlan.revision, nutritionInputsRevision);
      }
      return;
    }
    skipNextScheduleRevisionRef.current = outcome.appliedPlanRevision;
    setErrorFeedback(null);
    setAppliedContextKey(`${snap.planId}:${snap.dateKey}`);
    schedulerRef.current?.dismiss();
  }, [activePlan, applyMacroTargetFitProposal, nutritionInputsRevision]);

  const handleDismissProposal = useCallback(() => {
    setErrorFeedback(null);
    setAppliedContextKey(null);
    schedulerRef.current?.dismiss();
  }, []);

  const handleUndoProposal = useCallback(() => {
    if (!activePlan) return;
    skipNextScheduleRevisionRef.current = activePlan.revision + 1;
    const undone = undoLastMacroProposal();
    if (undone) {
      setAppliedContextKey(null);
      setErrorFeedback(null);
      schedulerRef.current?.dismiss();
    }
  }, [activePlan, undoLastMacroProposal]);

  const viewModel = useMemo(
    () => buildCardapiosViewModel(composerPlans, activeDateKey, meals),
    [composerPlans, activeDateKey, meals, tbcaRevision],
  );

  const canUndo =
    lastAppliedMacroProposalUndo !== null &&
    lastAppliedMacroProposalUndo.dateKey === activeDateKey &&
    lastAppliedMacroProposalUndo.planId === activePlan?.id &&
    lastAppliedMacroProposalUndo.expectedPlanRevisionAfterApply === activePlan?.revision;

  const justApplied = appliedContextKey !== null && appliedContextKey === activeContextKey;

  const showBanner =
    proposalSnapshot.status !== 'idle' || canUndo || justApplied || Boolean(errorFeedback);

  return (
    <CardapiosContent
      viewModel={viewModel}
      macroFitControl={
        showBanner
          ? {
              snapshot: proposalSnapshot,
              canUndo,
              justApplied,
              errorFeedback,
              onApply: handleApplyProposal,
              onDismiss: handleDismissProposal,
              onUndo: handleUndoProposal,
            }
          : null
      }
    />
  );
}

export const NutritionWorkspace = CardapioScreen;
