import { isValidLocalDateKey } from '../../../shared/utils/local-date.ts';
import type {
  CardapioPlan,
  ComposerDayPlan,
  IngredientAdjustment,
  MealItem,
  MealTargetAllocation,
  RecipeInstance,
  ReferenceProfileId,
} from '../domain/entities/nutrient';
import { isValidSupplementMicronutrientIntake, type SupplementMicronutrientIntake } from '../domain/rules/supplement-intake.ts';

export interface PersistedNutritionState {
  activeDateKey: string;
  referenceProfileId: ReferenceProfileId;
  dailyGoals: { kcal: number; proteinG: number; carbsG: number; fatG: number };
  meals: MealItem[];
  intakeDayConfirmations: string[];
  composerPlans?: CardapioPlan[];
  activeComposerPlanId?: string;
  supplementMicronutrientIntakes?: SupplementMicronutrientIntake[];
}

const REFERENCE_PROFILE_IDS: readonly ReferenceProfileId[] = [
  'adult_male_19_30',
  'adult_female_19_30',
  'adult_male_19_50',
  'adult_female_19_50',
  'adult_51_plus',
  'adult_female_51_plus',
  'adult_male_51_70',
  'adult_female_51_70',
  'adult_male_71_plus',
  'adult_female_71_plus',
];
const MEAL_STATUSES = ['planned', 'consumed', 'partial', 'substituted', 'skipped'] as const;
const PLAN_STATUSES = ['draft', 'active', 'archived'] as const;
const LOCK_MODES = ['proportional', 'locked', 'flexible'] as const;
const QTY_STATUSES = ['known', 'missing', 'to_taste'] as const;
const ADJ_MODES = ['proportional', 'balanced', 'flexible'] as const;
const RECIPE_CATEGORIES = ['cafe', 'almoco', 'lanche', 'jantar'] as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isFiniteInRange(value: unknown, min: number, max: number): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
}

function isOptionalFiniteInRange(value: unknown, min: number, max: number): boolean {
  return value === undefined || value === null || isFiniteInRange(value, min, max);
}

function isSafeMealImageUrl(value: unknown): boolean {
  if (value === undefined) return true;
  if (typeof value !== 'string' || value.length > 2048) return false;
  if (value.startsWith('/') && !value.startsWith('//')) return true;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
}

function isMealPortion(value: unknown): boolean {
  return isRecord(value) &&
    typeof value.foodId === 'string' && value.foodId.length > 0 &&
    isFiniteInRange(value.quantityG, 0.1, 100_000);
}

function isMeal(value: unknown): value is MealItem {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === 'string' && value.id.length > 0 &&
    typeof value.dateKey === 'string' && isValidLocalDateKey(value.dateKey) &&
    typeof value.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value.time) &&
    typeof value.title === 'string' && value.title.trim().length > 0 && value.title.length <= 80 &&
    typeof value.description === 'string' && value.description.length <= 500 &&
    (value.recipeId === undefined || (typeof value.recipeId === 'string' && value.recipeId.length <= 120)) &&
    isSafeMealImageUrl(value.imageUrl) &&
    (value.substitutionNote === undefined || (typeof value.substitutionNote === 'string' && value.substitutionNote.length <= 300)) &&
    isFiniteInRange(value.planned_quantity, 0, 100_000) &&
    isFiniteInRange(value.consumed_quantity, 0, 100_000) &&
    Array.isArray(value.planned_foods) && value.planned_foods.length <= 40 && value.planned_foods.every(isMealPortion) &&
    Array.isArray(value.consumed_foods) && value.consumed_foods.length <= 40 && value.consumed_foods.every(isMealPortion) &&
    typeof value.status === 'string' && MEAL_STATUSES.includes(value.status as typeof MEAL_STATUSES[number])
  );
}

function isIngredientAdjustment(value: unknown): value is IngredientAdjustment {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === 'string' && value.id.length > 0 && value.id.length <= 120 &&
    typeof value.foodId === 'string' && value.foodId.length > 0 && value.foodId.length <= 120 &&
    isOptionalFiniteInRange(value.baseQuantityG, 0.1, 2000) &&
    isOptionalFiniteInRange(value.currentQuantityG, 0.1, 2000) &&
    isOptionalFiniteInRange(value.minQuantityG, 0.1, 2000) &&
    isOptionalFiniteInRange(value.maxQuantityG, 0.1, 2000) &&
    typeof value.quantityStatus === 'string' && QTY_STATUSES.includes(value.quantityStatus as typeof QTY_STATUSES[number]) &&
    typeof value.mode === 'string' && LOCK_MODES.includes(value.mode as typeof LOCK_MODES[number])
  );
}

function isRecipeInstance(value: unknown): value is RecipeInstance {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === 'string' && value.id.length > 0 && value.id.length <= 120 &&
    typeof value.name === 'string' && value.name.trim().length > 0 && value.name.length <= 140 &&
    typeof value.category === 'string' && RECIPE_CATEGORIES.includes(value.category as typeof RECIPE_CATEGORIES[number]) &&
    isSafeMealImageUrl(value.imageUrl) &&
    isFiniteInRange(value.baseServings, 0.25, 12) &&
    isFiniteInRange(value.targetServings, 0.25, 12) &&
    typeof value.adjustmentMode === 'string' && ADJ_MODES.includes(value.adjustmentMode as typeof ADJ_MODES[number]) &&
    Array.isArray(value.ingredients) && value.ingredients.length <= 40 && value.ingredients.every(isIngredientAdjustment)
  );
}

function isComposerDayPlan(value: unknown): value is ComposerDayPlan {
  if (!isRecord(value)) return false;
  if (typeof value.dateKey !== 'string' || !isValidLocalDateKey(value.dateKey)) return false;
  if (!Array.isArray(value.slots) || value.slots.length > 20) return false;
  return value.slots.every((slot) => (
    isRecord(slot) &&
    typeof slot.id === 'string' && slot.id.length > 0 && slot.id.length <= 120 &&
    typeof slot.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(slot.time) &&
    typeof slot.title === 'string' && slot.title.trim().length > 0 && slot.title.length <= 80 &&
    Array.isArray(slot.recipes) && slot.recipes.length <= 12 && slot.recipes.every(isRecipeInstance)
  ));
}

function isMealAllocation(value: unknown): value is MealTargetAllocation {
  return (
    isRecord(value) &&
    typeof value.slotId === 'string' && value.slotId.length > 0 &&
    isFiniteInRange(value.energySharePercent, 0, 100) &&
    isOptionalFiniteInRange(value.proteinSharePercent, 0, 100) &&
    isOptionalFiniteInRange(value.carbsSharePercent, 0, 100) &&
    isOptionalFiniteInRange(value.fatSharePercent, 0, 100)
  );
}

function isCardapioPlan(value: unknown): value is CardapioPlan {
  if (!isRecord(value)) return false;
  if (
    typeof value.id !== 'string' || value.id.length === 0 || value.id.length > 120 ||
    typeof value.name !== 'string' || value.name.trim().length === 0 || value.name.length > 120 ||
    !isFiniteInRange(value.revision, 1, 1_000_000_000) ||
    typeof value.status !== 'string' || !PLAN_STATUSES.includes(value.status as typeof PLAN_STATUSES[number]) ||
    typeof value.startDateKey !== 'string' || !isValidLocalDateKey(value.startDateKey) ||
    typeof value.endDateKey !== 'string' || !isValidLocalDateKey(value.endDateKey) ||
    !isRecord(value.targets) ||
    !isFiniteInRange(value.targets.kcal, 500, 10_000) ||
    !isFiniteInRange(value.targets.proteinG, 0, 2_000) ||
    !isFiniteInRange(value.targets.carbsG, 0, 2_000) ||
    !isFiniteInRange(value.targets.fatG, 0, 2_000) ||
    !Array.isArray(value.mealAllocations) || value.mealAllocations.length > 20 || !value.mealAllocations.every(isMealAllocation) ||
    !isRecord(value.days) ||
    !Array.isArray(value.variants) || value.variants.length > 24
  ) {
    return false;
  }

  const dayEntries = Object.entries(value.days);
  if (dayEntries.length === 0 || dayEntries.length > 60) return false;
  for (const [key, day] of dayEntries) {
    if (!isValidLocalDateKey(key) || !isComposerDayPlan(day) || day.dateKey !== key) return false;
  }
  for (const variant of value.variants) {
    if (
      !isRecord(variant) ||
      typeof variant.id !== 'string' || variant.id.length === 0 ||
      typeof variant.name !== 'string' || variant.name.trim().length === 0 ||
      typeof variant.createdAt !== 'string' ||
      !isComposerDayPlan(variant.dayPlan) ||
      !isFiniteInRange(variant.weightedDeviationPercent, 0, 1000) ||
      !isRecord(variant.macros) ||
      !isFiniteInRange(variant.macros.kcal, 0, 50_000) ||
      !isFiniteInRange(variant.macros.proteinG, 0, 5_000) ||
      !isFiniteInRange(variant.macros.carbsG, 0, 5_000) ||
      !isFiniteInRange(variant.macros.fatG, 0, 5_000)
    ) {
      return false;
    }
  }
  return true;
}

export function mergeNutritionPersistedState(
  persisted: unknown,
  current: PersistedNutritionState,
): PersistedNutritionState {
  if (!isRecord(persisted)) return current;
  const activeDateKey = typeof persisted.activeDateKey === 'string' && isValidLocalDateKey(persisted.activeDateKey)
    ? persisted.activeDateKey
    : current.activeDateKey;
  const referenceProfileId = typeof persisted.referenceProfileId === 'string' &&
    REFERENCE_PROFILE_IDS.includes(persisted.referenceProfileId as ReferenceProfileId)
    ? persisted.referenceProfileId as ReferenceProfileId
    : current.referenceProfileId;
  const goals = isRecord(persisted.dailyGoals) ? persisted.dailyGoals : null;
  const dailyGoals = goals &&
    isFiniteInRange(goals.kcal, 500, 10_000) &&
    isFiniteInRange(goals.proteinG, 0, 2_000) &&
    isFiniteInRange(goals.carbsG, 0, 2_000) &&
    isFiniteInRange(goals.fatG, 0, 2_000)
    ? {
        kcal: goals.kcal,
        proteinG: goals.proteinG,
        carbsG: goals.carbsG,
        fatG: goals.fatG,
      }
    : current.dailyGoals;
  const meals = Array.isArray(persisted.meals)
    ? persisted.meals
        .slice(0, 5000)
        .filter(isMeal)
        .filter((meal) => meal.id !== 'meal-prev-1')
        .map((meal) => meal.id === 'meal-1' && meal.title === 'Café da manhã' && meal.recipeId === 'rec-cafe-completo' && meal.status === 'consumed'
          ? { ...meal, status: 'planned' as const, consumed_quantity: 0, consumed_foods: [] }
          : meal)
        .filter((meal, index, list) => list.findIndex((candidate) => candidate.id === meal.id) === index)
        .sort((a, b) => b.dateKey.localeCompare(a.dateKey) || b.time.localeCompare(a.time))
        .slice(0, 2000)
    : current.meals;
  const intakeDayConfirmations = Array.isArray(persisted.intakeDayConfirmations)
    ? [...new Set(persisted.intakeDayConfirmations.filter((dateKey): dateKey is string =>
        typeof dateKey === 'string' && isValidLocalDateKey(dateKey),
      ))]
    : current.intakeDayConfirmations;
  const supplementMicronutrientIntakes = Array.isArray(persisted.supplementMicronutrientIntakes)
    ? persisted.supplementMicronutrientIntakes
        .slice(0, 5000)
        .filter(isValidSupplementMicronutrientIntake)
        .filter((event, index, list) => list.findIndex((candidate) => candidate.id === event.id) === index)
        .sort((a, b) => b.dateKey.localeCompare(a.dateKey) || b.time.localeCompare(a.time) || b.recordedAt.localeCompare(a.recordedAt))
        .slice(0, 2000)
    : (current.supplementMicronutrientIntakes ?? []);

  const validatedPlans = Array.isArray(persisted.composerPlans)
    ? persisted.composerPlans.slice(0, 20).filter(isCardapioPlan)
    : undefined;
  const composerPlans =
    validatedPlans && validatedPlans.length > 0
      ? validatedPlans
      : current.composerPlans;
  const activeComposerPlanId =
    typeof persisted.activeComposerPlanId === 'string' &&
    composerPlans?.some((plan) => plan.id === persisted.activeComposerPlanId)
      ? persisted.activeComposerPlanId
      : composerPlans?.[0]?.id ?? current.activeComposerPlanId;

  const nextState: PersistedNutritionState = {
    activeDateKey,
    referenceProfileId,
    dailyGoals,
    meals,
    intakeDayConfirmations,
    supplementMicronutrientIntakes,
  };
  if (composerPlans !== undefined) {
    nextState.composerPlans = composerPlans;
  }
  if (activeComposerPlanId !== undefined) {
    nextState.activeComposerPlanId = activeComposerPlanId;
  }
  return nextState;
}
