import type { CellDisplayStatus } from '../types/cardapios.types.ts';

/**
 * Paleta global preservada e imutável do contrato Cardápios.
 */
export const cardapiosTokens = {
  canvasPrimary: '#101719',
  surfacePrimary: '#171F22',
  surfaceRaised: '#202B2E',
  surfaceInteractive: '#29373A',
  borderSubtle: '#344448',
  textPrimary: '#F2F0E8',
  textSecondary: '#B7C1BD',
  textMuted: '#8E9B96',
  accentPrimary: '#A7C9BE',
  accentSurface: '#253936',
} as const;

/**
 * Tokens locais das skins V9 (Maison Gastronomique / Haute Reliure e concorrentes de pesquisa).
 * Não substituem estados semânticos globais, cores nutricionais ou CTA Sage.
 */
export const cardapiosMaterialSkins = {
  maison: {
    leatherBase: '#111A18',
    leatherLowlight: '#17231F',
    leatherWarmReflection: '#28322B',
    goldTooling: '#B49A69',
    paperNatural: '#EEE9DE',
    paperHeader: '#E4DDD0',
    paperInk: '#202521',
    paperInkSecondary: '#434D46',
    paperInkMuted: '#57625B',
    paperActionInk: '#23423A',
    paperInteractive: '#DED6C6',
    paperRule: '#C9C1B2',
  },
  grandService: {
    porcelain: '#EAE7DF',
    celadon: '#A8B4A5',
    glazeHighlight: '#F6F4ED',
    silver: '#BFC2BE',
    ink: '#1E2421',
  },
  shikki: {
    roiro: '#080A09',
    roiroLowlight: '#111715',
    reflection: '#353C37',
    paper: '#E9E3D6',
    gold: '#AD8C51',
  },
} as const;

export const ACTIVE_CARDAPIOS_MATERIAL_SKIN = 'maison-a2-bound-menu' as const;

export const cardapiosMaterials = {
  /** Acabamento digital PBR inspirado em Morocco goatskin / encadernação Haute Reliure com blind tooling e filete champagne */
  cardapioShell: {
    backgroundColor: cardapiosMaterialSkins.maison.leatherBase,
    borderColor: '#2B3833',
    boxShadow:
      '0 18px 42px rgba(0, 0, 0, 0.54), inset 0 1px 0 rgba(180, 154, 105, 0.24), inset 0 -1px 0 rgba(0, 0, 0, 0.5)',
  },
  /** Capa fechada da receita em couro Marroquim escuro com lombada costurada e friso dourado discreto */
  recipeClosedCover: {
    backgroundColor: cardapiosMaterialSkins.maison.leatherLowlight,
    hoverBackgroundColor: '#1E2D28',
    borderColor: '#30403A',
    boxShadow:
      '0 10px 24px rgba(0, 0, 0, 0.36), inset 3px 0 8px rgba(0, 0, 0, 0.34), inset 0 1px 0 rgba(180, 154, 105, 0.22)',
  },
  /** Folha interna aberta da receita em papel rag/algodão editorial (#EEE9DE) emoldurada pela encadernação */
  recipeOpenPaper: {
    backgroundColor: cardapiosMaterialSkins.maison.paperNatural,
    frameBackgroundColor: cardapiosMaterialSkins.maison.leatherBase,
    borderColor: '#8E7D5B',
    boxShadow:
      '0 22px 48px rgba(0, 0, 0, 0.48), inset 0 1px 0 rgba(255, 255, 255, 0.55), inset 0 0 0 1px rgba(180, 154, 105, 0.28)',
  },
  /** Acabamento digital editorial legado (mantido para compatibilidade) */
  recipeSurface: {
    backgroundColor: cardapiosTokens.surfaceRaised,
    borderColor: cardapiosTokens.borderSubtle,
    boxShadow: 'inset 0 1px 0 rgba(242, 240, 232, 0.04)',
  },
  /** Acabamento digital em papel rag/cotton editorial para matriz TBCA de alta legibilidade */
  nutritionMatrix: {
    backgroundColor: cardapiosMaterialSkins.maison.paperNatural,
    headerBackgroundColor: cardapiosMaterialSkins.maison.paperHeader,
    borderColor: cardapiosMaterialSkins.maison.paperRule,
  },
  /** Ação funcional Sage original (com contorno nítido sobre o papel editorial) */
  primaryAction: {
    backgroundColor: cardapiosTokens.accentPrimary,
    color: cardapiosTokens.canvasPrimary,
    borderColor: '#76978B',
    boxShadow: '0 4px 12px rgba(16, 23, 25, 0.16), inset 0 1px 0 rgba(242, 240, 232, 0.35)',
  },
} as const;

const intFormatter = new Intl.NumberFormat('pt-BR', {
  maximumFractionDigits: 0,
});

const oneDecimalFormatter = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 1,
});

const twoDecimalFormatter = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

export function formatNutrientNumberPtBr(value: number, unit: string | null): string {
  if (!Number.isFinite(value)) return '—';
  if (unit === 'kcal') {
    return intFormatter.format(Math.round(value));
  }
  const abs = Math.abs(value);
  if (abs === 0) return '0';
  if (abs < 1) return twoDecimalFormatter.format(value);
  if (abs < 100) return oneDecimalFormatter.format(value);
  return intFormatter.format(Math.round(value));
}

export function formatMacroSummaryValue(
  value: number | null,
  status: CellDisplayStatus,
  unit: 'g' | 'kcal',
): string {
  if (status === 'true-zero') return unit === 'kcal' ? '0 kcal' : '0 g';
  if (status === 'trace') return 'Traços';
  if (status === 'not-detected') return 'Não detect.';
  if (status === 'not-analyzed') return 'Não analis.';
  if (status === 'not-applicable') return 'N/A';
  if (status === 'withheld') return 'Indisp.';
  if (value === null || !Number.isFinite(value)) return '—';
  return `${formatNutrientNumberPtBr(value, unit)} ${unit}`;
}

export function formatMatrixCellDisplay(
  value: number | null,
  status: CellDisplayStatus,
  unit: string | null,
): { text: string; title?: string } {
  switch (status) {
    case 'measured':
      return {
        text: value !== null && Number.isFinite(value) ? formatNutrientNumberPtBr(value, unit) : '—',
      };
    case 'true-zero':
      return {
        text: '0',
        title: 'Zero explícito quantificado na fonte',
      };
    case 'trace':
      return {
        text: 'Traços',
        title: 'Presença residual (traços) na fonte',
      };
    case 'not-detected':
      return {
        text: 'Não detectado',
        title: 'Abaixo do limite de detecção na fonte',
      };
    case 'not-analyzed':
      return {
        text: 'Não analisado',
        title: 'Nutriente não analisado para este alimento',
      };
    case 'not-in-source':
      return {
        text: '—',
        title: 'Não fornecido pela fonte',
      };
    case 'not-applicable':
      return {
        text: 'N/A',
        title: 'Não aplicável',
      };
    case 'withheld':
      return {
        text: 'Indisponível',
        title: 'Valor indisponível ou restrito na fonte',
      };
  }
}
