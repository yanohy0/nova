const prefetchedUris = new Set<string>();
const MAX_PREFETCHED_IMAGES = 12;

/**
 * Deduplicated, bounded photo prefetch for visible Cardápios recipes.
 * Never prefetches off-viewport bulk catalogs and silently ignores failures.
 */
export function prefetchVisibleRecipePhotos(uris: ReadonlyArray<string | null | undefined>): void {
  if (typeof window === 'undefined' || typeof Image === 'undefined') return;
  for (const raw of uris) {
    if (prefetchedUris.size >= MAX_PREFETCHED_IMAGES) break;
    if (!raw || typeof raw !== 'string') continue;
    const clean = raw.trim();
    if (!clean || prefetchedUris.has(clean)) continue;
    prefetchedUris.add(clean);
    const img = new Image();
    img.referrerPolicy = 'no-referrer';
    img.decoding = 'async';
    img.src = clean;
  }
}

export function clearPrefetchedPhotoCache(): void {
  prefetchedUris.clear();
}
