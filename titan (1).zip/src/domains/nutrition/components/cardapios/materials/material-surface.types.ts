export type MaterialSkinId =
  | 'maison-a1-leather-led'
  | 'maison-a2-bound-menu'
  | 'grand-service'
  | 'shikki-roiro'
  | 'shikki-nuritate'
  | 'solid-fallback';

export type MaterialRegion =
  | 'menu-shell'
  | 'recipe-surface'
  | 'recipe-cover-closed'
  | 'recipe-open-paper'
  | 'nutrition-matrix'
  | 'existing-divider'
  | 'folio-front'
  | 'folio-back';

export type FolioVariant = 'flat' | 'bi-fold' | 'cross-fold-2x2' | 'recipe-book-cover';

export interface FolioMaterial {
  frontAsset?: string;
  backAsset?: string;
  frontFallbackColor: string;
  backFallbackColor: string;
  assetVersion: string;
}

export interface ContentSafeInsets {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

export interface MaterialSurfaceRequest {
  skin: MaterialSkinId;
  region: MaterialRegion;
  width: number;
  height: number;
  pixelRatio: number;
  colorScheme: 'dark' | 'light';
  contentSafeInsets?: ContentSafeInsets;
}

export interface MaterialSurfaceHandle {
  uri?: string;
  nativeHandle?: unknown;
  widthPx: number;
  heightPx: number;
  cacheKey: string;
  fallbackColor: string;
  isFallback: boolean;
}

export interface MaterialSurfaceRenderer {
  initialize(): Promise<void>;
  renderStatic(request: MaterialSurfaceRequest): Promise<MaterialSurfaceHandle>;
  release(handle: MaterialSurfaceHandle): void;
  clearUnusedCache(): void;
  dispose(): Promise<void>;
}
