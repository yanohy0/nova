import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { MaterialRegion, MaterialSkinId } from './material-surface.types.ts';

export interface PbrBakeResult {
  uri: string;
  widthPx: number;
  heightPx: number;
}

export type PbrTileKind = 'leather' | 'paper';
export type PbrFrameVariant =
  | 'leather-stitched'
  | 'leather-spine-stitched'
  | 'paper-folio'
  | 'paper-matrix';

export interface PbrLayerAssets {
  tileUri: string;
  tileSizeCss: number;
  frameUri: string | null;
  frameSlicePx: number;
  frameWidthCss: number;
  spineUri: string | null;
  spineWidthCss: number;
  spineHeightCss: number;
}

interface RawTileData {
  size: number;
  heights: Float32Array;
  albedo: Uint8Array;
  roughness: Uint8Array;
}

interface BakerResources {
  renderer: THREE.WebGLRenderer;
  pmremGenerator: THREE.PMREMGenerator;
  envTarget: THREE.WebGLRenderTarget;
  scene: THREE.Scene;
  camera: THREE.OrthographicCamera;
  keyLight: THREE.DirectionalLight;
  rimLight: THREE.DirectionalLight;
  fillLight: THREE.DirectionalLight;
  hemiLight: THREE.HemisphereLight;
  isSoftwareGl: boolean;
  contextLost: boolean;
  leatherTile: RawTileData | null;
  paperTile: RawTileData | null;
  tileUriCache: Map<PbrTileKind, string>;
  frameUriCache: Map<PbrFrameVariant, string>;
  spineUriCache: string | null;
}

let sharedBaker: BakerResources | null = null;

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

function clampByte(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : Math.round(v);
}

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = clamp01((x - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

function hash2Periodic(ix: number, iy: number, period: number, seed: number): number {
  const wx = ((ix % period) + period) % period;
  const wy = ((iy % period) + period) % period;
  let h = (wx * 374761393 + wy * 668265263 + seed * 1442695041) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}

function hash1D(i: number, seed: number): number {
  let h = (i * 374761393 + seed * 1442695041) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}

function smoothPeriodicNoise(u: number, v: number, freq: number, seed: number): number {
  const sx = u * freq;
  const sy = v * freq;
  const x0 = Math.floor(sx);
  const y0 = Math.floor(sy);
  const fx = sx - x0;
  const fy = sy - y0;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const n00 = hash2Periodic(x0, y0, freq, seed);
  const n10 = hash2Periodic(x0 + 1, y0, freq, seed);
  const n01 = hash2Periodic(x0, y0 + 1, freq, seed);
  const n11 = hash2Periodic(x0 + 1, y0 + 1, freq, seed);
  return (n00 + (n10 - n00) * ux) * (1 - uy) + (n01 + (n11 - n01) * ux) * uy;
}

function fbmPeriodic(u: number, v: number, seed: number): number {
  return (
    smoothPeriodicNoise(u, v, 6, seed) * 0.52 +
    smoothPeriodicNoise(u, v, 14, seed + 19) * 0.31 +
    smoothPeriodicNoise(u, v, 32, seed + 47) * 0.17
  );
}

function voronoiPebble(
  u: number,
  v: number,
  cells: number,
  anisotropyX: number,
  anisotropyY: number,
  seed: number,
): { dome: number; crease: number; cellId: number } {
  const sx = u * cells;
  const sy = v * cells;
  const gx = Math.floor(sx);
  const gy = Math.floor(sy);
  let minD1 = 10;
  let minD2 = 10;
  let cellId = 0;

  for (let dy = -1; dy <= 1; dy += 1) {
    for (let dx = -1; dx <= 1; dx += 1) {
      const cx = gx + dx;
      const cy = gy + dy;
      const px = cx + 0.14 + 0.72 * hash2Periodic(cx, cy, cells, seed);
      const py = cy + 0.14 + 0.72 * hash2Periodic(cx, cy, cells, seed + 97);
      const dist = Math.hypot((sx - px) * anisotropyX, (sy - py) * anisotropyY);
      if (dist < minD1) {
        minD2 = minD1;
        minD1 = dist;
        cellId = hash2Periodic(cx, cy, cells, seed + 211);
      } else if (dist < minD2) {
        minD2 = dist;
      }
    }
  }

  const valleyDist = Math.max(0, minD2 - minD1);
  const crease = smoothstep(0.012, 0.22, valleyDist);
  const dome = Math.pow(clamp01(1 - minD1 * 1.08), 0.68);
  return { dome, crease, cellId };
}

/**
 * Seamless 512x512 Morocco Goatskin (Chèvre Sully) tile:
 * - Organic domain-warped 2-scale cellular pebbles (18x18 macro + 40x40 micro grain)
 * - Calibrated emerald-pine pull-up tonal depth (#0E1714 pores -> #2D4239 wax-burnished domes)
 * - Pronounced micro-roughness separation (0.90 matte pore -> 0.26 burnished dome)
 */
function createMoroccoLeatherTile(): RawTileData {
  const size = 512;
  const heights = new Float32Array(size * size);
  const albedo = new Uint8Array(size * size * 3);
  const roughness = new Uint8Array(size * size);

  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) {
      const u = x / size;
      const idx = y * size + x;
      const aIdx = idx * 3;

      const warpU = u + (smoothPeriodicNoise(u, v, 8, 11) - 0.5) * 0.024;
      const warpV = v + (smoothPeriodicNoise(u, v, 8, 29) - 0.5) * 0.024;

      const primary = voronoiPebble(warpU, warpV, 18, 0.85, 1.25, 101);
      const secondary = voronoiPebble(warpU + 0.013, warpV - 0.017, 40, 1.04, 0.92, 307);
      const pullUp = fbmPeriodic(u, v, 503);
      const microPore = smoothPeriodicNoise(u, v, 112, 709);

      const pebbleBody =
        primary.crease * (0.45 + 0.55 * primary.dome) * 0.74 +
        secondary.crease * (0.32 + 0.68 * secondary.dome) * 0.26;
      const poreDimple = microPore < 0.16 ? (0.16 - microPore) * 0.9 : 0;
      const h = clamp01(pebbleBody * 0.88 + 0.12 * pullUp - poreDimple);
      heights[idx] = h;

      const crown = smoothstep(0.22, 0.88, h);
      const individualTone = (primary.cellId - 0.5) * 8;
      const pullUpBoost = (pullUp - 0.5) * 10;

      albedo[aIdx] = clampByte(13 + crown * 32 + pullUpBoost * 0.55 + individualTone * 0.6);
      albedo[aIdx + 1] = clampByte(22 + crown * 44 + pullUpBoost * 0.85 + individualTone * 0.8);
      albedo[aIdx + 2] = clampByte(19 + crown * 35 + pullUpBoost * 0.65 + individualTone * 0.7);

      // Matte creased pores (0.90) vs wax-burnished pebble tops (0.26) for crisp studio highlights
      roughness[idx] = clampByte(234 - crown * 166 + (1 - primary.crease) * 18);
    }
  }

  return { size, heights, albedo, roughness };
}

/**
 * Seamless 512x512 Mould-Made Cotton Rag Paper (Arches / Fabriano 300g, #EEE9DE):
 * - Zero mathematical sine stripes
 * - Multi-octave cellulose pulp clouding + 3,600 wrapped curved cotton/flax fibers
 */
function createCottonPaperTile(): RawTileData {
  const size = 512;
  const heights = new Float32Array(size * size);
  const albedo = new Uint8Array(size * size * 3);
  const roughness = new Uint8Array(size * size);

  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) {
      const u = x / size;
      const idx = y * size + x;
      const aIdx = idx * 3;

      const pulpCloud = fbmPeriodic(u, v, 811);
      const grainTooth = smoothPeriodicNoise(u, v, 68, 919);
      const fineTooth = smoothPeriodicNoise(u, v, 140, 1021);
      const h = clamp01(
        0.47 + (pulpCloud - 0.5) * 0.24 + (grainTooth - 0.5) * 0.17 + (fineTooth - 0.5) * 0.12,
      );
      heights[idx] = h;

      const warmShift = (pulpCloud - 0.5) * 7;
      const microShade = (h - 0.5) * 12;
      albedo[aIdx] = clampByte(238 + warmShift + microShade);
      albedo[aIdx + 1] = clampByte(233 + warmShift * 0.85 + microShade);
      albedo[aIdx + 2] = clampByte(222 + warmShift * 0.55 + microShade * 0.9);
      roughness[idx] = clampByte(214 + (1 - h) * 34);
    }
  }

  const fiberCount = 3600;
  for (let i = 0; i < fiberCount; i += 1) {
    const x0 = hash1D(i, 41) * size;
    const y0 = hash1D(i, 73) * size;
    const angle = hash1D(i, 109) * Math.PI * 2;
    const len = 8 + hash1D(i, 149) * 20;
    const curve = (hash1D(i, 193) - 0.5) * 5;
    const isLightFiber = hash1D(i, 233) > 0.42;
    const strength = 0.35 + hash1D(i, 277) * 0.65;
    const steps = Math.ceil(len * 1.4);

    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);
    const perpX = -sinA;
    const perpY = cosA;

    for (let s = 0; s <= steps; s += 1) {
      const t = s / steps;
      const bend = Math.sin(t * Math.PI) * curve;
      const fx = x0 + cosA * len * t + perpX * bend;
      const fy = y0 + sinA * len * t + perpY * bend;
      const px = ((Math.round(fx) % size) + size) % size;
      const py = ((Math.round(fy) % size) + size) % size;
      const idx = py * size + px;
      const aIdx = idx * 3;
      const taper = Math.sin(t * Math.PI) * strength;

      if (isLightFiber) {
        heights[idx] = clamp01(heights[idx]! + 0.085 * taper);
        albedo[aIdx] = clampByte(albedo[aIdx]! + 5 * taper);
        albedo[aIdx + 1] = clampByte(albedo[aIdx + 1]! + 4.5 * taper);
        albedo[aIdx + 2] = clampByte(albedo[aIdx + 2]! + 3.5 * taper);
      } else {
        heights[idx] = clamp01(heights[idx]! - 0.055 * taper);
        albedo[aIdx] = clampByte(albedo[aIdx]! - 7 * taper);
        albedo[aIdx + 1] = clampByte(albedo[aIdx + 1]! - 8 * taper);
        albedo[aIdx + 2] = clampByte(albedo[aIdx + 2]! - 10 * taper);
      }
      roughness[idx] = clampByte(roughness[idx]! - 8 * taper);
    }
  }

  return { size, heights, albedo, roughness };
}

function roundedBoxSdf(
  px: number,
  py: number,
  cx: number,
  cy: number,
  halfW: number,
  halfH: number,
  radius: number,
): number {
  const qx = Math.abs(px - cx) - Math.max(0, halfW - radius);
  const qy = Math.abs(py - cy) - Math.max(0, halfH - radius);
  const outDist = Math.hypot(Math.max(qx, 0), Math.max(qy, 0));
  const inDist = Math.min(Math.max(qx, qy), 0);
  return outDist + inDist - radius;
}

function distToSegment(
  px: number,
  py: number,
  ax: number,
  ay: number,
  bx: number,
  by: number,
): { dist: number; t: number } {
  const dx = bx - ax;
  const dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  if (lenSq < 1e-6) return { dist: Math.hypot(px - ax, py - ay), t: 0 };
  const t = clamp01(((px - ax) * dx + (py - ay) * dy) / lenSq);
  return { dist: Math.hypot(px - (ax + t * dx), py - (ay + t * dy)), t };
}

interface StitchPoint {
  x: number;
  y: number;
  tx: number;
  ty: number;
  nx: number;
  ny: number;
}

/**
 * Generates exact phase-locked stitches for a 256x256 9-slice atlas (`slice = 56`, middle = `144`):
 * - Straight middle segments [56..200] receive 9 stitches at exact 16-texel pitch (64, 80, ..., 192)
 *   so CSS `border-image-repeat: round` repeats cleanly with zero stitch splitting or jump.
 * - Each corner [0..56] connects smoothly from (48, inset) around the rounded arc to (inset, 48).
 */
function buildNineSliceStitchPoints(inset: number, cornerRadius: number): StitchPoint[] {
  const size = 256;
  const slice = 56;
  const pts: StitchPoint[] = [];

  // Straight segment stitch centers: 64, 80, 96, 112, 128, 144, 160, 176, 192 (pitch = 16)
  for (let pos = slice + 8; pos <= size - slice - 8; pos += 16) {
    pts.push({ x: pos, y: inset, tx: 1, ty: 0, nx: 0, ny: -1 }); // Top
    pts.push({ x: size - inset, y: pos, tx: 0, ty: 1, nx: 1, ny: 0 }); // Right
    pts.push({ x: size - pos, y: size - inset, tx: -1, ty: 0, nx: 0, ny: 1 }); // Bottom
    pts.push({ x: inset, y: size - pos, tx: 0, ty: -1, nx: -1, ny: 0 }); // Left
  }

  // Corner zones linking (inset, 48) -> arc -> (48, inset) at ~16 texel spacing
  const r = Math.min(cornerRadius, slice - inset - 8);
  const straightStub = slice - 8 - (inset + r);
  const arcLen = 0.5 * Math.PI * r;
  const cornerLen = 2 * straightStub + arcLen;
  const intervals = Math.max(2, Math.round(cornerLen / 16));

  const sampleCornerPoint = (s: number): StitchPoint => {
    if (s <= straightStub) {
      return { x: inset, y: slice - 8 - s, tx: 0, ty: -1, nx: -1, ny: 0 };
    }
    const rem = s - straightStub;
    if (rem <= arcLen) {
      const a = Math.PI + (rem / Math.max(0.001, arcLen)) * (Math.PI / 2);
      return {
        x: inset + r + Math.cos(a) * r,
        y: inset + r + Math.sin(a) * r,
        tx: -Math.sin(a),
        ty: Math.cos(a),
        nx: Math.cos(a),
        ny: Math.sin(a),
      };
    }
    const rem2 = rem - arcLen;
    return { x: inset + r + rem2, y: inset, tx: 1, ty: 0, nx: 0, ny: -1 };
  };

  for (let k = 1; k < intervals; k += 1) {
    const tl = sampleCornerPoint((k / intervals) * cornerLen);
    // Top-Left
    pts.push(tl);
    // Top-Right (rotate 90 deg CW around 128,128)
    pts.push({
      x: size - tl.y,
      y: tl.x,
      tx: -tl.ty,
      ty: tl.tx,
      nx: -tl.ny,
      ny: tl.nx,
    });
    // Bottom-Right (rotate 180 deg)
    pts.push({
      x: size - tl.x,
      y: size - tl.y,
      tx: -tl.tx,
      ty: -tl.ty,
      nx: -tl.nx,
      ny: -tl.ny,
    });
    // Bottom-Left (rotate 270 deg CW)
    pts.push({
      x: tl.y,
      y: size - tl.x,
      tx: tl.ty,
      ty: -tl.tx,
      nx: tl.ny,
      ny: -tl.nx,
    });
  }

  return pts;
}

function buildNormalDataFromHeights(
  width: number,
  height: number,
  heights: Float32Array,
  strength: number,
  periodic: boolean,
): Uint8Array {
  const normalData = new Uint8Array(width * height * 4);
  for (let y = 0; y < height; y += 1) {
    const ym = periodic ? (y - 1 + height) % height : Math.max(0, y - 1);
    const yp = periodic ? (y + 1) % height : Math.min(height - 1, y + 1);
    for (let x = 0; x < width; x += 1) {
      const xm = periodic ? (x - 1 + width) % width : Math.max(0, x - 1);
      const xp = periodic ? (x + 1) % width : Math.min(width - 1, x + 1);

      const tl = heights[ym * width + xm] ?? 0;
      const tc = heights[ym * width + x] ?? 0;
      const tr = heights[ym * width + xp] ?? 0;
      const ml = heights[y * width + xm] ?? 0;
      const mr = heights[y * width + xp] ?? 0;
      const bl = heights[yp * width + xm] ?? 0;
      const bc = heights[yp * width + x] ?? 0;
      const br = heights[yp * width + xp] ?? 0;

      const gx = (tr + 2 * mr + br - (tl + 2 * ml + bl)) * 0.25 * strength;
      const gy = (bl + 2 * bc + br - (tl + 2 * tc + tr)) * 0.25 * strength;
      const invLen = 1 / Math.hypot(-gx, -gy, 1);

      const pIdx = (y * width + x) * 4;
      normalData[pIdx] = clampByte((-gx * invLen * 0.5 + 0.5) * 255);
      normalData[pIdx + 1] = clampByte((gy * invLen * 0.5 + 0.5) * 255);
      normalData[pIdx + 2] = clampByte((invLen * 0.5 + 0.5) * 255);
      normalData[pIdx + 3] = 255;
    }
  }
  return normalData;
}

function getOrCreateSharedBaker(): BakerResources | null {
  if (typeof document === 'undefined' || typeof WebGLRenderingContext === 'undefined') {
    return null;
  }
  if (sharedBaker && !sharedBaker.contextLost) {
    return sharedBaker;
  }

  try {
    const canvas = document.createElement('canvas');
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      premultipliedAlpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });

    const gl = renderer.getContext();
    const dbgInfo = gl.getExtension('WEBGL_debug_renderer_info');
    const glRenderer = dbgInfo ? String(gl.getParameter(dbgInfo.UNMASKED_RENDERER_WEBGL)) : '';
    const isSoftwareGl = /swiftshader|llvmpipe|softpipe/i.test(glRenderer);

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.28;
    renderer.setClearColor(0x000000, 0);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    roomEnv.dispose();

    const scene = new THREE.Scene();
    scene.environment = envTarget.texture;
    scene.environmentIntensity = 1.15;

    const camera = new THREE.OrthographicCamera(-0.5, 0.5, 0.5, -0.5, 0.1, 10);
    camera.position.set(0, 0, 2);
    camera.lookAt(0, 0, 0);

    // Grazing studio key light from top-left to carve deep 3D pebble & stitch catchlights
    const keyLight = new THREE.DirectionalLight('#FFF0D4', 3.4);
    keyLight.position.set(-2.2, 2.4, 1.35);
    scene.add(keyLight);

    // Cool sage rim light from bottom-right to illuminate gold tooling & bevel curves
    const rimLight = new THREE.DirectionalLight('#B8D6CC', 1.45);
    rimLight.position.set(2.2, -1.7, 1.15);
    scene.add(rimLight);

    const fillLight = new THREE.DirectionalLight('#FAF5EA', 0.58);
    fillLight.position.set(0.15, 0.6, 2.6);
    scene.add(fillLight);

    const hemiLight = new THREE.HemisphereLight('#F4EFE4', '#0A100E', 0.6);
    scene.add(hemiLight);

    const baker: BakerResources = {
      renderer,
      pmremGenerator,
      envTarget,
      scene,
      camera,
      keyLight,
      rimLight,
      fillLight,
      hemiLight,
      isSoftwareGl,
      contextLost: false,
      leatherTile: null,
      paperTile: null,
      tileUriCache: new Map(),
      frameUriCache: new Map(),
      spineUriCache: null,
    };

    canvas.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      baker.contextLost = true;
    });
    canvas.addEventListener('webglcontextrestored', () => {
      baker.contextLost = false;
    });

    sharedBaker = baker;
    return baker;
  } catch {
    return null;
  }
}

export function canBakePbrInBrowser(): boolean {
  return typeof document !== 'undefined' && typeof WebGLRenderingContext !== 'undefined';
}

function makeDataTexture(
  data: Uint8Array,
  w: number,
  h: number,
  srgb: boolean,
  repeat: boolean,
): THREE.DataTexture {
  const tex = new THREE.DataTexture(data, w, h, THREE.RGBAFormat);
  tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.flipY = true;
  tex.wrapS = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.wrapT = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Bakes a 100% seamless 512x512 Three.js PBR-lit Morocco goatskin or cotton rag tile ONCE.
 * Renders a 3x3 tiled PlaneGeometry(3, 3) captured on the center [-0.5..0.5] so border pixels
 * wrap with zero seam and zero distortion at any CSS box size.
 */
export function bakePbrTileUri(kind: PbrTileKind): string | null {
  const baker = getOrCreateSharedBaker();
  if (!baker) return null;
  const cached = baker.tileUriCache.get(kind);
  if (cached) return cached;

  const isPaper = kind === 'paper';
  if (isPaper && !baker.paperTile) baker.paperTile = createCottonPaperTile();
  if (!isPaper && !baker.leatherTile) baker.leatherTile = createMoroccoLeatherTile();

  const tile = isPaper ? baker.paperTile! : baker.leatherTile!;
  const size = tile.size;
  const n = size * size;

  const albedoData = new Uint8Array(n * 4);
  const roughData = new Uint8Array(n * 4);
  const aoData = new Uint8Array(n * 4);

  for (let i = 0; i < n; i += 1) {
    const pIdx = i * 4;
    const aIdx = i * 3;
    albedoData[pIdx] = tile.albedo[aIdx]!;
    albedoData[pIdx + 1] = tile.albedo[aIdx + 1]!;
    albedoData[pIdx + 2] = tile.albedo[aIdx + 2]!;
    albedoData[pIdx + 3] = 255;

    const r = tile.roughness[i]!;
    roughData[pIdx] = r;
    roughData[pIdx + 1] = r;
    roughData[pIdx + 2] = r;
    roughData[pIdx + 3] = 255;

    const ao = isPaper ? 248 : clampByte(186 + tile.heights[i]! * 69);
    aoData[pIdx] = ao;
    aoData[pIdx + 1] = ao;
    aoData[pIdx + 2] = ao;
    aoData[pIdx + 3] = 255;
  }

  const normalData = buildNormalDataFromHeights(
    size,
    size,
    tile.heights,
    isPaper ? 2.5 : 5.4,
    true,
  );

  const map = makeDataTexture(albedoData, size, size, true, true);
  map.repeat.set(3, 3);
  const normalMap = makeDataTexture(normalData, size, size, false, true);
  normalMap.repeat.set(3, 3);
  const roughnessMap = makeDataTexture(roughData, size, size, false, true);
  roughnessMap.repeat.set(3, 3);
  const aoMap = makeDataTexture(aoData, size, size, false, true);
  aoMap.repeat.set(3, 3);

  const geometry = new THREE.PlaneGeometry(3, 3);
  const uvAttr = geometry.getAttribute('uv');
  if (uvAttr) geometry.setAttribute('uv1', uvAttr);
  const material = new THREE.MeshPhysicalMaterial({
    map,
    normalMap,
    normalScale: new THREE.Vector2(isPaper ? 1.65 : 2.75, isPaper ? 1.65 : 2.75),
    roughnessMap,
    roughness: isPaper ? 0.96 : 0.72,
    metalness: 0.03,
    aoMap,
    aoMapIntensity: isPaper ? 0.45 : 0.92,
    sheen: isPaper ? 0.14 : 0.62,
    sheenRoughness: isPaper ? 0.85 : 0.42,
    sheenColor: new THREE.Color(isPaper ? '#FAF6EC' : '#577063'),
    clearcoat: isPaper ? 0 : 0.3,
    clearcoatRoughness: 0.28,
  });

  const mesh = new THREE.Mesh(geometry, material);
  baker.scene.add(mesh);
  baker.renderer.setPixelRatio(1);
  baker.renderer.setSize(size, size, false);
  baker.renderer.setClearColor(0x000000, 1);
  baker.renderer.render(baker.scene, baker.camera);
  const uri = baker.renderer.domElement.toDataURL('image/png');

  baker.scene.remove(mesh);
  geometry.dispose();
  material.dispose();
  map.dispose();
  normalMap.dispose();
  roughnessMap.dispose();
  aoMap.dispose();

  baker.tileUriCache.set(kind, uri);
  return uri;
}

/**
 * Bakes a 256x256 Retina 2x 9-slice Three.js PBR Frame Atlas (`slice = 56` -> `28px` CSS border):
 * - 3D vertex-displaced padded edge cushion bevel
 * - Rounded-corner SDF debossed stitch groove + 3D slanted Couture Sellier waxed-linen stitches + awl dimples
 * - Blind-tooled channel + hot-stamped metallic champagne gold leaf fillet (`metalness: 0.94`)
 * - Transparent center beyond 27px CSS so Layer A's crisp tiled interior shows with ZERO stretch
 */
export function bakePbrFrameAtlasUri(variant: PbrFrameVariant): string | null {
  const baker = getOrCreateSharedBaker();
  if (!baker) return null;
  const cached = baker.frameUriCache.get(variant);
  if (cached) return cached;

  const isPaper = variant === 'paper-folio' || variant === 'paper-matrix';
  if (isPaper && !baker.paperTile) baker.paperTile = createCottonPaperTile();
  if (!isPaper && !baker.leatherTile) baker.leatherTile = createMoroccoLeatherTile();

  const tile = isPaper ? baker.paperTile! : baker.leatherTile!;
  const size = 256;
  const n = size * size;
  const tileSize = tile.size;

  const heights = new Float32Array(n);
  const albedoData = new Uint8Array(n * 4);
  const roughData = new Uint8Array(n * 4);
  const metalData = new Uint8Array(n * 4);
  const aoData = new Uint8Array(n * 4);

  const cornerRadius = variant === 'paper-matrix' ? 20 : variant === 'leather-stitched' ? 36 : 28;
  const half = size * 0.5;
  const hasStitching = !isPaper;
  const hasGold = variant !== 'paper-matrix';

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const idx = y * size + x;
      const pIdx = idx * 4;
      const tx = (x * 2) % tileSize;
      const ty = (y * 2) % tileSize;
      const tIdx = ty * tileSize + tx;
      const aIdx = tIdx * 3;

      const baseH = tile.heights[tIdx]!;
      heights[idx] = baseH;
      albedoData[pIdx] = tile.albedo[aIdx]!;
      albedoData[pIdx + 1] = tile.albedo[aIdx + 1]!;
      albedoData[pIdx + 2] = tile.albedo[aIdx + 2]!;

      const rb = tile.roughness[tIdx]!;
      roughData[pIdx] = rb;
      roughData[pIdx + 1] = rb;
      roughData[pIdx + 2] = rb;
      roughData[pIdx + 3] = 255;

      metalData[pIdx] = 8;
      metalData[pIdx + 1] = 8;
      metalData[pIdx + 2] = 8;
      metalData[pIdx + 3] = 255;

      const baseAo = isPaper ? 248 : clampByte(192 + baseH * 63);
      aoData[pIdx] = baseAo;
      aoData[pIdx + 1] = baseAo;
      aoData[pIdx + 2] = baseAo;
      aoData[pIdx + 3] = 255;

      const sdf = roundedBoxSdf(x + 0.5, y + 0.5, half, half, half, half, cornerRadius);

      // Alpha feather: solid around border ring [0..-36], fades cleanly to 0 across [-36..-54]
      const alphaWeight = sdf <= -54 ? 0 : sdf >= -36 ? 1 : 1 - smoothstep(-36, -54, sdf);
      albedoData[pIdx + 3] = clampByte(alphaWeight * 255);

      if (alphaWeight <= 0.005) continue;

      if (isPaper) {
        if (sdf > -10) {
          const edgeBevel = smoothstep(-10, 0, sdf);
          heights[idx] = clamp01(heights[idx]! - edgeBevel * 0.2);
          const ao = clampByte(aoData[pIdx]! * (1 - edgeBevel * 0.24));
          aoData[pIdx] = ao;
          aoData[pIdx + 1] = ao;
          aoData[pIdx + 2] = ao;
        }
        if (hasGold) {
          const ruleDist = Math.abs(sdf + 22);
          if (ruleDist < 4) {
            const groove = 1 - smoothstep(0, 3.2, ruleDist);
            heights[idx] = clamp01(heights[idx]! - groove * 0.18);
            if (ruleDist < 1.6) {
              const foil = 0.36 * (1 - ruleDist / 1.6);
              albedoData[pIdx] = clampByte(albedoData[pIdx]! * (1 - foil) + 188 * foil);
              albedoData[pIdx + 1] = clampByte(albedoData[pIdx + 1]! * (1 - foil) + 162 * foil);
              albedoData[pIdx + 2] = clampByte(albedoData[pIdx + 2]! * (1 - foil) + 110 * foil);
              const fm = clampByte(170 * foil + 8 * (1 - foil));
              metalData[pIdx] = fm;
              metalData[pIdx + 1] = fm;
              metalData[pIdx + 2] = fm;
            }
          }
        }
      } else {
        // Outer padded leather bevel & edge burnish
        if (sdf > -11) {
          const bevelT = smoothstep(-11, 0, sdf);
          heights[idx] = clamp01(heights[idx]! - bevelT * 0.28);
          const eAo = clampByte(aoData[pIdx]! * (1 - bevelT * 0.38));
          aoData[pIdx] = eAo;
          aoData[pIdx + 1] = eAo;
          aoData[pIdx + 2] = eAo;
        }

        // Stitch channel groove at inset = 18 texels (9px CSS)
        if (hasStitching) {
          const sDist = Math.abs(sdf + 18);
          if (sDist < 4.4) {
            const groove = Math.cos((sDist / 4.4) * (Math.PI * 0.5));
            const gSq = groove * groove;
            heights[idx] = clamp01(heights[idx]! - gSq * 0.26);
            const gAo = clampByte(aoData[pIdx]! * (1 - gSq * 0.32));
            aoData[pIdx] = gAo;
            aoData[pIdx + 1] = gAo;
            aoData[pIdx + 2] = gAo;
          }
        }

        // Blind-tooled inner channel & metallic champagne gold leaf fillet at inset = 31 texels (15.5px CSS)
        if (hasGold) {
          const tDist = Math.abs(sdf + 31);
          if (tDist < 4.5) {
            const deboss = Math.cos((tDist / 4.5) * (Math.PI * 0.5));
            heights[idx] = clamp01(heights[idx]! - deboss * deboss * 0.36);

            if (tDist < 1.85) {
              const foilMask = smoothstep(1.85, 0.5, tDist) * (0.76 + 0.24 * baseH);
              albedoData[pIdx] = clampByte(albedoData[pIdx]! * (1 - foilMask) + 214 * foilMask);
              albedoData[pIdx + 1] = clampByte(albedoData[pIdx + 1]! * (1 - foilMask) + 182 * foilMask);
              albedoData[pIdx + 2] = clampByte(albedoData[pIdx + 2]! * (1 - foilMask) + 120 * foilMask);

              const rVal = clampByte(roughData[pIdx]! * (1 - foilMask) + 46 * foilMask);
              roughData[pIdx] = rVal;
              roughData[pIdx + 1] = rVal;
              roughData[pIdx + 2] = rVal;

              const mVal = clampByte(242 * foilMask + 8 * (1 - foilMask));
              metalData[pIdx] = mVal;
              metalData[pIdx + 1] = mVal;
              metalData[pIdx + 2] = mVal;
            }
          }
        }
      }
    }
  }

  // Stamp crisp 3D Couture Sellier saddle stitches around the phase-locked 9-slice perimeter
  if (hasStitching) {
    const pts = buildNineSliceStitchPoints(18, Math.max(8, cornerRadius - 18));
    const halfLen = 5.6;
    const threadRadius = 1.72;
    const holeRadius = 2.15;
    const slantCos = Math.cos(0.28);
    const slantSin = Math.sin(0.28);

    for (let i = 0; i < pts.length; i += 1) {
      const pt = pts[i]!;
      const sx = pt.tx * slantCos - pt.nx * slantSin;
      const sy = pt.ty * slantCos - pt.ny * slantSin;
      const ax = pt.x - sx * halfLen;
      const ay = pt.y - sy * halfLen;
      const bx = pt.x + sx * halfLen;
      const by = pt.y + sy * halfLen;

      const minX = Math.max(0, Math.floor(Math.min(ax, bx) - holeRadius * 2));
      const maxX = Math.min(size - 1, Math.ceil(Math.max(ax, bx) + holeRadius * 2));
      const minY = Math.max(0, Math.floor(Math.min(ay, by) - holeRadius * 2));
      const maxY = Math.min(size - 1, Math.ceil(Math.max(ay, by) + holeRadius * 2));

      for (let py = minY; py <= maxY; py += 1) {
        for (let px = minX; px <= maxX; px += 1) {
          const idx = py * size + px;
          const pIdx = idx * 4;

          const dHole = Math.min(
            Math.hypot(px + 0.5 - ax, py + 0.5 - ay),
            Math.hypot(px + 0.5 - bx, py + 0.5 - by),
          );
          if (dHole < holeRadius) {
            const hMask = 1 - smoothstep(0, holeRadius, dHole);
            heights[idx] = clamp01(heights[idx]! - hMask * 0.62);
            const hAo = clampByte(aoData[pIdx]! * (1 - hMask * 0.72));
            aoData[pIdx] = hAo;
            aoData[pIdx + 1] = hAo;
            aoData[pIdx + 2] = hAo;
          }

          const seg = distToSegment(px + 0.5, py + 0.5, ax, ay, bx, by);
          if (seg.dist < threadRadius * 1.45) {
            if (seg.dist < threadRadius) {
              const profile = Math.sqrt(Math.max(0, 1 - (seg.dist / threadRadius) ** 2));
              const plyTwist = 0.87 + 0.13 * Math.sin(seg.t * Math.PI * 6);
              const cov = smoothstep(threadRadius, threadRadius * 0.42, seg.dist);
              const crown = 0.65 + 0.35 * profile * plyTwist;
              heights[idx] = clamp01(heights[idx]! * (1 - cov) + crown * cov);

              const shade = (0.78 + 0.32 * profile) * plyTwist;
              albedoData[pIdx] = clampByte(albedoData[pIdx]! * (1 - cov) + 196 * shade * cov);
              albedoData[pIdx + 1] = clampByte(albedoData[pIdx + 1]! * (1 - cov) + 172 * shade * cov);
              albedoData[pIdx + 2] = clampByte(albedoData[pIdx + 2]! * (1 - cov) + 126 * shade * cov);

              const tr = clampByte(roughData[pIdx]! * (1 - cov) + 74 * cov);
              roughData[pIdx] = tr;
              roughData[pIdx + 1] = tr;
              roughData[pIdx + 2] = tr;

              const ta = clampByte(aoData[pIdx]! * (1 - cov) + 252 * cov);
              aoData[pIdx] = ta;
              aoData[pIdx + 1] = ta;
              aoData[pIdx + 2] = ta;
            } else {
              const contact = 1 - smoothstep(threadRadius, threadRadius * 1.45, seg.dist);
              const sAo = clampByte(aoData[pIdx]! * (1 - contact * 0.32));
              aoData[pIdx] = sAo;
              aoData[pIdx + 1] = sAo;
              aoData[pIdx + 2] = sAo;
            }
          }
        }
      }
    }
  }

  const normalData = buildNormalDataFromHeights(size, size, heights, isPaper ? 2.4 : 4.8, false);

  const map = makeDataTexture(albedoData, size, size, true, false);
  const normalMap = makeDataTexture(normalData, size, size, false, false);
  const roughnessMap = makeDataTexture(roughData, size, size, false, false);
  const metalnessMap = makeDataTexture(metalData, size, size, false, false);
  const aoMap = makeDataTexture(aoData, size, size, false, false);

  // Subdivided 3D border cushion mesh
  const geometry = new THREE.PlaneGeometry(1, 1, 64, 64);
  const posAttr = geometry.attributes.position as THREE.BufferAttribute;
  const uvAttr = geometry.attributes.uv as THREE.BufferAttribute;
  geometry.setAttribute('uv1', uvAttr);

  for (let i = 0; i < posAttr.count; i += 1) {
    const u = uvAttr.getX(i);
    const v = uvAttr.getY(i);
    const edgeDist = Math.min(u, 1 - u, v, 1 - v);
    const cushionZ = -0.018 * (1 - smoothstep(0, 0.075, edgeDist));
    posAttr.setZ(i, cushionZ);
  }
  posAttr.needsUpdate = true;
  geometry.computeVertexNormals();

  const material = new THREE.MeshPhysicalMaterial({
    map,
    normalMap,
    normalScale: new THREE.Vector2(isPaper ? 1.55 : 2.6, isPaper ? 1.55 : 2.6),
    roughnessMap,
    roughness: isPaper ? 0.96 : 0.74,
    metalnessMap,
    metalness: 1.0,
    aoMap,
    aoMapIntensity: isPaper ? 0.45 : 0.94,
    sheen: isPaper ? 0.14 : 0.58,
    sheenRoughness: 0.44,
    sheenColor: new THREE.Color(isPaper ? '#FAF6EC' : '#577063'),
    clearcoat: isPaper ? 0 : 0.26,
    clearcoatRoughness: 0.3,
    transparent: true,
  });

  const mesh = new THREE.Mesh(geometry, material);
  baker.scene.add(mesh);
  baker.renderer.setPixelRatio(1);
  baker.renderer.setSize(size, size, false);
  baker.renderer.setClearColor(0x000000, 0);
  baker.renderer.render(baker.scene, baker.camera);
  const uri = baker.renderer.domElement.toDataURL('image/png');

  baker.scene.remove(mesh);
  geometry.dispose();
  material.dispose();
  map.dispose();
  normalMap.dispose();
  roughnessMap.dispose();
  metalnessMap.dispose();
  aoMap.dispose();

  baker.frameUriCache.set(variant, uri);
  return uri;
}

/**
 * Bakes a 44x256 vertical seamless French-joint spine hinge strip (`lombada + mors`) ONCE.
 * Renders a convex cylindrical leather spine shoulder + deep recessed French hinge crease
 * with horizontal seamless tiling (`repeat-y`), zero distortion at any height.
 */
export function bakePbrSpineStripUri(): string | null {
  const baker = getOrCreateSharedBaker();
  if (!baker) return null;
  if (baker.spineUriCache) return baker.spineUriCache;
  if (!baker.leatherTile) baker.leatherTile = createMoroccoLeatherTile();

  const tile = baker.leatherTile;
  const tileSize = tile.size;
  const outW = 32;
  const outH = 256;
  const n = outW * outH;

  const heights = new Float32Array(n);
  const albedoData = new Uint8Array(n * 4);
  const roughData = new Uint8Array(n * 4);
  const aoData = new Uint8Array(n * 4);

  for (let y = 0; y < outH; y += 1) {
    for (let x = 0; x < outW; x += 1) {
      const idx = y * outW + x;
      const pIdx = idx * 4;
      const tx = (x * 2) % tileSize;
      const ty = (y * 2) % tileSize;
      const tIdx = ty * tileSize + tx;
      const aIdx = tIdx * 3;

      let h = tile.heights[tIdx]!;
      let r = tile.albedo[aIdx]!;
      let g = tile.albedo[aIdx + 1]!;
      let b = tile.albedo[aIdx + 2]!;
      let rough = tile.roughness[tIdx]!;
      let ao = clampByte(192 + h * 63);

      // u in [0..1]: 0..0.44 curved spine shoulder, 0.44..0.72 deep French joint, 0.72..1.0 fades cleanly
      const u = (x + 0.5) / outW;
      let alpha = 1;
      if (u < 0.44) {
        const bump = Math.sin((u / 0.44) * Math.PI);
        h = clamp01(h + bump * 0.28);
        rough = clampByte(rough - bump * 52);
      } else {
        const jointT = (u - 0.58) / 0.14;
        const crease = Math.exp(-jointT * jointT);
        h = clamp01(h - crease * 0.48);
        ao = clampByte(ao * (1 - crease * 0.62));
        if (u > 0.74) {
          alpha = 1 - smoothstep(0.74, 1.0, u);
        }
      }

      // Subtle blind-tooled vertical twin crease accent alongside French joint
      if (Math.abs(u - 0.74) < 0.03) {
        r = clampByte(r + 18);
        g = clampByte(g + 15);
        b = clampByte(b + 10);
      }

      heights[idx] = h;
      albedoData[pIdx] = r;
      albedoData[pIdx + 1] = g;
      albedoData[pIdx + 2] = b;
      albedoData[pIdx + 3] = clampByte(alpha * 255);

      roughData[pIdx] = rough;
      roughData[pIdx + 1] = rough;
      roughData[pIdx + 2] = rough;
      roughData[pIdx + 3] = 255;

      aoData[pIdx] = ao;
      aoData[pIdx + 1] = ao;
      aoData[pIdx + 2] = ao;
      aoData[pIdx + 3] = 255;
    }
  }

  const normalData = buildNormalDataFromHeights(outW, outH, heights, 4.8, true);

  const map = makeDataTexture(albedoData, outW, outH, true, false);
  const normalMap = makeDataTexture(normalData, outW, outH, false, false);
  const roughnessMap = makeDataTexture(roughData, outW, outH, false, false);
  const aoMap = makeDataTexture(aoData, outW, outH, false, false);

  const geometry = new THREE.PlaneGeometry(1, 1, 24, 16);
  const posAttr = geometry.attributes.position as THREE.BufferAttribute;
  const uvAttr = geometry.attributes.uv as THREE.BufferAttribute;
  geometry.setAttribute('uv1', uvAttr);

  for (let i = 0; i < posAttr.count; i += 1) {
    const u = uvAttr.getX(i);
    let spineZ = 0;
    if (u < 0.44) {
      spineZ = 0.022 * Math.sin((u / 0.44) * Math.PI);
    } else {
      const jt = (u - 0.58) / 0.14;
      spineZ = -0.028 * Math.exp(-jt * jt);
    }
    posAttr.setZ(i, spineZ);
  }
  posAttr.needsUpdate = true;
  geometry.computeVertexNormals();

  const material = new THREE.MeshPhysicalMaterial({
    map,
    normalMap,
    normalScale: new THREE.Vector2(2.6, 2.6),
    roughnessMap,
    roughness: 0.72,
    metalness: 0.04,
    aoMap,
    aoMapIntensity: 0.94,
    sheen: 0.58,
    sheenRoughness: 0.42,
    sheenColor: new THREE.Color('#577063'),
    clearcoat: 0.28,
    clearcoatRoughness: 0.28,
    transparent: true,
  });

  const mesh = new THREE.Mesh(geometry, material);
  baker.scene.add(mesh);
  baker.renderer.setPixelRatio(1);
  baker.renderer.setSize(outW, outH, false);
  baker.renderer.setClearColor(0x000000, 0);
  baker.renderer.render(baker.scene, baker.camera);
  const uri = baker.renderer.domElement.toDataURL('image/png');

  baker.scene.remove(mesh);
  geometry.dispose();
  material.dispose();
  map.dispose();
  normalMap.dispose();
  roughnessMap.dispose();
  aoMap.dispose();

  baker.spineUriCache = uri;
  return uri;
}

/**
 * Resolves cached non-distorting Three.js PBR layer URIs (tiled base + 9-slice frame + optional spine)
 * instantaneously after the initial one-time session bake (<45ms total).
 */
export function resolvePbrLayerAssets(
  skin: MaterialSkinId,
  region: MaterialRegion,
): PbrLayerAssets | null {
  if (skin === 'solid-fallback' || region === 'existing-divider') return null;

  const isPaper =
    region === 'recipe-open-paper' ||
    region === 'nutrition-matrix' ||
    region === 'folio-front';
  const tileUri = bakePbrTileUri(isPaper ? 'paper' : 'leather');
  if (!tileUri) return null;

  const hasSpine = region === 'recipe-cover-closed' || region === 'folio-back';
  const frameVariant: PbrFrameVariant | null =
    region === 'menu-shell'
      ? 'leather-stitched'
      : hasSpine
        ? 'leather-spine-stitched'
        : region === 'recipe-open-paper' || region === 'folio-front'
          ? 'paper-folio'
          : region === 'nutrition-matrix'
            ? 'paper-matrix'
            : null;

  const frameUri = frameVariant ? bakePbrFrameAtlasUri(frameVariant) : null;
  const spineUri = hasSpine ? bakePbrSpineStripUri() : null;

  return {
    tileUri,
    tileSizeCss: 256,
    frameUri,
    frameSlicePx: 56,
    frameWidthCss: 28,
    spineUri,
    spineWidthCss: 12,
    spineHeightCss: 128,
  };
}

/** Legacy single-surface bake entry retained for compatibility. */
export function bakePbrSurfaceUri(
  skin: MaterialSkinId,
  region: MaterialRegion,
  requestedWidth: number,
  requestedHeight: number,
  dpr = 1,
): PbrBakeResult | null {
  if (skin === 'solid-fallback') return null;
  const isPaper =
    region === 'recipe-open-paper' ||
    region === 'nutrition-matrix' ||
    region === 'folio-front';
  const uri = bakePbrTileUri(isPaper ? 'paper' : 'leather');
  if (!uri) return null;
  return {
    uri,
    widthPx: Math.max(48, Math.round(requestedWidth * Math.min(2, dpr))),
    heightPx: Math.max(48, Math.round(requestedHeight * Math.min(2, dpr))),
  };
}

export function disposeSharedPbrBaker(): void {
  if (!sharedBaker) return;
  sharedBaker.leatherTile = null;
  sharedBaker.paperTile = null;
  sharedBaker.tileUriCache.clear();
  sharedBaker.frameUriCache.clear();
  sharedBaker.spineUriCache = null;
  sharedBaker.envTarget.dispose();
  sharedBaker.pmremGenerator.dispose();
  sharedBaker.renderer.dispose();
  sharedBaker = null;
}
