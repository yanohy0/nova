import type { CellDisplayStatus } from '../types/cardapios.types.ts';

export function buildRecipeToggleA11yProps(
  recipeTitle: string,
  bodyId: string,
  isExpanded: boolean,
) {
  return {
    'aria-expanded': isExpanded,
    'aria-controls': bodyId,
    'aria-label': isExpanded
      ? `Recolher receita ${recipeTitle}`
      : `Abrir receita ${recipeTitle}`,
  } as const;
}

export function buildMatrixDisclosureA11yProps(
  recipeTitle: string,
  matrixId: string,
  isExpanded: boolean,
) {
  return {
    'aria-expanded': isExpanded,
    'aria-controls': matrixId,
    'aria-label': isExpanded
      ? `Ocultar matriz nutricional TBCA de ${recipeTitle}`
      : `Ver mais informações nutricionais TBCA de ${recipeTitle}`,
  } as const;
}

export function buildPreparationActionA11yProps(
  recipeTitle: string,
  panelId: string,
  isOpen: boolean,
) {
  return {
    'aria-expanded': isOpen,
    'aria-controls': panelId,
    'aria-label': `Receita e Preparo de ${recipeTitle}`,
  } as const;
}

export function buildMatrixCellA11yLabel(
  columnLabel: string,
  unit: string | null,
  formattedText: string,
  status: CellDisplayStatus | undefined,
  statusDescription: string | undefined,
): string | undefined {
  if (statusDescription) {
    return `${columnLabel}: ${statusDescription}`;
  }
  if (!status || status === 'measured') {
    return unit ? `${columnLabel}: ${formattedText} ${unit}` : `${columnLabel}: ${formattedText}`;
  }
  return `${columnLabel}: ${formattedText}`;
}
