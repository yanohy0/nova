import { memo, useCallback, useMemo, useRef, type PointerEvent } from 'react';
import { buildMatrixCellA11yLabel } from '../accessibility/cardapios.accessibility';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosMaterialSkins,
  cardapiosTokens,
  formatMatrixCellDisplay,
} from '../styles/cardapios.tokens';
import type { NutritionGroupId, NutritionMatrixViewModel } from '../types/cardapios.types';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';

interface NutritionMatrixProps {
  matrixId: string;
  recipeTitle: string;
  matrix: NutritionMatrixViewModel;
  surfaceTone?: 'paper' | 'dark';
}

interface ColumnGroupSpan {
  groupId: NutritionGroupId;
  groupLabel: string;
  colSpan: number;
  widthPx: number;
}

const MATRIX_SAFE_INSETS = { top: 6, right: 6, bottom: 6, left: 6 } as const;

export const NutritionMatrix = memo(function NutritionMatrix({
  matrixId,
  recipeTitle,
  matrix,
  surfaceTone = 'paper',
}: NutritionMatrixProps) {
  const matrixRef = useRef<HTMLDivElement | null>(null);
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const dragStateRef = useRef<{ active: boolean; startX: number; scrollLeft: number }>({
    active: false,
    startX: 0,
    scrollLeft: 0,
  });

  const { columns, rows, sourceLabel } = matrix;
  const isPaper = surfaceTone === 'paper';
  const inkPrimary = isPaper ? cardapiosMaterialSkins.maison.paperInk : cardapiosTokens.textPrimary;
  const inkSecondary = isPaper
    ? cardapiosMaterialSkins.maison.paperInkSecondary
    : cardapiosTokens.textSecondary;
  const inkMuted = isPaper ? cardapiosMaterialSkins.maison.paperInkMuted : cardapiosTokens.textMuted;
  const ruleColor = isPaper ? cardapiosMaterialSkins.maison.paperRule : cardapiosTokens.borderSubtle;
  const bodyBg = isPaper
    ? cardapiosMaterials.nutritionMatrix.backgroundColor
    : cardapiosTokens.surfaceRaised;
  const headerBg = isPaper
    ? cardapiosMaterials.nutritionMatrix.headerBackgroundColor
    : cardapiosTokens.surfacePrimary;

  const groupSpans = useMemo<ColumnGroupSpan[]>(() => {
    const spans: ColumnGroupSpan[] = [];
    for (const col of columns) {
      const last = spans[spans.length - 1];
      if (last && last.groupId === col.groupId) {
        last.colSpan += 1;
        last.widthPx += col.widthPx;
      } else {
        spans.push({
          groupId: col.groupId,
          groupLabel: col.groupLabel,
          colSpan: 1,
          widthPx: col.widthPx,
        });
      }
    }
    return spans;
  }, [columns]);

  const totalTableWidth = useMemo(
    () => columns.reduce((sum, col) => sum + col.widthPx, 0),
    [columns],
  );

  const handlePointerDown = useCallback((event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType === 'touch') return;
    const el = scrollerRef.current;
    if (!el || el.scrollWidth <= el.clientWidth) return;
    dragStateRef.current = {
      active: true,
      startX: event.clientX,
      scrollLeft: el.scrollLeft,
    };
  }, []);

  const handlePointerMove = useCallback((event: PointerEvent<HTMLDivElement>) => {
    const state = dragStateRef.current;
    const el = scrollerRef.current;
    if (!state.active || !el) return;
    el.scrollLeft = state.scrollLeft - (event.clientX - state.startX);
  }, []);

  const handlePointerEnd = useCallback(() => {
    dragStateRef.current.active = false;
  }, []);

  return (
    <div
      ref={matrixRef}
      id={matrixId}
      className="relative mt-3 rounded-[10px] border overflow-hidden"
      style={{
        backgroundColor: bodyBg,
        borderColor: ruleColor,
      }}
    >
      <MaterialSurfaceLayer
        containerRef={matrixRef}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        region="nutrition-matrix"
        contentSafeInsets={MATRIX_SAFE_INSETS}
      />
      <div
        ref={scrollerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerEnd}
        onPointerCancel={handlePointerEnd}
        onPointerLeave={handlePointerEnd}
        className="relative z-10 overflow-x-auto titan-no-scrollbar cursor-grab active:cursor-grabbing"
      >
        <table
          className="border-collapse text-left"
          style={{ width: `${totalTableWidth}px`, tableLayout: 'fixed' }}
        >
          <caption className="sr-only">
            Matriz nutricional TBCA de {recipeTitle}
          </caption>
          <colgroup>
            {columns.map((col) => (
              <col key={col.nutrientId} style={{ width: `${col.widthPx}px` }} />
            ))}
          </colgroup>
          <thead>
            <tr
              className="border-b"
              style={{
                backgroundColor: headerBg,
                borderColor: ruleColor,
              }}
            >
              {groupSpans.map((group) => (
                <th
                  key={group.groupId}
                  colSpan={group.colSpan}
                  scope="colgroup"
                  className="px-3 py-2 text-[11px] font-semibold tracking-wide border-r last:border-r-0"
                  style={{
                    color: inkSecondary,
                    borderColor: ruleColor,
                    backgroundColor: headerBg,
                  }}
                >
                  {group.groupLabel}
                </th>
              ))}
            </tr>
            <tr
              className="border-b"
              style={{
                backgroundColor: headerBg,
                borderColor: ruleColor,
              }}
            >
              {columns.map((col, idx) => {
                const isNumeric = idx >= 2;
                return (
                  <th
                    key={col.nutrientId}
                    scope="col"
                    className={`px-3 py-2 text-[11px] font-semibold align-bottom border-r last:border-r-0 ${
                      isNumeric ? 'text-right' : 'text-left'
                    }`}
                    style={{
                      color: inkPrimary,
                      borderColor: ruleColor,
                      backgroundColor: headerBg,
                    }}
                  >
                    <span className="block leading-tight">{col.label}</span>
                    {col.unit && (
                      <span
                        className="block text-[10px] font-normal mt-0.5"
                        style={{ color: inkMuted }}
                      >
                        ({col.unit})
                      </span>
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr
                key={row.ingredientId}
                className="border-b last:border-b-0"
                style={{ borderColor: ruleColor }}
              >
                {columns.map((col, idx) => {
                  if (col.nutrientId === 'food') {
                    return (
                      <th
                        key={col.nutrientId}
                        scope="row"
                        className="px-3 py-2.5 text-[12px] font-semibold text-left align-top border-r"
                        style={{
                          color: inkPrimary,
                          borderColor: ruleColor,
                        }}
                      >
                        {row.foodName}
                      </th>
                    );
                  }
                  if (col.nutrientId === 'quantity') {
                    return (
                      <td
                        key={col.nutrientId}
                        className="px-3 py-2.5 text-[12px] font-mono-metric tabular-nums text-left align-top whitespace-nowrap border-r"
                        style={{
                          color: inkSecondary,
                          borderColor: ruleColor,
                        }}
                      >
                        {row.quantityDisplay}
                      </td>
                    );
                  }

                  const cell = row.cells[col.nutrientId];
                  const formatted = cell
                    ? formatMatrixCellDisplay(cell.value, cell.status, cell.unit)
                    : { text: '—', title: 'Não fornecido pela fonte' };
                  const isUnquantified =
                    !cell || (cell.status !== 'measured' && cell.status !== 'true-zero');
                  const cellA11yLabel = buildMatrixCellA11yLabel(
                    col.label,
                    col.unit,
                    formatted.text,
                    cell?.status,
                    formatted.title,
                  );

                  return (
                    <td
                      key={col.nutrientId}
                      title={formatted.title}
                      aria-label={cellA11yLabel}
                      className={`px-3 py-2.5 text-[12px] font-mono-metric tabular-nums align-top whitespace-nowrap border-r last:border-r-0 ${
                        idx >= 2 ? 'text-right' : 'text-left'
                      }`}
                      style={{
                        color: isUnquantified ? inkMuted : inkPrimary,
                        borderColor: ruleColor,
                      }}
                    >
                      {formatted.text}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div
        className="relative z-10 px-3 py-2 border-t flex flex-wrap items-center justify-between gap-2 text-[11px]"
        style={{
          backgroundColor: headerBg,
          borderColor: ruleColor,
          color: inkMuted,
        }}
      >
        <span>Fonte: {sourceLabel}</span>
        <span>Zero real (0) distinto de Traços, Não analisado e ausência (—)</span>
      </div>
    </div>
  );
});
