import { memo, useState } from 'react';
import { motion } from 'motion/react';
import { buildMatrixDisclosureA11yProps } from '../accessibility/cardapios.accessibility';
import { cardapiosMaterialSkins, cardapiosTokens } from '../styles/cardapios.tokens';

interface MatrixDisclosureProps {
  recipeTitle: string;
  matrixId: string;
  isExpanded: boolean;
  onToggle: () => void;
  surfaceTone?: 'paper' | 'dark';
}

export const MatrixDisclosure = memo(function MatrixDisclosure({
  recipeTitle,
  matrixId,
  isExpanded,
  onToggle,
  surfaceTone = 'paper',
}: MatrixDisclosureProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  const isPaper = surfaceTone === 'paper';
  const showInteractiveSurface = isExpanded || hovered || pressed;
  const a11yProps = buildMatrixDisclosureA11yProps(recipeTitle, matrixId, isExpanded);

  return (
    <motion.button
      type="button"
      onClick={onToggle}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setPressed(false);
      }}
      onPointerDown={() => setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerCancel={() => setPressed(false)}
      animate={{
        backgroundColor: showInteractiveSurface
          ? isPaper
            ? cardapiosMaterialSkins.maison.paperInteractive
            : cardapiosTokens.surfaceInteractive
          : isPaper
            ? 'rgba(222, 214, 198, 0)'
            : 'rgba(41, 55, 58, 0)',
        opacity: pressed ? 0.88 : 1,
      }}
      transition={{ duration: 0.095, ease: [0.33, 1, 0.68, 1] }}
      {...a11yProps}
      className="inline-flex items-center justify-end gap-1.5 min-h-[44px] px-2.5 -mr-2.5 rounded-[8px] text-[13px] font-semibold whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2"
      style={{
        color: isPaper ? cardapiosMaterialSkins.maison.paperActionInk : cardapiosTokens.accentPrimary,
        outlineColor: isPaper ? cardapiosMaterialSkins.maison.paperInk : cardapiosTokens.textPrimary,
      }}
    >
      <span>{isExpanded ? 'Ver menos' : 'Ver mais →'}</span>
    </motion.button>
  );
});
