import { memo, useRef } from 'react';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosTokens,
  formatMacroSummaryValue,
} from '../styles/cardapios.tokens';
import type { MealHistoryRowViewModel } from '../types/cardapios.types';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';

interface MealHistoryProps {
  rows: readonly MealHistoryRowViewModel[];
}

export const MealHistory = memo(function MealHistory({ rows }: MealHistoryProps) {
  const shellRef = useRef<HTMLElement | null>(null);

  return (
    <section
      ref={shellRef}
      aria-labelledby="cardapios-history-heading"
      className="relative overflow-hidden rounded-[18px] border p-4 sm:p-5 space-y-3"
      style={{
        backgroundColor: cardapiosMaterials.cardapioShell.backgroundColor,
        borderColor: cardapiosMaterials.cardapioShell.borderColor,
        boxShadow: cardapiosMaterials.cardapioShell.boxShadow,
      }}
    >
      <MaterialSurfaceLayer
        containerRef={shellRef}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        region="menu-shell"
      />
      <header className="relative z-10 flex items-baseline justify-between gap-3">
        <h2
          id="cardapios-history-heading"
          className="text-[15px] font-semibold tracking-wide uppercase"
          style={{ color: cardapiosTokens.textPrimary }}
        >
          Histórico de Refeições
        </h2>
        <span
          className="text-[12px] font-mono-metric tabular-nums"
          style={{ color: cardapiosTokens.textMuted }}
        >
          {rows.length} {rows.length === 1 ? 'registro' : 'registros'}
        </span>
      </header>

      {rows.length === 0 ? (
        <p className="relative z-10 text-[13px] py-2" style={{ color: cardapiosTokens.textSecondary }}>
          Nenhuma refeição registrada no histórico até o momento.
        </p>
      ) : (
        <div
          className="relative z-10 rounded-[12px] overflow-x-auto titan-no-scrollbar border"
          style={{
            backgroundColor: cardapiosMaterials.recipeSurface.backgroundColor,
            borderColor: cardapiosTokens.borderSubtle,
          }}
        >
          <table className="w-full border-collapse text-left min-w-[600px]">
            <caption className="sr-only">
              Histórico cronológico de refeições registradas e planejadas
            </caption>
            <thead>
              <tr
                className="border-b"
                style={{
                  backgroundColor: cardapiosMaterials.cardapioShell.backgroundColor,
                  borderColor: cardapiosTokens.borderSubtle,
                }}
              >
                <th
                  scope="col"
                  className="px-3.5 py-2.5 text-[11px] font-semibold tracking-wide"
                  style={{ color: cardapiosTokens.textSecondary }}
                >
                  Data / Hora
                </th>
                <th
                  scope="col"
                  className="px-3.5 py-2.5 text-[11px] font-semibold tracking-wide"
                  style={{ color: cardapiosTokens.textSecondary }}
                >
                  Refeição
                </th>
                <th
                  scope="col"
                  className="px-3.5 py-2.5 text-[11px] font-semibold tracking-wide"
                  style={{ color: cardapiosTokens.textSecondary }}
                >
                  Receita
                </th>
                <th
                  scope="col"
                  className="px-3.5 py-2.5 text-[11px] font-semibold tracking-wide text-right"
                  style={{ color: cardapiosTokens.textSecondary }}
                >
                  Porção
                </th>
                <th
                  scope="col"
                  className="px-3.5 py-2.5 text-[11px] font-semibold tracking-wide text-right"
                  style={{ color: cardapiosTokens.textSecondary }}
                >
                  Energia
                </th>
                <th
                  scope="col"
                  className="px-3.5 py-2.5 text-[11px] font-semibold tracking-wide text-right"
                  style={{ color: cardapiosTokens.textSecondary }}
                >
                  Situação
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const statusColor =
                  row.syncStatus === 'confirmed'
                    ? cardapiosTokens.accentPrimary
                    : row.syncStatus === 'pending'
                      ? cardapiosTokens.textSecondary
                      : cardapiosTokens.textMuted;

                return (
                  <tr
                    key={row.mealId}
                    className="border-b last:border-b-0"
                    style={{ borderColor: cardapiosTokens.borderSubtle }}
                  >
                    <td
                      className="px-3.5 py-2.5 text-[12px] font-mono-metric tabular-nums whitespace-nowrap"
                      style={{ color: cardapiosTokens.textSecondary }}
                    >
                      {row.dateLabel} · {row.timeLabel}
                    </td>
                    <td
                      className="px-3.5 py-2.5 text-[13px] font-medium whitespace-nowrap"
                      style={{ color: cardapiosTokens.textPrimary }}
                    >
                      {row.mealLabel}
                    </td>
                    <td
                      className="px-3.5 py-2.5 text-[13px]"
                      style={{ color: cardapiosTokens.textSecondary }}
                    >
                      {row.recipeTitle}
                    </td>
                    <td
                      className="px-3.5 py-2.5 text-[12px] font-mono-metric tabular-nums text-right whitespace-nowrap"
                      style={{ color: cardapiosTokens.textSecondary }}
                    >
                      {row.portionDisplay}
                    </td>
                    <td
                      className="px-3.5 py-2.5 text-[12px] font-mono-metric tabular-nums text-right whitespace-nowrap"
                      style={{ color: cardapiosTokens.textPrimary }}
                    >
                      {formatMacroSummaryValue(
                        row.energyKcal.value,
                        row.energyKcal.status,
                        'kcal',
                      )}
                    </td>
                    <td
                      className="px-3.5 py-2.5 text-[12px] font-medium text-right whitespace-nowrap"
                      style={{ color: statusColor }}
                    >
                      {row.statusLabel}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
});
