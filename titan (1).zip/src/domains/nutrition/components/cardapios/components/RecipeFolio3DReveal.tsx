import { memo, useEffect, useState } from 'react';
import { motion, useMotionValueEvent, useTransform, type MotionValue } from 'motion/react';
import { computeRecipeOrigamiFrame } from '../hooks/useFolioChoreography';
import { useMaterialSurfaceLayers } from '../hooks/useMaterialSurface';
import type { MaterialSkinId } from '../materials/material-surface.types';
import { cardapiosMaterials, cardapiosMaterialSkins } from '../styles/cardapios.tokens';

interface RecipeFolio3DRevealProps {
  progress: MotionValue<number>;
  isCardOpen: boolean;
  skin: MaterialSkinId;
  reduceMotion: boolean;
}

/**
 * Recipe-Card-Level 3D Symmetrical Origami Unfolding Choreography (`0 < progress < 1`):
 * - Uses synchronously cached Three.js PBR seamless tiles & Retina 9-slice frames (zero frame-0 flash,
 *   zero squash/stretch distortion while card height expands)
 * - Stage 1: Lower accordion leaf (`z: 12`) swings forward in +Z & down (`+172 -> 0 deg`) cleanly in front
 * - Stage 2: Twin lateral Morocco leather wings (`z: 6`) swing outward (`±168 -> 0 deg`) from center spine
 */
export const RecipeFolio3DReveal = memo(function RecipeFolio3DReveal({
  progress,
  isCardOpen,
  skin,
  reduceMotion,
}: RecipeFolio3DRevealProps) {
  const [active, setActive] = useState(() => {
    const p = progress.get();
    return p > 0.001 && p < 0.999;
  });

  useEffect(() => {
    if (!reduceMotion) {
      const p = progress.get();
      const target = isCardOpen ? 1 : 0;
      if (Math.abs(p - target) > 0.001) {
        setActive(true);
      }
    }
  }, [isCardOpen, reduceMotion, progress]);

  useMotionValueEvent(progress, 'change', (latest) => {
    const nextActive = latest > 0.001 && latest < 0.999;
    setActive((prev) => (prev === nextActive ? prev : nextActive));
  });

  // Synchronously resolve cached non-distorting PBR tiles & 9-slice frames
  const leatherAssets = useMaterialSurfaceLayers(skin, 'folio-back', !reduceMotion);
  const paperAssets = useMaterialSurfaceLayers(skin, 'folio-front', !reduceMotion);

  const overlayOpacity = useTransform(progress, (p) => computeRecipeOrigamiFrame(p).overlayOpacity);
  const leftWingY = useTransform(progress, (p) => computeRecipeOrigamiFrame(p).leftWingRotateYDeg);
  const rightWingY = useTransform(progress, (p) => computeRecipeOrigamiFrame(p).rightWingRotateYDeg);
  const bottomX = useTransform(progress, (p) => computeRecipeOrigamiFrame(p).bottomRotateXDeg);
  const wingSpecular = useTransform(
    progress,
    (p) => computeRecipeOrigamiFrame(p).wingSpecularOpacity,
  );
  const bottomSpecular = useTransform(
    progress,
    (p) => computeRecipeOrigamiFrame(p).bottomSpecularOpacity,
  );
  const centerShadow = useTransform(
    progress,
    (p) => computeRecipeOrigamiFrame(p).centerShadowOpacity,
  );
  const topHalfShadow = useTransform(
    progress,
    (p) => computeRecipeOrigamiFrame(p).topHalfShadowOpacity,
  );
  const creaseGlow = useTransform(progress, (p) => computeRecipeOrigamiFrame(p).creaseGlowOpacity);

  // Immediately render on the frame `isCardOpen` toggles so there is zero bright-paper frame-0 flash
  const pendingTransition =
    !reduceMotion && Math.abs(progress.get() - (isCardOpen ? 1 : 0)) > 0.001;

  if (reduceMotion || (!active && !pendingTransition)) {
    return null;
  }

  const paperTileStyle = {
    backgroundColor: cardapiosMaterialSkins.maison.paperNatural,
    backgroundImage: paperAssets ? `url(${paperAssets.tileUri})` : undefined,
    backgroundRepeat: 'repeat' as const,
    backgroundSize: paperAssets ? `${paperAssets.tileSizeCss}px ${paperAssets.tileSizeCss}px` : undefined,
  };

  const leatherTileStyle = {
    backgroundColor: cardapiosMaterialSkins.maison.leatherLowlight,
    backgroundImage: leatherAssets ? `url(${leatherAssets.tileUri})` : undefined,
    backgroundRepeat: 'repeat' as const,
    backgroundSize: leatherAssets ? `${leatherAssets.tileSizeCss}px ${leatherAssets.tileSizeCss}px` : undefined,
  };

  const leatherFrameStyle = leatherAssets?.frameUri
    ? {
        boxSizing: 'border-box' as const,
        borderStyle: 'solid' as const,
        borderColor: 'transparent',
        borderWidth: 24,
        borderImageSource: `url(${leatherAssets.frameUri})`,
        borderImageSlice: leatherAssets.frameSlicePx,
        borderImageWidth: '24px',
        borderImageRepeat: 'round' as const,
      }
    : null;

  const leatherEdgeColor = cardapiosMaterials.recipeClosedCover.borderColor;
  const paperEdgeColor = cardapiosMaterialSkins.maison.paperRule;

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none select-none absolute inset-0 z-30 rounded-[14px] overflow-visible"
      style={{
        opacity: overlayOpacity,
        perspective: 1400,
        perspectiveOrigin: '50% 44%',
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Center-top anchor sheet underneath unfolding lateral wings */}
      <div
        className="absolute inset-x-0 top-0 h-1/2 rounded-t-[14px] border-t border-x"
        style={{
          ...paperTileStyle,
          borderColor: paperEdgeColor,
          transform: 'translateZ(0px)',
        }}
      >
        <motion.div
          className="absolute inset-0 rounded-t-[14px]"
          style={{ opacity: centerShadow, backgroundColor: '#090E0D' }}
        />
        <motion.div
          className="absolute inset-0 rounded-t-[14px]"
          style={{ opacity: topHalfShadow, backgroundColor: '#090E0D' }}
        />
      </div>

      {/* Bottom anchor base sheet underneath Stage 1 descending accordion leaf */}
      <div
        className="absolute inset-x-0 top-1/2 h-1/2 rounded-b-[14px] border-b border-x"
        style={{
          ...paperTileStyle,
          borderColor: paperEdgeColor,
          transform: 'translateZ(-0.5px)',
        }}
      >
        <motion.div
          className="absolute inset-0 rounded-b-[14px]"
          style={{ opacity: topHalfShadow, backgroundColor: '#090E0D' }}
        />
      </div>

      {/* Left Lateral Origami Wing (+168 -> 0 deg around center vertical spine, z: 6) */}
      <motion.div
        className="absolute left-0 top-0 w-1/2 h-1/2"
        style={{
          transformOrigin: 'right center',
          transformStyle: 'preserve-3d',
          rotateY: leftWingY,
          z: 6,
        }}
      >
        <div
          className="absolute inset-0 rounded-tl-[14px] border-t border-l overflow-hidden"
          style={{
            ...paperTileStyle,
            borderColor: paperEdgeColor,
            transform: 'translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 10px 26px rgba(0, 0, 0, 0.34)',
          }}
        >
          <motion.div
            className="absolute inset-0 rounded-tl-[14px]"
            style={{ opacity: wingSpecular, backgroundColor: '#FFF5DF' }}
          />
          <motion.div
            className="absolute inset-0 rounded-tl-[14px]"
            style={{ opacity: topHalfShadow, backgroundColor: '#090E0D' }}
          />
        </div>
        <div
          className="absolute inset-0 rounded-tr-[14px] border overflow-hidden"
          style={{
            ...leatherTileStyle,
            borderColor: leatherEdgeColor,
            transform: 'rotateY(180deg) translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 16px 34px rgba(0, 0, 0, 0.5)',
          }}
        >
          {leatherFrameStyle ? <div className="absolute inset-0" style={leatherFrameStyle} /> : null}
          <motion.div
            className="absolute inset-0 rounded-tr-[14px]"
            style={{ opacity: wingSpecular, backgroundColor: '#FFE8BA' }}
          />
        </div>
      </motion.div>

      {/* Right Lateral Origami Wing (-168 -> 0 deg around center vertical spine, z: 6.5) */}
      <motion.div
        className="absolute left-1/2 top-0 w-1/2 h-1/2"
        style={{
          transformOrigin: 'left center',
          transformStyle: 'preserve-3d',
          rotateY: rightWingY,
          z: 6.5,
        }}
      >
        <div
          className="absolute inset-0 rounded-tr-[14px] border-t border-r overflow-hidden"
          style={{
            ...paperTileStyle,
            borderColor: paperEdgeColor,
            transform: 'translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 10px 26px rgba(0, 0, 0, 0.34)',
          }}
        >
          <motion.div
            className="absolute inset-0 rounded-tr-[14px]"
            style={{ opacity: wingSpecular, backgroundColor: '#FFF5DF' }}
          />
          <motion.div
            className="absolute inset-0 rounded-tr-[14px]"
            style={{ opacity: topHalfShadow, backgroundColor: '#090E0D' }}
          />
        </div>
        <div
          className="absolute inset-0 rounded-tl-[14px] border overflow-hidden"
          style={{
            ...leatherTileStyle,
            borderColor: leatherEdgeColor,
            transform: 'rotateY(180deg) translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 16px 34px rgba(0, 0, 0, 0.5)',
          }}
        >
          {leatherFrameStyle ? <div className="absolute inset-0" style={leatherFrameStyle} /> : null}
          <motion.div
            className="absolute inset-0 rounded-tl-[14px]"
            style={{ opacity: wingSpecular, backgroundColor: '#FFE8BA' }}
          />
        </div>
      </motion.div>

      {/* Lower Accordion Origami Leaf (+172 -> 0 deg downward around horizontal mid-crease, z: 12) */}
      <motion.div
        className="absolute inset-x-0 top-1/2 h-1/2"
        style={{
          transformOrigin: 'top center',
          transformStyle: 'preserve-3d',
          rotateX: bottomX,
          z: 12,
        }}
      >
        <div
          className="absolute inset-0 rounded-b-[14px] border-b border-x overflow-hidden"
          style={{
            ...paperTileStyle,
            borderColor: paperEdgeColor,
            transform: 'translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 14px 32px rgba(0, 0, 0, 0.38)',
          }}
        >
          <motion.div
            className="absolute inset-0 rounded-b-[14px]"
            style={{ opacity: bottomSpecular, backgroundColor: '#FFF5DF' }}
          />
        </div>
        <div
          className="absolute inset-0 rounded-t-[14px] border overflow-hidden"
          style={{
            ...leatherTileStyle,
            borderColor: leatherEdgeColor,
            transform: 'rotateX(180deg) translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 18px 40px rgba(0, 0, 0, 0.52)',
          }}
        >
          {leatherFrameStyle ? <div className="absolute inset-0" style={leatherFrameStyle} /> : null}
          <motion.div
            className="absolute inset-0 rounded-t-[14px]"
            style={{ opacity: bottomSpecular, backgroundColor: '#FFE8BA' }}
          />
        </div>
      </motion.div>

      {/* Subtle Champagne Gold Crease Ridge Lines catching light along active fold axes */}
      <motion.div
        className="absolute inset-x-0 top-1/2 h-[1px]"
        style={{
          opacity: creaseGlow,
          backgroundColor: cardapiosMaterialSkins.maison.goldTooling,
          z: 15,
        }}
      />
      <motion.div
        className="absolute inset-y-0 left-1/2 w-[1px]"
        style={{
          opacity: creaseGlow,
          backgroundColor: cardapiosMaterialSkins.maison.goldTooling,
          z: 15,
        }}
      />
    </motion.div>
  );
});
