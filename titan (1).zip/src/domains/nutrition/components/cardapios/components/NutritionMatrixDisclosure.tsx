import { memo } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  TITAN_MOTION_VARIANTS,
  useTitanReducedMotion,
} from '../../../../../shared/motion/titan-motion';
import type { NutritionMatrixViewModel } from '../types/cardapios.types';
import { NutritionMatrix } from './NutritionMatrix';

interface NutritionMatrixDisclosureProps {
  matrixId: string;
  recipeTitle: string;
  matrix: NutritionMatrixViewModel;
  isExpanded: boolean;
  surfaceTone?: 'paper' | 'dark';
}

export const NutritionMatrixDisclosure = memo(function NutritionMatrixDisclosure({
  matrixId,
  recipeTitle,
  matrix,
  isExpanded,
  surfaceTone = 'paper',
}: NutritionMatrixDisclosureProps) {
  const reduceMotion = useTitanReducedMotion();

  return (
    <AnimatePresence initial={false}>
      {isExpanded ? (
        <motion.div
          key="tbca-matrix"
          initial={reduceMotion ? false : TITAN_MOTION_VARIANTS.panel.initial}
          animate={
            reduceMotion
              ? { opacity: 1, height: 'auto', transition: { duration: 0 } }
              : TITAN_MOTION_VARIANTS.panel.animate
          }
          exit={
            reduceMotion
              ? { opacity: 0, height: 0, transition: { duration: 0 } }
              : TITAN_MOTION_VARIANTS.panel.exit
          }
          className="relative overflow-hidden"
        >
          <NutritionMatrix
            matrixId={matrixId}
            recipeTitle={recipeTitle}
            matrix={matrix}
            surfaceTone={surfaceTone}
          />
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
});
