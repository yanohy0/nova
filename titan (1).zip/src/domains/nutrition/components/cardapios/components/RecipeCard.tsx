import { memo, useCallback, useEffect, useId, useRef, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, useMotionValueEvent, useTransform } from 'motion/react';
import {
  TITAN_MOTION_VARIANTS,
  useTitanReducedMotion,
} from '../../../../../shared/motion/titan-motion';
import { buildRecipeToggleA11yProps } from '../accessibility/cardapios.accessibility';
import {
  computeRecipeOrigamiFrame,
  useFolioChoreography,
} from '../hooks/useFolioChoreography';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosTokens,
} from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';
import { IngredientList } from './IngredientList';
import { MacroSummary } from './MacroSummary';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';
import { NutritionMatrixDisclosure } from './NutritionMatrixDisclosure';
import { RecipeFolio3DReveal } from './RecipeFolio3DReveal';
import { RecipeHeader } from './RecipeHeader';
import { RecipePhoto } from './RecipePhoto';
import { RecipePreparationAction } from './RecipePreparationAction';

interface RecipeCardProps {
  recipe: RecipeCardViewModel;
  isCardOpen: boolean;
  isMatrixExpanded: boolean;
  onToggleCard: (recipeId: string, defaultOpen: boolean) => void;
  onToggleMatrix: (recipeId: string, defaultExpanded?: boolean) => void;
}

export const RecipeCard = memo(function RecipeCard({
  recipe,
  isCardOpen,
  isMatrixExpanded,
  onToggleCard,
  onToggleMatrix,
}: RecipeCardProps) {
  const cardRef = useRef<HTMLElement | null>(null);
  const matrixId = useId();
  const bodyId = useId();
  const [closedHovered, setClosedHovered] = useState(false);
  const [closedPressed, setClosedPressed] = useState(false);
  const [showOpenBody, setShowOpenBody] = useState(isCardOpen);

  const reduceMotion = useTitanReducedMotion();
  const { progress } = useFolioChoreography({
    isExpanded: isCardOpen,
    variant: reduceMotion ? 'flat' : 'recipe-book-cover',
    reduceMotion,
  });

  useEffect(() => {
    if (isCardOpen) {
      setShowOpenBody(true);
    } else if (reduceMotion) {
      setShowOpenBody(false);
    }
  }, [isCardOpen, reduceMotion]);

  useMotionValueEvent(progress, 'change', (latest) => {
    if (!isCardOpen && latest <= 0.02) {
      setShowOpenBody(false);
    }
  });

  const contentOpacity = useTransform(progress, (p) =>
    reduceMotion ? 1 : computeRecipeOrigamiFrame(p).contentOpacity,
  );
  const contentScale = useTransform(progress, (p) =>
    reduceMotion ? 1 : computeRecipeOrigamiFrame(p).contentScale,
  );

  const handleToggleCard = useCallback(() => {
    onToggleCard(recipe.recipeId, recipe.isNextToConsume);
  }, [onToggleCard, recipe.recipeId, recipe.isNextToConsume]);

  const handleToggleMatrix = useCallback(() => {
    onToggleMatrix(recipe.recipeId, isCardOpen);
  }, [onToggleMatrix, recipe.recipeId, isCardOpen]);

  const containerBg = showOpenBody
    ? cardapiosMaterials.recipeOpenPaper.backgroundColor
    : closedPressed || closedHovered
      ? cardapiosMaterials.recipeClosedCover.hoverBackgroundColor
      : cardapiosMaterials.recipeClosedCover.backgroundColor;

  const containerBorder = showOpenBody
    ? cardapiosMaterials.recipeOpenPaper.borderColor
    : cardapiosMaterials.recipeClosedCover.borderColor;

  const containerShadow = showOpenBody
    ? cardapiosMaterials.recipeOpenPaper.boxShadow
    : cardapiosMaterials.recipeClosedCover.boxShadow;

  return (
    <motion.article
      ref={cardRef}
      layout="position"
      transition={TITAN_MOTION_VARIANTS.layout.transition}
      className={
        showOpenBody
          ? 'relative overflow-visible rounded-[14px] border p-4 sm:p-5 space-y-3.5'
          : 'relative overflow-visible rounded-[14px] border p-3.5 sm:p-4'
      }
      style={{
        backgroundColor: containerBg,
        borderColor: containerBorder,
        boxShadow: containerShadow,
        perspective: 1350,
      }}
      aria-label={recipe.title}
    >
      <MaterialSurfaceLayer
        key={showOpenBody ? 'open-paper' : 'closed-cover'}
        containerRef={cardRef}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        region={showOpenBody ? 'recipe-open-paper' : 'recipe-cover-closed'}
      />

      {!showOpenBody ? (
        <div className="relative z-10 flex items-center gap-3.5">
          <RecipePhoto image={recipe.image} sizePx={56} />

          <div className="min-w-0 flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-4">
            <h3 className="min-w-0 m-0 text-[14px] sm:text-[15px] font-semibold leading-snug">
              <button
                type="button"
                onClick={handleToggleCard}
                onMouseEnter={() => setClosedHovered(true)}
                onMouseLeave={() => {
                  setClosedHovered(false);
                  setClosedPressed(false);
                }}
                onPointerDown={() => setClosedPressed(true)}
                onPointerUp={() => setClosedPressed(false)}
                onPointerCancel={() => setClosedPressed(false)}
                {...buildRecipeToggleA11yProps(recipe.title, bodyId, false)}
                className="w-full text-left min-h-[44px] -mx-2 px-2 py-1 rounded-[8px] inline-flex items-center justify-between gap-2 focus-visible:outline-2 focus-visible:outline-offset-2"
                style={{
                  color: cardapiosTokens.textPrimary,
                  outlineColor: cardapiosTokens.textPrimary,
                }}
              >
                <span>{recipe.title}</span>
                <ChevronDown
                  className="w-4 h-4 shrink-0 sm:hidden"
                  style={{ color: cardapiosTokens.accentPrimary }}
                  aria-hidden="true"
                />
              </button>
            </h3>

            <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
              <MacroSummary macros={recipe.macros} surfaceTone="dark" />
              <ChevronDown
                className="hidden sm:block w-4 h-4 shrink-0"
                style={{ color: cardapiosTokens.accentPrimary }}
                aria-hidden="true"
              />
            </div>
          </div>
        </div>
      ) : (
        <motion.div
          key="recipe-open-sheet"
          initial={reduceMotion ? false : { height: 72 }}
          animate={{
            height: isCardOpen ? 'auto' : 72,
            transition: reduceMotion
              ? { duration: 0 }
              : {
                  height: {
                    duration: isCardOpen ? 0.64 : 0.44,
                    delay: isCardOpen ? 0.08 : 0.16,
                    ease: [0.32, 0.08, 0.24, 1],
                  },
                },
          }}
          className="relative z-10 overflow-hidden"
        >
          <motion.div
            className="space-y-3.5"
            style={
              reduceMotion
                ? undefined
                : {
                    opacity: contentOpacity,
                    scale: contentScale,
                    transformOrigin: 'center top',
                  }
            }
          >
            <RecipeHeader
              recipe={recipe}
              matrixId={matrixId}
              bodyId={bodyId}
              isCardOpen={isCardOpen}
              onToggleCard={handleToggleCard}
              isMatrixExpanded={isMatrixExpanded}
              onToggleMatrix={handleToggleMatrix}
              surfaceTone="paper"
            />

            <div id={bodyId} className="space-y-3.5">
              <IngredientList ingredients={recipe.ingredients} surfaceTone="paper" />

              <NutritionMatrixDisclosure
                matrixId={matrixId}
                recipeTitle={recipe.title}
                matrix={recipe.nutritionMatrix}
                isExpanded={isMatrixExpanded}
                surfaceTone="paper"
              />

              <RecipePreparationAction
                recipeTitle={recipe.title}
                preparation={recipe.preparation}
                surfaceTone="paper"
              />
            </div>
          </motion.div>
        </motion.div>
      )}

      <RecipeFolio3DReveal
        progress={progress}
        isCardOpen={isCardOpen}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        reduceMotion={reduceMotion}
      />
    </motion.article>
  );
});
