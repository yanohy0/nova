import { memo, useEffect, useRef, useState } from 'react';
import { Utensils } from 'lucide-react';
import { cardapiosTokens } from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';

interface RecipePhotoProps {
  image: RecipeCardViewModel['image'];
  sizePx?: number;
}

export const RecipePhoto = memo(function RecipePhoto({ image, sizePx }: RecipePhotoProps) {
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(true);
  const fromNetworkRef = useRef(false);

  useEffect(() => {
    setHasError(false);
    const el = imgRef.current;
    if (el && el.complete && el.naturalWidth > 0) {
      fromNetworkRef.current = false;
      setIsLoaded(true);
    } else if (typeof window !== 'undefined' && image.uri) {
      fromNetworkRef.current = true;
      setIsLoaded(false);
    } else {
      fromNetworkRef.current = false;
      setIsLoaded(true);
    }
  }, [image.uri]);

  const showPlaceholder = !image.uri || hasError;
  const width = sizePx ?? image.width;
  const height = sizePx ?? image.height;

  return (
    <div
      className="shrink-0 overflow-hidden rounded-[12px] border"
      style={{
        width,
        height,
        backgroundColor: cardapiosTokens.surfacePrimary,
        borderColor: cardapiosTokens.borderSubtle,
      }}
    >
      {showPlaceholder ? (
        <div
          className="w-full h-full flex items-center justify-center"
          role="img"
          aria-label={image.accessibilityLabel}
          style={{
            backgroundColor: cardapiosTokens.surfacePrimary,
            color: cardapiosTokens.textMuted,
          }}
        >
          <Utensils className="w-5 h-5" strokeWidth={1.6} aria-hidden="true" />
        </div>
      ) : (
        <img
          ref={imgRef}
          src={image.uri as string}
          alt={image.accessibilityLabel}
          width={width}
          height={height}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onLoad={() => setIsLoaded(true)}
          onError={() => {
            setIsLoaded(true);
            setHasError(true);
          }}
          className="w-full h-full object-cover block"
          style={{
            opacity: isLoaded ? 1 : 0,
            transition: fromNetworkRef.current
              ? 'opacity 150ms cubic-bezier(0.33, 1, 0.68, 1)'
              : 'none',
          }}
        />
      )}
    </div>
  );
});
