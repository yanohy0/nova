import { memo, useRef } from 'react';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosTokens,
} from '../styles/cardapios.tokens';
import type { MenuGroupViewModel } from '../types/cardapios.types';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';
import { RecipeCard } from './RecipeCard';

interface MenuGroupProps {
  menu: MenuGroupViewModel;
  isCardExpanded: (recipeId: string, defaultExpanded: boolean) => boolean;
  onToggleCard: (recipeId: string, defaultExpanded: boolean) => void;
  isRecipeExpanded: (recipeId: string, defaultExpanded?: boolean) => boolean;
  onToggleMatrix: (recipeId: string, defaultExpanded?: boolean) => void;
}

const MENU_SHELL_SAFE_INSETS = { top: 14, right: 14, bottom: 14, left: 14 } as const;

export const MenuGroup = memo(function MenuGroup({
  menu,
  isCardExpanded,
  onToggleCard,
  isRecipeExpanded,
  onToggleMatrix,
}: MenuGroupProps) {
  const shellRef = useRef<HTMLElement | null>(null);

  return (
    <section
      ref={shellRef}
      aria-label={`${menu.code} — ${menu.title}`}
      className="relative overflow-visible rounded-[18px] border p-4 sm:p-5 space-y-4"
      style={{
        backgroundColor: cardapiosMaterials.cardapioShell.backgroundColor,
        borderColor: cardapiosMaterials.cardapioShell.borderColor,
        boxShadow: cardapiosMaterials.cardapioShell.boxShadow,
      }}
    >
      <MaterialSurfaceLayer
        containerRef={shellRef}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        region="menu-shell"
        contentSafeInsets={MENU_SHELL_SAFE_INSETS}
      />

      <header className="relative z-10 flex flex-wrap items-baseline justify-between gap-2 pb-1">
        <div className="flex flex-wrap items-baseline gap-2.5">
          <h2
            className="text-[15px] font-semibold tracking-wide uppercase"
            style={{ color: cardapiosTokens.accentPrimary }}
          >
            {menu.code}
          </h2>
          <span aria-hidden="true" style={{ color: cardapiosTokens.textMuted }}>
            ·
          </span>
          <p
            className="text-[14px] font-medium"
            style={{ color: cardapiosTokens.textSecondary }}
          >
            {menu.title}
          </p>
        </div>
      </header>

      <div className="relative z-10 space-y-3">
        {menu.recipes.map((recipe) => {
          const cardOpen = isCardExpanded(recipe.recipeId, recipe.isNextToConsume);
          return (
            <RecipeCard
              key={recipe.recipeId}
              recipe={recipe}
              isCardOpen={cardOpen}
              isMatrixExpanded={isRecipeExpanded(recipe.recipeId, cardOpen)}
              onToggleCard={onToggleCard}
              onToggleMatrix={onToggleMatrix}
            />
          );
        })}
      </div>
    </section>
  );
});
