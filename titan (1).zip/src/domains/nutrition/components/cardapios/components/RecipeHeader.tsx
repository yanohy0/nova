import { memo, useState } from 'react';
import { motion } from 'motion/react';
import { buildRecipeToggleA11yProps } from '../accessibility/cardapios.accessibility';
import { cardapiosMaterialSkins, cardapiosTokens } from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';
import { MacroSummary } from './MacroSummary';
import { MatrixDisclosure } from './MatrixDisclosure';
import { RecipePhoto } from './RecipePhoto';

interface RecipeHeaderProps {
  recipe: RecipeCardViewModel;
  matrixId: string;
  bodyId: string;
  isCardOpen: boolean;
  onToggleCard: () => void;
  isMatrixExpanded: boolean;
  onToggleMatrix: () => void;
  surfaceTone?: 'paper' | 'dark';
}

export const RecipeHeader = memo(function RecipeHeader({
  recipe,
  matrixId,
  bodyId,
  isCardOpen,
  onToggleCard,
  isMatrixExpanded,
  onToggleMatrix,
  surfaceTone = 'paper',
}: RecipeHeaderProps) {
  const [titleHovered, setTitleHovered] = useState(false);
  const [titlePressed, setTitlePressed] = useState(false);

  const isPaper = surfaceTone === 'paper';
  const primaryInk = isPaper ? cardapiosMaterialSkins.maison.paperInk : cardapiosTokens.textPrimary;

  return (
    <div className="flex items-start gap-3.5 sm:gap-4">
      {/* Foto antes do título (posição congelada) */}
      <RecipePhoto image={recipe.image} />

      <div className="min-w-0 flex-1 flex flex-col justify-between gap-2">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 sm:gap-4">
          <h3 className="min-w-0 m-0 text-[15px] sm:text-[16px] font-semibold leading-snug">
            <motion.button
              type="button"
              onClick={onToggleCard}
              onMouseEnter={() => setTitleHovered(true)}
              onMouseLeave={() => {
                setTitleHovered(false);
                setTitlePressed(false);
              }}
              onPointerDown={() => setTitlePressed(true)}
              onPointerUp={() => setTitlePressed(false)}
              onPointerCancel={() => setTitlePressed(false)}
              animate={{
                backgroundColor:
                  titlePressed || titleHovered
                    ? isPaper
                      ? cardapiosMaterialSkins.maison.paperInteractive
                      : cardapiosTokens.surfaceInteractive
                    : isPaper
                      ? 'rgba(222, 214, 198, 0)'
                      : 'rgba(41, 55, 58, 0)',
                opacity: titlePressed ? 0.9 : 1,
              }}
              transition={{ duration: 0.095, ease: [0.33, 1, 0.68, 1] }}
              {...buildRecipeToggleA11yProps(recipe.title, bodyId, isCardOpen)}
              className="text-left min-h-[44px] -mx-2 px-2 py-1 rounded-[8px] focus-visible:outline-2 focus-visible:outline-offset-2"
              style={{
                color: primaryInk,
                outlineColor: primaryInk,
              }}
            >
              {recipe.title}
            </motion.button>
          </h3>

          {/* Macros no canto superior direito: Prot. · Gord. · Carb. · kcal */}
          <div className="shrink-0 sm:pt-1">
            <MacroSummary macros={recipe.macros} surfaceTone={surfaceTone} />
          </div>
        </div>

        {/* Ver mais → / Ver menos no canto inferior direito do cabeçalho */}
        <div className="flex items-center justify-end">
          <MatrixDisclosure
            recipeTitle={recipe.title}
            matrixId={matrixId}
            isExpanded={isMatrixExpanded}
            onToggle={onToggleMatrix}
            surfaceTone={surfaceTone}
          />
        </div>
      </div>
    </div>
  );
});
