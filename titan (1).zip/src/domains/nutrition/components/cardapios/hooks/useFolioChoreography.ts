import { useEffect, useRef } from 'react';
import { animate, useMotionValue, type MotionValue } from 'motion/react';
import type { FolioVariant } from '../materials/material-surface.types.ts';

export interface CrossFoldFrame {
  /** Hierarchical Right Wing (carries Q2 + folded Q4) hinged along vertical center spine (-172 -> 0 deg). */
  wingRotateYDeg: number;
  /** Specular highlight opacity [0..1] on the moving Right Wing as it turns past the light. */
  wingHighlightOpacity: number;
  /** Dynamic cast shadow projected onto Q1 underneath the unfolding Right Wing. */
  q1ShadowOpacity: number;
  /** Bottom pair (Q3 + Q4) hinged along horizontal center crease (+172 -> 0 deg). */
  bottomRotateXDeg: number;
  /** Specular highlight opacity [0..1] on the moving Bottom Wings as they swing open. */
  bottomHighlightOpacity: number;
  /** Dynamic crease shadow projected onto top strip (Q1 + Q2) during Phase 2 unfold. */
  topStripShadowOpacity: number;
  /** Center crease specular hairline opacity while unfolding. */
  creaseOpacity: number;
  /** Overall transient folio overlay opacity (0 at rest, 1 mid-fold, dissolves cleanly at end). */
  overlayOpacity: number;
  /** Real semantic NutritionMatrix reveal opacity. */
  tableOpacity: number;
}

export interface BiFoldFrame {
  topOpacity: number;
  bottomRotateXDeg: number;
  bottomHighlightOpacity: number;
  topShadowOpacity: number;
  creaseOpacity: number;
  overlayOpacity: number;
  tableOpacity: number;
}

export interface RecipeBookFrame {
  /** Front Morocco leather cover swing around left sewn spine (0 -> -112 deg). */
  coverRotateYDeg: number;
  coverTiltXDeg: number;
  coverOpacity: number;
  coverSpecularOpacity: number;
  spineShadowOpacity: number;
  pagePitchXDeg: number;
  pageScale: number;
  pageOpacity: number;
  overlayOpacity: number;
}

export interface RecipeOrigamiFrame {
  /** Left lateral wing hinged on center vertical spine (+168 -> 0 deg). */
  leftWingRotateYDeg: number;
  /** Right lateral wing hinged on center vertical spine (-168 -> 0 deg). */
  rightWingRotateYDeg: number;
  /** Lower origami leaf hinged on horizontal mid-crease (+172 -> 0 deg). */
  bottomRotateXDeg: number;
  /** Specular highlight on lateral wings as they catch studio overhead light. */
  wingSpecularOpacity: number;
  /** Specular highlight on lower leaf as it swings open toward viewer. */
  bottomSpecularOpacity: number;
  /** Dynamic fold shadow cast onto the center base during wing unfold. */
  centerShadowOpacity: number;
  /** Dynamic fold shadow cast onto upper half during lower accordion unfold. */
  topHalfShadowOpacity: number;
  /** Gold/champagne ridge line glow along active origami creases. */
  creaseGlowOpacity: number;
  /** Transient 3D origami overlay opacity (0 at rest, 1 mid-fold, dissolves cleanly at settle). */
  overlayOpacity: number;
  /** Real open recipe content opacity & subtle scale settle. */
  contentOpacity: number;
  contentScale: number;
}

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return value < 0 ? 0 : value > 1 ? 1 : value;
}

function smoothWindow(progress: number, start: number, end: number): number {
  if (end <= start) return progress >= end ? 1 : 0;
  const t = clamp01((progress - start) / (end - start));
  return t * t * (3 - 2 * t);
}

export function getFolioDurationSec(variant: FolioVariant, opening: boolean): number {
  if (variant === 'flat') {
    return opening ? 0.24 : 0.2;
  }
  if (variant === 'bi-fold') {
    return opening ? 0.44 : 0.34;
  }
  if (variant === 'recipe-book-cover') {
    return opening ? 0.88 : 0.62;
  }
  return opening ? 0.52 : 0.4;
}

/**
 * Pure deterministic 3D Recipe-Level Symmetrical Origami Folding kinematics (zero-collision order):
 * - Closed (`p = 0`): Lateral Morocco leather wings (`±168 deg`) sit tucked over the top half, and the
 *   lower accordion leaf (`+172 deg`) sits folded cleanly on top over the packet.
 * - Stage 1 (`0.02..0.48`): Lower origami leaf swings forward in +Z and downward (`+172 -> 0 deg`) as
 *   the recipe sheet expands vertically, revealing the closed Morocco leather twin gatefold doors above.
 * - Stage 2 (`0.36..0.88`): Twin lateral Morocco leather wings swing symmetrically outward (`±168 -> 0 deg`)
 *   from the center vertical spine, flipping from Haute Reliure goatskin verso to #EEE9DE cotton rag paper.
 * - Stage 3 (`0.82..1.00`): Origami panels lock at 0 deg and hand off seamlessly to the live recipe sheet.
 */
export function computeRecipeOrigamiFrame(rawProgress: number): RecipeOrigamiFrame {
  const p = clamp01(rawProgress);

  const uBottom = smoothWindow(p, 0.02, 0.48);
  const uWings = smoothWindow(p, 0.36, 0.88);
  const uSettle = smoothWindow(p, 0.82, 1.0);
  const presence = smoothWindow(p, 0.0, 0.015);

  const rawBottomX = 172 * (1 - uBottom);
  const rawLeftY = 168 * (1 - uWings);
  const rawRightY = -168 * (1 - uWings);

  const bottomRotateXDeg = Math.abs(rawBottomX) < 0.2 ? 0 : rawBottomX;
  const leftWingRotateYDeg = Math.abs(rawLeftY) < 0.2 ? 0 : rawLeftY;
  const rightWingRotateYDeg = Math.abs(rawRightY) < 0.2 ? 0 : rawRightY;

  const wingRad = (Math.abs(rightWingRotateYDeg) * Math.PI) / 180;
  const bottomRad = (Math.abs(bottomRotateXDeg) * Math.PI) / 180;

  return {
    leftWingRotateYDeg,
    rightWingRotateYDeg,
    bottomRotateXDeg,
    wingSpecularOpacity: clamp01(Math.sin(wingRad) * 0.42),
    bottomSpecularOpacity: clamp01(Math.sin(bottomRad) * 0.44),
    centerShadowOpacity: clamp01(0.54 * (1 - uWings) * (p > 0.01 ? 1 : 0)),
    topHalfShadowOpacity: clamp01(0.42 * (1 - uBottom) * (p > 0.01 ? 1 : 0)),
    creaseGlowOpacity: clamp01(
      Math.max(Math.sin(uBottom * Math.PI), Math.sin(uWings * Math.PI)) * 0.88 * (1 - uSettle),
    ),
    overlayOpacity: clamp01(presence * (1 - uSettle)),
    contentOpacity: smoothWindow(p, 0.64, 0.96),
    contentScale: 0.975 + 0.025 * smoothWindow(p, 0.48, 0.96),
  };
}

export function computeRecipeBookFrame(rawProgress: number): RecipeBookFrame {
  const p = clamp01(rawProgress);

  const uOpen = smoothWindow(p, 0.02, 0.78);
  const uPage = smoothWindow(p, 0.14, 0.86);
  const uSettle = smoothWindow(p, 0.74, 1.0);
  const presence = smoothWindow(p, 0.0, 0.04);

  const rawAngle = -112 * uOpen;
  const coverRotateYDeg = Math.abs(rawAngle) < 0.15 ? 0 : rawAngle;
  const rad = (Math.abs(coverRotateYDeg) * Math.PI) / 180;

  const coverTiltXDeg = 3.5 * Math.sin(uOpen * Math.PI);
  const coverFade = 1 - smoothWindow(p, 0.54, 0.86);
  const coverOpacity = clamp01(presence * coverFade);
  const coverSpecularOpacity = clamp01(Math.sin(rad) * 0.42 * coverOpacity);

  const spineShadowOpacity = clamp01(Math.sin(uOpen * Math.PI) * 0.55 * (1 - uSettle));
  const pagePitchXDeg = -7.5 * (1 - uPage);
  const pageScale = 0.972 + 0.028 * uPage;
  const pageOpacity = smoothWindow(p, 0.12, 0.58);
  const overlayOpacity = clamp01(presence * (1 - uSettle));

  return {
    coverRotateYDeg,
    coverTiltXDeg,
    coverOpacity,
    coverSpecularOpacity,
    spineShadowOpacity,
    pagePitchXDeg: Math.abs(pagePitchXDeg) < 0.05 ? 0 : pagePitchXDeg,
    pageScale,
    pageOpacity,
    overlayOpacity,
  };
}

/**
 * Pure deterministic Euclidean 2-stage 3D cross-fold kinematics driven by a single
 * clock `progress in [0..1]`:
 * - Closed (`p = 0`): all 4 quadrants sit folded cleanly inside the top-left Q1 packet
 *   (Q4 folded onto Q2, Q2+Q4 folded onto Q1, Q3 folded onto Q1).
 * - Phase 1 (`0.05..0.50`): Right Wing (Q2+Q4) swings forward in +Z from -172 deg -> 0 deg
 *   around the vertical center spine, flipping from dark bound verso to editorial rag recto.
 * - Phase 2 (`0.40..0.88`): Bottom Leaves (Q3 + Q4) swing forward in +Z & downward from
 *   +172 deg -> 0 deg around the horizontal center crease synchronously.
 * - Phase 3 (`0.84..1.00`): Sheet flattens to 0 deg and dissolves onto real semantic table.
 */
export function computeCrossFoldFrame(rawProgress: number): CrossFoldFrame {
  const p = clamp01(rawProgress);

  const u1 = smoothWindow(p, 0.05, 0.5);
  const u2 = smoothWindow(p, 0.4, 0.88);
  const settle = smoothWindow(p, 0.84, 1.0);

  const rawWingY = -172 * (1 - u1);
  const wingRotateYDeg = Math.abs(rawWingY) < 0.2 ? 0 : rawWingY;

  const rawBottomX = 172 * (1 - u2);
  const bottomRotateXDeg = Math.abs(rawBottomX) < 0.2 ? 0 : rawBottomX;

  const wingRad = (Math.abs(wingRotateYDeg) * Math.PI) / 180;
  const bottomRad = (Math.abs(bottomRotateXDeg) * Math.PI) / 180;

  const wingHighlightOpacity = clamp01(Math.sin(wingRad) * 0.26);
  const bottomHighlightOpacity = clamp01(Math.sin(bottomRad) * 0.28);

  const q1ShadowOpacity = clamp01(0.46 * (1 - u1) * (p > 0.01 ? 1 : 0));
  const topStripShadowOpacity = clamp01(0.38 * Math.sin(u2 * Math.PI) * (1 - settle));

  const activeFoldPresence = smoothWindow(p, 0, 0.04);
  const overlayOpacity = clamp01(activeFoldPresence * (1 - settle));
  const tableOpacity = smoothWindow(p, 0.72, 0.96);

  const creaseOpacity = clamp01(
    Math.max(Math.sin(u1 * Math.PI) * 0.75, Math.sin(u2 * Math.PI) * 0.85) * (1 - settle),
  );

  return {
    wingRotateYDeg,
    wingHighlightOpacity,
    q1ShadowOpacity,
    bottomRotateXDeg,
    bottomHighlightOpacity,
    topStripShadowOpacity,
    creaseOpacity,
    overlayOpacity,
    tableOpacity,
  };
}

/**
 * Pure deterministic 3D Bi-Fold kinematics (single horizontal crease, +172 -> 0 deg).
 */
export function computeBiFoldFrame(rawProgress: number): BiFoldFrame {
  const p = clamp01(rawProgress);
  const u = smoothWindow(p, 0.06, 0.84);
  const settle = smoothWindow(p, 0.82, 1.0);

  const rawAngle = 172 * (1 - u);
  const bottomRotateXDeg = Math.abs(rawAngle) < 0.2 ? 0 : rawAngle;
  const rad = (Math.abs(bottomRotateXDeg) * Math.PI) / 180;

  return {
    topOpacity: 1,
    bottomRotateXDeg,
    bottomHighlightOpacity: clamp01(Math.sin(rad) * 0.26),
    topShadowOpacity: clamp01(0.42 * (1 - u) * (p > 0.01 ? 1 : 0)),
    creaseOpacity: clamp01(Math.sin(u * Math.PI) * 0.8 * (1 - settle)),
    overlayOpacity: clamp01(smoothWindow(p, 0, 0.05) * (1 - settle)),
    tableOpacity: smoothWindow(p, 0.7, 0.96),
  };
}

interface UseFolioChoreographyOptions {
  isExpanded: boolean;
  variant: FolioVariant;
  reduceMotion: boolean;
}

export interface UseFolioChoreographyResult {
  progress: MotionValue<number>;
}

/**
 * Single deterministic clock (`progress in [0..1]`) per recipe matrix disclosure:
 * - Reverses smoothly from the current frame on midpoint interruption
 * - Settles immediately when `reduceMotion` is active or page hides to background
 * - Never drives domain state or nutrition calculations
 */
export function useFolioChoreography({
  isExpanded,
  variant,
  reduceMotion,
}: UseFolioChoreographyOptions): UseFolioChoreographyResult {
  const progress = useMotionValue(isExpanded ? 1 : 0);
  const firstMountRef = useRef(true);
  const activeAnimationRef = useRef<ReturnType<typeof animate> | null>(null);

  useEffect(() => {
    const target = isExpanded ? 1 : 0;

    if (firstMountRef.current) {
      firstMountRef.current = false;
      progress.set(target);
      return;
    }

    activeAnimationRef.current?.stop();

    if (reduceMotion) {
      progress.set(target);
      return;
    }

    const duration = getFolioDurationSec(variant, isExpanded);
    const current = progress.get();
    const remainingRatio = Math.max(0.15, Math.abs(target - current));

    activeAnimationRef.current = animate(progress, target, {
      duration: duration * remainingRatio,
      ease:
        variant === 'recipe-book-cover'
          ? 'linear'
          : isExpanded
            ? [0.22, 1, 0.36, 1]
            : [0.4, 0, 0.2, 1],
    });

    return () => {
      activeAnimationRef.current?.stop();
    };
  }, [isExpanded, variant, reduceMotion, progress]);

  useEffect(() => {
    if (typeof document === 'undefined') return undefined;
    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        activeAnimationRef.current?.stop();
        progress.set(isExpanded ? 1 : 0);
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [isExpanded, progress]);

  return { progress };
}
