import { useCallback, useState } from 'react';

export function useRecipeMatrixExpansion() {
  const [expandedByRecipeId, setExpandedByRecipeId] = useState<Record<string, boolean>>({});

  const isRecipeExpanded = useCallback(
    (recipeId: string, defaultExpanded = false): boolean =>
      expandedByRecipeId[recipeId] ?? defaultExpanded,
    [expandedByRecipeId],
  );

  const toggleRecipeMatrix = useCallback((recipeId: string, defaultExpanded = false) => {
    setExpandedByRecipeId((prev) => ({
      ...prev,
      [recipeId]: !(prev[recipeId] ?? defaultExpanded),
    }));
  }, []);

  const pruneRemovedMatrices = useCallback((activeRecipeIds: readonly string[]) => {
    const activeSet = new Set(activeRecipeIds);
    setExpandedByRecipeId((prev) => {
      const keys = Object.keys(prev);
      if (keys.every((key) => activeSet.has(key))) {
        return prev;
      }
      const next: Record<string, boolean> = {};
      for (const key of keys) {
        if (activeSet.has(key)) {
          next[key] = prev[key]!;
        }
      }
      return next;
    });
  }, []);

  return {
    isRecipeExpanded,
    toggleRecipeMatrix,
    pruneRemovedMatrices,
  };
}
