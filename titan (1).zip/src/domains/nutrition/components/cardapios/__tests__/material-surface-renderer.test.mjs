import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {
  buildMatrixCellA11yLabel,
  buildMatrixDisclosureA11yProps,
  buildPreparationActionA11yProps,
  buildRecipeToggleA11yProps,
} from '../accessibility/cardapios.accessibility.ts';
import {
  computeBiFoldFrame,
  computeCrossFoldFrame,
  computeRecipeBookFrame,
  computeRecipeOrigamiFrame,
  getFolioDurationSec,
} from '../hooks/useFolioChoreography.ts';
import {
  buildMaterialCacheKey,
  generateProceduralSurfacePixels,
  MATERIAL_ASSET_VERSION,
  resolveFallbackColor,
  resolveFolioMaterialMetadata,
} from '../materials/material-surface-procedural.ts';
import { MaterialSurfaceRenderer2D } from '../materials/material-surface-renderer.ts';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterialSkins,
  cardapiosTokens,
} from '../styles/cardapios.tokens.ts';
import {
  clearPrefetchedPhotoCache,
  prefetchVisibleRecipePhotos,
} from '../utils/recipe-image-prefetch.ts';

function parseHex(hex) {
  const clean = hex.replace('#', '');
  return {
    r: Number.parseInt(clean.slice(0, 2), 16),
    g: Number.parseInt(clean.slice(2, 4), 16),
    b: Number.parseInt(clean.slice(4, 6), 16),
  };
}

function relativeLuminance(hex) {
  const { r, g, b } = parseHex(hex);
  const linear = [r, g, b].map((c) => {
    const v = c / 255;
    return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2];
}

function contrastRatio(a, b) {
  const l1 = relativeLuminance(a);
  const l2 = relativeLuminance(b);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

// 1. V9/PBR Material Skin Tokens, Version & WCAG Contrast Contracts
assert.equal(ACTIVE_CARDAPIOS_MATERIAL_SKIN, 'maison-a2-bound-menu');
assert.equal(MATERIAL_ASSET_VERSION, 'v9.4.0-maison');
assert.ok(cardapiosMaterialSkins.maison.leatherBase);
assert.ok(cardapiosMaterialSkins.maison.goldTooling);
assert.ok(cardapiosMaterialSkins.grandService.porcelain);
assert.ok(cardapiosMaterialSkins.shikki.roiro);

const folioMeta = resolveFolioMaterialMetadata(ACTIVE_CARDAPIOS_MATERIAL_SKIN);
assert.equal(folioMeta.frontFallbackColor, cardapiosMaterialSkins.maison.paperNatural);
assert.equal(folioMeta.backFallbackColor, cardapiosMaterialSkins.maison.leatherLowlight);
assert.equal(folioMeta.assetVersion, MATERIAL_ASSET_VERSION);

for (const ink of [
  cardapiosMaterialSkins.maison.paperInk,
  cardapiosMaterialSkins.maison.paperInkSecondary,
  cardapiosMaterialSkins.maison.paperInkMuted,
  cardapiosMaterialSkins.maison.paperActionInk,
]) {
  assert.ok(
    contrastRatio(ink, cardapiosMaterialSkins.maison.paperNatural) >= 4.5,
    `Paper ink ${ink} must achieve >= 4.5:1 contrast on #EEE9DE paper`,
  );
}
for (const ink of [
  cardapiosTokens.textPrimary,
  cardapiosTokens.textSecondary,
  cardapiosTokens.accentPrimary,
]) {
  assert.ok(
    contrastRatio(ink, cardapiosMaterialSkins.maison.leatherLowlight) >= 4.5,
    `Leather ink ${ink} must achieve >= 4.5:1 contrast on dark Morocco leather`,
  );
}

// 2. Cache Key Determinism & Quantization Sensitivity
const baseReq = {
  skin: 'maison-a2-bound-menu',
  region: 'menu-shell',
  width: 361,
  height: 243,
  pixelRatio: 2,
  colorScheme: 'dark',
  contentSafeInsets: { top: 14, right: 14, bottom: 14, left: 14 },
};
const quantizedCloseReq = { ...baseReq, width: 359, height: 241 };
assert.equal(
  buildMaterialCacheKey(baseReq),
  buildMaterialCacheKey(quantizedCloseReq),
  'Close dimensions within 8dp quantization should share cache key',
);
assert.notEqual(
  buildMaterialCacheKey(baseReq),
  buildMaterialCacheKey({ ...baseReq, skin: 'grand-service' }),
);
assert.notEqual(
  buildMaterialCacheKey(baseReq),
  buildMaterialCacheKey({ ...baseReq, region: 'nutrition-matrix' }),
);
assert.notEqual(
  buildMaterialCacheKey(baseReq),
  buildMaterialCacheKey({ ...baseReq, pixelRatio: 1 }),
);
assert.notEqual(
  buildMaterialCacheKey(baseReq),
  buildMaterialCacheKey({ ...baseReq, contentSafeInsets: { top: 0, right: 0, bottom: 0, left: 0 } }),
);

// 3. Procedural Pixel Fallback & Content-Safe Exclusion Contract
for (const [region, insets] of [
  ['menu-shell', { top: 14, right: 14, bottom: 14, left: 14 }],
  ['recipe-surface', { top: 12, right: 12, bottom: 12, left: 12 }],
  ['nutrition-matrix', { top: 8, right: 8, bottom: 8, left: 8 }],
]) {
  const width = 320;
  const height = 160;
  const surface = generateProceduralSurfacePixels({
    skin: 'maison-a2-bound-menu',
    region,
    width,
    height,
    pixelRatio: 1,
    colorScheme: 'dark',
    contentSafeInsets: insets,
  });

  assert.equal(surface.widthPx, width);
  assert.equal(surface.heightPx, height);
  assert.equal(surface.data.length, width * height * 4);

  const baseRgb = parseHex(surface.fallbackColor);
  let perimeterModulatedCount = 0;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const idx = (y * width + x) * 4;
      const r = surface.data[idx];
      const g = surface.data[idx + 1];
      const b = surface.data[idx + 2];
      const a = surface.data[idx + 3];
      assert.equal(a, 255);

      const insideSafe =
        x >= insets.left &&
        x <= width - insets.right &&
        y >= insets.top &&
        y <= height - insets.bottom;

      const delta = Math.max(
        Math.abs(r - baseRgb.r),
        Math.abs(g - baseRgb.g),
        Math.abs(b - baseRgb.b),
      );

      if (insideSafe) {
        assert.equal(
          delta,
          0,
          `Pixel (${x}, ${y}) inside ${region} contentSafeInsets must have 0 modulation`,
        );
      } else if (delta > 0) {
        perimeterModulatedCount += 1;
      }
    }
  }

  assert.ok(perimeterModulatedCount > 0, `Outer frame perimeter for ${region} should exhibit subtle finish`);
}

// Verify deterministic output across repeated calls and all V9/PBR skins & folio faces
for (const [skin, region] of [
  ['solid-fallback', 'menu-shell'],
  ['maison-a1-leather-led', 'recipe-surface'],
  ['maison-a2-bound-menu', 'recipe-cover-closed'],
  ['maison-a2-bound-menu', 'recipe-open-paper'],
  ['maison-a2-bound-menu', 'nutrition-matrix'],
  ['maison-a2-bound-menu', 'folio-front'],
  ['maison-a2-bound-menu', 'folio-back'],
  ['grand-service', 'menu-shell'],
  ['shikki-roiro', 'menu-shell'],
]) {
  const req = {
    skin,
    region,
    width: 64,
    height: 48,
    pixelRatio: 1,
    colorScheme: 'dark',
    contentSafeInsets: region.startsWith('folio-')
      ? undefined
      : { top: 8, right: 8, bottom: 8, left: 8 },
  };
  const resA = generateProceduralSurfacePixels(req);
  const resB = generateProceduralSurfacePixels(req);
  assert.deepEqual(resA.data, resB.data, `Procedural generation for ${skin}/${region} must be deterministic`);
  assert.equal(resA.fallbackColor, resolveFallbackColor(skin, region));
}

// 4. Recipe-Level 3D Book Cover Kinematics + Legacy Folio Helpers
assert.equal(getFolioDurationSec('flat', true), 0.24);
assert.equal(getFolioDurationSec('bi-fold', true), 0.44);
assert.equal(getFolioDurationSec('cross-fold-2x2', true), 0.52);
assert.equal(getFolioDurationSec('recipe-book-cover', true), 0.88);
assert.equal(getFolioDurationSec('recipe-book-cover', false), 0.62);

const oriStart = computeRecipeOrigamiFrame(0);
assert.equal(oriStart.leftWingRotateYDeg, 168);
assert.equal(oriStart.rightWingRotateYDeg, -168);
assert.equal(oriStart.bottomRotateXDeg, 172);
assert.equal(oriStart.overlayOpacity, 0);
assert.equal(oriStart.contentOpacity, 0);

const oriStage1Mid = computeRecipeOrigamiFrame(0.24);
assert.ok(oriStage1Mid.overlayOpacity > 0.9, 'Origami overlay active during Stage 1 lower accordion unfold');
assert.ok(
  oriStage1Mid.bottomRotateXDeg > 0 && oriStage1Mid.bottomRotateXDeg < 172,
  'Lower accordion leaf unfolds from +172 to 0 deg first cleanly in front',
);
assert.ok(oriStage1Mid.bottomSpecularOpacity > 0);
assert.ok(oriStage1Mid.creaseGlowOpacity > 0);

const oriStage2Mid = computeRecipeOrigamiFrame(0.62);
assert.equal(oriStage2Mid.bottomRotateXDeg, 0);
assert.ok(
  oriStage2Mid.leftWingRotateYDeg > 0 && oriStage2Mid.leftWingRotateYDeg < 168,
  'Left wing swings symmetrically from +168 to 0 deg in Stage 2',
);
assert.ok(
  oriStage2Mid.rightWingRotateYDeg < 0 && oriStage2Mid.rightWingRotateYDeg > -168,
  'Right wing swings symmetrically from -168 to 0 deg in Stage 2',
);
assert.ok(oriStage2Mid.wingSpecularOpacity > 0);
assert.ok(oriStage2Mid.centerShadowOpacity > 0);

const oriEnd = computeRecipeOrigamiFrame(1);
assert.equal(oriEnd.leftWingRotateYDeg, 0);
assert.equal(oriEnd.rightWingRotateYDeg, 0);
assert.equal(oriEnd.bottomRotateXDeg, 0);
assert.equal(oriEnd.overlayOpacity, 0);
assert.equal(oriEnd.contentOpacity, 1);
assert.equal(oriEnd.contentScale, 1);

const rbStart = computeRecipeBookFrame(0);
assert.equal(rbStart.coverRotateYDeg, 0);
assert.equal(rbStart.overlayOpacity, 0);
assert.equal(rbStart.pageOpacity, 0);

const rbMid = computeRecipeBookFrame(0.36);
assert.ok(rbMid.overlayOpacity > 0.85, '3D cover stage is active mid-opening');
assert.ok(rbMid.coverRotateYDeg < -20 && rbMid.coverRotateYDeg > -112, 'Cover swings open around left spine');
assert.ok(rbMid.coverSpecularOpacity > 0, 'Cover catches warm specular highlight mid-swing');
assert.ok(rbMid.spineShadowOpacity > 0, 'Spine projects cast shadow onto emerging paper page');
assert.ok(rbMid.pageOpacity > 0, 'Paper page reveals underneath');

const rbEnd = computeRecipeBookFrame(1);
assert.equal(rbEnd.coverRotateYDeg, -112);
assert.equal(rbEnd.overlayOpacity, 0);
assert.equal(rbEnd.coverOpacity, 0);
assert.equal(rbEnd.pagePitchXDeg, 0);
assert.equal(rbEnd.pageScale, 1);
assert.equal(rbEnd.pageOpacity, 1);

const cfEnd = computeCrossFoldFrame(1);
assert.equal(cfEnd.overlayOpacity, 0);
assert.equal(cfEnd.tableOpacity, 1);

const bfEnd = computeBiFoldFrame(1);
assert.equal(bfEnd.overlayOpacity, 0);
assert.equal(bfEnd.tableOpacity, 1);

// 5. MaterialSurfaceRenderer2D Headless Lifecycle & LRU Release/Cleanup
const renderer = new MaterialSurfaceRenderer2D();
await renderer.initialize();

const h1 = await renderer.renderStatic(baseReq);
assert.equal(h1.isFallback, true, 'Headless Node without DOM Canvas must return solid fallback');
assert.equal(h1.fallbackColor, cardapiosMaterialSkins.maison.leatherBase);
assert.equal(renderer.getCacheSize(), 1);

const h2 = await renderer.renderStatic(quantizedCloseReq);
assert.equal(h2.cacheKey, h1.cacheKey);
assert.equal(renderer.getCacheSize(), 1);

renderer.release(h1);
renderer.clearUnusedCache();
assert.equal(renderer.getCacheSize(), 1, 'Still referenced by h2 so cache entry remains');

renderer.release(h2);
renderer.clearUnusedCache();
assert.equal(renderer.getCacheSize(), 0, 'Releasing all handles frees unused cache entries');

await renderer.dispose();
const hAfterDispose = await renderer.renderStatic({ ...baseReq, skin: 'solid-fallback' });
assert.equal(hAfterDispose.isFallback, true);
await renderer.dispose();
assert.equal(renderer.getCacheSize(), 0);

// 6. Accessibility Builders
const toggleClosed = buildRecipeToggleA11yProps('Café completo', 'body-1', false);
assert.equal(toggleClosed['aria-expanded'], false);
assert.equal(toggleClosed['aria-controls'], 'body-1');
assert.match(toggleClosed['aria-label'], /Abrir receita Café completo/);

const matrixOpen = buildMatrixDisclosureA11yProps('Café completo', 'matrix-1', true);
assert.equal(matrixOpen['aria-expanded'], true);
assert.equal(matrixOpen['aria-controls'], 'matrix-1');
assert.match(matrixOpen['aria-label'], /Ocultar matriz nutricional TBCA/);

const prepProps = buildPreparationActionA11yProps('Café completo', 'prep-1', false);
assert.equal(prepProps['aria-expanded'], false);
assert.equal(prepProps['aria-controls'], 'prep-1');
assert.equal(prepProps['aria-label'], 'Receita e Preparo de Café completo');

assert.equal(
  buildMatrixCellA11yLabel('Proteína', 'g', '24,5', 'measured', undefined),
  'Proteína: 24,5 g',
);
assert.equal(
  buildMatrixCellA11yLabel('Vitamina C', 'mg', '—', 'not-in-source', 'Não fornecido pela fonte'),
  'Vitamina C: Não fornecido pela fonte',
);

// 7. Image Prefetch Safety in SSR/Headless Mode
prefetchVisibleRecipePhotos(['https://example.com/a.jpg', null, undefined, '']);
clearPrefetchedPhotoCache();

// 8. Cardápios Clean Material Guard (no CSS blur/gradients, single-context PBR only)
async function collectCardapiosSourceFiles(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === '__tests__') continue;
      files.push(...(await collectCardapiosSourceFiles(full)));
    } else if (/\.(ts|tsx)$/.test(entry.name)) {
      files.push(full);
    }
  }
  return files;
}

const cardapiosFiles = await collectCardapiosSourceFiles(
  path.resolve('src/domains/nutrition/components/cardapios'),
);
assert.ok(cardapiosFiles.length >= 16);

const forbiddenPatterns = [
  /from\s+['"]@react-three\//,
  /filament/i,
  /webgpu/i,
  /react-native-reanimated/,
  /lottie/i,
  /backdrop-blur/,
  /linear-gradient/,
  /radial-gradient/,
  /repeating-linear-gradient/,
];

for (const file of cardapiosFiles) {
  const content = await fs.readFile(file, 'utf8');
  for (const pattern of forbiddenPatterns) {
    assert.ok(
      !pattern.test(content),
      `Forbidden pattern ${pattern} found in Cardápios file: ${file}`,
    );
  }
}

console.log('PBR Material Baker, Recipe-Level 3D Book Reveal, WCAG Contrast & Guard tests passed.');
