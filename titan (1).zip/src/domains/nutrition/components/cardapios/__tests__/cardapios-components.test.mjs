import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import esbuild from 'esbuild';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { buildInitialComposerPlans } from '../../../domain/rules/cardapio-composer-engine.ts';
import { buildMealFromCardapioSlot } from '../../../domain/rules/recipe-engine.ts';
import { ensureTbcaCatalogLoaded } from '../../../data/sources/tbca-adapter.ts';
import { buildCardapiosViewModel } from '../view-models/cardapios.mapper.ts';

await ensureTbcaCatalogLoaded();

const tmpRoot = path.resolve('node_modules');
await fs.mkdir(tmpRoot, { recursive: true });
const tmpDir = await fs.mkdtemp(path.join(tmpRoot, '.tmp-cardapios-test-'));
const bundlePath = path.join(tmpDir, 'cardapios-bundle.mjs');

try {
  await esbuild.build({
    entryPoints: [
      path.resolve('src/domains/nutrition/components/cardapios/components/CardapiosContent.tsx'),
      path.resolve('src/domains/nutrition/components/cardapios/components/RecipeCard.tsx'),
    ],
    outdir: tmpDir,
    bundle: true,
    format: 'esm',
    platform: 'node',
    jsx: 'automatic',
    external: [
      'react',
      'react-dom',
      'lucide-react',
      'three',
      'three/addons/environments/RoomEnvironment.js',
    ],
    outExtension: { '.js': '.mjs' },
  });

  const { CardapiosContent } = await import(
    pathToFileURL(path.join(tmpDir, 'CardapiosContent.mjs')).href
  );
  const { RecipeCard } = await import(
    pathToFileURL(path.join(tmpDir, 'RecipeCard.mjs')).href
  );

  const dateKey = '2026-11-26';
  const meals = [
    buildMealFromCardapioSlot({
      id: 'meal-1',
      dateKey,
      time: '07:30',
      title: 'Café da manhã',
      recipeId: 'rec-cafe-completo',
      status: 'planned',
    }),
    buildMealFromCardapioSlot({
      id: 'meal-2',
      dateKey,
      time: '12:30',
      title: 'Almoço',
      recipeId: 'rec-almoco-frango',
      status: 'consumed',
    }),
    buildMealFromCardapioSlot({
      id: 'meal-3',
      dateKey,
      time: '16:00',
      title: 'Lanche da tarde',
      recipeId: 'rec-lanche-iogurte',
      status: 'consumed',
    }),
    buildMealFromCardapioSlot({
      id: 'meal-4',
      dateKey,
      time: '20:30',
      title: 'Jantar',
      recipeId: 'rec-jantar-salmao',
      status: 'planned',
    }),
  ];

  const plans = buildInitialComposerPlans(
    dateKey,
    { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
    meals,
  );
  const vm = buildCardapiosViewModel(plans, dateKey, meals);

  // 1. Render full CardapiosContent in initial state
  const fullHtml = renderToStaticMarkup(React.createElement(CardapiosContent, { viewModel: vm }));

  // Frozen hierarchy order: CARDÁPIOS -> Cardápio A -> Cardápio B -> Histórico de Refeições
  const idxTitle = fullHtml.indexOf('>Cardápios</h1>');
  const idxMenuA = fullHtml.indexOf('>Cardápio A</h2>');
  const idxMenuB = fullHtml.indexOf('>Cardápio B</h2>');
  const idxHistory = fullHtml.indexOf('>Histórico de Refeições</h2>');
  assert.ok(idxTitle !== -1 && idxMenuA > idxTitle);
  assert.ok(idxMenuB > idxMenuA);
  assert.ok(idxHistory > idxMenuB, 'Histórico must appear below all cardápios');

  // 1 open recipe card + its default-open TBCA matrix ("Ver menos") = 2 expanded; 7 closed recipes + 1 collapsed prep = 8
  const expandedTrueCount = (fullHtml.match(/aria-expanded="true"/g) || []).length;
  const expandedFalseCount = (fullHtml.match(/aria-expanded="false"/g) || []).length;
  assert.equal(expandedTrueCount, 2, 'Next recipe card and its TBCA matrix both start open by default');
  assert.equal(expandedFalseCount, 8);

  // Ingredients and TBCA matrix are both visible by default inside the open recipe card, with zero visible scrollbar
  assert.equal((fullHtml.match(/aria-label="Ingredientes da receita"/g) || []).length, 1);
  assert.equal((fullHtml.match(/Ver menos/g) || []).length, 1);
  assert.equal((fullHtml.match(/Matriz nutricional TBCA de/g) || []).length, 1);
  assert.ok(fullHtml.includes('titan-no-scrollbar'), 'Tables must hide browser scrollbars cleanly');
  assert.equal((fullHtml.match(/>Receita e Preparo<\/button>/g) || []).length, 1);

  // No non-token hex colors, backdrop-blur, gradients, or bitmap textures
  assert.ok(!fullHtml.includes('#8FB5A9'));
  assert.ok(!fullHtml.includes('#9BBFB3'));
  assert.ok(!fullHtml.includes('backdrop-blur'));
  assert.ok(!fullHtml.includes('linear-gradient'));
  assert.ok(!fullHtml.includes('radial-gradient'));
  assert.ok(!fullHtml.includes('repeating-linear-gradient'));
  assert.ok(!fullHtml.includes('blur('));

  // 2. Render open RecipeCard with collapsed vs expanded matrix independently
  const sampleRecipe = vm.menus[0].recipes[2]; // Iogurte proteico (has photo & OFF+TBCA status)
  assert.ok(sampleRecipe);

  const openCollapsedMatrixHtml = renderToStaticMarkup(
    React.createElement(RecipeCard, {
      recipe: sampleRecipe,
      isCardOpen: true,
      isMatrixExpanded: false,
      onToggleCard: () => {},
      onToggleMatrix: () => {},
    }),
  );

  // Photo appears before Title; Macros order is Prot. -> Gord. -> Carb. -> kcal
  const idxPhoto = openCollapsedMatrixHtml.indexOf('<img ');
  const idxRecipeHeading = openCollapsedMatrixHtml.indexOf(`>${sampleRecipe.title}</button>`);
  assert.ok(idxPhoto !== -1 && idxRecipeHeading > idxPhoto, 'Photo must come before title');

  const idxProt = openCollapsedMatrixHtml.indexOf('>Prot.</dt>');
  const idxGord = openCollapsedMatrixHtml.indexOf('>Gord.</dt>');
  const idxCarb = openCollapsedMatrixHtml.indexOf('>Carb.</dt>');
  const idxKcal = openCollapsedMatrixHtml.indexOf(' kcal</dd>');
  assert.ok(idxProt !== -1 && idxGord > idxProt && idxCarb > idxGord && idxKcal > idxCarb);

  const idxIngredients = openCollapsedMatrixHtml.indexOf('aria-label="Ingredientes da receita"');
  const idxPrep = openCollapsedMatrixHtml.indexOf('Receita e Preparo');
  assert.ok(idxIngredients > idxRecipeHeading);
  assert.ok(idxPrep > idxIngredients);
  assert.ok(!openCollapsedMatrixHtml.includes('<table'));

  // Expanded matrix mounts table with exact 6 first columns, no kJ, and explicit TBCA statuses
  const openExpandedMatrixHtml = renderToStaticMarkup(
    React.createElement(RecipeCard, {
      recipe: sampleRecipe,
      isCardOpen: true,
      isMatrixExpanded: true,
      onToggleCard: () => {},
      onToggleMatrix: () => {},
    }),
  );
  assert.ok(openExpandedMatrixHtml.includes('<table'));
  assert.ok(openExpandedMatrixHtml.includes('Ver menos'));
  assert.ok(!openExpandedMatrixHtml.includes('>kJ<'));
  assert.ok(openExpandedMatrixHtml.includes('Não fornecido pela fonte'));

  // 3. Recipe without image URI renders solid placeholder in exact frame without crashing
  const noUriRecipe = vm.menus[0].recipes[0];
  assert.equal(noUriRecipe.image.uri, null);
  const noUriHtml = renderToStaticMarkup(
    React.createElement(RecipeCard, {
      recipe: noUriRecipe,
      isCardOpen: true,
      isMatrixExpanded: false,
      onToggleCard: () => {},
      onToggleMatrix: () => {},
    }),
  );
  assert.ok(noUriHtml.includes('role="img"'));
  assert.ok(noUriHtml.includes(`width:88px;height:88px`));

  void bundlePath;
  console.log('Cardápios component render and contract tests passed.');
} finally {
  await fs.rm(tmpDir, { recursive: true, force: true });
}
