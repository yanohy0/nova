import {
  MICRONUTRIENT_ORDER,
  type CardapioPlan,
  type FoodSourceItem,
  type IngredientAdjustment,
  type MealItem,
  type NutrientId,
  type RecipeInstance,
} from '../../../domain/entities/nutrient.ts';
import { MICRONUTRIENT_PT_LABELS } from '../../../domain/rules/cardapio-composer-engine.ts';
import { validateFoodMacroComposition } from '../../../domain/rules/food-data-quality.ts';
import {
  computePortionsMacrosWithQuality,
  normalizeNutrientEntry,
  resolveFoodById,
} from '../../../domain/rules/nutrition-calculator.ts';
import { formatNutrientNumberPtBr } from '../styles/cardapios.tokens.ts';
import type {
  CardapiosViewModel,
  CellDisplayStatus,
  IngredientRowViewModel,
  MealHistoryRowViewModel,
  MenuGroupViewModel,
  NutritionGroupId,
  NutritionMatrixCell,
  NutritionMatrixColumn,
  NutritionMatrixRow,
  NutritionMatrixViewModel,
  RecipeCardViewModel,
  RecipeConsumptionStatus,
  RecipeMacroSummary,
} from '../types/cardapios.types.ts';

const MENU_CODES = ['A', 'B', 'C', 'D', 'E', 'F'] as const;

const VITAMIN_IDS: readonly NutrientId[] = [
  'vitamin_a',
  'vitamin_c',
  'vitamin_d',
  'vitamin_e',
  'vitamin_k',
  'vitamin_b1',
  'vitamin_b2',
  'vitamin_b3',
  'vitamin_b5',
  'vitamin_b6',
  'vitamin_b7',
  'vitamin_b9',
  'vitamin_b12',
];

const MINERAL_IDS: readonly NutrientId[] = [
  'calcium',
  'copper',
  'iron',
  'phosphorus',
  'magnesium',
  'manganese',
  'potassium',
  'selenium',
  'sodium',
  'zinc',
  'choline',
  'iodine',
  'chloride',
  'molybdenum',
  'chromium',
  'fluoride',
];

const GROUP_LABELS: Record<NutritionGroupId, string> = {
  base: 'Composição',
  'energy-macros': 'Energia e Macronutrientes',
  centesimal: 'Composição centesimal',
  'detailed-carbs': 'Carboidratos detalhados',
  'amino-acids': 'Aminoácidos',
  lipids: 'Lipídios',
  sterols: 'Esteróis',
  vitamins: 'Vitaminas',
  minerals: 'Minerais',
  carotenoids: 'Carotenoides',
  flavonoids: 'Flavonoides e bioativos',
  'functional-indices': 'Índices funcionais',
  'added-components': 'Componentes adicionados',
  other: 'Outros',
};

function normalizeImageUri(uri: string | undefined | null): string | null {
  if (typeof uri !== 'string') return null;
  const trimmed = uri.trim();
  return trimmed.length > 0 ? trimmed : null;
}

function formatIngredientQuantity(ing: IngredientAdjustment): IngredientRowViewModel['quantity'] {
  if (ing.quantityStatus === 'to_taste') {
    return {
      value: null,
      unit: null,
      display: 'a gosto',
    };
  }
  if (
    ing.quantityStatus === 'missing' ||
    ing.currentQuantityG === null ||
    !Number.isFinite(ing.currentQuantityG)
  ) {
    return {
      value: null,
      unit: null,
      display: 'Quantidade não informada',
    };
  }
  return {
    value: ing.currentQuantityG,
    unit: 'g',
    display: `${formatNutrientNumberPtBr(ing.currentQuantityG, 'g')} g`,
  };
}

function mapIngredient(ing: IngredientAdjustment): {
  viewModel: IngredientRowViewModel;
  food: FoodSourceItem | null;
} {
  const food = resolveFoodById(ing.foodId);
  const status: IngredientRowViewModel['status'] = !food
    ? 'unresolved'
    : ing.quantityStatus === 'missing'
      ? 'pending'
      : food.source_id === 'TITAN_LEGACY'
        ? 'manual'
        : 'resolved';

  return {
    food,
    viewModel: {
      ingredientId: ing.id,
      foodDisplayName: food?.name ?? ing.displayName ?? ing.foodId,
      quantity: formatIngredientQuantity(ing),
      tbcaFoodCode: food?.source_id === 'TBCA' ? food.source_record_id : null,
      sourceLabel: food ? food.source_version : null,
      status,
    },
  };
}

function computeRecipeMacroSummary(ingredients: readonly IngredientAdjustment[]): RecipeMacroSummary {
  const knownPortions = ingredients
    .filter(
      (ing) =>
        ing.quantityStatus === 'known' &&
        ing.currentQuantityG !== null &&
        Number.isFinite(ing.currentQuantityG) &&
        ing.currentQuantityG > 0,
    )
    .map((ing) => ({
      foodId: ing.foodId,
      quantityG: ing.currentQuantityG as number,
    }));

  const hasMissingQuantities = ingredients.some((ing) => ing.quantityStatus === 'missing');

  if (knownPortions.length === 0) {
    return {
      protein: { value: null, unit: 'g', status: 'not-in-source' },
      fat: { value: null, unit: 'g', status: 'not-in-source' },
      carbohydrate: { value: null, unit: 'g', status: 'not-in-source' },
      energyKcal: { value: null, unit: 'kcal', status: 'not-in-source' },
      isPartial: true,
    };
  }

  const quality = computePortionsMacrosWithQuality(knownPortions);
  const allUnresolved = quality.quantifiedGrams === 0;
  const isPartial =
    hasMissingQuantities ||
    quality.unresolvedFoodIds.length > 0 ||
    quality.lowConfidenceFoodIds.length > 0;

  if (allUnresolved) {
    return {
      protein: { value: null, unit: 'g', status: 'not-in-source' },
      fat: { value: null, unit: 'g', status: 'not-in-source' },
      carbohydrate: { value: null, unit: 'g', status: 'not-in-source' },
      energyKcal: { value: null, unit: 'kcal', status: 'not-in-source' },
      isPartial: true,
    };
  }

  const makeMacroValue = (val: number, unit: 'g' | 'kcal'): RecipeMacroSummary['protein'] => ({
    value: val,
    unit,
    status: val === 0 ? 'true-zero' : 'measured',
  });

  return {
    protein: makeMacroValue(quality.macros.proteinG, 'g'),
    fat: makeMacroValue(quality.macros.fatG, 'g'),
    carbohydrate: makeMacroValue(quality.macros.carbsG, 'g'),
    energyKcal: makeMacroValue(quality.macros.kcal, 'kcal'),
    isPartial,
  };
}

function mapScalarFieldCell(
  nutrientId: string,
  unit: string,
  rawPerBasis: number | null | undefined,
  basisQuantityG: number,
  quantityG: number | null,
  quantityStatus: IngredientAdjustment['quantityStatus'],
  sourceCode: string | null,
): NutritionMatrixCell {
  if (quantityStatus !== 'known' || quantityG === null || !Number.isFinite(quantityG)) {
    return {
      nutrientId,
      value: null,
      unit,
      status: 'not-applicable',
      sourceCode,
    };
  }
  if (rawPerBasis === null || rawPerBasis === undefined || !Number.isFinite(rawPerBasis)) {
    return {
      nutrientId,
      value: null,
      unit,
      status: 'not-in-source',
      sourceCode,
    };
  }
  if (rawPerBasis === 0) {
    return {
      nutrientId,
      value: 0,
      unit,
      status: 'true-zero',
      sourceCode,
    };
  }
  const scaled = (rawPerBasis / basisQuantityG) * quantityG;
  return {
    nutrientId,
    value: scaled,
    unit,
    status: 'measured',
    sourceCode,
  };
}

function mapMicronutrientCell(
  food: FoodSourceItem,
  nutrientId: NutrientId,
  quantityG: number | null,
  quantityStatus: IngredientAdjustment['quantityStatus'],
): NutritionMatrixCell {
  const record = normalizeNutrientEntry(food, nutrientId);
  const unit = record.normalized_unit || MICRONUTRIENT_PT_LABELS[nutrientId].unit;

  if (quantityStatus !== 'known' || quantityG === null || !Number.isFinite(quantityG)) {
    return {
      nutrientId,
      value: null,
      unit,
      status: 'not-applicable',
      sourceCode: food.source_record_id,
    };
  }

  let status: CellDisplayStatus;
  let value: number | null = null;

  switch (record.data_status) {
    case 'quantified':
      if (record.normalized_value === 0) {
        status = 'true-zero';
        value = 0;
      } else if (
        record.normalized_value !== null &&
        Number.isFinite(record.normalized_value) &&
        Number.isFinite(record.basis_quantity) &&
        record.basis_quantity > 0
      ) {
        status = 'measured';
        value = (record.normalized_value / record.basis_quantity) * quantityG;
      } else {
        status = 'not-in-source';
      }
      break;
    case 'trace':
      status = 'trace';
      break;
    case 'not_analyzed':
      status = 'not-analyzed';
      break;
    case 'unit_mismatch':
    case 'invalid_value':
      status = 'withheld';
      break;
    case 'missing':
    default:
      status = 'not-in-source';
      break;
  }

  return {
    nutrientId,
    value,
    unit,
    status,
    sourceCode: food.source_record_id,
  };
}

function buildNutritionMatrix(
  mappedIngredients: ReadonlyArray<{
    raw: IngredientAdjustment;
    viewModel: IngredientRowViewModel;
    food: FoodSourceItem | null;
  }>,
): NutritionMatrixViewModel {
  const resolvedFoods = mappedIngredients
    .map((item) => item.food)
    .filter((f): f is FoodSourceItem => f !== null);

  // Columns 1–6: strictly invariant order per Section 8.2 (no kJ!)
  const columns: NutritionMatrixColumn[] = [
    {
      nutrientId: 'food',
      label: 'Alimento',
      unit: null,
      groupId: 'base',
      groupLabel: GROUP_LABELS.base,
      order: 1,
      fixed: true,
      widthPx: 220,
    },
    {
      nutrientId: 'quantity',
      label: 'Quantidade',
      unit: 'g',
      groupId: 'base',
      groupLabel: GROUP_LABELS.base,
      order: 2,
      fixed: true,
      widthPx: 96,
    },
    {
      nutrientId: 'kcal',
      label: 'kcal',
      unit: 'kcal',
      groupId: 'energy-macros',
      groupLabel: GROUP_LABELS['energy-macros'],
      order: 3,
      fixed: false,
      widthPx: 84,
    },
    {
      nutrientId: 'protein',
      label: 'Proteínas',
      unit: 'g',
      groupId: 'energy-macros',
      groupLabel: GROUP_LABELS['energy-macros'],
      order: 4,
      fixed: false,
      widthPx: 94,
    },
    {
      nutrientId: 'carbs',
      label: 'Carboidratos',
      unit: 'g',
      groupId: 'energy-macros',
      groupLabel: GROUP_LABELS['energy-macros'],
      order: 5,
      fixed: false,
      widthPx: 108,
    },
    {
      nutrientId: 'fat',
      label: 'Gorduras',
      unit: 'g',
      groupId: 'energy-macros',
      groupLabel: GROUP_LABELS['energy-macros'],
      order: 6,
      fixed: false,
      widthPx: 92,
    },
  ];

  let orderCounter = 7;

  // Group 2: Detailed carbs (only if returned by at least one food in the recipe)
  const hasFiber = resolvedFoods.some(
    (f) => f.macros.fiberGPerBasis !== null && f.macros.fiberGPerBasis !== undefined,
  );
  if (hasFiber) {
    columns.push({
      nutrientId: 'fiber',
      label: 'Fibras',
      unit: 'g',
      groupId: 'detailed-carbs',
      groupLabel: GROUP_LABELS['detailed-carbs'],
      order: orderCounter++,
      fixed: false,
      widthPx: 84,
    });
  }

  // Group 4: Lipids
  const hasSatFat = resolvedFoods.some(
    (f) =>
      f.macros.saturatedFatGPerBasis !== null && f.macros.saturatedFatGPerBasis !== undefined,
  );
  if (hasSatFat) {
    columns.push({
      nutrientId: 'saturated_fat',
      label: 'Gord. saturadas',
      unit: 'g',
      groupId: 'lipids',
      groupLabel: GROUP_LABELS.lipids,
      order: orderCounter++,
      fixed: false,
      widthPx: 116,
    });
  }

  // Group 5: Sterols
  const hasCholesterol = resolvedFoods.some(
    (f) =>
      f.macros.cholesterolMgPerBasis !== null && f.macros.cholesterolMgPerBasis !== undefined,
  );
  if (hasCholesterol) {
    columns.push({
      nutrientId: 'cholesterol',
      label: 'Colesterol',
      unit: 'mg',
      groupId: 'sterols',
      groupLabel: GROUP_LABELS.sterols,
      order: orderCounter++,
      fixed: false,
      widthPx: 96,
    });
  }

  // Group 6: Vitamins (only nutrients present in at least one source food)
  for (const vitId of VITAMIN_IDS) {
    if (!MICRONUTRIENT_ORDER.includes(vitId)) continue;
    const isPresentInAnyFood = resolvedFoods.some((f) => f.micronutrients[vitId] !== undefined);
    if (!isPresentInAnyFood) continue;
    const sampleUnit =
      resolvedFoods.find((f) => f.micronutrients[vitId]?.normalized_unit)?.micronutrients[vitId]
        ?.normalized_unit ?? MICRONUTRIENT_PT_LABELS[vitId].unit;
    columns.push({
      nutrientId: vitId,
      label: MICRONUTRIENT_PT_LABELS[vitId].label,
      unit: sampleUnit,
      groupId: 'vitamins',
      groupLabel: GROUP_LABELS.vitamins,
      order: orderCounter++,
      fixed: false,
      widthPx: 112,
    });
  }

  // Group 7: Minerals (only nutrients present in at least one source food)
  for (const minId of MINERAL_IDS) {
    if (!MICRONUTRIENT_ORDER.includes(minId)) continue;
    const isPresentInAnyFood = resolvedFoods.some(
      (f) =>
        f.micronutrients[minId] !== undefined ||
        (minId === 'sodium' &&
          f.macros.sodiumMgPerBasis !== null &&
          f.macros.sodiumMgPerBasis !== undefined),
    );
    if (!isPresentInAnyFood) continue;
    const sampleUnit =
      resolvedFoods.find((f) => f.micronutrients[minId]?.normalized_unit)?.micronutrients[minId]
        ?.normalized_unit ?? MICRONUTRIENT_PT_LABELS[minId].unit;
    columns.push({
      nutrientId: minId,
      label: MICRONUTRIENT_PT_LABELS[minId].label,
      unit: sampleUnit,
      groupId: 'minerals',
      groupLabel: GROUP_LABELS.minerals,
      order: orderCounter++,
      fixed: false,
      widthPx: 102,
    });
  }

  const rows: NutritionMatrixRow[] = mappedIngredients.map(({ raw, viewModel, food }) => {
    const cells: Record<string, NutritionMatrixCell> = {};
    const qty = raw.currentQuantityG;
    const qtyStatus = raw.quantityStatus;
    const sourceCode = food?.source_record_id ?? null;

    if (!food || !validateFoodMacroComposition(food).valid) {
      for (const col of columns) {
        if (col.nutrientId === 'food' || col.nutrientId === 'quantity') continue;
        cells[col.nutrientId] = {
          nutrientId: col.nutrientId,
          value: null,
          unit: col.unit,
          status: 'not-in-source',
          sourceCode,
        };
      }
      return {
        ingredientId: viewModel.ingredientId,
        foodName: viewModel.foodDisplayName,
        quantityDisplay: viewModel.quantity.display,
        cells,
      };
    }

    const basis = food.macros.basisQuantityG > 0 ? food.macros.basisQuantityG : 100;
    cells.kcal = mapScalarFieldCell(
      'kcal',
      'kcal',
      food.macros.kcalPerBasis,
      basis,
      qty,
      qtyStatus,
      sourceCode,
    );
    cells.protein = mapScalarFieldCell(
      'protein',
      'g',
      food.macros.proteinGPerBasis,
      basis,
      qty,
      qtyStatus,
      sourceCode,
    );
    cells.carbs = mapScalarFieldCell(
      'carbs',
      'g',
      food.macros.carbsGPerBasis,
      basis,
      qty,
      qtyStatus,
      sourceCode,
    );
    cells.fat = mapScalarFieldCell(
      'fat',
      'g',
      food.macros.fatGPerBasis,
      basis,
      qty,
      qtyStatus,
      sourceCode,
    );

    if (hasFiber) {
      cells.fiber = mapScalarFieldCell(
        'fiber',
        'g',
        food.macros.fiberGPerBasis,
        basis,
        qty,
        qtyStatus,
        sourceCode,
      );
    }
    if (hasSatFat) {
      cells.saturated_fat = mapScalarFieldCell(
        'saturated_fat',
        'g',
        food.macros.saturatedFatGPerBasis,
        basis,
        qty,
        qtyStatus,
        sourceCode,
      );
    }
    if (hasCholesterol) {
      cells.cholesterol = mapScalarFieldCell(
        'cholesterol',
        'mg',
        food.macros.cholesterolMgPerBasis,
        basis,
        qty,
        qtyStatus,
        sourceCode,
      );
    }

    for (const col of columns) {
      if (col.groupId === 'vitamins' || col.groupId === 'minerals') {
        if (
          col.nutrientId === 'sodium' &&
          food.micronutrients.sodium === undefined &&
          food.macros.sodiumMgPerBasis !== null &&
          food.macros.sodiumMgPerBasis !== undefined
        ) {
          cells[col.nutrientId] = mapScalarFieldCell(
            'sodium',
            'mg',
            food.macros.sodiumMgPerBasis,
            basis,
            qty,
            qtyStatus,
            sourceCode,
          );
        } else {
          cells[col.nutrientId] = mapMicronutrientCell(
            food,
            col.nutrientId as NutrientId,
            qty,
            qtyStatus,
          );
        }
      }
    }

    return {
      ingredientId: viewModel.ingredientId,
      foodName: viewModel.foodDisplayName,
      quantityDisplay: viewModel.quantity.display,
      cells,
    };
  });

  const uniqueSources = Array.from(
    new Set(resolvedFoods.map((f) => f.source_version).filter(Boolean)),
  );

  return {
    columns,
    rows,
    sourceLabel: uniqueSources.length > 0 ? uniqueSources.join(' · ') : 'TBCA 7.2',
  };
}

function mapRecipe(
  recipe: RecipeInstance,
  menuId: string,
  slotTitle: string,
  slotTime: string,
  consumptionStatus: RecipeConsumptionStatus,
  isNextToConsume: boolean,
): RecipeCardViewModel {
  const mappedIngredients = recipe.ingredients.map((ing) => ({
    raw: ing,
    ...mapIngredient(ing),
  }));

  const macros = computeRecipeMacroSummary(recipe.ingredients);
  const nutritionMatrix = buildNutritionMatrix(mappedIngredients);

  const totalKnownGrams = recipe.ingredients.reduce(
    (sum, ing) =>
      ing.quantityStatus === 'known' &&
      ing.currentQuantityG !== null &&
      Number.isFinite(ing.currentQuantityG)
        ? sum + ing.currentQuantityG
        : sum,
    0,
  );

  return {
    recipeId: `${menuId}:${recipe.id}`,
    menuId,
    mealSlotLabel: slotTitle,
    mealTime: slotTime,
    consumptionStatus,
    isNextToConsume,
    title: recipe.name,
    image: {
      uri: normalizeImageUri(recipe.imageUrl),
      cacheKey: recipe.sourceRecipeId ?? recipe.id,
      width: 88,
      height: 88,
      accessibilityLabel: `Fotografia da receita ${recipe.name}`,
    },
    macros,
    ingredients: mappedIngredients.map((item) => item.viewModel),
    nutritionMatrix,
    // Domain RECIPE_CATALOG does not carry step-by-step cooking instructions yet;
    // keep null rather than inventing instructions (Section 14).
    preparation:
      totalKnownGrams > 0
        ? {
            steps: [],
            totalPortionDisplay: `${formatNutrientNumberPtBr(totalKnownGrams, 'g')} g`,
            sourceLabel: nutritionMatrix.sourceLabel,
          }
        : null,
  };
}

function formatDateKeyPtBr(dateKey: string): string {
  const parts = dateKey.split('-');
  if (parts.length !== 3) return dateKey;
  const year = Number(parts[0]);
  const month = Number(parts[1]);
  const day = Number(parts[2]);
  if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day)) {
    return dateKey;
  }
  const date = new Date(year, month - 1, day);
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
  }).format(date);
}

function mapMealHistory(meals: readonly MealItem[]): MealHistoryRowViewModel[] {
  const sorted = [...meals].sort((a, b) => {
    const dateCompare = b.dateKey.localeCompare(a.dateKey);
    if (dateCompare !== 0) return dateCompare;
    return a.time.localeCompare(b.time);
  });

  return sorted.map((meal) => {
    const activePortions =
      meal.status === 'consumed' || meal.status === 'partial' || meal.status === 'substituted'
        ? meal.consumed_foods.length > 0
          ? meal.consumed_foods
          : meal.planned_foods
        : meal.planned_foods;

    const quality = computePortionsMacrosWithQuality(activePortions);
    const totalGrams = activePortions.reduce(
      (sum, p) => (Number.isFinite(p.quantityG) && p.quantityG > 0 ? sum + p.quantityG : sum),
      0,
    );

    const syncStatus: MealHistoryRowViewModel['syncStatus'] =
      meal.status === 'consumed' || meal.status === 'partial' || meal.status === 'substituted'
        ? 'confirmed'
        : meal.status === 'skipped'
          ? 'failed'
          : 'pending';

    const statusLabel =
      meal.status === 'consumed'
        ? 'Confirmada'
        : meal.status === 'partial'
          ? 'Parcial'
          : meal.status === 'substituted'
            ? 'Substituída'
            : meal.status === 'skipped'
              ? 'Pulada'
              : 'Planejada';

    const energyKcal: MealHistoryRowViewModel['energyKcal'] =
      meal.status === 'skipped'
        ? { value: 0, unit: 'kcal', status: 'true-zero' }
        : quality.quantifiedGrams === 0
          ? { value: null, unit: 'kcal', status: 'not-in-source' }
          : {
              value: quality.macros.kcal,
              unit: 'kcal',
              status: quality.macros.kcal === 0 ? 'true-zero' : 'measured',
            };

    return {
      mealId: meal.id,
      occurredAt: `${meal.dateKey}T${meal.time}`,
      dateLabel: formatDateKeyPtBr(meal.dateKey),
      timeLabel: meal.time,
      mealLabel: meal.title,
      recipeTitle: meal.substitutionNote || meal.description || meal.title,
      portionDisplay:
        totalGrams > 0 ? `${formatNutrientNumberPtBr(totalGrams, 'g')} g` : '—',
      energyKcal,
      syncStatus,
      statusLabel,
    };
  });
}

function resolveSlotConsumptionStatus(
  linkedMealId: string | undefined,
  slotId: string,
  slotTime: string,
  slotTitle: string,
  dayMeals: readonly MealItem[],
): RecipeConsumptionStatus {
  const exactMatch =
    (linkedMealId ? dayMeals.find((m) => m.id === linkedMealId) : undefined) ??
    dayMeals.find((m) => m.id === slotId) ??
    dayMeals.find((m) => m.time === slotTime && m.title === slotTitle);

  return exactMatch?.status ?? 'planned';
}

export function buildCardapiosViewModel(
  plans: readonly CardapioPlan[],
  activeDateKey: string,
  meals: readonly MealItem[],
): CardapiosViewModel {
  const dayMeals = meals.filter((meal) => meal.dateKey === activeDateKey);
  const activePlanId =
    plans.find((p) => p.status === 'active')?.id ?? plans[0]?.id ?? null;
  let nextToConsumeAssigned = false;

  const menus: MenuGroupViewModel[] = plans.map((plan, index) => {
    const code = MENU_CODES[index] ?? String(index + 1);
    const dayPlan =
      plan.days[activeDateKey] ??
      Object.values(plan.days)[0];

    const recipes: RecipeCardViewModel[] = [];
    if (dayPlan) {
      for (const slot of dayPlan.slots) {
        const consumptionStatus = resolveSlotConsumptionStatus(
          slot.linkedMealId,
          slot.id,
          slot.time,
          slot.title,
          dayMeals,
        );
        for (const recipe of slot.recipes) {
          const canBeNext =
            !nextToConsumeAssigned &&
            plan.id === activePlanId &&
            consumptionStatus === 'planned';
          if (canBeNext) {
            nextToConsumeAssigned = true;
          }
          recipes.push(
            mapRecipe(
              recipe,
              plan.id,
              slot.title,
              slot.time,
              consumptionStatus,
              canBeNext,
            ),
          );
        }
      }
    }

    return {
      menuId: plan.id,
      code: `Cardápio ${code}`,
      title: plan.name,
      recipes,
    };
  });

  return {
    menus,
    history: mapMealHistory(meals),
  };
}
