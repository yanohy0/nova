export type CellDisplayStatus =
  | 'measured'
  | 'true-zero'
  | 'trace'
  | 'not-detected'
  | 'not-analyzed'
  | 'not-in-source'
  | 'not-applicable'
  | 'withheld';

export interface NutrientDisplayValue {
  value: number | null;
  unit: 'g' | 'kcal';
  status: CellDisplayStatus;
}

export interface RecipeMacroSummary {
  protein: NutrientDisplayValue;
  fat: NutrientDisplayValue;
  carbohydrate: NutrientDisplayValue;
  energyKcal: NutrientDisplayValue;
  isPartial: boolean;
}

export interface IngredientRowViewModel {
  ingredientId: string;
  foodDisplayName: string;
  quantity: {
    value: number | null;
    unit: string | null;
    display: string;
  };
  tbcaFoodCode?: string | null;
  sourceLabel?: string | null;
  status: 'resolved' | 'pending' | 'unresolved' | 'manual';
}

export type NutritionGroupId =
  | 'base'
  | 'energy-macros'
  | 'centesimal'
  | 'detailed-carbs'
  | 'amino-acids'
  | 'lipids'
  | 'sterols'
  | 'vitamins'
  | 'minerals'
  | 'carotenoids'
  | 'flavonoids'
  | 'functional-indices'
  | 'added-components'
  | 'other';

export interface NutritionMatrixColumn {
  nutrientId: string;
  label: string;
  unit: string | null;
  groupId: NutritionGroupId;
  groupLabel: string;
  order: number;
  fixed: boolean;
  widthPx: number;
}

export interface NutritionMatrixCell {
  nutrientId: string;
  value: number | null;
  unit: string | null;
  status: CellDisplayStatus;
  sourceCode?: string | null;
}

export interface NutritionMatrixRow {
  ingredientId: string;
  foodName: string;
  quantityDisplay: string;
  cells: Record<string, NutritionMatrixCell>;
}

export interface NutritionMatrixViewModel {
  columns: NutritionMatrixColumn[];
  rows: NutritionMatrixRow[];
  sourceLabel: string;
  asOf?: string;
}

export interface PreparationStepViewModel {
  stepNumber: number;
  instruction: string;
}

export interface PreparationViewModel {
  steps: PreparationStepViewModel[];
  totalPortionDisplay: string | null;
  sourceLabel: string | null;
}

export type RecipeConsumptionStatus =
  | 'planned'
  | 'consumed'
  | 'partial'
  | 'substituted'
  | 'skipped';

export interface RecipeCardViewModel {
  recipeId: string;
  menuId: string;
  mealSlotLabel: string;
  mealTime: string;
  consumptionStatus: RecipeConsumptionStatus;
  isNextToConsume: boolean;
  title: string;
  image: {
    uri: string | null;
    cacheKey?: string;
    width: number;
    height: number;
    accessibilityLabel: string;
  };
  macros: RecipeMacroSummary;
  ingredients: IngredientRowViewModel[];
  nutritionMatrix: NutritionMatrixViewModel;
  preparation: PreparationViewModel | null;
}

export interface MenuGroupViewModel {
  menuId: string;
  code: string;
  title: string;
  recipes: RecipeCardViewModel[];
}

export interface MealHistoryRowViewModel {
  mealId: string;
  occurredAt: string;
  dateLabel: string;
  timeLabel: string;
  mealLabel: string;
  recipeTitle: string;
  portionDisplay: string;
  energyKcal: NutrientDisplayValue;
  syncStatus: 'confirmed' | 'pending' | 'failed';
  statusLabel: string;
}

export interface CardapiosViewModel {
  menus: MenuGroupViewModel[];
  history: MealHistoryRowViewModel[];
}
