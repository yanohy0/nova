import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, ChevronRight } from 'lucide-react';
import {
  computeDailyMacroAndEnergyBreakdown,
  type MealConsumptionStatus,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import {
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '@/src/shared/graphics/fluid-shader-engine';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { formatKcal } from '@/src/shared/utils/formatters';

interface EnergySummaryProps {
  consumedKcal: number;
  goalKcal: number;
  plannedRemainingKcal?: number;
  plannedMealsCount?: number;
  isEstimatedGoal?: boolean;
  dataCoveragePercent?: number | null;
  unresolvedFoodCount?: number;
  lowConfidenceFoodCount?: number;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

const BAR_HEIGHT = 24;
const MIN_RENDER_WIDTH = 120;
const INTERPOLATION_TIME_CONSTANT_SECONDS = 0.14;

function drawEnergyFallback(
  canvas: HTMLCanvasElement,
  width: number,
  ratio: number,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const pixelWidth = Math.max(2, Math.round(width * dpr));
  const pixelHeight = Math.max(2, Math.round(BAR_HEIGHT * dpr));
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, BAR_HEIGHT);
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(0, 0, width, BAR_HEIGHT, BAR_HEIGHT / 2);
  ctx.clip();

  // Purple-tinted smoked borosilicate glass cavity
  const cavity = ctx.createLinearGradient(0, 0, 0, BAR_HEIGHT);
  cavity.addColorStop(0, '#221338');
  cavity.addColorStop(0.46, '#0E071B');
  cavity.addColorStop(1, '#07040F');
  ctx.fillStyle = cavity;
  ctx.fillRect(0, 0, width, BAR_HEIGHT);

  // Subtle laser-etched optical scale
  ctx.fillStyle = 'rgba(202, 168, 242, 0.16)';
  for (let i = 1; i < 12; i += 1) {
    ctx.fillRect(Math.round((width * i) / 12), 2, 1, 4);
  }

  const fillWidth = Math.max(0, Math.min(width, width * ratio));
  if (fillWidth > 0.5) {
    const fluid = ctx.createLinearGradient(0, 1, 0, BAR_HEIGHT - 1);
    fluid.addColorStop(0, '#6BF2A6');
    fluid.addColorStop(0.26, '#1DC96B');
    fluid.addColorStop(0.68, '#09723B');
    fluid.addColorStop(1, '#032916');
    ctx.fillStyle = fluid;
    ctx.fillRect(0, 0, fillWidth, BAR_HEIGHT);

    // Jagged green-white stepped-leader lightning bolt inside plasma
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(4, BAR_HEIGHT * 0.52);
    const step = 12;
    let toggle = 1;
    for (let x = 14; x < fillWidth - 4; x += step) {
      toggle = -toggle;
      ctx.lineTo(x, BAR_HEIGHT * 0.5 + toggle * 4.2);
    }
    ctx.lineTo(Math.max(4, fillWidth - 2), BAR_HEIGHT * 0.5);
    ctx.strokeStyle = 'rgba(134, 255, 190, 0.48)';
    ctx.lineWidth = 3.2;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(232, 255, 242, 0.92)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.restore();

    if (ratio > 0.015 && ratio < 0.99) {
      const edgeX = Math.min(width - 1, fillWidth);
      const meniscus = ctx.createLinearGradient(edgeX - 4, 0, edgeX + 4, 0);
      meniscus.addColorStop(0, 'rgba(110, 242, 172, 0)');
      meniscus.addColorStop(0.45, 'rgba(220, 255, 236, 0.90)');
      meniscus.addColorStop(0.75, 'rgba(4, 16, 10, 0.62)');
      meniscus.addColorStop(1, 'rgba(182, 148, 248, 0)');
      ctx.fillStyle = meniscus;
      ctx.fillRect(edgeX - 4, 1, 8, BAR_HEIGHT - 2);
    }
  }

  // Curved cylindrical purple-tinted borosilicate glass reflections
  const topGlare = ctx.createLinearGradient(0, 1, 0, 8);
  topGlare.addColorStop(0, 'rgba(244, 232, 255, 0.42)');
  topGlare.addColorStop(1, 'rgba(244, 232, 255, 0)');
  ctx.fillStyle = topGlare;
  ctx.fillRect(4, 1, Math.max(0, width - 8), 7);

  const botBounce = ctx.createLinearGradient(0, BAR_HEIGHT - 5, 0, BAR_HEIGHT);
  botBounce.addColorStop(0, 'rgba(178, 134, 246, 0)');
  botBounce.addColorStop(1, 'rgba(178, 134, 246, 0.24)');
  ctx.fillStyle = botBounce;
  ctx.fillRect(5, BAR_HEIGHT - 5, Math.max(0, width - 10), 4);

  ctx.restore();
}

const MEAL_STATUS_LABELS: Record<MealConsumptionStatus, string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

interface EnergyDetailSheetProps {
  open: boolean;
  onClose: () => void;
  consumedKcal: number;
  goalKcal: number;
  hasValidGoal: boolean;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

function EnergyDetailSheet({
  open,
  onClose,
  consumedKcal,
  goalKcal,
  hasValidGoal,
  onOpenNutrition,
}: EnergyDetailSheetProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);

  const breakdown = useMemo(
    () => computeDailyMacroAndEnergyBreakdown(meals, activeDateKey),
    [meals, activeDateKey],
  );

  const topFoods = useMemo(
    () =>
      [...breakdown.consumedFoods]
        .filter((f) => f.macros.kcal > 0)
        .sort((a, b) => b.macros.kcal - a.macros.kcal),
    [breakdown.consumedFoods],
  );

  const diff = hasValidGoal ? goalKcal - consumedKcal : null;

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      animateOpen
      title="Análise energética do dia"
      subtitle="Comparativo rigoroso entre planejado, consumido e meta"
    >
      <div className="space-y-4">
        <div className="titan-luxury-group grid grid-cols-3 gap-2.5 p-3.5 text-center font-mono-metric">
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">Consumido</div>
            <div className="text-sm font-semibold text-[var(--titan-text-primary)] mt-0.5">
              {formatKcal(consumedKcal)} kcal
            </div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">Planejado</div>
            <div className="text-sm font-semibold text-[var(--titan-text-secondary)] mt-0.5">
              {formatKcal(Math.round(breakdown.plannedTotals.kcal))} kcal
            </div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">
              {diff !== null && diff < 0 ? 'Excedente' : 'Restante'}
            </div>
            <div
              className={`text-sm font-semibold mt-0.5 ${
                diff !== null && diff < 0 ? 'text-[var(--titan-champagne)]' : 'text-[var(--titan-accent)]'
              }`}
            >
              {diff === null ? '—' : `${formatKcal(Math.abs(diff))} kcal`}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Contribuição por refeição
          </h3>
          {breakdown.meals.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhuma refeição cadastrada nesta data.
            </p>
          ) : (
            <div className="titan-luxury-group divide-y divide-[rgba(193,204,196,0.08)] px-3">
              {breakdown.meals.map((item) => (
                <div key={item.mealId} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {item.time} · {item.title}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)]">
                      {MEAL_STATUS_LABELS[item.status]} · planejado {formatKcal(Math.round(item.planned.kcal))} kcal
                    </div>
                  </div>
                  <span
                    className={`font-mono-metric font-semibold shrink-0 ${
                      item.isRecorded ? 'text-[var(--titan-accent)]' : 'text-[var(--titan-text-muted)]'
                    }`}
                  >
                    {item.isRecorded ? `${formatKcal(Math.round(item.consumed.kcal))} kcal` : '0 kcal reg.'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Alimentos registrados
          </h3>
          {topFoods.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhum alimento consumido foi registrado ainda hoje.
            </p>
          ) : (
            <div className="titan-luxury-group max-h-52 overflow-y-auto divide-y divide-[rgba(193,204,196,0.08)] px-3">
              {topFoods.map((food, idx) => (
                <div key={`${food.mealId}-${food.foodId}-${idx}`} className="py-2 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {food.foodName}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)] truncate">
                      {food.mealTitle} · {food.quantityG} g
                    </div>
                  </div>
                  <span className="font-mono-metric text-[var(--titan-text-primary)] shrink-0">
                    {formatKcal(Math.round(food.macros.kcal))} kcal
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {onOpenNutrition && (
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenNutrition('cardapio');
            }}
            className="titan-button titan-button--mineral w-full !min-h-[44px] !text-xs"
          >
            <span>Gerenciar refeições no Cardápio</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        )}
      </div>
    </BottomSheet>
  );
}

export const EnergySummary = memo(function EnergySummary({
  consumedKcal,
  goalKcal,
  onOpenNutrition,
}: EnergySummaryProps) {
  const [detailOpen, setDetailOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const safeConsumed = Number.isFinite(consumedKcal)
    ? Math.max(0, consumedKcal)
    : 0;
  const hasValidGoal = Number.isFinite(goalKcal) && goalKcal > 0;
  const safeGoal = hasValidGoal ? goalKcal : 1;
  const ratio = hasValidGoal
    ? Math.min(1, Math.max(0, safeConsumed / safeGoal))
    : 0;
  const rawPercent = hasValidGoal ? Math.round((safeConsumed / safeGoal) * 100) : 0;
  const progressValue = Math.min(100, Math.max(0, rawPercent));

  const targetRatioRef = useRef(ratio);
  const currentRatioRef = useRef(ratio);
  const lastFrameAtRef = useRef(0);
  const sizeRef = useRef({ w: 280, h: BAR_HEIGHT });
  const tiltRef = useRef<[number, number]>([0, 0]);
  const tiltSettlingUntilRef = useRef(0);
  const isVisibleRef = useRef(true);
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  useEffect(() => {
    targetRatioRef.current = ratio;
    const engine = getSharedFluidEngine();

    if (
      typeof window !== 'undefined' &&
      prefersReducedMotion()
    ) {
      currentRatioRef.current = ratio;
      lastFrameAtRef.current = 0;
      if (providerRef.current) {
        const rendered = engine.renderSinglePass(providerRef.current);
        if (!rendered && canvasRef.current) {
          drawEnergyFallback(canvasRef.current, sizeRef.current.w, ratio);
        }
      }
      return;
    }

    lastFrameAtRef.current = 0;
    if (providerRef.current) {
      const rendered = engine.renderSinglePass(providerRef.current);
      if (!rendered && canvasRef.current) {
        drawEnergyFallback(canvasRef.current, sizeRef.current.w, ratio);
      }
    }
    if (
      Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005 ||
      (isVisibleRef.current && targetRatioRef.current > 0.004)
    ) {
      engine.wake();
    }
  }, [ratio]);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const engine = getSharedFluidEngine();
    sizeRef.current.w = Math.max(MIN_RENDER_WIDTH, container.clientWidth);

    const provider = (): FluidDrawJob | null => {
      const now = performance.now();
      const elapsed = lastFrameAtRef.current
        ? Math.min(0.05, Math.max(0, (now - lastFrameAtRef.current) / 1000))
        : 1 / 60;
      lastFrameAtRef.current = now;

      const motionAllowed = typeof window === 'undefined' ? false : !prefersReducedMotion();
      currentRatioRef.current = motionAllowed
        ? interpolateRatio(
            currentRatioRef.current,
            targetRatioRef.current,
            elapsed,
            INTERPOLATION_TIME_CONSTANT_SECONDS,
          )
        : targetRatioRef.current;

      const isInterpolating =
        Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005;
      const isTiltSettling = motionAllowed && now < tiltSettlingUntilRef.current;

      return {
        kind: 'energy',
        targetCanvas: canvas,
        width: sizeRef.current.w,
        height: sizeRef.current.h,
        fill: currentRatioRef.current,
        tilt: motionAllowed ? tiltRef.current : [0, 0],
        isAnimating: isInterpolating || isTiltSettling,
        idleAnimating: isVisibleRef.current && motionAllowed && currentRatioRef.current > 0.004,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const renderCurrent = () => {
      const rendered = engine.renderSinglePass(provider);
      if (!rendered) {
        drawEnergyFallback(canvas, sizeRef.current.w, currentRatioRef.current);
      }
    };

    const resizeObserver =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            sizeRef.current.w = Math.max(MIN_RENDER_WIDTH, container.clientWidth);
            renderCurrent();
          })
        : null;
    resizeObserver?.observe(container);

    const intersectionObserver =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                renderCurrent();
                if (
                  !prefersReducedMotion() &&
                  (targetRatioRef.current > 0.004 ||
                    Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005 ||
                    performance.now() < tiltSettlingUntilRef.current)
                ) {
                  engine.wake();
                }
              }
            },
            { threshold: 0.05 },
          )
        : null;
    intersectionObserver?.observe(container);

    renderCurrent();
    const unsubscribe = engine.subscribe(provider, true);
    if (!prefersReducedMotion() && targetRatioRef.current > 0.004) {
      engine.wake();
    }
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handleMotionPreference = (event: MediaQueryListEvent) => {
      if (event.matches) {
        currentRatioRef.current = targetRatioRef.current;
        lastFrameAtRef.current = 0;
        tiltSettlingUntilRef.current = 0;
        renderCurrent();
      } else if (
        isVisibleRef.current &&
        (targetRatioRef.current > 0.004 ||
          Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005)
      ) {
        lastFrameAtRef.current = 0;
        engine.wake();
      }
    };
    motionQuery.addEventListener('change', handleMotionPreference);

    return () => {
      providerRef.current = null;
      unsubscribe();
      resizeObserver?.disconnect();
      intersectionObserver?.disconnect();
      motionQuery.removeEventListener('change', handleMotionPreference);
    };
  }, []);

  const hasLiquidReadoutRoom = hasValidGoal && rawPercent > 0 && ratio >= 0.16;
  const percentAnchorStyle = hasLiquidReadoutRoom
    ? {
        left: `${(ratio * 100).toFixed(2)}%`,
        transform: 'translate3d(calc(-100% - 10px), -50%, 0)',
      }
    : {
        left: '12px',
        transform: 'translate3d(0, -50%, 0)',
      };

  return (
    <section aria-label="Energia" className="px-0.5 py-1">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
          Energia
        </span>
        <button
          type="button"
          onClick={() => setDetailOpen(true)}
          aria-label="Abrir análise energética do dia"
          className="inline-flex items-center gap-0.5 min-h-[28px] px-1.5 -mr-1.5 rounded-lg text-[11px] font-medium text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
        >
          <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
      </div>

      <div className="mt-1 flex items-baseline justify-between gap-2">
        <span className="font-display text-3xl sm:text-4xl font-semibold tabular-nums text-[var(--titan-text-primary)] tracking-tight">
          {formatKcal(safeConsumed)} kcal
        </span>
        <span className="text-sm font-medium font-mono-metric text-[var(--titan-text-muted)] text-right tabular-nums">
          {hasValidGoal ? `${formatKcal(safeGoal)} kcal` : 'Meta não definida'}
        </span>
      </div>

      {/* Cápsula 3D em vidro borossilicato levemente roxo + bio-plasma verde volumétrico e raios stepped-leader */}
      <div className="mt-2.5 relative">
        <div
          ref={containerRef}
          className="relative h-[24px] w-full rounded-full overflow-visible transition-transform duration-150 ease-out active:scale-[0.992]"
          role={hasValidGoal ? 'progressbar' : 'group'}
          aria-valuenow={hasValidGoal ? progressValue : undefined}
          aria-valuemin={hasValidGoal ? 0 : undefined}
          aria-valuemax={hasValidGoal ? 100 : undefined}
          aria-valuetext={
            hasValidGoal
              ? `${formatKcal(safeConsumed)} de ${formatKcal(safeGoal)} quilocalorias; ${rawPercent}% da meta`
              : undefined
          }
          aria-label={
            hasValidGoal
              ? 'Progresso de energia consumida no dia'
              : 'Energia consumida; meta diária não definida'
          }
        >
          <canvas
            ref={canvasRef}
            className="relative z-[1] block w-full h-full rounded-full drop-shadow-[0_6px_14px_rgba(0,0,0,0.48)]"
            aria-hidden="true"
          />
          <span
            aria-hidden="true"
            style={{
              ...percentAnchorStyle,
              textShadow:
                hasValidGoal && rawPercent > 0
                  ? '0 0 10px rgba(74, 222, 128, 0.90), 0 0 22px rgba(16, 185, 129, 0.58), 0 1px 2px rgba(2, 12, 8, 0.96)'
                  : '0 1px 2px rgba(0, 0, 0, 0.9)',
            }}
            className="pointer-events-none absolute top-1/2 z-[2] inline-flex items-center text-[10.5px] font-bold font-mono-metric tracking-tight text-[#F4FFF8] tabular-nums transition-[left,transform] duration-200 ease-out"
          >
            {hasValidGoal ? `${rawPercent}%` : '—'}
          </span>
        </div>
        <button
          type="button"
          onClick={() => setDetailOpen(true)}
          onPointerMove={(e) => {
            if (prefersReducedMotion()) return;
            const r = e.currentTarget.getBoundingClientRect();
            if (r.width <= 0 || r.height <= 0) return;
            const nx = ((e.clientX - r.left) / r.width - 0.5) * 0.45;
            const ny = ((e.clientY - r.top) / r.height - 0.5) * 0.45;
            tiltRef.current = [nx, -ny];
            tiltSettlingUntilRef.current = performance.now() + 260;
            getSharedFluidEngine().wake();
          }}
          onPointerLeave={() => {
            tiltRef.current = [0, 0];
            if (!prefersReducedMotion()) {
              tiltSettlingUntilRef.current = performance.now() + 200;
              getSharedFluidEngine().wake();
            }
          }}
          aria-label="Detalhar consumo energético"
          className="absolute inset-0 z-[2] rounded-full cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
        />
      </div>

      {detailOpen && (
        <EnergyDetailSheet
          open={detailOpen}
          onClose={() => setDetailOpen(false)}
          consumedKcal={safeConsumed}
          goalKcal={safeGoal}
          hasValidGoal={hasValidGoal}
          onOpenNutrition={onOpenNutrition}
        />
      )}
    </section>
  );
});
