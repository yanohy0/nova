import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const temporaryDirectory = await mkdtemp(path.join(os.tmpdir(), 'titan-usda-import-'));
const outputPath = path.join(root, 'src/domains/nutrition/data/sources/usda-fdc-catalog.generated.test-output.ts');
const inputPath = path.join(temporaryDirectory, 'foundation.json');
const food = {
  fdcId: 170989,
  description: 'USDA test apple raw',
  dataType: 'Foundation',
  foodNutrients: [
    { nutrient: { id: 1003, number: '203', name: 'Protein', unitName: 'g' }, amount: 0.3 },
    { nutrient: { id: 1004, number: '204', name: 'Total lipid (fat)', unitName: 'g' }, amount: 0.2 },
    { nutrient: { id: 1005, number: '205', name: 'Carbohydrate, by difference', unitName: 'g' }, amount: 13.8 },
    { nutrient: { id: 2048, number: '958', name: 'Energy (Atwater Specific Factors)', unitName: 'kcal' }, amount: 52 },
  ],
};
const rawBytes = Buffer.from(JSON.stringify({ FoundationFoods: [food] }));
await writeFile(inputPath, rawBytes);
const expectedInputHash = createHash('sha256').update(rawBytes).digest('hex');
const auditOutputPath = path.join(path.dirname(outputPath), `usda-fdc-catalog.generated.test-output.Foundation.2026-10-29.${expectedInputHash.slice(0, 12)}.audit.json`);

function runImporter(...args) {
  return spawnSync(process.execPath, [
    '--experimental-strip-types', '--loader', './scripts/ts-extension-loader.mjs',
    'scripts/import-usda-fdc.mjs', '--input', inputPath, '--type', 'Foundation',
    '--release', '2026-10-29', '--source-url', 'https://fdc.nal.usda.gov/download-datasets/',
    '--output', outputPath, ...args,
  ], { cwd: root, encoding: 'utf8' });
}

try {
  const imported = runImporter();
  assert.equal(imported.status, 0, imported.stderr || imported.stdout);
  const generated = await readFile(outputPath, 'utf8');
  assert.match(generated, /"status": "imported"/);
  assert.match(generated, /"foodCount": 1/);
  assert.match(generated, new RegExp(expectedInputHash));
  assert.match(generated, /usda-fdc:170989/);
  assert.match(generated, new RegExp(`sha256:${expectedInputHash}`));
  const secondImport = runImporter();
  assert.equal(secondImport.status, 0, secondImport.stderr || secondImport.stdout);
  assert.equal(await readFile(outputPath, 'utf8'), generated, 'same input and options must generate byte-identical catalog output');

  await writeFile(outputPath, 'keep-existing-generated-catalog');
  const mismatchInput = Buffer.from(JSON.stringify({ SRLegacyFoods: [food] }));
  await writeFile(inputPath, mismatchInput);
  const mismatch = runImporter();
  assert.notEqual(mismatch.status, 0, 'dataset envelope mismatch must fail the import');
  assert.equal(await readFile(outputPath, 'utf8'), 'keep-existing-generated-catalog',
    'failed imports must preserve the previous generated catalog');
  const protoJson = JSON.stringify({ FoundationFoods: [food] }).replace(
    '"fdcId":170989',
    '"__proto__":{"pollutedUsda":true},"fdcId":170989',
  );
  await writeFile(inputPath, Buffer.from(protoJson));
  const protoImport = runImporter('--');
  assert.equal(protoImport.status, 0, `importer must accept '--' and sanitize prototype keys: ${protoImport.stderr || protoImport.stdout}`);
  assert.equal(({}).pollutedUsda, undefined, 'USDA JSON import must never pollute Object.prototype');
  const scriptSource = await readFile(path.join(root, 'scripts/import-usda-fdc.mjs'), 'utf8');
  assert.match(scriptSource, /__proto__/, 'import-usda-fdc.mjs must explicitly strip __proto__/constructor/prototype keys during JSON.parse');

  console.log('USDA FDC offline import tests passed.');
} finally {
  await rm(outputPath, { force: true });
  await rm(auditOutputPath, { force: true });
  await rm(temporaryDirectory, { recursive: true, force: true });
}
