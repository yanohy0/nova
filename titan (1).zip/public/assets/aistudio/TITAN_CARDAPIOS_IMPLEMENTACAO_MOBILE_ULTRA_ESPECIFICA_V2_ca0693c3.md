# TITAN V.MAX — Cardápios Mobile Native
## Especificação de implementação ultra-específica, materiais premium, dados TBCA e compatibilidade comercial

**Versão:** 2.0 — adaptação mobile nativa  
**Data de pesquisa:** 26/11/2026  
**Escopo:** somente o componente Cardápios e seus elementos internos já aprovados  
**Contrato:** layout congelado — não redesenhar, reorganizar, expandir ou reinterpretar

---

# 0. Mandato executivo

Implementar o componente **Cardápios** em uma aplicação mobile nativa React Native, preservando integralmente o layout aprovado no documento original fornecido pelo produto.

Esta versão corrige a divergência da especificação anterior: a implementação não pode depender de HTML, CSS, `backdrop-filter`, pseudo-elementos de navegador, DOM, `next/image` ou APIs exclusivas da Web. O componente mobile deve usar primitivas nativas de React Native e bibliotecas compatíveis com a New Architecture.

O objetivo visual é **ultra luxo por precisão material**, não por excesso de efeitos. Os quatro acabamentos aprovados são mantidos, assim como a paleta, ordem nutricional, posição da fotografia, macros, ação `Ver mais →`, ingredientes, matriz TBCA, ação `Receita e Preparo` e histórico.

## 0.1 Decisão técnica central

Para este componente específico, a stack principal é:

- React Native New Architecture (Fabric) + Expo SDK 58 / React Native 0.88 como baseline de referência em 26/11/2026, desde que a matriz de compatibilidade de cada dependência seja confirmada antes do merge.
- Expo Development Builds / EAS Build para compilar e testar módulos nativos reais.
- React Native `View`, `Text`, `Pressable`, `ScrollView`, `SectionList` e `StyleSheet` como base de layout e superfícies.
- `react-native-reanimated` 4 + `react-native-worklets` para a expansão controlada da matriz e transições realmente necessárias.
- `expo-image` para fotografias das receitas, cache nativo e carregamento previsível.
- `react-native-gesture-handler` 3 apenas quando forem necessários gestos especializados; não usá-lo como substituto de `Pressable` para cliques simples.
- Zustand apenas para estado compartilhado entre telas, quando já fizer parte da arquitetura do app; o estado de expansão de cada receita deve permanecer local ao componente.
- TanStack Query para dados remotos/cache de servidor, quando já existir camada de API.
- `expo-sqlite` ou o armazenamento persistente já adotado pelo app para dados locais/offline; o componente visual não abre conexão direta com o banco.
- React Native Testing Library + Jest para testes de componentes; Maestro para fluxos E2E em Android e iOS.

**Não adicionar Filament, Three.js, WebGPU, TypeGPU ou Skia obrigatoriamente ao Cardápios.** Este componente, conforme o layout aprovado, é uma interface 2D de receitas, fotografias e dados tabulares. Não existe nele um objeto 3D que justifique um renderer 3D. A adoção dessas tecnologias aqui aumentaria o custo de integração e memória sem melhorar proporcionalmente os quatro materiais opacos definidos.

`react-native-skia` pode ser avaliado como dependência opcional apenas se surgir uma necessidade visual 2D comprovada que não possa ser resolvida com Views, imagens e SVG. Nenhum dos quatro acabamentos exige Skia para sua primeira implementação.

## 0.2 Resultado obrigatório

O componente deve:

1. Preservar o layout aprovado em todos os breakpoints mobile definidos pelo design atual.
2. Reproduzir os quatro acabamentos materiais sem blur, transparência, vidro, glow ou texturas bitmap.
3. Manter fotografia natural e sem filtros.
4. Manter os macros na posição e ordem aprovadas.
5. Abrir a matriz TBCA somente quando o usuário acionar `Ver mais →`.
6. Manter expansão independente por receita.
7. Preservar a ordem e as unidades dos nutrientes.
8. Diferenciar zero real, traços, não detectado, não analisado, ausente na fonte e não aplicável.
9. Funcionar com VoiceOver e TalkBack.
10. Manter leitura e navegação fluídas em aparelhos intermediários.
11. Não depender de GPU 3D, WebGPU ou efeitos gráficos de alto consumo.
12. Não introduzir novas áreas, navegação, filtros, grupos ou cartões.

## 0.3 O que não será implementado

- Não alterar layout, estrutura, hierarquia, agrupamento, ordem ou posições relativas.
- Não criar painéis, barras de navegação, tabs, filtros, gráficos, submenus ou novos grupos.
- Não criar mini-cards de alimentos, nutrientes ou ingredientes.
- Não mover o histórico para cima dos cardápios.
- Não converter a matriz em cards por nutriente.
- Não substituir a matriz por gráficos.
- Não adicionar vidro, glassmorphism, blur ou transparência.
- Não adicionar textura de porcelana, fibra de carbono ou metal escovado.
- Não adicionar animações contínuas.
- Não recalcular nutrientes ou fazer homologação TBCA dentro da camada visual.
- Não adicionar uma biblioteca de UI completa apenas para renderizar o Cardápios.
- Não instalar uma segunda engine gráfica para desenhar superfícies opacas.

---

# 1. Contrato imutável do layout

## 1.1 Árvore visual aprovada

A hierarquia, a ordem e as posições relativas permanecem exatamente assim:

```text
CARDÁPIOS
│
├── CARDÁPIO A
│   ├── RECEITA 01
│   │   ├── Foto antes do título
│   │   ├── Macros no canto superior direito
│   │   │   Prot. · Gord. · Carb. · kcal
│   │   ├── Ver mais → (canto inferior direito do cabeçalho)
│   │   ├── Alimentos / ingredientes
│   │   ├── Matriz TBCA (oculta inicialmente)
│   │   └── Receita e Preparo (parte inferior)
│   │
│   └── RECEITA 02
│       └── Mesma estrutura
│
├── CARDÁPIO B
│   └── Receitas independentes
│
└── HISTÓRICO DE REFEIÇÕES
    └── Tabela/lista abaixo de todos os cardápios
```

## 1.2 Posições que não podem mudar

| Elemento | Posição/ordem obrigatória | Proibição |
|---|---|---|
| Título CARDÁPIOS | Cabeçalho que já existe | Não criar outro cabeçalho |
| Cardápios A/B | Ordem e agrupamento atuais | Não criar tabs, navegação ou filtros |
| Foto da receita | Antes do título | Não mover para overlay ou coluna |
| Título | Posição atual | Não criar painel adicional |
| Macros | Canto superior direito do cabeçalho | Não mover para rodapé ou faixa |
| Ordem das macros | Prot. · Gord. · Carb. · kcal | Não inverter |
| `Ver mais →` | Canto inferior direito do cabeçalho | Não mover nem transformar em card |
| Ingredientes | Abaixo do cabeçalho, na posição atual | Não ocultar inicialmente |
| Matriz TBCA | Dentro da própria receita | Recolhida inicialmente |
| Receita e Preparo | Parte inferior da receita | Não mover para área externa |
| Histórico | Abaixo de todos os cardápios | Não misturar com os cardápios |

## 1.3 Tradução do layout para primitivas mobile

A troca de DOM/CSS por React Native não autoriza alterar a composição visual.

- Usar `View` para as caixas estruturais que já existem.
- Usar `Text` para títulos, valores, labels e unidades.
- Usar `Pressable` para ações existentes.
- Usar `expo-image` para a fotografia existente.
- Usar `ScrollView` para o deslocamento horizontal interno da matriz, se necessário.
- Usar `SectionList` ou `FlashList` apenas como estratégia de renderização quando o volume de dados exigir, nunca como justificativa para reorganizar o conteúdo.
- Não criar um `View` visível adicional em volta de cada ingrediente, macro ou célula.
- Um overlay de acabamento só pode existir como camada absoluta dentro do contêiner já existente, com `pointerEvents="none"`, sem participar do cálculo de layout. Preferir não adicionar overlay quando a cor sólida e a borda forem suficientes.
- Não usar `position: 'absolute'` para reposicionar elementos aprovados. A única exceção é um filete de acabamento ou uma camada de fundo que não altera hit testing, dimensões ou fluxo.
- Não mudar `padding`, `margin`, `gap`, `width`, `height`, `minHeight`, `borderRadius` ou alinhamentos aprovados sem comparar com o layout original e registrar uma divergência objetiva.

## 1.4 Responsividade sem redesign

O layout deve manter a mesma hierarquia nos aparelhos pequenos, médios, grandes e tablets.

- Não criar uma nova versão em cards para telas estreitas.
- Não converter a matriz em lista de nutrientes.
- Não mudar a posição relativa da foto, título, macros e `Ver mais →`.
- Em telas estreitas, permitir rolagem horizontal interna da matriz; não comprimir dezenas de colunas até ficarem ilegíveis.
- Respeitar `SafeAreaView`/insets da aplicação hospedeira sem alterar o conteúdo interno aprovado.
- Usar `useWindowDimensions()` somente para escolher medidas já previstas pelo sistema responsivo do app, não para inventar uma nova composição.
- Validar fonte ampliada e escala de acessibilidade; quando o texto aumentar, permitir crescimento vertical sem sobreposição ou truncamento indevido.

## 1.5 Gate de layout obrigatório

Antes de estilizar:

1. Capturar a implementação de referência.
2. Registrar dimensões da tela, densidade, safe areas, fonte, escala de texto e conteúdo.
3. Registrar a posição e dimensões de cada elemento aprovado.
4. Criar baseline em iOS e Android.
5. Comparar screenshots lado a lado após cada fase.

A implementação só passa quando a estrutura e a geometria visual continuam equivalentes ao layout aprovado. Diferenças de antialiasing entre plataformas são aceitáveis; mudança de hierarquia, posição ou tamanho não é.

---

# 2. Pesquisa de repositórios — top 3 por funcionalidade

**Critério:** adoção pública aproximada (estrelas do GitHub), compatibilidade com React Native New Architecture, manutenção observável, licença, adequação ao problema e custo de dependência. As estrelas são fotografias aproximadas consultadas em 26/11/2026; não são prova de qualidade nem substituem inspeção de releases, issues, licença e matriz de compatibilidade.

## 2.1 Fundação mobile e arquitetura

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [react/react-native](https://github.com/facebook/react-native) | 127k | Runtime nativo React, Fabric, JSI e APIs de plataforma | Base obrigatória |
| [expo/expo](https://github.com/expo/expo) | 53.8k | SDK, módulos nativos, build e ferramentas de distribuição | Base recomendada |
| [tamagui/tamagui](https://github.com/tamagui/tamagui) | 14.3k | Sistema de tokens e componentes cross-platform | Referência; não instalar para este componente |

**Decisão:** React Native + Expo Development Build. Não usar Tamagui como camada visual deste componente porque o layout e os materiais estão aprovados e devem ser preservados. O Expo fornece a fundação operacional; o componente mantém `StyleSheet` e primitivas nativas para reduzir o número de camadas.

## 2.2 Design system e componentes nativos

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [callstack/react-native-paper](https://github.com/callstack/react-native-paper) | 14.5k | Componentes Material Design para RN | Referência, não instalar |
| [tamagui/tamagui](https://github.com/tamagui/tamagui) | 14.3k | Tokens, estilo e UI multiplataforma | Referência, não instalar |
| [nativewind/nativewind](https://github.com/nativewind/nativewind) | 8.1k | Estilo utility-first para RN | Não adicionar ao componente |

**Vencedor de implementação:** primitivas nativas `View`, `Text`, `Pressable`, `Image`/`expo-image` e `StyleSheet`. Os repositórios são referência para tokenização, estados e padrões, não para importar uma biblioteca que imponha outra linguagem visual.

## 2.3 Animações e gestos

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [software-mansion/react-native-reanimated](https://github.com/software-mansion/react-native-reanimated) | 11.1k | Animações no UI runtime/worklets | Escolha principal |
| [software-mansion/react-native-gesture-handler](https://github.com/software-mansion/react-native-gesture-handler) | 6.8k | Reconhecimento de gestos nativos | Usar somente se houver gesto especializado |
| [nandorojo/moti](https://github.com/nandorojo/moti) | 4.5k | Abstração de animações RN | Não adicionar; depende de linha Reanimated 3 no README analisado |

**Decisão:** Reanimated 4 + `react-native-worklets`, com versão explicitamente compatível com o React Native instalado. `Pressable` nativo é suficiente para toques simples. Não adicionar Gesture Handler apenas para `Ver mais` ou `Receita e Preparo`.

A versão Reanimated 4 deve ser escolhida pela tabela oficial de compatibilidade com a versão real do React Native. Reanimated 4 funciona apenas na New Architecture; não misturar pacote `react-native-worklets` de versão incompatível. Conferir [tabela de compatibilidade](https://docs.swmansion.com/react-native-reanimated/docs/guides/compatibility/) antes de instalar.

## 2.4 Renderização 2D customizada

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [wcandillon/react-native-skia](https://github.com/wcandillon/react-native-skia) | 8.8k | Desenho GPU 2D, paths, shaders e canvas | Opcional, não obrigatório |
| [software-mansion/react-native-svg](https://github.com/software-mansion/react-native-svg) | 8.0k | Vetores SVG multiplataforma | Usar somente para ícones/figuras vetoriais existentes |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | Engine 3D WebGL/WebGPU | Fora do escopo deste componente |

**Decisão:** nenhuma engine de desenho adicional na primeira entrega. As superfícies aprovadas são opacas, planas e uniformes. `StyleSheet` e Views nativas atendem ao requisito. Skia só entra se um protótipo demonstrar que uma forma, máscara ou composição 2D necessária não pode ser construída com Views/SVG sem custo maior.

**Risco de manutenção:** em 2026, a Shopify publicou que manteria o patrocínio do React Native Skia até o fim de 2026 e que o mantenedor planejava assumir o projeto sob outro nome, com possível arquivamento do repositório original após a transição. Portanto, não tornar o pacote atual uma dependência estrutural do Cardápios. Antes de qualquer adoção futura, confirmar o repositório canônico, o pacote npm, a compatibilidade com Expo/RN, o backend GPU e o processo de atualização. Referência: [Shopify — Native is now the future of mobile at Shopify (2026)](https://shopify.engineering/back-to-native).

## 2.5 Imagens e cache

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [expo/expo — expo-image](https://github.com/expo/expo/tree/main/packages/expo-image) | 53.8k no monorepo Expo | Imagem nativa, cache, formatos e transições | Escolha principal |
| [DylanVann/react-native-fast-image](https://github.com/DylanVann/react-native-fast-image) | 8.4k | Cache nativo baseado em SDWebImage/Glide | Alternativa a benchmark |
| [react/react-native](https://github.com/facebook/react-native) | 127k | `Image` nativo | Fallback/base simples |

**Decisão:** `expo-image`. Já integra com Expo e usa SDWebImage no iOS e Glide no Android. Configurar `cachePolicy="disk"` por padrão para imagens remotas, reservar a geometria antes do carregamento e usar `contentFit="cover"` sem filtros. Não usar BlurHash se o requisito visual continuar proibindo blur/preview desfocado; usar placeholder sólido no mesmo espaço da fotografia.

`react-native-fast-image` deve ser avaliado somente se um teste demonstrar ganho real de cache, autenticação, pré-carregamento ou memória em relação a `expo-image`. Não instalar os dois.

## 2.6 Listas e virtualização

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [Shopify/flash-list](https://github.com/Shopify/flash-list) | 7.2k | Lista reciclável; v2 para New Architecture | Principal candidata se profiling exigir |
| [Flipkart/recyclerlistview](https://github.com/Flipkart/recyclerlistview) | 5.4k | Reciclagem de células e listas complexas | Alternativa histórica; não padrão |
| [LegendApp/legend-list](https://github.com/LegendApp/legend-list) | 3.4k | Lista RN/React com tamanhos dinâmicos | Alternativa a benchmark |

**Decisão:** começar com `ScrollView`/`SectionList` nativos se o número real de cardápios, receitas e registros históricos for moderado. Se o profiling demonstrar queda de FPS, memória excessiva ou renderização de muitos itens fora da viewport, testar FlashList v2. Não instalar FlashList e LegendList simultaneamente.

FlashList v2 exige New Architecture; não usar v2 em uma aplicação que ainda esteja na arquitetura legada. Veja [migração FlashList v2](https://github.com/Shopify/flash-list/blob/main/documentation/docs/v2-migration.md).

**Risco de continuidade:** a Shopify também informou em 2026 que continuaria corrigindo problemas críticos do FlashList até o fim do ano e que discutia a transferência de stewardship de longo prazo. Como o Cardápios não precisa necessariamente de reciclagem avançada, manter `SectionList`/`FlatList` como baseline e só adotar FlashList após profiling, due diligence do mantenedor e aprovação de compatibilidade para a linha de RN utilizada. Revalidar o estado do projeto antes de cada major upgrade. Referência: [Shopify — Native is now the future of mobile at Shopify (2026)](https://shopify.engineering/back-to-native).

## 2.7 Tabelas e matriz nutricional

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [TanStack/table](https://github.com/TanStack/table) | 28.6k | Motor headless de colunas, agrupamento e estado | Opcional se a matriz evoluir em complexidade |
| [callstack/react-native-paper](https://github.com/callstack/react-native-paper) | 14.5k | DataTable e padrões de apresentação | Apenas referência; não instalar |
| [KevinVandy/material-react-table](https://github.com/KevinVandy/material-react-table) | 1.8k | Implementação de tabela Material UI para web | Não utilizar em RN |

**Decisão:** matriz nativa própria com `View`/`Text`, largura explícita de colunas e `ScrollView horizontal` dentro da área existente. A matriz atual é principalmente de leitura e possui ordem rígida; uma biblioteca de datagrid completa não se justifica. TanStack Table só pode ser adicionada se surgir necessidade comprovada de agrupamento dinâmico, filtros, seleção, ordenação ou agregações interativas. A documentação TanStack informa que seu core é headless e pode ser renderizado com UI própria, inclusive em ambientes JS-to-native, mas não fornece o layout de tabela nativo pronto.

## 2.8 Estado, dados remotos e persistência

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [pmndrs/zustand](https://github.com/pmndrs/zustand) | 58.9k | Estado global leve | Estado compartilhado do app, se necessário |
| [TanStack/query](https://github.com/TanStack/query) | 50.6k | Cache, sincronização e dados remotos | Dados remotos |
| [reduxjs/redux-toolkit](https://github.com/reduxjs/redux-toolkit) | 11.2k | Store, reducers e fluxo global estruturado | Alternativa; não combinar sem motivo |

**Decisão:** TanStack Query para dados de servidor; Zustand somente para estado global já compartilhado por mais telas. Estado de abertura de matriz pertence ao componente e deve usar `useState` ou reducer local. Não armazenar o estado `isExpanded` no servidor nem no banco.

Persistência local fica na camada de repositório/serviço do aplicativo, por exemplo com `expo-sqlite` se esse já for o mecanismo selecionado. O componente recebe `view models`; não executa SQL, não monta query HTTP e não calcula nutrientes.

## 2.9 Padrões de disclosure e acessibilidade

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [tailwindlabs/headlessui](https://github.com/tailwindlabs/headlessui) | 28.8k | Disclosure e padrões headless acessíveis para Web | Referência conceitual, não usar diretamente em RN |
| [radix-ui/primitives](https://github.com/radix-ui/primitives) | 19.5k | Collapsible controlado, estados e acessibilidade Web | Referência conceitual |
| [adobe/react-spectrum](https://github.com/adobe/react-spectrum) | 16.1k | Hooks, estados e padrões de acessibilidade | Referência conceitual |

Esses projetos não substituem as APIs de acessibilidade do React Native. A implementação final usa `Pressable`, `accessibilityRole`, `accessibilityLabel`, `accessibilityHint` e `accessibilityState`. Não adicionar Headless UI, Radix ou React Spectrum ao bundle nativo apenas para implementar `Ver mais →`.

## 2.10 Referências de produto: receitas, ingredientes e planejamento

| Repositório | Estrelas aprox. | Função investigada | Decisão |
|---|---:|---|---|
| [mealie-recipes/mealie](https://github.com/mealie-recipes/mealie) | 14k | Identidade da receita, imagem, planejamento e estrutura de receita | Referência principal de comportamento da receita |
| [TandoorRecipes/recipes](https://github.com/TandoorRecipes/recipes) | 8.6k | Receita/ingrediente, unidades, escala e planejamento | Referência de domínio e relações |
| [simonoppowa/OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker) | 3k | Dados nutricionais, receitas reutilizáveis, fonte e unidade | Referência de rastreabilidade |

Os projetos Mealie/Tandoor/OpenNutriTracker não são bibliotecas UI mobile para copiar no app. Mealie/Tandoor são referências de comportamento e domínio; OpenNutriTracker é Flutter/Dart e não fornece código React Native reutilizável. As licenças AGPL/GPL exigem revisão jurídica; a decisão segura é aprender os padrões e reimplementar de forma independente, salvo aprovação jurídica explícita para reutilização.

## 2.11 Testes e qualidade

| Repositório | Estrelas aprox. | Função | Decisão |
|---|---:|---|---|
| [mobile-dev-inc/Maestro](https://github.com/mobile-dev-inc/Maestro) | 16.5k | E2E mobile Android/iOS | Escolha principal E2E |
| [wix/Detox](https://github.com/wix/Detox) | 12.0k | E2E gray-box React Native | Alternativa se já for adotado no app |
| [callstack/react-native-testing-library](https://github.com/callstack/react-native-testing-library) | 3.4k | Testes de comportamento de componentes | Escolha unit/component |

**Decisão:** RNTL + Jest para estados, semântica e dados; Maestro para fluxos de usuário reais; testes visuais em aparelhos e simuladores. Não instalar Maestro e Detox apenas para executar os mesmos fluxos, a menos que haja necessidade diferente de white-box/black-box.

---

# 3. Stack final aprovada para o componente mobile

## 3.1 Dependências principais

| Camada | Escolha | Status |
|---|---|---|
| Runtime | React Native New Architecture / Fabric | Obrigatória |
| SDK/build | Expo SDK estável compatível + Development Build/EAS | Obrigatória se o app usa Expo |
| Tipagem | TypeScript `strict` | Obrigatória |
| Estilo/layout | React Native `StyleSheet` e primitives | Obrigatória |
| Interação simples | `Pressable` | Obrigatória |
| Animação | Reanimated 4 + Worklets compatíveis | Recomendada para disclosure |
| Imagens | `expo-image` | Recomendada |
| Gestos especializados | Gesture Handler 3 | Condicional |
| Dados remotos | TanStack Query | Apenas se o app já usa dados remotos/cache |
| Estado global | Zustand | Apenas se houver estado compartilhado |
| Matriz TBCA | `View`/`Text`/`ScrollView` nativos | Obrigatória |
| Virtualização | `SectionList` ou FlashList v2 após profiling | Condicional |
| Gráficos GPU | Skia | Não necessário inicialmente |
| Renderer 3D | Filament/Three.js/WebGPU | Fora do componente |
| E2E | Maestro | Recomendada |
| Testes de componente | Jest + RNTL | Recomendada |

## 3.2 Baseline de versão

Em 26/11/2026, a documentação consultada lista Expo SDK 58 com React Native 0.88. O documento utiliza isso como baseline de referência, não como ordem para atualizar cegamente qualquer app existente. **Atenção à compatibilidade:** a tabela oficial do Expo SDK 58 lista iOS 16.4+ e Android 7/API 24+; a matriz de React Native 0.88 indica mínimo de iOS 15.1 e Android API 24. Portanto, não prometer compatibilidade iOS 15.1 se a aplicação usar o pacote Expo SDK 58 sem validar a cadeia de módulos. Se suportar aparelhos com iOS abaixo de 16.4 for requisito comercial, decidir o deployment target antes de fixar Expo SDK 58: testar uma linha Expo anterior ainda suportada ou uma configuração React Native 0.88 bare com módulos Expo selecionados, sempre validando cada dependência nativa. A escolha final deve ser baseada na distribuição real dos dispositivos dos usuários e nas regras atuais das lojas.

Regra de instalação:

1. Auditar `package.json`, lockfile, RN, Expo, React, Hermes e arquitetura atuais.
2. Se o projeto já estiver em RN/Expo, alinhar todo o conjunto pela matriz oficial.
3. Não atualizar Expo, RN, Reanimated, Gesture Handler, Skia e módulos nativos em uma única mudança sem gates separados.
4. Utilizar `npx expo install` para pacotes Expo e versões esperadas pelo SDK.
5. Executar `npx expo install --check` e `npx expo-doctor`.
6. Gerar Development Builds em Android e iOS; Expo Go não representa dependências nativas fora do runtime pré-compilado.
7. Fixar versões no lockfile e validar build Release, não somente Metro/Debug.

Expo SDK 58 informa React Native 0.88, enquanto a New Architecture é obrigatória desde RN 0.82 e SDK 55+. Reanimated 4 é apenas New Architecture. Fontes: [Expo SDK 58](https://expo.dev/sdk/58), [Expo New Architecture](https://docs.expo.dev/guides/new-architecture/), [Reanimated compatibility](https://docs.swmansion.com/react-native-reanimated/docs/guides/compatibility/).

## 3.3 Não adicionar por padrão

- Tamagui, React Native Paper, gluestack ou NativeWind para renderizar este componente.
- Skia Graphite se Views nativas já reproduzirem os quatro acabamentos.
- Filament, Three.js, WebGPU ou TypeGPU.
- Motion/Moti se Reanimated já controla a única expansão.
- TanStack Table para uma matriz estática de leitura.
- FlashList e LegendList juntos.
- FastImage e Expo Image juntos.
- Zustand para um estado que pode permanecer local.
- Redux Toolkit se Zustand/TanStack Query já cobrem as responsabilidades.

---

# 4. Direção visual: quatro acabamentos e sem variação de layout

## 4.1 Princípio

A interface deve parecer premium por contraste tonal, alinhamento, fotografia, qualidade tipográfica e precisão das bordas. Os materiais são metáforas visuais de superfícies físicas, não simulações PBR literais.

A principal riqueza visual é a fotografia natural da receita. As superfícies devem ser discretas e estáveis.

## 4.2 Quatro acabamentos oficiais

| ID | Material | Aplicação | Aparência |
|---|---|---|---|
| `material.cardapio-shell` | Obsidian Ceramic Hardcoat | Contêiner externo do cardápio | Grafite denso, uniforme e fosco-acetinado |
| `material.recipe-surface` | Satin Graphite | Superfície interna da receita | Opaca, micro-satin, tonalmente elevada |
| `material.nutrition-matrix` | Anti-glare Graphite Display | Matriz TBCA | Opaca, antirreflexo e de leitura clara |
| `material.primary-action` | Mineral Satin Enamel | Ação `Receita e Preparo` | Sage sólido, acabamento acetinado discreto |

Não criar quinto material para alimentos, macros, histórico ou células.

## 4.3 Proibições

- Glassmorphism.
- Transparência de superfície.
- Blur ou backdrop blur.
- Glow permanente.
- Reflexo metálico animado.
- Bevel ou emboss.
- Textura fotográfica de cerâmica, tecido, carbono ou metal.
- Ruído procedural visível.
- Gradiente metálico.
- Elevação exagerada.
- Sombra múltipla.
- Tilt/parallax.
- Scale no pressionamento que mova visualmente a geometria.
- Brilho especular espalhado pelo conteúdo.
- Caixas extras por alimento, ingrediente ou célula.

## 4.4 Tokens de cor — preservar

```ts
export const cardapiosTokens = {
  canvasPrimary: '#101719',
  surfacePrimary: '#171F22',
  surfaceRaised: '#202B2E',
  surfaceInteractive: '#29373A',
  borderSubtle: '#344448',
  textPrimary: '#F2F0E8',
  textSecondary: '#B7C1BD',
  textMuted: '#8E9B96',
  accentPrimary: '#A7C9BE',
  accentSurface: '#253936',
} as const;
```

Não criar tonalidades adicionais permanentes. Valores alpha podem ser usados apenas para um filete de acabamento muito sutil quando não houver outra solução, sem transformar a superfície em transparente.

## 4.5 Contraste

| Foreground | Background | Contraste aproximado | Uso |
|---|---|---:|---|
| `#F2F0E8` | `#171F22` | 14.66:1 | Texto primário |
| `#F2F0E8` | `#202B2E` | 12.72:1 | Texto primário de receita |
| `#B7C1BD` | `#202B2E` | 7.87:1 | Texto secundário |
| `#B7C1BD` | `#29373A` | 6.68:1 | Texto secundário em interação |
| `#8E9B96` | `#29373A` | 4.28:1 | Não usar em texto normal |
| `#8E9B96` | `#202B2E` | 5.03:1 | Texto normal, sujeito à validação final |
| `#A7C9BE` | `#171F22` | 9.35:1 | Acento/indicador |
| `#101719` | `#A7C9BE` | 10.13:1 | Texto do botão Sage |
| `#344448` | `#171F22` | 1.65:1 | Divisor decorativo, nunca único indicador de estado |

- Texto normal: mínimo 4.5:1 para WCAG AA.
- Texto grande: mínimo 3:1.
- Componentes/indicadores não textuais essenciais: mínimo 3:1 com cores adjacentes.
- Cor não pode ser o único sinal de seleção, foco ou erro.
- `textMuted` não deve ser aplicado sobre `surfaceInteractive` para texto normal.
- `borderSubtle` é decorativa e não pode ser único indicador de ação ou seleção.
- Validar contraste real com o fundo renderizado e a opacidade final em iOS e Android.

---

# 5. Materiais em React Native — implementação visual exata

## 5.1 Obsidian Ceramic Hardcoat — contêiner externo

**Aplicação:** container externo de cada cardápio, sem alterar dimensões ou agrupamento.

**Propriedades obrigatórias:**

- `backgroundColor: '#171F22'`.
- `borderColor: '#344448'`.
- Borda de 1 unidade lógica, ou `StyleSheet.hairlineWidth` quando a captura mostrar que 1 dp fica pesado.
- `opacity: 1`.
- Sem textura bitmap.
- Sem blur.
- Sem background image.
- Sem gradient.
- Sem overlay animado.
- Uma única sombra ambiental extremamente discreta somente se a referência atual exigir separação do canvas.

**Android/iOS:** não tentar igualar sombra usando um conjunto de `elevation`, `shadowOpacity`, `shadowRadius` e pseudo-camadas que deformem o contêiner. Preferir superfície sólida + borda. Se sombra for aprovada, calibrar iOS e Android separadamente por screenshot.

## 5.2 Satin Graphite — superfície da receita

**Aplicação:** superfície já existente que agrupa foto, título, macros, ingredientes e ação.

- `backgroundColor: '#202B2E'`.
- Opacidade 100%.
- Sem brilho especular.
- Sem textura.
- Sem linha metálica.
- Sem caixa separada em volta de título, foto ou macros.
- Sem `elevation` alto.
- Estado pressionado/selecionado usa `#29373A` somente quando o componente realmente tem estado de interação/seleção.

A superfície deve ter aparência uniforme em todos os cardápios.

## 5.3 Anti-glare Graphite Display — matriz TBCA

**Aplicação:** fundo da matriz, dentro da receita existente.

- Superfície opaca.
- Sem blur e sem transmissão.
- Fundo de contraste suficiente para números.
- Linhas de divisão finas e contínuas.
- Cabeçalho de grupo tipograficamente distinto.
- Colunas numéricas alinhadas pela direita.
- Sem cards por célula.
- Sem chip de cor por nutriente.
- Não fazer o fundo de cabeçalho transparente para deixar linhas passando por trás.

A matriz deve parecer um instrumento de consulta de precisão, não um dashboard colorido.

## 5.4 Mineral Satin Enamel — botão Receita e Preparo

- Fundo Sage sólido `#A7C9BE`.
- Texto grafite `#101719`.
- Sem gradiente metálico.
- Sem glow.
- Sem bevel.
- Sem scale no toque.
- Estado pressionado muda levemente o tom, sem mudar dimensões.
- Foco visível com contorno de contraste suficiente e sem deslocar o layout.
- Área de toque deve atender às recomendações de plataforma; expandir `hitSlop` se necessário, sem alterar a posição visível do botão.

## 5.5 Estilos de referência

Os valores geométricos do layout aprovado devem vir dos estilos já existentes. O snippet abaixo mostra somente os tokens materiais:

```ts
import { StyleSheet } from 'react-native';

export const cardapiosMaterialStyles = StyleSheet.create({
  menuShell: {
    backgroundColor: '#171F22',
    borderColor: '#344448',
    borderWidth: StyleSheet.hairlineWidth,
  },
  recipeSurface: {
    backgroundColor: '#202B2E',
  },
  nutritionMatrix: {
    backgroundColor: '#202B2E',
  },
  interactiveSurface: {
    backgroundColor: '#29373A',
  },
  primaryAction: {
    backgroundColor: '#A7C9BE',
  },
  primaryActionText: {
    color: '#101719',
  },
  primaryText: {
    color: '#F2F0E8',
  },
  secondaryText: {
    color: '#B7C1BD',
  },
  mutedText: {
    color: '#8E9B96',
  },
});
```

**Não copiar dimensões, radius, margins, paddings ou flex values desse snippet para substituir os valores do layout real.**

---

# 6. Arquitetura de componentes mobile

## 6.1 Árvore de código — sem alterar árvore visual

```text
CardapiosScreen
└── CardapiosContent
    ├── CardapiosHeading                 # elemento já existente
    ├── MenuGroup A                      # agrupamento existente
    │   ├── RecipeCard                   # estrutura existente
    │   │   ├── RecipeHeader             # mantém regiões aprovadas
    │   │   │   ├── RecipePhoto          # foto antes do título
    │   │   │   ├── RecipeTitle
    │   │   │   ├── MacroSummary         # canto superior direito
    │   │   │   └── MatrixDisclosure     # canto inferior direito
    │   │   ├── IngredientList
    │   │   ├── NutritionMatrixDisclosure# inicialmente fechada
    │   │   └── RecipePreparationAction # parte inferior
    │   └── RecipeCard...
    ├── MenuGroup B                      # agrupamento existente
    │   └── RecipeCard...
    └── MealHistory                      # abaixo de todos os cardápios
```

Os nomes representam responsabilidades de código. Não obrigam a criar wrappers visíveis adicionais. O agente deve mapear os elementos para os componentes/arquivos que já existirem antes de criar novos.

## 6.2 Responsabilidades

### `CardapiosScreen`

- Recebe snapshot de dados já carregados.
- Conecta os view models do domínio aos componentes visuais.
- Não calcula calorias ou nutrientes.
- Não contém lógica de consulta TBCA.
- Não gerencia abertura de matriz de outras telas.

### `RecipeCard`

- Recebe uma receita normalizada.
- Preserva ordem e posicionamento.
- Não consulta API.
- Não faz associação de alimentos.
- Não calcula totais nutricionais durante render.

### `RecipeHeader`

- Mantém a posição da foto, título, macros e `Ver mais →`.
- Não muda a ordem por orientação de tela.
- Não cria um novo card de cabeçalho.

### `RecipePhoto`

- Usa `expo-image`.
- Mantém a geometria atual.
- Exibe placeholder sólido no mesmo espaço.
- Não aplica blur, filtro escuro ou overlay.

### `MacroSummary`

- Recebe números calculados pelo domínio.
- Mantém ordem `Prot. · Gord. · Carb. · kcal`.
- Não recalcula a composição.
- Alinha valores numericamente.

### `MatrixDisclosure`

- É independente por `recipeId`.
- Atualiza `accessibilityState.expanded`.
- Controla somente a matriz da receita acionada.
- Mantém o trigger no local aprovado.

### `NutritionMatrix`

- Recebe colunas e células prontas.
- Mantém ordem aprovada.
- Não inventa nutrientes.
- Não interpreta célula ausente como zero.
- Usa scroll horizontal interno quando necessário.

### `IngredientList`

- Mostra ingredientes no estado fechado.
- Preserva a ordem do domínio.
- Mostra quantidade/unidade de acordo com o contrato de dados existente.
- Não cria mini-cards.

### `RecipePreparationAction`

- Mantém ação na parte inferior.
- Aciona o fluxo existente de Receita e Preparo.
- Não inventa um modal, rota ou novo painel se o app não possuir esse comportamento.

### `MealHistory`

- Permanece abaixo de todos os cardápios.
- Mostra somente registros persistidos/confirmados segundo o contrato existente.
- Mantém formato atual de tabela/lista.

## 6.3 Organização de diretórios sugerida

Adaptar ao padrão real do monorepo; não criar pastas duplicadas:

```text
src/
  features/
    cardapios/
      components/
        CardapiosScreen.tsx
        CardapiosContent.tsx
        RecipeCard.tsx
        RecipeHeader.tsx
        RecipePhoto.tsx
        MacroSummary.tsx
        MatrixDisclosure.tsx
        IngredientList.tsx
        NutritionMatrix.tsx
        RecipePreparationAction.tsx
        MealHistory.tsx
      hooks/
        useRecipeMatrixExpansion.ts
      view-models/
        cardapios.mapper.ts
      styles/
        cardapios.tokens.ts
        cardapios.styles.ts
      accessibility/
        cardapios.accessibility.ts
      __tests__/
        *.test.tsx
      index.ts
  domain/
    nutrition/
    recipes/
    tbca/
  data/
    repositories/
    queries/
```

Separar domínio e visual. Se os módulos de receita/TBCA já estiverem organizados em outra pasta, reutilizar os módulos atuais em vez de duplicar.

---

# 7. Contratos TypeScript — view models e semântica

O componente deve receber dados prontos para apresentação. Estes contratos são referência e precisam ser reconciliados com os tipos do projeto antes de criar novos tipos duplicados.

## 7.1 Identificadores

- IDs devem ser estáveis e persistidos.
- Não usar índice de array como `key` se receitas/ingredientes puderem ser reordenados.
- `recipeId` controla expansão local.
- `ingredientId` identifica a linha.
- `nutrientId` identifica o campo TBCA.
- `menuId` identifica o cardápio.

## 7.2 Macro

```ts
export type NutrientDisplayValue = {
  value: number | null;
  unit: 'g' | 'kcal';
  status:
    | 'measured'
    | 'true-zero'
    | 'trace'
    | 'not-detected'
    | 'not-analyzed'
    | 'not-in-source'
    | 'not-applicable'
    | 'withheld';
};

export type RecipeMacroSummary = {
  protein: NutrientDisplayValue;
  fat: NutrientDisplayValue;
  carbohydrate: NutrientDisplayValue;
  energyKcal: NutrientDisplayValue;
};
```

Se o domínio possuir enum equivalente, reutilizar o enum existente. Não manter duas definições para o mesmo significado.

## 7.3 Receita

```ts
export type RecipeCardViewModel = {
  recipeId: string;
  menuId: string;
  title: string;
  image: {
    uri: string | null;
    cacheKey?: string;
    width?: number;
    height?: number;
    accessibilityLabel: string;
  };
  macros: RecipeMacroSummary;
  ingredients: IngredientRowViewModel[];
  nutritionMatrix: NutritionMatrixViewModel;
  preparation: PreparationViewModel | null;
};
```

Não permitir `image.uri` como string vazia. URL inválida deve ser normalizada na camada mapper para `null` e renderizar placeholder.

## 7.4 Ingredientes

```ts
export type IngredientRowViewModel = {
  ingredientId: string;
  foodDisplayName: string;
  quantity: {
    value: number | null;
    unit: string | null;
    display: string;
  };
  tbcaFoodCode?: string | null;
  sourceLabel?: string | null;
  status: 'resolved' | 'pending' | 'unresolved' | 'manual';
};
```

- Não inferir quantidade a partir do nome.
- Não converter ausência de quantidade em zero.
- `a gosto` só pode aparecer quando o domínio já tiver classificado o ingrediente como condimento/tempero sem quantidade especificada, conforme regra nutricional existente. A UI não decide isso.
- Nome original e nome normalizado devem permanecer campos distintos no domínio.

## 7.5 Matriz nutricional

```ts
export type NutritionMatrixColumn = {
  nutrientId: string;
  label: string;
  unit: string | null;
  groupId: string;
  order: number;
  fixed: boolean;
};

export type NutritionMatrixCell = {
  nutrientId: string;
  value: number | null;
  unit: string | null;
  status:
    | 'measured'
    | 'true-zero'
    | 'trace'
    | 'not-detected'
    | 'not-analyzed'
    | 'not-in-source'
    | 'not-applicable'
    | 'withheld';
  sourceCode?: string | null;
};

export type NutritionMatrixRow = {
  ingredientId: string;
  foodName: string;
  quantityDisplay: string;
  cells: Record<string, NutritionMatrixCell>;
};

export type NutritionMatrixViewModel = {
  columns: NutritionMatrixColumn[];
  rows: NutritionMatrixRow[];
  sourceLabel: string;
  asOf?: string;
};
```

## 7.6 Histórico

```ts
export type MealHistoryRowViewModel = {
  mealId: string;
  occurredAt: string;
  mealLabel: string;
  recipeTitle: string;
  portionDisplay: string;
  energyKcal: NutrientDisplayValue;
  syncStatus: 'confirmed' | 'pending' | 'failed';
};
```

Só registros confirmados podem aparecer como persistidos. Se a aplicação já exibir operações pendentes, precisam continuar visualmente identificadas como pendentes; não inventar confirmação.

---

# 8. Dados nutricionais e TBCA — regras da camada de apresentação

## 8.1 Separação de responsabilidades

O componente Cardápios não é o motor TBCA.

- A associação de alimentos é realizada no domínio.
- A recuperação de nutrientes é realizada no domínio/repositório.
- A conversão de unidades é realizada em uma camada aprovada.
- O cálculo da receita é realizado fora do componente visual.
- O componente recebe o resultado normalizado e a proveniência necessária.

Não alterar a semântica da TBCA para facilitar uma tabela visual.

## 8.2 Ordem obrigatória das primeiras colunas

| Ordem | Campo | Unidade/apresentação |
|---:|---|---|
| 1 | Alimento | Nome do alimento |
| 2 | Quantidade | Quantidade usada na receita |
| 3 | kcal | Quilocalorias |
| 4 | Proteínas | g |
| 5 | Carboidratos | g |
| 6 | Gorduras | g |

Não mostrar kJ. Não mover energia para depois de todos os macros. A ordem visual acima é imutável na matriz.

## 8.3 Ordem obrigatória dos grupos adicionais

| Ordem | Grupo | Campos permitidos |
|---:|---|---|
| 1 | Composição centesimal | Umidade, cinzas, álcool |
| 2 | Carboidratos detalhados | Açúcares, fibras, amido, carboidratos disponíveis e demais campos disponíveis |
| 3 | Aminoácidos | Aminoácidos individuais disponíveis |
| 4 | Lipídios | Saturados, monoinsaturados, poli-insaturados, trans e ácidos graxos individuais |
| 5 | Esteróis | Colesterol e outros esteróis disponíveis |
| 6 | Vitaminas | Vitaminas e componentes individuais disponíveis |
| 7 | Minerais | Elementos minerais disponíveis |
| 8 | Carotenoides | Compostos individuais disponíveis |
| 9 | Flavonoides e bioativos | Compostos individuais disponíveis na fonte |
| 10 | Índices funcionais | Índice glicêmico, carga glicêmica e classificações disponíveis |
| 11 | Componentes adicionados | Açúcares, gorduras e sal adicionados, conforme disponibilidade |
| 12 | Outros | Campos adicionais realmente existentes na fonte |

- Não alterar a ordem por locale, ordenação automática ou nome.
- Não criar coluna para nutrientes não retornados pela fonte.
- Não decompor valores agregados em compostos individuais inexistentes.
- Preservar nome/unidade de origem quando não houver normalização aprovada.
- Não acrescentar colunas decorativas.

## 8.4 Estados de célula — nunca colapsar em zero

| Status | Apresentação sugerida | Significado |
|---|---|---|
| `measured` | Valor formatado + unidade | Valor quantificado |
| `true-zero` | `0` + unidade | Zero explícito real |
| `trace` | `Traços` | Presença residual |
| `not-detected` | `Não detectado` | Abaixo do limite/estado da fonte |
| `not-analyzed` | `Não analisado` | Campo sem análise |
| `not-in-source` | `—` com explicação acessível | Não fornecido pela fonte |
| `not-applicable` | `N/A` com explicação acessível | Não aplicável |
| `withheld` | `Indisponível` | Valor indisponível/restrito |

O estado deve existir no objeto de dados, não ser deduzido a partir de string vazia.

## 8.5 Formatação numérica

- Locale padrão `pt-BR`, respeitando o locale do produto se existir.
- Formatar com `Intl.NumberFormat` em camada de apresentação.
- Nunca usar valor formatado como entrada de novo cálculo.
- Não arredondar cumulativamente.
- Não exibir casas decimais sem justificativa da precisão.
- Preservar precisão necessária para valores pequenos.
- Mostrar unidade de maneira consistente no cabeçalho ou célula conforme o design aprovado.
- O componente não decide precisão analítica nem altera unidade da fonte.

## 8.6 Totais por receita

Os macros do cabeçalho são os totais que vêm do domínio. A UI apenas formata.

- Não somar macros a partir de valores parciais da matriz durante render.
- Não calcular kcal a partir de macros na camada visual.
- Não corrigir diferenças entre nutrientes e energia por heurística local.
- Não somar campos que não sejam aditivos.
- Se o domínio sinalizar dados parciais, respeitar o indicador de completude e não apresentar como cálculo completo.

---

# 9. Fotografia da receita — implementação nativa premium

## 9.1 Tecnologia

Usar `expo-image` como escolha principal. A documentação atual descreve suporte a cache de memória e disco, formatos de imagem e transições entre fontes; em iOS utiliza SDWebImage e em Android Glide.

## 9.2 Regras visuais

- A fotografia permanece antes do título.
- Manter largura, altura, ratio, bordas e posição aprovados.
- `contentFit="cover"` para preservar o enquadramento sem distorção.
- Não aplicar overlay escuro, filtro, saturação artificial, blur, glow ou moldura cromada.
- Não deformar a proporção.
- Não deslocar conteúdo quando a imagem carregar.
- Reservar espaço no layout com as dimensões atuais antes do request.
- Fallback deve ocupar exatamente o mesmo espaço da foto.
- Se a imagem não existir, manter a estrutura e apresentar o placeholder aprovado; não puxar automaticamente imagem genérica de outro alimento.

## 9.3 Cache e carregamento

- Cache padrão em disco para imagens remotas, conforme política do Expo Image.
- Usar `cacheKey` versionada quando o conteúdo de uma imagem mudar sem mudar URI.
- Não usar cache de memória para todas as fotografias de alta resolução sem orçamento.
- Não prefetch da biblioteca inteira; priorizar imagens das próximas receitas dentro de limite de concorrência.
- Configurar um orçamento finito de cache em disco no iOS por `Image.configureCache({ maxDiskSize })`; a documentação atual indica que o cache de disco iOS não possui limite padrão. Escolher o tamanho após medir o peso médio das fotos e o orçamento total de armazenamento. Não assumir que Android e iOS aplicam a mesma política: no Android, a documentação descreve limite LRU padrão de cerca de 250 MB.
- Respeitar cancelamento/liberação de recursos quando a tela desmontar.
- `onError` deve falhar silenciosamente para o usuário, mantendo placeholder; registrar telemetria sem URL com token ou dado sensível.
- Não pré-carregar imagens fora de viewport indiscriminadamente.

## 9.4 Formatos e pipeline

- Preferir AVIF ou WebP onde o suporte real de decoder do conjunto alvo estiver validado.
- Manter JPEG como fallback amplo para fotografia.
- Manter dimensões coerentes com o viewport e DPR; não servir imagem 4K em miniatura.
- Remover metadados EXIF desnecessários no pipeline de publicação, preservando orientação.
- Variantes de tamanho precisam manter crop consistente para não alterar composição visual entre aparelhos.
- Verificar qualidade perceptual das fotos de alimentos; não usar compressão tão alta que destrua textura.

---

# 10. Cabeçalho da receita

## 10.1 Foto e título

- A foto continua antes do título.
- O título usa `textPrimary`.
- Preservar tipografia, peso, altura de linha e alinhamento já aprovados.
- Não usar caps lock forçado se o conteúdo original não usar.
- Limitar truncamento apenas se já existir regra aprovada; preferir quebra de linha sem sobreposição.

## 10.2 Macros

Ordem: `Prot. · Gord. · Carb. · kcal`.

- Valores formatados antes do render ou por formatter puro.
- Números alinhados por largura de dígito, usando fonte com tabular figures quando disponível.
- Não separar macros em chips ou caixas novas.
- Não mover macros para a linha do título se atualmente estiverem no canto superior direito.
- Não reduzir a legibilidade para forçar uma única linha em telas estreitas; aplicar comportamento responsivo já previsto no layout mantendo ancoragem superior direita.
- Unidades permanecem claras.
- `null` não vira `0`.

## 10.3 Estado incompleto

Quando uma macro estiver indisponível, renderizar o estado de ausência aprovado, sem deslocar as outras macros. Não ocultar um macro se isso alterar a geometria de todo o cabeçalho sem baseline que justifique.

---

# 11. `Ver mais →` e expansão da matriz

## 11.1 Estado independente por receita

Cada receita mantém seu estado independente.

```ts
type RecipeExpansionState = Record<string, boolean>;
```

Se a tela renderiza um número pequeno de receitas, manter estado local no componente pai/gerenciador do Cardápios. Não usar Zustand apenas para isso.

Regras:

- `recipeId` é a chave do estado.
- Abrir a matriz de uma receita não fecha outra, salvo se isso já for comportamento funcional aprovado.
- Fechar uma matriz não altera outras.
- O estado inicial de todas é `false`.
- Estado da UI não é persistido no banco por padrão.
- A remoção de uma receita deve remover a chave do conjunto de expansão sem afetar IDs restantes.

## 11.2 Controle acessível

Usar `Pressable`.

- `accessibilityRole="button"`.
- `accessibilityLabel` descritivo, incluindo o título da receita quando necessário.
- `accessibilityState={{ expanded: isExpanded }}`.
- `accessibilityHint` descreve que a matriz nutricional será exibida/ocultada.
- O estado visual não depende apenas da cor.
- Não usar `onPress` no container inteiro da receita; apenas no controle existente.
- Evitar conflito com rolagem vertical/horizontal.

## 11.3 Animação Reanimated

Uma expansão simples deve utilizar o menor custo possível.

- Duração de referência ao abrir: 160–220 ms.
- Ao fechar: 140–190 ms.
- Curva `Easing.out(Easing.cubic)` ao abrir e `Easing.inOut(Easing.cubic)` ao fechar, calibrada em aparelho físico.
- Animar apenas a altura medida e opacidade, com `overflow: 'hidden'` na área da matriz.
- Medir conteúdo em estado de layout não visível/medição controlada; não inventar altura fixa.
- Não usar `withSpring` elástico exagerado para tabela.
- Não animar todas as células individualmente.
- Não iniciar animação quando `reduceMotion` estiver ativo.
- Garantir que o conteúdo aberto seja acessível para leitor de tela depois da transição.
- Não atrasar foco/acesso até uma animação longa terminar.

A implementação deve escolher uma única estratégia de expansão; não combinar `LayoutAnimation`, Reanimated, Moti e uma animação manual ao mesmo tempo.

## 11.4 Redução de movimento

Respeitar o recurso de redução de movimento do sistema. Quando ativo, abrir/fechar sem transição animada ou com transição mínima não essencial, mantendo a mesma estrutura e função.

---

# 12. Ingredientes

- Ingredientes permanecem visíveis no estado fechado.
- Ordem vem do domínio.
- Quantidade, unidade e nome não podem se separar visualmente.
- Não criar card por ingrediente.
- Não esconder ingredientes sob o disclosure.
- Não inferir quantidades.
- Quando houver ingrediente sem quantidade, apresentar o estado conforme domínio, sem preencher `0` ou criar `a gosto` automaticamente.
- Manter chaves estáveis por `ingredientId`.
- Atualizar somente a linha/receita afetada quando a quantidade mudar, não forçar render de todos os cardápios.

---

# 13. Matriz TBCA — arquitetura de tabela nativa

## 13.1 Estrutura visual

A matriz abre dentro da própria receita e utiliza a região existente. Não criar um painel externo.

A ordem das primeiras colunas é invariável:

1. Alimento
2. Quantidade
3. kcal
4. Proteínas (g)
5. Carboidratos (g)
6. Gorduras (g)

Depois, grupos adicionais na ordem da seção 8.3.

## 13.2 Primitivas nativas

- Cabeçalho geral e subcabeçalhos: `View` + `Text`.
- Linha de nutriente/alimento: `View` com colunas de largura calculada.
- Rolagem horizontal: `ScrollView horizontal` dentro da região da matriz.
- Rolagem vertical: usar rolagem principal da tela ou scroll interno existente; evitar scroll vertical aninhado se não houver necessidade.
- `nestedScrollEnabled` apenas quando o cenário Android exigir e tiver sido testado.
- Não depender de CSS `position: sticky`, `colSpan`, `table-layout` ou DOM semantics.

## 13.3 Larguras de coluna

- `Alimento` possui largura mínima suficiente para leitura do nome sem comprimir quantidade.
- `Quantidade` mantém unidade e número próximos.
- Colunas numéricas possuem largura constante por grupo para permitir comparação vertical.
- Colunas não se redimensionam individualmente conforme cada valor, pois isso faz números saltarem entre linhas.
- A largura total deve permitir rolagem horizontal sem encolher texto a ponto de perder leitura.
- A primeira coluna fixa e a coluna de quantidade fixa são opcionais; só implementar com sincronização de scroll validada em iOS e Android. Default: tabela inteira rola horizontalmente como um único conteúdo.

## 13.4 Cabeçalho de grupo

- `colSpan` lógico é representado por uma View com largura igual à soma das colunas do grupo.
- Não criar cartões por grupo.
- Cabeçalho de grupo usa `textSecondary`/`textPrimary` segundo importância.
- Borda horizontal fina; fundo opaco.
- Não usar fundo colorido distinto para cada grupo.

## 13.5 Acessibilidade no React Native

React Native não fornece uma tabela HTML nativa com a semântica completa de `table`, `thead`, `tbody`, `tr`, `th` e `td`. A implementação deve compensar isso explicitamente:

- Dar `accessibilityRole="header"` aos cabeçalhos quando a plataforma suportar.
- Criar rótulos descritivos para linhas/valores importantes.
- Preservar ordem de foco de leitura: alimento → quantidade → energia → proteínas → carboidratos → gorduras → campos adicionais.
- Evitar uma célula com `accessible={true}` que esconda todos os filhos sem fornecer um rótulo completo.
- Quando uma linha inteira for agrupada como um único elemento acessível, o `accessibilityLabel` deve incluir alimento, quantidade e valores relevantes.
- Não marcar conteúdo decorativo como acessível.
- Testar VoiceOver e TalkBack manualmente.

## 13.6 Sticky columns e sincronização

Não habilitar sticky first columns na primeira entrega. A sincronização horizontal entre uma parte fixa e uma parte móvel cria risco de desalinhamento de alturas, linhas, acessibilidade e gesto.

Só implementar se um teste de usabilidade demonstrar que o usuário perde contexto sem isso. O piloto deve provar:

- Mesma altura de linha nas duas regiões.
- Scroll sincronizado sem atraso.
- Nenhum flicker ao voltar ao início.
- Sem interceptar gestos verticais.
- Sem foco fora da ordem.
- Sem clipping em iPhone pequeno e Android de baixa densidade.

## 13.7 Virtualização da matriz

A matriz de uma receita normalmente contém poucas linhas de ingredientes e muitas colunas nutricionais. Portanto, a primeira versão deve evitar virtualização de célula.

- Montar a matriz quando abrir.
- Desmontar ao fechar se a tabela for pesada e não houver estado de interação para preservar.
- Manter dados view model em memória para reabrir sem recalcular.
- Não instanciar dezenas/centenas de elementos desnecessários antes da expansão.
- Virtualizar somente se profiling com dados reais demonstrar problema.

---

# 14. Receita e Preparo

- Permanecer na parte inferior da mesma receita.
- Preservar texto, posição, dimensões e aparência aprovados.
- Usar Mineral Satin Enamel.
- `Pressable` com estado pressed/focused.
- Não inserir novo botão duplicado.
- Não inventar nova rota, modal, sheet ou accordion.
- Acionar o comportamento que já existe no produto.
- Se o fluxo abrir outra tela, preservar rota e contrato atuais.
- Etapas sequenciais devem ser lidas em ordem.
- Não transformar cada passo em mini-card.
- Se preparo estiver ausente, apresentar estado de ausência definido pelo produto; não inventar instruções.

---

# 15. Histórico de refeições

- Permanece abaixo de todos os cardápios.
- Preservar o formato atual de tabela/lista.
- Não introduzir filtros, gráficos, agrupamentos extras, tabs ou nova navegação.
- Chave estável por `mealId`.
- Datas e horários formatados por locale.
- Não marcar operação como confirmada antes da persistência/acknowledgment correspondente.
- Se houver estado pendente, apresentar visualmente sem fingir que é definitivo.
- Se for lista pequena, usar `ScrollView`/`SectionList` nativo.
- Se for extensa, perfilar e então avaliar FlashList v2.
- Não criar uma lista virtualizada aninhada em outra sem provar que rolagem, foco e performance funcionam.

---

# 16. Arquitetura de estado e dados

## 16.1 Princípio

A tela recebe snapshot normalizado. O componente não é proprietário da verdade nutricional.

- Dados remotos: TanStack Query, se utilizado pelo app.
- Estado global compartilhado: Zustand, apenas se necessário.
- Expansão de matriz: estado local.
- Persistência: repositório/SQLite da aplicação.
- Formatação: funções puras de apresentação.
- Cálculo: domínio nutricional.

## 16.2 Evitar

- Store global para cada linha de tabela.
- Query HTTP dentro de `RecipeCard`.
- SQL dentro de `NutritionMatrix`.
- Cálculo de energia dentro de render.
- Mutar dados de TBCA ao exibir.
- Guardar número formatado como número de domínio.
- `useEffect` que recalcula dados derivados a cada render.
- Fazer o componente observar o dashboard inteiro se só utiliza uma receita.

## 16.3 Atualização otimista

Se a tela tiver ação de registrar refeição/quantidade:

- Atualizar UI apenas pelo fluxo existente.
- Marcar estado pendente se a operação ainda não confirmou.
- Fazer rollback visual em erro quando houver optimistic update.
- Não sobrescrever um registro mais recente com resposta atrasada.
- Não duplicar histórico por retries.
- Garantir idempotência no serviço de domínio.

---

# 17. Performance mobile e robustez

## 17.1 Não usar GPU para superfícies opacas

A materialidade aprovada é baseada em cores sólidas, bordas discretas e tipografia. Não há razão para criar um canvas Skia, um contexto WebGL ou um renderer 3D para cada receita.

O custo gráfico deve ficar próximo de Views nativas comuns.

## 17.2 Renderização React

- Passar props específicas para cada subcomponente.
- Usar `React.memo` somente em componentes comprovadamente afetados por renders repetidos.
- Estabilizar `renderItem`, callbacks e arrays derivados quando necessário.
- Não criar objetos/arrays complexos em cada célula a cada render.
- Não colocar todos os `recipes` e todos os nutrientes em uma store global.
- Separar `recipeId`, `ingredientId` e `nutrientId` para keys.
- Não usar índice de array como key.
- Não fazer parsing de dados TBCA durante render.

## 17.3 Imagens e memória

- Servir imagens na resolução apropriada ao frame atual e DPR.
- Não usar imagens gigantes para thumbnail.
- Configurar cache policy por tipo de asset.
- Limitar prefetch.
- Não carregar fotos de cardápios fora da janela sem necessidade.
- Preservar espaço de layout antes do load.
- Testar memory warning no iOS e pressão de memória Android.

## 17.4 Scroll e listas

- Preferir uma única rolagem vertical principal.
- Matriz usa scroll horizontal interno.
- Evitar ScrollView vertical dentro de ScrollView vertical.
- Se for usar lista virtualizada, manter um único dono do eixo vertical.
- Não ativar `removeClippedSubviews` sem testar conteúdo expandido e acessibilidade.
- Confirmar que abrir uma matriz não salta o scroll para o topo.
- Confirmar que o item expandido permanece visível e não muda a posição de outras receitas de forma inesperada.

## 17.5 Metas de engenharia

Metas iniciais, a confirmar por benchmark em dispositivos reais:

- 60 FPS sustentados durante scroll e disclosure em aparelhos de referência.
- Nenhuma queda prolongada de frame ao abrir matriz de tamanho normal.
- Nenhum bloqueio do JS por parse, cálculo de nutrientes ou processamento de imagem.
- Nenhum layout shift ao carregar fotografia.
- Matriz fechada não monta suas células.
- Nenhuma imagem fora de viewport é carregada em massa.
- Nenhum crash por memória em navegação repetida.
- Tempo de toque percebido imediato; ação não deve esperar animação terminar.

Metas não são benchmarks medidos. Registrar baselines e comparar antes/depois.

---

# 18. Acessibilidade mobile

## 18.1 Pressable / ações

- `accessibilityRole="button"`.
- `accessibilityLabel` com verbo e destino/resultado.
- `accessibilityHint` somente quando acrescentar informação.
- `accessibilityState.disabled` quando aplicável.
- `accessibilityState.expanded` para `Ver mais →`.
- Focus/pressed state perceptível sem depender apenas da cor.
- Hit target adequado à recomendação Apple/Android; usar `hitSlop` sem reposicionar visualmente.

## 18.2 Tipografia

- Respeitar escala de fonte do sistema.
- Não truncar informação nutricional essencial.
- Macros podem reduzir apenas até o limite testado; não usar tamanho ilegível para caber em uma linha.
- Valores tabulares podem usar `fontVariant: ['tabular-nums']` quando compatível com fonte/plataforma, validando renderização.
- Fonte customizada deve ter licença comercial e pesos realmente disponíveis.

## 18.3 Contraste

Revalidar pares WCAG com o valor final, incluindo disabled, pressed e foco. Borda de baixa intensidade não deve ser a única forma de identificar o estado.

## 18.4 VoiceOver e TalkBack

Executar testes manuais para:

- Ler cabeçalho da receita.
- Ler macros na ordem correta.
- Abrir e fechar `Ver mais →`.
- Navegar na matriz sem perder alimento/unidade.
- Ler quantidade e nutrientes.
- Retornar ao cabeçalho.
- Ativar Receita e Preparo.
- Navegar pelo histórico.

Não usar uma única label gigantesca em todo o cardápio. Agrupar apenas quando isso melhorar leitura e não eliminar acesso a subelementos importantes.

---

# 19. Testes obrigatórios

## 19.1 Unitários e componentes — Jest + React Native Testing Library

Cobrir:

- Foto antes do título.
- Macros no canto superior direito representado pela mesma hierarquia/alinhamento.
- Ordem `Prot. · Gord. · Carb. · kcal`.
- `Ver mais →` associado à receita correta.
- Matriz recolhida inicialmente.
- Abrir uma matriz sem alterar a expansão das outras.
- Fechar matriz sem alterar outras.
- Ingredientes visíveis quando matriz fechada.
- `Receita e Preparo` na parte inferior.
- Histórico depois de todos os cardápios.
- Ausência não convertida em zero.
- `true-zero`, `trace`, `not-detected`, `not-analyzed`, `not-in-source`, `not-applicable` exibidos corretamente.
- Ordem fixa de colunas.
- Ausência de coluna kJ.
- `recipeId`, `ingredientId` e `nutrientId` como keys.
- Imagem sem URI não quebra layout.
- Falha de imagem exibe placeholder no mesmo espaço.
- `accessibilityState.expanded` atualizado.

## 19.2 E2E — Maestro

Fluxos obrigatórios:

1. Abrir Cardápios.
2. Percorrer Cardápio A e Cardápio B.
3. Verificar foto, título e macros de uma receita.
4. Abrir a matriz dessa receita.
5. Rolar horizontalmente para grupos adicionais.
6. Fechar matriz.
7. Abrir matriz de outra receita sem perda de estado indevida.
8. Acionar Receita e Preparo.
9. Rolar até Histórico de Refeições.
10. Navegar com escala de fonte ampliada.

Executar em Android e iOS, emuladores/simuladores e pelo menos um aparelho físico de cada plataforma antes de release.

## 19.3 Regressão visual

Capturar:

- Tela inicial do componente com todos os cardápios recolhidos.
- Cada cardápio com duas ou mais receitas.
- Uma matriz aberta.
- Uma matriz aberta com scroll horizontal deslocado.
- Estado pressed do botão.
- Falha de carregamento da fotografia.
- Histórico com registros suficientes para rolagem.

Comparar com baseline do layout aprovado. O teste visual deve detectar mudanças em posição, dimensões, ordem e cores; aceitar diferenças de antialiasing nativo que não modifiquem a estrutura.

## 19.4 Matriz de dispositivos

No mínimo:

- iPhone compacto/menor viewport compatível.
- iPhone atual de viewport maior.
- Android intermediário com memória limitada.
- Android popular com densidade de tela comum.
- Android premium.
- Tablet, se estiver no escopo real do app.

Não inferir compatibilidade apenas de simuladores.

---

# 20. Debug — diagnóstico por sintoma

## 20.1 Superfície parece plana demais

Verificar nesta ordem:

1. Cor de base corresponde ao token correto?
2. A borda está sendo aplicada no contêiner existente?
3. O fundo ao redor tem contraste previsto?
4. A superfície recebeu sombra/elevation não aprovada?
5. O dispositivo está aplicando cor alpha inadvertida?

Não corrigir adicionando gradiente, textura, blur ou brilho.

## 20.2 Parece um conjunto de caixas empilhadas

1. Verificar wrappers adicionais criados na migração.
2. Remover bordas duplicadas.
3. Garantir que ingredientes/macros não ganharam cards próprios.
4. Confirmar que matriz herda a superfície aprovada e não cria painel externo.
5. Rever sombra e radius sem mudar o layout aprovado.

## 20.3 Imagem pisca ou desloca conteúdo

1. Confirmar width/height fixos do frame antes do load.
2. Confirmar `cacheKey` consistente.
3. Comparar `expo-image` cachePolicy e transition.
4. Desativar crossfade em cache hit quando não agrega valor.
5. Confirmar URL/versão do asset.
6. Garantir placeholder sólido.

## 20.4 Expansão salta o scroll

1. Verificar medição inicial e altura alvo.
2. Garantir que a matriz é filha da região da receita já existente.
3. Evitar `ScrollView` vertical interno.
4. Conferir `maintainVisibleContentPosition` se usado em lista virtualizada.
5. Medir antes e depois em aparelho real.
6. Não alterar posição do trigger.

## 20.5 Matriz horizontal fica desalinhada

1. Conferir largura fixa por coluna.
2. Conferir unidade e formatter.
3. Confirmar que cabeçalho usa soma de largura das colunas.
4. Não deixar texto determinar largura de cada célula.
5. Confirmar que todos os rows usam a mesma definição de colunas.
6. Desabilitar sticky split se a sincronização não for perfeita.

## 20.6 Texto pequeno falha contraste

1. Recalcular par exato com cor final.
2. Substituir foreground apenas pelo token aprovado adequado.
3. Não clarear todas as superfícies.
4. Testar em modo de alto contraste se houver suporte.

## 20.7 App trava ao abrir/fechar várias receitas

1. Confirmar que uma expansão não recalcula o snapshot inteiro.
2. Garantir estado de expansão por ID.
3. Desmontar matriz fechada se necessário.
4. Memoizar `NutritionMatrix` apenas após medir re-render.
5. Reduzir montagem de células invisíveis.
6. Conferir image memory e listas aninhadas.

---

# 21. Plano de execução por fases

## Fase 0 — auditoria do app e baseline

- Inspecionar `package.json`, lockfile e estrutura atual.
- Confirmar se o componente será implementado no app mobile nativo ou se existe apenas versão web.
- Confirmar Expo SDK, React Native, React, Hermes, New Architecture e módulos nativos atuais.
- Localizar componente Cardápios atual e styles.
- Localizar origem das receitas, imagens, macros, ingredientes, TBCA e histórico.
- Capturar screenshots em iOS/Android ou, se ainda não existir app nativo, capturar baseline Web e registrar que o port mobile ainda será necessário.
- Não migrar o projeto inteiro nesta fase.

**Gate:** inventário do que existe, mapa de dependências e baseline do layout.

## Fase 1 — alinhamento da fundação mobile

- Confirmar RN/Expo suportados.
- Confirmar New Architecture.
- Configurar development builds.
- Confirmar Reanimated/Worklets compatíveis.
- Confirmar Gesture Handler apenas se for necessário.
- Confirmar build Release em Android e iOS.

**Gate:** build nativo limpo antes de alterar o componente.

## Fase 2 — tokens e materiais

- Implementar os tokens exatos.
- Mapear quatro acabamentos para estilos nativos.
- Aplicar em wrappers já existentes.
- Preservar dimensões.
- Validar contraste.

**Gate:** screenshot de superfícies aprovado sem alterar layout.

## Fase 3 — imagem e cabeçalho

- Integrar `expo-image`.
- Preservar o espaço e posição da foto.
- Implementar placeholder sem blur.
- Preservar título e macros.
- Validar ordem e tabular figures.

**Gate:** foto, título e macros equivalentes ao layout aprovado.

## Fase 4 — ingredientes e estado local

- Tipar view models.
- Reutilizar dados do domínio.
- Garantir ingredientes visíveis.
- Criar estado independente de expansão por `recipeId`.

**Gate:** estado inicial e independência por receita corretos.

## Fase 5 — matriz TBCA nativa

- Implementar tabela de Views.
- Aplicar ordem fixa das seis primeiras colunas.
- Aplicar grupos adicionais na ordem aprovada.
- Implementar scroll horizontal interno.
- Mapear status de dados sem transformá-los em zero.
- Acessibilidade e leitura de linha.

**Gate:** matriz correta em iOS e Android com amostra TBCA representativa.

## Fase 6 — animação e histórico

- Implementar disclosure com Reanimated se necessário.
- Respeitar redução de movimento.
- Preservar posição do scroll.
- Validar Receita e Preparo.
- Integrar Histórico de Refeições abaixo dos cardápios.

**Gate:** fluxo completo sem quebra de layout.

## Fase 7 — performance, acessibilidade e release

- Profiling em aparelhos reais.
- Benchmark de scroll e expansão.
- Testar memória/imagens.
- Testar TalkBack/VoiceOver.
- Testes RNTL e Maestro.
- Revisão de licenças e build de produção.

**Gate:** todos os critérios de aceite atendidos.

---

# 22. Critérios finais de aceite

## 22.1 Layout — bloqueante

- [ ] Não foram criadas áreas novas.
- [ ] Não foi alterada a ordem dos cardápios.
- [ ] Cardápio A e B mantêm agrupamento.
- [ ] Foto continua antes do título.
- [ ] Macros continuam no canto superior direito.
- [ ] Ordem Prot. · Gord. · Carb. · kcal permanece.
- [ ] `Ver mais →` continua no canto inferior direito do cabeçalho.
- [ ] Ingredientes continuam visíveis no estado fechado.
- [ ] Matriz TBCA começa fechada.
- [ ] A matriz abre dentro da própria receita.
- [ ] Receita e Preparo permanece na parte inferior.
- [ ] Histórico permanece abaixo de todos os cardápios.
- [ ] Não há cards de alimentos/células.
- [ ] Não há nova barra, filtro, painel ou grupo.

## 22.2 Materiais

- [ ] Obsidian Ceramic Hardcoat é opaco e uniforme.
- [ ] Satin Graphite é opaco e micro-satin sem textura visível.
- [ ] Anti-glare Graphite Display é opaco e legível.
- [ ] Mineral Satin Enamel é Sage sólido.
- [ ] Não existe glassmorphism.
- [ ] Não existe blur.
- [ ] Não existe glow permanente.
- [ ] Não existe metal cromado decorativo.
- [ ] Não existe textura bitmap repetitiva.
- [ ] Sombras não são empilhadas.

## 22.3 Imagens

- [ ] Imagem preserva ratio e crop.
- [ ] Placeholder ocupa o mesmo espaço.
- [ ] Não há layout shift.
- [ ] Cache está configurado.
- [ ] Nenhum filtro artificial altera comida.

## 22.4 Dados

- [ ] Macros vêm do domínio.
- [ ] Ordem das colunas está correta.
- [ ] kJ não aparece.
- [ ] Unidades estão preservadas.
- [ ] Zero real é diferente de ausência.
- [ ] Traços são distintos de zero.
- [ ] Não analisado é diferente de não detectado.
- [ ] Campos sem fonte não são inventados.
- [ ] Valores formatados não retornam para cálculos.

## 22.5 Mobile e acessibilidade

- [ ] Compila em iOS Release.
- [ ] Compila em Android Release.
- [ ] Reanimated/Worklets seguem matriz de compatibilidade.
- [ ] VoiceOver consegue navegar e expandir.
- [ ] TalkBack consegue navegar e expandir.
- [ ] Fonte ampliada não causa sobreposição.
- [ ] Gestos de scroll não são interceptados pelo trigger.
- [ ] Redução de movimento é respeitada.

## 22.6 Performance

- [ ] Scroll sem stutter prolongado.
- [ ] Expansão não renderiza todas as receitas de novo.
- [ ] Matriz fechada não monta milhares de células.
- [ ] Imagens são carregadas sob demanda.
- [ ] Nenhum renderer 3D é inicializado por este componente.
- [ ] Uso de memória foi medido em aparelhos reais.

---

# 23. Licenciamento e comercialização

Antes de copiar código ou incorporar dependências:

- Registrar nome, URL, versão, commit, licença e função de cada dependência.
- Verificar licença transitiva e assets incluídos.
- Não presumir que arquivos de conteúdo seguem a licença do repositório de código.
- Não copiar imagens de receitas, fontes, ícones ou datasets sem licença apropriada.
- Preservar avisos MIT/Apache exigidos.
- Revisar GPL/AGPL antes de integrar código de aplicações de receita.

Os repositórios de referência Mealie, Tandoor e OpenNutriTracker foram escolhidos por estrutura funcional, não como autorização para copiar seus componentes. Reutilizar padrões de informação e arquitetura; implementar código próprio ou revisar juridicamente cada trecho antes de transportar.

Para as dependências escolhidas, manter inventário atualizado. As licenças reportadas pelos próprios repositórios consultados incluem MIT para React Native, Expo, Reanimated, Gesture Handler, Skia, SVG, FlashList, Legend List, Zustand, TanStack e RNTL; Maestro declara Apache-2.0. Confirmar a licença da versão exata no momento de instalar.

---

# 24. Instrução final para o agente de código

Implemente este componente no runtime mobile React Native, respeitando o layout congelado.

Antes de alterar arquivos:

1. Faça inventário do repositório real.
2. Identifique se o Cardápios já está em React Native ou se só existe implementação Web.
3. Identifique componentes, tokens, estado, fontes e serviços já existentes.
4. Não duplicar infraestrutura que o app já possui.
5. Não atualizar a stack inteira como parte da tarefa do componente sem decisão arquitetural separada.
6. Reconciliar os tipos de exemplo com o domínio verdadeiro.
7. Criar baseline visual.

Durante a implementação:

- Não alterar layout.
- Não alterar paleta.
- Não adicionar novos grupos/áreas.
- Não instalar biblioteca sem demonstrar necessidade.
- Não fazer consulta ou cálculo nutricional dentro da UI.
- Não usar zero para dado ausente.
- Não incluir renderer 3D/WebGPU/Filament/Three.js no Cardápios.
- Não aplicar blur, transparência ou glassmorphism.
- Preservar a fotografia natural.
- Manter a expansão da matriz por receita.
- Preservar ordem e unidades TBCA.
- Criar testes junto com a implementação.

Não remover código legado sem análise de referências, dependências e testes. Se algum detalhe de layout da implementação atual divergir do documento de referência, não decidir unilateralmente: registrar a divergência e preservar o contrato aprovado.

**Definição de pronto:** o Cardápios original, com o mesmo layout, executado como componente mobile nativo, com quatro materiais opacos refinados, fotografia de alimentos natural, matriz TBCA fiel aos dados, expansão acessível por receita e performance estável em aparelhos reais.

---

# 25. Referências — documentação e repositórios

## 25.1 Documentação oficial

- [Expo SDK 58](https://expo.dev/sdk/58)
- [Expo SDK 58 changelog](https://expo.dev/changelog/sdk-58)
- [Expo New Architecture](https://docs.expo.dev/guides/new-architecture/)
- [Expo Image](https://docs.expo.dev/versions/latest/sdk/image/)
- [React Native](https://reactnative.dev/docs/getting-started)
- [Reanimated 4 compatibility](https://docs.swmansion.com/react-native-reanimated/docs/guides/compatibility/)
- [Reanimated getting started](https://docs.swmansion.com/react-native-reanimated/docs/fundamentals/getting-started/)
- [Gesture Handler compatibility](https://docs.swmansion.com/react-native-gesture-handler/docs/fundamentals/installation/)
- [FlashList v2 migration](https://github.com/Shopify/flash-list/blob/main/documentation/docs/v2-migration.md)
- [TanStack Table overview](https://tanstack.com/table/latest/docs/overview)
- [WCAG 2.2](https://www.w3.org/TR/WCAG22/)

## 25.2 Repositórios — aplicação/arquitetura

- [React Native](https://github.com/facebook/react-native)
- [Expo](https://github.com/expo/expo)
- [Tamagui](https://github.com/tamagui/tamagui)

## 25.3 Repositórios — design system

- [React Native Paper](https://github.com/callstack/react-native-paper)
- [Tamagui](https://github.com/tamagui/tamagui)
- [NativeWind](https://github.com/nativewind/nativewind)

## 25.4 Repositórios — animação/gestos

- [React Native Reanimated](https://github.com/software-mansion/react-native-reanimated)
- [React Native Gesture Handler](https://github.com/software-mansion/react-native-gesture-handler)
- [Moti](https://github.com/nandorojo/moti)

## 25.5 Repositórios — renderização 2D

- [React Native Skia](https://github.com/wcandillon/react-native-skia)
- [React Native SVG](https://github.com/software-mansion/react-native-svg)
- [Three.js](https://github.com/mrdoob/three.js)

## 25.6 Repositórios — imagens

- [Expo Image](https://github.com/expo/expo/tree/main/packages/expo-image)
- [React Native Fast Image](https://github.com/DylanVann/react-native-fast-image)
- [React Native](https://github.com/facebook/react-native)

## 25.7 Repositórios — listas

- [FlashList](https://github.com/Shopify/flash-list)
- [RecyclerListView](https://github.com/Flipkart/recyclerlistview)
- [Legend List](https://github.com/LegendApp/legend-list)

## 25.8 Repositórios — tabelas

- [TanStack Table](https://github.com/TanStack/table)
- [React Native Paper](https://github.com/callstack/react-native-paper)
- [Material React Table](https://github.com/KevinVandy/material-react-table)

## 25.9 Repositórios — estado e dados

- [Zustand](https://github.com/pmndrs/zustand)
- [TanStack Query](https://github.com/TanStack/query)
- [Redux Toolkit](https://github.com/reduxjs/redux-toolkit)

## 25.10 Repositórios — testes

- [Maestro](https://github.com/mobile-dev-inc/Maestro)
- [Detox](https://github.com/wix/Detox)
- [React Native Testing Library](https://github.com/callstack/react-native-testing-library)

## 25.11 Referências de produto — receitas/nutrição

- [Mealie](https://github.com/mealie-recipes/mealie)
- [Tandoor Recipes](https://github.com/TandoorRecipes/recipes)
- [OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker)

**Observação sobre estrelas:** contagens são aproximações registradas durante a pesquisa em 26/11/2026. Podem variar. Revalidar estrelas, última atividade, licença, release, issues abertas e compatibilidade antes da adoção definitiva. A seleção técnica não é um ranking puro de estrelas.

---

# 26. Decisão final

A arquitetura correta para o **Cardápios mobile** é deliberadamente mais leve que a stack 3D global do aplicativo.

- React Native/Fabric fornece a superfície nativa.
- Expo organiza módulos, builds e distribuição.
- Reanimated controla a expansão e microinterações.
- Expo Image entrega fotografias com cache nativo.
- Views e Text nativos desenham os quatro materiais opacos.
- A matriz TBCA é uma tabela nativa sob medida, com scroll horizontal e sem conversão em cards.
- TanStack Query/Zustand/SQLite ficam nas camadas de dados do aplicativo, não dentro do componente.
- Skia fica opcional.
- Filament, Three.js, WebGPU e TypeGPU ficam fora deste componente porque não existe objeto 3D na especificação aprovada.

**Não confundir stack máxima com maior quantidade de bibliotecas.** Para este componente, máxima qualidade é obter acabamento consistente, tipografia nítida, foto natural, tabela precisa, expansão acessível e funcionamento estável em ampla variedade de aparelhos — sem modificar um único elemento do layout aprovado.
