import { useEffect, useId, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { useEscapeKey } from '../hooks/use-escape-key';

interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  animateOpen?: boolean;
  children: ReactNode;
}

const FOCUSABLE_SELECTOR = [
  'a[href]',
  'area[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',');

let activeModalCount = 0;
let previousBodyOverflow = '';

function lockBodyScroll(): () => void {
  if (activeModalCount === 0) {
    previousBodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
  }
  activeModalCount += 1;
  return () => {
    activeModalCount = Math.max(0, activeModalCount - 1);
    if (activeModalCount === 0) {
      document.body.style.overflow = previousBodyOverflow;
      previousBodyOverflow = '';
    }
  };
}

export function BottomSheet({
  open,
  onClose,
  title,
  subtitle,
  animateOpen = false,
  children,
}: BottomSheetProps) {
  const titleId = useId();
  const subtitleId = useId();
  const panelRef = useRef<HTMLElement | null>(null);
  useEscapeKey(open, onClose);

  useEffect(() => {
    if (!open) return;
    const panel = panelRef.current;
    if (!panel) return;

    const previouslyFocused = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null;
    const releaseScrollLock = lockBodyScroll();
    const focusableElements = () => Array.from(
      panel.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR),
    ).filter((element) => element.getAttribute('aria-hidden') !== 'true' && element.getClientRects().length > 0);

    const firstFocusable = focusableElements()[0];
    (firstFocusable ?? panel).focus();

    const containFocus = (event: KeyboardEvent) => {
      if (event.key !== 'Tab') return;
      const focusable = focusableElements();
      if (focusable.length === 0) {
        event.preventDefault();
        panel.focus();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const active = document.activeElement;
      if (event.shiftKey && (active === first || !panel.contains(active))) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && (active === last || !panel.contains(active))) {
        event.preventDefault();
        first?.focus();
      }
    };

    document.addEventListener('keydown', containFocus, true);
    return () => {
      document.removeEventListener('keydown', containFocus, true);
      releaseScrollLock();
      if (previouslyFocused?.isConnected) previouslyFocused.focus();
    };
  }, [open]);

  if (!open) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[var(--titan-bg-canvas)]/84 ${
        animateOpen ? 'animate-sheet-backdrop' : ''
      }`}
      onClick={onClose}
    >
      <section
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={subtitle ? subtitleId : undefined}
        tabIndex={-1}
        className={`w-full sm:max-w-lg bg-[var(--titan-surface-elevated)] border-t sm:border border-[var(--titan-border)]/85 shadow-[inset_0_1px_0_rgba(241,240,233,0.065),0_24px_48px_-16px_rgba(0,0,0,0.85)] rounded-t-3xl sm:rounded-2xl max-h-[85dvh] flex flex-col overflow-hidden focus:outline-none ${
          animateOpen ? 'animate-sheet-panel' : ''
        }`}
        onClick={(event) => event.stopPropagation()}
      >
        <div className="sm:hidden pt-3 pb-1 flex justify-center" aria-hidden="true">
          <div className="w-10 h-1 rounded-full bg-[var(--titan-text-secondary)]/30" />
        </div>
        <div className="flex items-start justify-between gap-4 px-5 py-4 border-b border-[var(--titan-border)]/70">
          <div className="min-w-0">
            <h2 id={titleId} className="text-base font-semibold text-[var(--titan-text-primary)] truncate">{title}</h2>
            {subtitle && (
              <p id={subtitleId} className="text-xs text-[var(--titan-text-secondary)] mt-0.5 truncate">{subtitle}</p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar painel"
            className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center rounded-xl text-[var(--titan-text-secondary)] shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 overflow-y-auto pb-safe">{children}</div>
      </section>
    </div>
  );
}
