import { useEffect, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';

export const TITAN_EASE = [0.22, 1, 0.36, 1] as const;

export const TITAN_DURATIONS = {
  press: 0.1,
  quick: 0.16,
  standard: 0.2,
  progress: 0.26,
  panel: 0.24,
} as const;

export function useTitanReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return;
    const query = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReduced(query.matches);
    const onChange = (event: MediaQueryListEvent) => setReduced(event.matches);
    query.addEventListener('change', onChange);
    return () => query.removeEventListener('change', onChange);
  }, []);

  return reduced;
}

export { AnimatePresence, MotionConfig, motion };
