import { useCallback, useMemo, useState } from 'react';
import { AnatomyViewport, type AnatomyStageIndicators } from '@/src/domains/anatomy/application/anatomy-public';
import {
  calculateWeightTrend,
  computeEvolutionCockpitIndicator,
  sortMeasurementsChronologically,
  useEvolutionStore,
} from '@/src/domains/evolution/application/evolution-public';
import {
  computeDayPlanSummary,
  computeNutritionTotals,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import { useProfileStore } from '@/src/domains/profile/application/profile-public';
import type { MuscleGroupId } from '@/src/shared/types/common';
import { EnergySummary } from '../components/EnergySummary';
import { ExerciseHydrationCalculator } from '../components/ExerciseHydrationCalculator';
import { HomeHeader } from '../components/HomeHeader';
import { HydrationSummary } from '../components/HydrationSummary';
import { MacroOverview } from '../components/MacroOverview';
import { MicronutrientSummary } from '../components/MicronutrientSummary';
import { NextMeal } from '../components/NextMeal';
import { TodayWorkout } from '../components/TodayWorkout';

interface CockpitScreenProps {
  onOpenTraining: () => void;
  onOpenTrainingPlans?: () => void;
  onOpenExerciseLibrary?: (muscleId?: MuscleGroupId) => void;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

export function CockpitScreen({
  onOpenTraining,
  onOpenTrainingPlans,
  onOpenExerciseLibrary,
  onOpenNutrition,
}: CockpitScreenProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const dailyGoals = useNutritionStore((s) => s.dailyGoals);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const profile = useProfileStore((s) => s.profile);
  const evolutionRecords = useEvolutionStore((s) => s.records);
  const [openGoalsRequestKey, setOpenGoalsRequestKey] = useState(0);

  const chronologicalRecords = useMemo(
    () => sortMeasurementsChronologically(evolutionRecords),
    [evolutionRecords],
  );

  const bodyComparison = useMemo(() => {
    const latestRecord = chronologicalRecords[chronologicalRecords.length - 1];
    const latestWeight = latestRecord?.weightKg;
    const currentWeightKg = Number.isFinite(latestWeight)
      ? latestWeight ?? null
      : profileConfigured && Number.isFinite(profile.currentWeightKg)
      ? profile.currentWeightKg
      : null;
    const targetWeightKg =
      profileConfigured && Number.isFinite(profile.targetWeightKg)
        ? profile.targetWeightKg
        : null;
    const hasObservedMeasurements = Boolean(
      latestRecord &&
        (Number.isFinite(latestRecord.waistCm) ||
          Number.isFinite(latestRecord.chestCm) ||
          Number.isFinite(latestRecord.armCm) ||
          Number.isFinite(latestRecord.thighCm)),
    );
    return {
      currentWeightKg,
      targetWeightKg,
      profileConfigured,
      sex: profile.sex,
      goal: profile.goal,
      heightCm: profile.heightCm,
      waistCm: latestRecord?.waistCm ?? null,
      bodyFatPercent: profile.bodyFatPercent ?? null,
      hasObservedMeasurements,
    };
  }, [chronologicalRecords, profileConfigured, profile]);

  const totals = useMemo(
    () => computeNutritionTotals(meals, activeDateKey),
    [meals, activeDateKey],
  );
  const evolutionIndicator = useMemo(
    () => computeEvolutionCockpitIndicator(chronologicalRecords, profile.goal),
    [chronologicalRecords, profile.goal],
  );
  const weightTrend = useMemo(
    () => calculateWeightTrend(chronologicalRecords, 30),
    [chronologicalRecords],
  );
  const stageIndicators = useMemo<AnatomyStageIndicators>(() => {
    const rate = weightTrend?.changePerWeekKg ?? null;
    if (rate !== null) {
      const direction: 'up' | 'down' | 'flat' =
        rate > 0.02 ? 'up' : rate < -0.02 ? 'down' : 'flat';
      const isAlignedWithGoal =
        profile.goal === 'gain_muscle'
          ? rate >= 0
          : profile.goal === 'lose_weight'
          ? rate <= 0
          : Math.abs(rate) <= 0.25;
      const sign = rate > 0 ? '+' : rate < 0 ? '-' : '';
      const weeklyRateFormatted = `${sign}${Math.abs(rate).toFixed(2)} kg/sem`;
      return {
        direction,
        isAlignedWithGoal,
        weeklyRateFormatted,
        ariaLabel: `Taxa semanal de peso: ${weeklyRateFormatted}`,
      };
    }

    const sign =
      evolutionIndicator.deltaKg > 0 ? '+' : evolutionIndicator.deltaKg < 0 ? '-' : '';
    const fallbackFormatted =
      chronologicalRecords.length >= 2
        ? `${sign}${Math.abs(evolutionIndicator.deltaKg).toFixed(2)} kg/sem`
        : '0.00 kg/sem';
    return {
      direction: evolutionIndicator.direction,
      isAlignedWithGoal: evolutionIndicator.isAlignedWithGoal,
      weeklyRateFormatted: fallbackFormatted,
      ariaLabel: `Taxa semanal de peso: ${fallbackFormatted}`,
    };
  }, [weightTrend, evolutionIndicator, profile.goal, chronologicalRecords.length]);
  const daySummary = useMemo(
    () => computeDayPlanSummary(meals, activeDateKey),
    [meals, activeDateKey],
  );
  const macroGoals = useMemo(
    () => ({
      carbsG: dailyGoals.carbsG,
      proteinG: dailyGoals.proteinG,
      fatG: dailyGoals.fatG,
    }),
    [dailyGoals.carbsG, dailyGoals.proteinG, dailyGoals.fatG],
  );

  const handleOpenGoals = useCallback(() => {
    setOpenGoalsRequestKey((prev) => prev + 1);
  }, []);

  const handleOpenExerciseLibrary = useMemo(
    () => (onOpenExerciseLibrary ? (muscleId?: MuscleGroupId) => onOpenExerciseLibrary(muscleId) : undefined),
    [onOpenExerciseLibrary],
  );

  return (
    <div className="space-y-5 sm:space-y-6">
      <HomeHeader openGoalsRequestKey={openGoalsRequestKey} />

      <section
        aria-label="Resumo nutricional do dia"
        className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-start"
      >
        <div className="lg:col-span-7 min-w-0">
          <EnergySummary
            consumedKcal={totals.kcal}
            goalKcal={dailyGoals.kcal}
            isEstimatedGoal={!profileConfigured}
            dataCoveragePercent={totals.dataCoveragePercent}
            unresolvedFoodCount={totals.unresolvedFoodCount}
            lowConfidenceFoodCount={totals.lowConfidenceFoodCount}
            onOpenNutrition={onOpenNutrition}
          />
        </div>
        <div className="lg:col-span-5 min-w-0">
          <MacroOverview
            carbsG={totals.carbsG}
            proteinG={totals.proteinG}
            fatG={totals.fatG}
            goals={macroGoals}
            plannedRemaining={daySummary.plannedRemainingMacros}
            isEstimatedGoal={!profileConfigured}
            onOpenNutrition={onOpenNutrition}
          />
        </div>
      </section>

      {/* Product hierarchy: nutrition summary leads above; anatomy and daily actions sit cleanly below. */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-start">
        <div className="lg:col-span-7 min-w-0">
          <AnatomyViewport
            onOpenExerciseLibrary={handleOpenExerciseLibrary}
            bodyComparison={bodyComparison}
            stageIndicators={stageIndicators}
          />
        </div>

        <div className="lg:col-span-5 min-w-0 space-y-4 sm:space-y-5">
          <TodayWorkout
            onOpenTraining={onOpenTraining}
            onOpenTrainingPlans={onOpenTrainingPlans}
            onOpenExerciseLibrary={onOpenExerciseLibrary}
          />
          <HydrationSummary
            isEstimatedGoal={!profileConfigured}
            onOpenGoals={handleOpenGoals}
          />
          <ExerciseHydrationCalculator />
          <NextMeal
            meal={daySummary.nextPlannedMeal}
            daySummary={daySummary}
            onOpenNutrition={onOpenNutrition}
          />
          <MicronutrientSummary onOpenNutrition={onOpenNutrition} />
        </div>
      </div>
    </div>
  );
}
