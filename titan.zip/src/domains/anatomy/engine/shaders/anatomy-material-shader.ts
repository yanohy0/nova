import type * as THREE from 'three';

export interface AnatomyShaderUniforms {
  uActiveMusclesMask: { value: number };
  uPrimaryMusclesMask: { value: number };
  uSecondaryMusclesMask: { value: number };
  uSelectedMuscleIndex: { value: number };
  uSelectedMuscleSide: { value: number };
  uSelectedSideAny: { value: number };
  uHasSelection: { value: number };
  uMuscleRestingColor: { value: THREE.Color };
  uMuscleDimmedColor: { value: THREE.Color };
  uMusclePrimaryColor: { value: THREE.Color };
  uMuscleSecondaryColor: { value: THREE.Color };
  uMuscleSelectedColor: { value: THREE.Color };
  uSweepY: { value: number };
  uHologramMode: { value: number };
  uHologramTint: { value: THREE.Color };
  uHologramAccent: { value: THREE.Color };
  uScanPhase?: { value: number };
  uTime?: { value: number };
  uBodyRole?: { value: number }; // 0 = current, 1 = goal
  uBacklightOrigin?: { value: THREE.Vector3 };
}

type AnatomyMaterialRole = 'body' | 'muscle';

function replaceShaderChunk(source: string, chunkName: string, replacement: string, stage: 'vertex' | 'fragment'): string {
  const token = `#include <${chunkName}>`;
  const occurrences = source.split(token).length - 1;
  if (occurrences !== 1) {
    throw new Error(`TITAN anatomy shader patch expected exactly one ${stage} <${chunkName}> chunk; found ${occurrences}`);
  }
  return source.replace(token, replacement);
}

/**
 * Adds anatomy-specific PBR + SSS wrap + holographic character shading to Three.js MeshStandardMaterial.
 * Preserves workout primary/secondary highlights when a muscle is manually selected by layering
 * the selection contour additively instead of dimming or overwriting workout colors.
 */
export function applyAnatomyMaterialEnhancements(
  material: THREE.MeshStandardMaterial,
  uniforms: AnatomyShaderUniforms,
  role: AnatomyMaterialRole,
): void {
  const scanPhase = uniforms.uScanPhase ?? { value: 0 };
  const timeUniform = uniforms.uTime ?? { value: 0 };
  const bodyRole = uniforms.uBodyRole ?? { value: 0 };
  const backlightOrigin = uniforms.uBacklightOrigin ?? {
    value: { x: 0, y: 0.14, z: -0.65 } as unknown as THREE.Vector3,
  };

  material.onBeforeCompile = (shader) => {
    shader.uniforms.uSweepY = uniforms.uSweepY;
    shader.uniforms.uHologramMode = uniforms.uHologramMode;
    shader.uniforms.uHologramTint = uniforms.uHologramTint;
    shader.uniforms.uHologramAccent = uniforms.uHologramAccent;
    shader.uniforms.uScanPhase = scanPhase;
    shader.uniforms.uTime = timeUniform;
    shader.uniforms.uBodyRole = bodyRole;
    shader.uniforms.uBacklightOrigin = backlightOrigin;

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'common',
      `#include <common>
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;
${role === 'muscle' ? `
attribute float aMuscleId;
attribute float aMuscleSide;
uniform int uActiveMusclesMask;
uniform int uPrimaryMusclesMask;
uniform int uSecondaryMusclesMask;
uniform int uSelectedMuscleIndex;
uniform float uSelectedMuscleSide;
uniform float uSelectedSideAny;
uniform float uHasSelection;
uniform vec3 uMuscleRestingColor;
uniform vec3 uMuscleDimmedColor;
uniform vec3 uMusclePrimaryColor;
uniform vec3 uMuscleSecondaryColor;
uniform vec3 uMuscleSelectedColor;
varying vec3 vMuscleColor;
varying float vMuscleActive;
varying float vMuscleSelected;
varying float vMusclePrimary;
varying float vMuscleSecondary;
varying float vIsMuscleZone;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'begin_vertex',
      `#include <begin_vertex>
${role === 'muscle' ? `
int titanMuscleId = int(aMuscleId + 0.5);
float titanIsActive = float((uActiveMusclesMask >> titanMuscleId) & 1);
float titanIsPrimary = float((uPrimaryMusclesMask >> titanMuscleId) & 1);
float titanIsSecondary = float((uSecondaryMusclesMask >> titanMuscleId) & 1);
float titanIsSelected = (titanMuscleId > 0 && titanMuscleId == uSelectedMuscleIndex) ? 1.0 : 0.0;
float titanSideMatch = 1.0 - step(0.5, abs(aMuscleSide - uSelectedMuscleSide));
titanSideMatch = mix(titanSideMatch, 1.0, uSelectedSideAny);
titanIsSelected *= titanSideMatch * uHasSelection;
vec3 titanWorkoutColor = mix(uMuscleRestingColor, uMuscleSecondaryColor, titanIsSecondary);
titanWorkoutColor = mix(titanWorkoutColor, uMusclePrimaryColor, titanIsPrimary);
// Selection never erases workout colors: workout highlight remains primary/secondary,
// while selection adds a dedicated contour & rim highlight in the fragment stage.
vMuscleColor = titanWorkoutColor;
vMuscleActive = max(titanIsPrimary, titanIsSecondary);
vMuscleSelected = titanIsSelected;
vMusclePrimary = titanIsPrimary;
vMuscleSecondary = titanIsSecondary;
vIsMuscleZone = titanMuscleId > 0 ? 1.0 : 0.0;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'project_vertex',
      `vec4 titanWorldPos4 = modelMatrix * vec4(transformed, 1.0);
vAnatomyWorldY = titanWorldPos4.y;
vAnatomyWorldPos = titanWorldPos4.xyz;
vAnatomyWorldNormal = normalize(mat3(modelMatrix) * objectNormal);
#include <project_vertex>`,
      'vertex',
    );

    if (role === 'muscle') {
      shader.uniforms.uActiveMusclesMask = uniforms.uActiveMusclesMask;
      shader.uniforms.uPrimaryMusclesMask = uniforms.uPrimaryMusclesMask;
      shader.uniforms.uSecondaryMusclesMask = uniforms.uSecondaryMusclesMask;
      shader.uniforms.uSelectedMuscleIndex = uniforms.uSelectedMuscleIndex;
      shader.uniforms.uSelectedMuscleSide = uniforms.uSelectedMuscleSide;
      shader.uniforms.uSelectedSideAny = uniforms.uSelectedSideAny;
      shader.uniforms.uHasSelection = uniforms.uHasSelection;
      shader.uniforms.uMuscleRestingColor = uniforms.uMuscleRestingColor;
      shader.uniforms.uMuscleDimmedColor = uniforms.uMuscleDimmedColor;
      shader.uniforms.uMusclePrimaryColor = uniforms.uMusclePrimaryColor;
      shader.uniforms.uMuscleSecondaryColor = uniforms.uMuscleSecondaryColor;
      shader.uniforms.uMuscleSelectedColor = uniforms.uMuscleSelectedColor;

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>
uniform float uSweepY;
uniform float uHologramMode;
uniform vec3 uHologramTint;
uniform vec3 uHologramAccent;
uniform vec3 uMuscleSelectedColor;
uniform float uScanPhase;
uniform float uTime;
uniform float uBodyRole;
uniform vec3 uBacklightOrigin;
varying vec3 vMuscleColor;
varying float vMuscleActive;
varying float vMuscleSelected;
varying float vMusclePrimary;
varying float vMuscleSecondary;
varying float vIsMuscleZone;
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>
float titanSweepGate = smoothstep(-0.08, 0.02, uSweepY) * (1.0 - smoothstep(1.82, 1.92, uSweepY));
float titanSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 10.0, 2.0)) * titanSweepGate;
vec3 titanNormalStep = fwidth(vAnatomyWorldNormal);
float titanPosStep = max(0.0008, length(fwidth(vAnatomyWorldPos)));
float titanCurvature = clamp(length(titanNormalStep) / titanPosStep * 0.048, 0.0, 1.0);
float titanCavityAO = mix(0.60, 1.04, 1.0 - titanCurvature * 0.64);
float titanMaskEdge = clamp((abs(dFdx(vMuscleActive)) + abs(dFdy(vMuscleActive))) * 1.4, 0.0, 1.0);
float titanZoneEdge = clamp((abs(dFdx(vIsMuscleZone)) + abs(dFdy(vIsMuscleZone))) * 1.1, 0.0, 1.0);
vec3 titanSkinBase = diffuseColor.rgb;
float titanMuscleRestBlend = vIsMuscleZone * 0.22;
vec3 titanSculptedBase = mix(
  titanSkinBase * (0.68 - titanMuscleRestBlend * 0.34) * titanCavityAO + uHologramTint * 0.045,
  vMuscleColor * titanCavityAO,
  vMuscleActive * 0.94
);
diffuseColor.rgb = titanSculptedBase * (1.0 - titanMaskEdge * 0.26 - titanZoneEdge * 0.14) + vec3(0.016, 0.014, 0.011) * titanSweep;
if (uHologramMode > 0.5) {
  float titanMuscleLift = mix(0.66, 0.98, vMuscleActive);
  vec3 titanObsidianHolo = diffuseColor.rgb * mix(0.38, 0.30, vIsMuscleZone) * titanCavityAO + uHologramTint * (0.036 + 0.028 * vIsMuscleZone);
  vec3 titanHoloSurface = mix(
    titanObsidianHolo,
    vMuscleColor * titanMuscleLift * titanCavityAO + uHologramTint * 0.025,
    vMuscleActive
  );
  diffuseColor.rgb = titanHoloSurface * (1.0 - titanMaskEdge * 0.22);
}
`,
        'fragment',
      );

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>
vec3 titanViewDir = normalize(vViewPosition);
vec3 titanNormal = normalize(normal);
float titanNdotV = max(dot(titanNormal, titanViewDir), 0.0);
float titanHoloCoreRim = pow(1.0 - titanNdotV, 1.95);
float titanHoloFresnel = pow(1.0 - titanNdotV, 3.05);
float titanHoloSharpRim = pow(1.0 - titanNdotV, 5.6);
vec3 titanBackDir = normalize(uBacklightOrigin - vAnatomyWorldPos);
float titanBackWrap = pow(clamp(dot(titanViewDir, -titanBackDir + vAnatomyWorldNormal * 0.45), 0.0, 1.0), 2.6);
float titanLowerProximity = exp(-max(0.0, vAnatomyWorldY) * 1.05);
vec3 titanSSS = mix(uHologramTint, uHologramAccent, 0.28) * titanBackWrap * (0.048 + titanLowerProximity * 0.088);
totalEmissiveRadiance += titanSSS;
if (uHologramMode > 0.5) {
  float titanScanCoord = vAnatomyWorldY * 360.0 - uTime * 1.55 + uScanPhase;
  float titanHoloScanSignal = 0.5 + 0.5 * cos(titanScanCoord);
  float titanHoloBand = pow(titanHoloScanSignal, 14.0);
  float titanTopoLine = pow(0.5 + 0.5 * cos(vAnatomyWorldPos.x * 210.0 + vAnatomyWorldPos.z * 88.0), 20.0);
  float titanScanWave = pow(0.5 + 0.5 * cos(vAnatomyWorldY * 5.2 - uTime * 0.85 + uScanPhase), 18.0);
  float titanEdgeGate = 0.14 + 0.86 * smoothstep(0.08, 0.68, titanHoloCoreRim);
  float titanHoloScan = (titanHoloBand * 0.58 + titanTopoLine * 0.36 + titanScanWave * 0.28) * titanEdgeGate;
  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 26.0, 2.0));
  vec3 titanHoloBaseEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.22, 0.86, titanHoloFresnel));
  vec3 titanLineColor = mix(uHologramTint * 1.05, vMuscleColor, vMuscleActive * 0.72);
  float titanMaskRim = clamp((abs(dFdx(vMuscleActive)) + abs(dFdy(vMuscleActive))) * 1.25, 0.0, 1.0);
  vec3 titanWorkoutGlow = vMuscleColor * (
    vMusclePrimary * (0.34 + titanHoloCoreRim * 0.52) +
    vMuscleSecondary * (0.24 + titanHoloCoreRim * 0.40) +
    titanMaskRim * 0.36 * vMuscleActive
  );
  vec3 titanHoloEdge = mix(titanHoloBaseEdge, vMuscleColor, vMuscleActive * 0.58);
  float titanRoleRimBoost = mix(0.56, 0.70, uBodyRole);
  totalEmissiveRadiance += titanHoloEdge * (
    titanHoloCoreRim * 0.095 +
    titanHoloFresnel * titanRoleRimBoost +
    titanHoloSharpRim * 0.48 +
    titanHoloSweep * 0.50
  ) + titanLineColor * (titanHoloScan * (0.22 + vMuscleActive * 0.14))
    + titanWorkoutGlow;
  // Selection adds a crisp champagne/white contour without erasing primary/secondary workout colors.
  float titanSelectionContour = smoothstep(0.16, 0.84, titanHoloFresnel) * 1.25 + 0.20;
  totalEmissiveRadiance += uMuscleSelectedColor * (vMuscleSelected * titanSelectionContour);
}`,
        'fragment',
      );
    } else {
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>
uniform float uHologramMode;
uniform float uSweepY;
uniform vec3 uHologramTint;
uniform vec3 uHologramAccent;
uniform float uScanPhase;
uniform float uTime;
uniform float uBodyRole;
uniform vec3 uBacklightOrigin;
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>
vec3 titanNormalStep = fwidth(vAnatomyWorldNormal);
float titanPosStep = max(0.0008, length(fwidth(vAnatomyWorldPos)));
float titanCurvature = clamp(length(titanNormalStep) / titanPosStep * 0.048, 0.0, 1.0);
float titanCavityAO = mix(0.60, 1.04, 1.0 - titanCurvature * 0.64);
if (uHologramMode > 0.5) {
  vec3 titanHoloSurface = diffuseColor.rgb * 0.38 * titanCavityAO + uHologramTint * 0.036;
  diffuseColor.rgb = titanHoloSurface;
}`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>
vec3 titanViewDir = normalize(vViewPosition);
vec3 titanNormal = normalize(normal);
float titanNdotV = max(dot(titanNormal, titanViewDir), 0.0);
float titanHoloCoreRim = pow(1.0 - titanNdotV, 1.95);
float titanHoloFresnel = pow(1.0 - titanNdotV, 3.05);
float titanHoloSharpRim = pow(1.0 - titanNdotV, 5.6);
vec3 titanBackDir = normalize(uBacklightOrigin - vAnatomyWorldPos);
float titanBackWrap = pow(clamp(dot(titanViewDir, -titanBackDir + vAnatomyWorldNormal * 0.45), 0.0, 1.0), 2.6);
float titanLowerProximity = exp(-max(0.0, vAnatomyWorldY) * 1.05);
totalEmissiveRadiance += mix(uHologramTint, uHologramAccent, 0.28) * titanBackWrap * (0.048 + titanLowerProximity * 0.088);
if (uHologramMode > 0.5) {
  float titanScanCoord = vAnatomyWorldY * 360.0 - uTime * 1.55 + uScanPhase;
  float titanHoloScanSignal = 0.5 + 0.5 * cos(titanScanCoord);
  float titanHoloBand = pow(titanHoloScanSignal, 14.0);
  float titanTopoLine = pow(0.5 + 0.5 * cos(vAnatomyWorldPos.x * 210.0 + vAnatomyWorldPos.z * 88.0), 20.0);
  float titanScanWave = pow(0.5 + 0.5 * cos(vAnatomyWorldY * 5.2 - uTime * 0.85 + uScanPhase), 18.0);
  float titanEdgeGate = 0.14 + 0.86 * smoothstep(0.08, 0.68, titanHoloCoreRim);
  float titanHoloScan = (titanHoloBand * 0.58 + titanTopoLine * 0.36 + titanScanWave * 0.28) * titanEdgeGate;
  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 26.0, 2.0));
  vec3 titanHoloEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.22, 0.86, titanHoloFresnel));
  float titanRoleRimBoost = mix(0.56, 0.70, uBodyRole);
  totalEmissiveRadiance += titanHoloEdge * (
    titanHoloCoreRim * 0.095 +
    titanHoloFresnel * titanRoleRimBoost +
    titanHoloSharpRim * 0.44 +
    titanHoloSweep * 0.46
  ) + uHologramTint * (titanHoloScan * 0.22);
}`,
        'fragment',
      );
    }
  };

  material.customProgramCacheKey = () => `titan-anatomy-${role}-pbr-v11.3-single-pass-worldy`;
}
