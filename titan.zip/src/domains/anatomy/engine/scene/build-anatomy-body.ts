import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { MuscleGroupId, MuscleSide } from '@/src/shared/types/common';
import {
  createDefaultCurrentBodyProfile,
  createDefaultGoalBodyProfile,
  type BodyIdentityProfile,
  type BodyRole,
} from '../../domain/body-identity';
import { MUSCLE_ID_TO_SHADER_INDEX } from '../../mapping/anatomy-identifiers';
import { buildEvaluatedHumanMeshGeometries } from '../assets/human-mesh-decoder';
import { averageClosedLoftSeamNormals, createLoftTopology, writeLoftCapPositions } from './loft-topology';
import {
  attachMuscleIdAttribute,
  type AnatomyMaterialSet,
} from '../materials/anatomy-materials';

export type AnatomyLodLevel = 'high' | 'mid' | 'low';

export interface BuildAnatomyBodyOptions {
  role?: BodyRole;
  identity?: BodyIdentityProfile;
  lod?: AnatomyLodLevel;
}

export interface MuscleMeshEntry {
  muscleId: MuscleGroupId;
  side: MuscleSide;
}

export interface AnatomyBodyRig {
  role: BodyRole;
  root: THREE.Group;
  shellGroup: THREE.Group;
  superficialGroup: THREE.Group;
  deepGroup: THREE.Group;
  skeletonGroup: THREE.Group;
  muscleEntries: MuscleMeshEntry[];
  muscleSurface: THREE.Mesh | null;
  pickableMeshes: THREE.Mesh[];
  occlusionMeshes: THREE.Mesh[];
  dispose: () => void;
}

interface CrossSectionSlice {
  y: number;
  rx: number;
  rz: number;
  cx?: number;
  cz?: number;
  chestCleft?: number;
  spineIndent?: number;
  pectoralShelf?: number;
  latFlare?: number;
  abTaper?: number;
  serratus?: number;
  faceBridge?: number;
  browRidge?: number;
  jawContour?: number;
  cheekBone?: number;
  noseTip?: number;
  mouthLips?: number;
  clavicleRidge?: number;
  iliacCrest?: number;
  quadRidge?: number;
  patellaKnee?: number;
  calfDiamond?: number;
  armPeak?: number;
}

function catmullRom(a: number, b: number, c: number, d: number, t: number): number {
  const t2 = t * t;
  const t3 = t2 * t;
  return 0.5 * (
    2 * b +
    (-a + c) * t +
    (2 * a - 5 * b + 4 * c - d) * t2 +
    (-a + 3 * b - 3 * c + d) * t3
  );
}

function smoothCrossSections(
  slices: CrossSectionSlice[],
  subdivisions: number,
): CrossSectionSlice[] {
  if (slices.length < 3 || subdivisions <= 1) return slices;
  const result: CrossSectionSlice[] = [];
  const keys: Array<keyof CrossSectionSlice> = [
    'y',
    'rx',
    'rz',
    'cx',
    'cz',
    'chestCleft',
    'spineIndent',
    'pectoralShelf',
    'latFlare',
    'abTaper',
    'serratus',
    'faceBridge',
    'browRidge',
    'jawContour',
    'cheekBone',
    'noseTip',
    'mouthLips',
    'clavicleRidge',
    'iliacCrest',
    'quadRidge',
    'patellaKnee',
    'calfDiamond',
    'armPeak',
  ];

  for (let index = 0; index < slices.length - 1; index += 1) {
    const p0 = slices[Math.max(0, index - 1)]!;
    const p1 = slices[index]!;
    const p2 = slices[index + 1]!;
    const p3 = slices[Math.min(slices.length - 1, index + 2)]!;

    for (let step = 0; step < subdivisions; step += 1) {
      const t = step / subdivisions;
      const sample: CrossSectionSlice = {
        y: 0,
        rx: 0.005,
        rz: 0.005,
      };
      for (const key of keys) {
        const a = Number(p0[key] ?? 0);
        const b = Number(p1[key] ?? 0);
        const c = Number(p2[key] ?? 0);
        const d = Number(p3[key] ?? 0);
        const value = catmullRom(a, b, c, d, t);
        if (key === 'y' || key === 'rx' || key === 'rz') {
          sample[key] = value;
        } else if (Math.abs(value) > 0.000001) {
          sample[key] = value;
        }
      }
      sample.y = Math.max(p1.y, Math.min(p2.y, sample.y));
      sample.rx = Math.max(0.004, sample.rx);
      sample.rz = Math.max(0.004, sample.rz);
      result.push(sample);
    }
  }
  result.push(slices[slices.length - 1]!);
  return result;
}

function buildLoftedGeometry(
  slices: CrossSectionSlice[],
  radialSegments = 48,
  angleStart = 0,
  angleEnd = Math.PI * 2,
  capEnds = true,
  radialOffset = 0,
  smoothSubdivisions = 1,
  bulge = 0,
  definitionSharpness = 0.5,
): THREE.BufferGeometry {
  const geometrySlices = smoothCrossSections(slices, smoothSubdivisions);
  const closed = Math.abs(angleEnd - angleStart - Math.PI * 2) < 0.001;
  const rows = geometrySlices.length;
  const topology = createLoftTopology(rows, radialSegments, closed, capEnds);
  const { columns: cols, vertexCount, uvs, indices } = topology;
  const positions = new Float32Array(vertexCount * 3);
  let positionOffset = 0;

  for (let r = 0; r < rows; r += 1) {
    const slice = geometrySlices[r];
    if (!slice) continue;
    const v = r / Math.max(1, rows - 1);
    const cx = slice.cx ?? 0;
    const cz = slice.cz ?? 0;

    for (let c = 0; c < cols; c += 1) {
      const u = c / radialSegments;
      const theta = angleStart + u * (angleEnd - angleStart);
      const cosT = Math.cos(theta);
      const sinT = Math.sin(theta);

      const longitudinalProfile = Math.pow(Math.max(0, Math.sin(Math.PI * v)), 0.85);
      const transverseProfile = closed ? 1 : Math.pow(Math.max(0, Math.sin(Math.PI * u)), 0.62);
      const sculptedOffset = radialOffset + bulge * longitudinalProfile * transverseProfile;
      let rx = Math.max(0.004, slice.rx + sculptedOffset);
      let rz = Math.max(0.004, slice.rz + sculptedOffset);

      const frontFactor = Math.max(0, sinT);
      const backFactor = Math.max(0, -sinT);
      const sideFactor = Math.abs(cosT);
      const centerLine = Math.exp(-Math.pow(cosT * 3.8, 2));
      const bilateralPeaks = Math.exp(-Math.pow((sideFactor - 0.52) * 3.2, 2));

      if (slice.chestCleft) {
        rz -= slice.chestCleft * frontFactor * centerLine * (0.75 + 0.5 * definitionSharpness);
      }
      if (slice.pectoralShelf) {
        rz += slice.pectoralShelf * frontFactor * bilateralPeaks;
      }
      if (slice.clavicleRidge) {
        const clavWing = Math.exp(-Math.pow((sideFactor - 0.56) * 2.8, 2)) * frontFactor;
        const sternalNotch = centerLine * frontFactor;
        rz += slice.clavicleRidge * clavWing * 0.9;
        rz -= slice.clavicleRidge * sternalNotch * 0.65;
      }
      if (slice.spineIndent) {
        const erectorRidge = Math.exp(-Math.pow((sideFactor - 0.24) * 5.2, 2)) * backFactor;
        rz -= slice.spineIndent * backFactor * centerLine * (0.7 + 0.55 * definitionSharpness);
        rz += slice.spineIndent * 0.36 * erectorRidge * (0.6 + 0.4 * definitionSharpness);
      }
      if (slice.latFlare) {
        const posterolateral = Math.pow(sideFactor, 1.35) * Math.max(0, -sinT * 0.55 + 0.45);
        rx += slice.latFlare * posterolateral;
      }
      if (slice.abTaper) {
        // Rectus abdominis linea alba + semilunaris groove + oblique ridge
        const lineaSemilunaris = Math.exp(-Math.pow((sideFactor - 0.44) * 5.8, 2));
        rz -= slice.abTaper * 0.46 * frontFactor * centerLine * definitionSharpness;
        rz += slice.abTaper * 0.28 * frontFactor * Math.exp(-Math.pow((sideFactor - 0.24) * 5.2, 2)) * definitionSharpness;
        rz -= slice.abTaper * 0.22 * frontFactor * lineaSemilunaris * definitionSharpness;
      }
      if (slice.iliacCrest) {
        // Adonis belt V-taper + hip socket sculpt
        const vTaper = Math.exp(-Math.pow((sideFactor - 0.62) * 3.6, 2)) * Math.max(0, sinT * 0.7 + 0.3);
        rx += slice.iliacCrest * Math.pow(sideFactor, 1.8) * 0.45;
        rz += slice.iliacCrest * vTaper * (0.65 + 0.4 * definitionSharpness);
      }
      if (slice.serratus) {
        const ribAngle = Math.exp(-Math.pow((sideFactor - 0.86) * 4.5, 2));
        rx += slice.serratus * ribAngle * Math.sin(v * Math.PI * 3.0) * 0.38 * definitionSharpness;
      }
      if (slice.faceBridge) {
        const noseBridge = Math.exp(-Math.pow(cosT * 12.0, 2)) * frontFactor;
        const eyeHollow = Math.exp(-Math.pow((sideFactor - 0.35) * 6.4, 2)) * frontFactor;
        const templePlane = Math.exp(-Math.pow((sideFactor - 0.88) * 5.5, 2));
        rz += slice.faceBridge * noseBridge * 0.017;
        rz -= slice.faceBridge * eyeHollow * 0.0085;
        rx -= slice.faceBridge * templePlane * 0.0035;
      }
      if (slice.noseTip) {
        const tipCone = Math.exp(-Math.pow(cosT * 13.5, 2)) * frontFactor;
        const cheekHollow = Math.exp(-Math.pow((sideFactor - 0.45) * 4.8, 2)) * frontFactor;
        rz += slice.noseTip * tipCone * 0.019;
        rz -= slice.noseTip * cheekHollow * 0.0045;
      }
      if (slice.cheekBone) {
        const zygoma = Math.exp(-Math.pow((sideFactor - 0.60) * 4.4, 2)) * Math.max(0, sinT * 0.75 + 0.25);
        const earRelief = Math.exp(-Math.pow((sideFactor - 0.98) * 8.5, 2)) * Math.max(0, -sinT * 0.4 + 0.6);
        rx += slice.cheekBone * zygoma * 0.0055 + slice.cheekBone * earRelief * 0.0045;
        rz += slice.cheekBone * zygoma * 0.005;
      }
      if (slice.mouthLips) {
        const philtrumLips = Math.exp(-Math.pow(cosT * 5.2, 2)) * frontFactor;
        rz += slice.mouthLips * philtrumLips * 0.0075;
      }
      if (slice.browRidge) {
        const brow = Math.exp(-Math.pow(cosT * 2.6, 2)) * frontFactor;
        rz += slice.browRidge * brow;
      }
      if (slice.jawContour) {
        const jawCorner = Math.exp(-Math.pow((sideFactor - 0.70) * 3.8, 2)) * Math.max(0, sinT * 0.55 + 0.3);
        const chinPeak = Math.exp(-Math.pow(cosT * 5.6, 2)) * frontFactor;
        rx += slice.jawContour * jawCorner * 0.72;
        rz += slice.jawContour * chinPeak * 0.78;
      }
      if (slice.quadRidge) {
        const rectus = Math.exp(-Math.pow(cosT * 3.0, 2)) * frontFactor;
        const vastusLat = Math.exp(-Math.pow((sideFactor - 0.78) * 3.2, 2)) * Math.max(0, sinT + 0.22);
        const vmoTeardrop = Math.exp(-Math.pow((sideFactor - 0.36) * 4.6, 2)) * frontFactor;
        rz += slice.quadRidge * (rectus * 0.65 + vmoTeardrop * 0.38);
        rx += slice.quadRidge * vastusLat * 0.75;
      }
      if (slice.patellaKnee) {
        const patella = Math.exp(-Math.pow(cosT * 4.4, 2)) * frontFactor;
        rz += slice.patellaKnee * patella;
      }
      if (slice.calfDiamond) {
        const gastroc = bilateralPeaks * backFactor;
        const tibialCrest = Math.exp(-Math.pow(cosT * 5.5, 2)) * frontFactor;
        rz += slice.calfDiamond * gastroc + slice.calfDiamond * tibialCrest * 0.22;
        rx += slice.calfDiamond * 0.38 * sideFactor * backFactor;
      }
      if (slice.armPeak) {
        const bicepsRidge = frontFactor * Math.exp(-Math.pow(cosT * 2.8, 2));
        const tricepsHorse = backFactor * bilateralPeaks;
        const brachialis = sideFactor * Math.exp(-Math.pow(sinT * 3.2, 2));
        rz += slice.armPeak * (bicepsRidge * 0.82 + tricepsHorse * 0.72);
        rx += slice.armPeak * brachialis * 0.28;
      }

      positions[positionOffset++] = cx + cosT * rx;
      positions[positionOffset++] = slice.y;
      positions[positionOffset++] = cz + sinT * rz;
    }
  }

  const firstSlice = geometrySlices[0]!;
  const lastSlice = geometrySlices[rows - 1]!;
  positionOffset = writeLoftCapPositions(
    positions,
    positionOffset,
    [firstSlice.cx ?? 0, firstSlice.y, firstSlice.cz ?? 0],
    [lastSlice.cx ?? 0, lastSlice.y, lastSlice.cz ?? 0],
    topology.hasClosedCaps,
  );
  if (positionOffset !== positions.length) {
    throw new Error('Anatomy loft position buffer length mismatch');
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.setIndex(new THREE.BufferAttribute(indices, 1));
  geo.computeVertexNormals();

  if (closed) {
    const normals = geo.getAttribute('normal');
    if (!(normals.array instanceof Float32Array)) {
      throw new Error('Anatomy loft normals must use Float32Array before seam averaging');
    }
    averageClosedLoftSeamNormals(normals.array, rows, radialSegments);
    normals.needsUpdate = true;
  }
  return geo;
}

function mergeStaticBatch(
  parts: THREE.BufferGeometry[],
  disposableList: THREE.BufferGeometry[],
  preserveUV = false,
): THREE.BufferGeometry | null {
  if (parts.length === 0) return null;
  if (!preserveUV) {
    for (const part of parts) part.deleteAttribute('uv');
  }
  const merged = mergeGeometries(parts, false);
  for (const part of parts) part.dispose();
  if (!merged) return null;

  const normals = merged.getAttribute('normal') as THREE.BufferAttribute | undefined;
  if (normals?.array instanceof Float32Array) {
    const source = normals.array;
    const packedNormals = new Int16Array(source.length);
    for (let index = 0; index < source.length; index += 1) {
      const value = source[index] ?? 0;
      packedNormals[index] = Math.round(Math.max(-1, Math.min(1, value)) * 32767);
    }
    merged.setAttribute('normal', new THREE.BufferAttribute(packedNormals, 3, true));
  }

  const positions = merged.getAttribute('position');
  const index = merged.getIndex();
  if (index && positions && positions.count <= 65_535 && !(index.array instanceof Uint16Array)) {
    merged.setIndex(new THREE.BufferAttribute(new Uint16Array(index.array), 1));
  }

  merged.computeBoundingBox();
  merged.computeBoundingSphere();
  disposableList.push(merged);
  return merged;
}

export function buildAnatomyBody(
  materials: AnatomyMaterialSet,
  options: BuildAnatomyBodyOptions = {},
): AnatomyBodyRig {
  const role: BodyRole = options.role ?? 'current';
  const identity: BodyIdentityProfile =
    options.identity ??
    (role === 'goal' ? createDefaultGoalBodyProfile() : createDefaultCurrentBodyProfile());
  const lod: AnatomyLodLevel = options.lod ?? 'high';

  const lodSegScale = lod === 'low' ? 0.55 : lod === 'mid' ? 0.78 : 1.0;
  const seg = (base: number) => Math.max(12, Math.round(base * lodSegScale));
  const sub = (base: number) => Math.max(2, Math.round(base * (lod === 'low' ? 0.5 : 1)));

  const root = new THREE.Group();
  root.name = role === 'goal' ? 'titan-anatomy-goal-body' : 'titan-anatomy-current-body';

  const shellGroup = new THREE.Group();
  const superficialGroup = new THREE.Group();
  const deepGroup = new THREE.Group();
  const skeletonGroup = new THREE.Group();

  root.add(shellGroup, skeletonGroup, deepGroup, superficialGroup);

  const muscleEntries: MuscleMeshEntry[] = [];
  const pickableMeshes: THREE.Mesh[] = [];
  const occlusionMeshes: THREE.Mesh[] = [];
  const geometries: THREE.BufferGeometry[] = [];

  const shellGeos: THREE.BufferGeometry[] = [];
  const muscleGeos: THREE.BufferGeometry[] = [];
  const deepGeos: THREE.BufferGeometry[] = [];
  const skeletonGeos: THREE.BufferGeometry[] = [];

  // Morphological coefficients derived from BodyIdentityProfile (never uniform scaling)
  const p = identity.phenotype;
  const l = identity.localChanges;
  const r = identity.regionalMorphs;
  const heightScale = p.height;
  const fatSoft = p.bodyFat;
  const defSharp = Math.max(0.15, Math.min(1.0, p.muscle * 0.85 + (1 - fatSoft) * 0.35));

  const shoulderExpand = 0.008 + l.shoulderWidth * 0.028 + r.deltoids * 0.014;
  const chestThick = 0.004 + l.chestThickness * 0.026 + r.pectoralis * 0.018;
  const latWidth = 0.006 + l.backWidth * 0.032 + r.latissimus * 0.022;
  const trapLift = 0.003 + r.trapezius * 0.016;
  const waistFat = (fatSoft - 0.25) * 0.026 - r.abdominals * 0.008;
  const hipFat = (fatSoft - 0.25) * 0.020;
  const armBulge = 0.003 + l.upperArmVolume * 0.020 + (r.biceps + r.triceps) * 0.008;
  const forearmBulge = 0.002 + l.forearmVolume * 0.013 + r.forearms * 0.008;
  const gluteBulge = 0.004 + r.glutes * 0.022 + fatSoft * 0.008;
  const thighBulge = 0.004 + l.thighVolume * 0.024 + (r.quadriceps + r.hamstrings) * 0.010;
  const calfBulge = 0.002 + l.calfVolume * 0.016 + r.calves * 0.012;

  const yScale = (y: number) => y * heightScale;

  // Real anatomical human manifold evaluated from CC0 MakeHuman hm08 + parametric morph targets
  const evaluatedHuman = buildEvaluatedHumanMeshGeometries(identity, 0.0018);
  shellGeos.push(evaluatedHuman.occlusionShellGeometry);
  muscleGeos.push(evaluatedHuman.superficialGeometry);

  const registerSculptedLoftMask = (
    muscleId: MuscleGroupId,
    side: MuscleSide,
    slices: CrossSectionSlice[],
    angleStart: number,
    angleEnd: number,
    radialSegs = 24,
    radialOffset = -0.016,
    bulge = 0.004,
  ) => {
    const geo = buildLoftedGeometry(
      slices,
      seg(radialSegs),
      angleStart,
      angleEnd,
      false,
      radialOffset,
      sub(4),
      bulge,
      defSharp,
    );
    const numericSide = side === 'left' ? 1 : side === 'right' ? -1 : 0;
    attachMuscleIdAttribute(geo, MUSCLE_ID_TO_SHADER_INDEX[muscleId], numericSide);
    deepGeos.push(geo);
  };

  const addShellEllipsoid = (
    center: THREE.Vector3,
    scale: THREE.Vector3,
    segments = 16,
  ) => {
    const geo = new THREE.SphereGeometry(1, seg(segments), Math.max(8, Math.floor(seg(segments) * 0.7)));
    geo.scale(scale.x, scale.y, scale.z);
    geo.translate(center.x, center.y, center.z);
    geo.computeVertexNormals();
    attachMuscleIdAttribute(geo, 0);
    skeletonGeos.push(geo);
  };

  const addDeepPlane = (
    slices: CrossSectionSlice[],
    angleStart = 0,
    angleEnd = Math.PI * 2,
    radialOffset = -0.018,
  ) => {
    const geo = buildLoftedGeometry(slices, seg(32), angleStart, angleEnd, false, radialOffset, 2, 0, defSharp);
    attachMuscleIdAttribute(geo, 0);
    deepGeos.push(geo);
  };

  const addBoneTube = (points: THREE.Vector3[], radius: number, segs = 14) => {
    const curve = new THREE.CatmullRomCurve3(points);
    const geo = new THREE.TubeGeometry(curve, segs, radius, 8, false);
    attachMuscleIdAttribute(geo, 0);
    skeletonGeos.push(geo);
  };

  // === LAYER 01: HIGH-RESOLUTION SCULPTED HUMAN TORSO + NECK + CRANIUM ===
  const torsoAndHeadSlices: CrossSectionSlice[] = [
    { y: yScale(0.84), rx: 0.138 + hipFat * 0.65, rz: 0.100 + gluteBulge * 0.35, cz: -0.008, iliacCrest: 0.006 },
    { y: yScale(0.90), rx: 0.151 + hipFat, rz: 0.112 + gluteBulge * 0.48 + hipFat * 0.6, cz: -0.004, iliacCrest: 0.011, spineIndent: 0.010 },
    { y: yScale(0.97), rx: 0.135 + waistFat, rz: 0.097 + waistFat * 0.85, cz: 0.006, spineIndent: 0.015, abTaper: 0.008, iliacCrest: 0.005 },
    { y: yScale(1.05), rx: 0.139 + waistFat * 0.85, rz: 0.102 + waistFat * 0.75, cz: 0.010, spineIndent: 0.017, abTaper: 0.012 },
    { y: yScale(1.13), rx: 0.158 + latWidth * 0.45, rz: 0.112 + chestThick * 0.25, cz: 0.010, chestCleft: 0.009, spineIndent: 0.018, serratus: 0.008, abTaper: 0.011 },
    { y: yScale(1.22), rx: 0.179 + latWidth * 0.85, rz: 0.122 + chestThick * 0.78, cz: 0.008, chestCleft: 0.022, pectoralShelf: 0.016 + r.pectoralis * 0.013, spineIndent: 0.020, latFlare: latWidth * 0.46, serratus: 0.010 },
    { y: yScale(1.31), rx: 0.194 + latWidth, rz: 0.125 + chestThick, cz: 0.005, chestCleft: 0.025, pectoralShelf: 0.016 + r.pectoralis * 0.014, spineIndent: 0.017, latFlare: latWidth * 0.54 },
    { y: yScale(1.39), rx: 0.178 + shoulderExpand * 0.72, rz: 0.106 + chestThick * 0.55, cz: -0.002, chestCleft: 0.012, clavicleRidge: 0.008, spineIndent: 0.012 },
    { y: yScale(1.44), rx: 0.094 + trapLift * 0.88, rz: 0.074 + trapLift * 0.45, cz: -0.008, clavicleRidge: 0.005 },
    { y: yScale(1.49), rx: 0.055 + trapLift * 0.30, rz: 0.056, cz: -0.007 },
    { y: yScale(1.56), rx: 0.051, rz: 0.055, cz: -0.002 },
    { y: yScale(1.595), rx: 0.058, rz: 0.072, cz: 0.014, jawContour: 0.010 },
    { y: yScale(1.628), rx: 0.068, rz: 0.083, cz: 0.012, jawContour: 0.006, mouthLips: 0.85 },
    { y: yScale(1.662), rx: 0.076, rz: 0.089, cz: 0.009, cheekBone: 0.88, noseTip: 0.92 },
    { y: yScale(1.695), rx: 0.081, rz: 0.095, cz: 0.005, faceBridge: 0.95, cheekBone: 0.65 },
    { y: yScale(1.725), rx: 0.082, rz: 0.097, cz: 0.002, faceBridge: 0.60, browRidge: 0.007 },
    { y: yScale(1.760), rx: 0.077, rz: 0.093, cz: -0.001 },
    { y: yScale(1.795), rx: 0.054, rz: 0.067, cz: -0.005 },
    { y: yScale(1.822), rx: 0.022, rz: 0.027, cz: -0.006 },
  ];

  // === LAYER 03: DEEP STRUCTURES ===
  addDeepPlane(torsoAndHeadSlices.slice(1, 6), 0, Math.PI * 2, -0.022);
  addDeepPlane(torsoAndHeadSlices.slice(4, 8), 0.15, Math.PI - 0.15, -0.016);
  addDeepPlane(torsoAndHeadSlices.slice(4, 8), Math.PI + 0.15, Math.PI * 2 - 0.15, -0.016);

  // === LAYER 04: SKELETAL REFERENCE ===
  addBoneTube(
    [
      new THREE.Vector3(0, yScale(0.89), -0.032),
      new THREE.Vector3(0, yScale(1.06), -0.028),
      new THREE.Vector3(0, yScale(1.24), -0.044),
      new THREE.Vector3(0, yScale(1.42), -0.036),
      new THREE.Vector3(0, yScale(1.57), -0.018),
    ],
    0.014,
    20,
  );
  addBoneTube(
    [
      new THREE.Vector3(0, yScale(1.19), 0.076),
      new THREE.Vector3(0, yScale(1.38), 0.068),
    ],
    0.011,
    10,
  );
  const skullGeo = new THREE.SphereGeometry(0.062, 18, 14);
  skullGeo.scale(0.88, 1.08, 1.0);
  skullGeo.translate(0, yScale(1.70), 0.004);
  attachMuscleIdAttribute(skullGeo, 0);
  skeletonGeos.push(skullGeo);

  [1.18, 1.24, 1.30, 1.35].forEach((ry, idx) => {
    const rx = 0.122 + idx * 0.012;
    const rz = 0.082 + idx * 0.005;
    const ribPts: THREE.Vector3[] = [];
    for (let i = 0; i <= 16; i += 1) {
      const t = (i / 16) * Math.PI * 2;
      ribPts.push(new THREE.Vector3(Math.cos(t) * rx, yScale(ry), Math.sin(t) * rz));
    }
    addBoneTube(ribPts, 0.0055, 24);
  });

  const pelvisPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 16; i += 1) {
    const t = (i / 16) * Math.PI * 2;
    pelvisPts.push(new THREE.Vector3(Math.cos(t) * 0.118, yScale(0.90), Math.sin(t) * 0.074));
  }
  addBoneTube(pelvisPts, 0.011, 20);

  // Anatomical skeletal limb axes matching MakeHuman A-pose
  const buildArmSlices = (side: -1 | 1): CrossSectionSlice[] => {
    const shoulderX = 0.185 + shoulderExpand * 0.4;
    const elbowX = 0.320 + latWidth * 0.25;
    const wristX = 0.452;
    return [
      { y: yScale(1.135), rx: 0.022, rz: 0.024, cx: side * wristX, cz: 0.065 },
      { y: yScale(1.19), rx: 0.032 + forearmBulge, rz: 0.032 + forearmBulge, cx: side * (elbowX + 0.065), cz: 0.022 },
      { y: yScale(1.245), rx: 0.036, rz: 0.036, cx: side * elbowX, cz: -0.022 },
      { y: yScale(1.33), rx: 0.048 + armBulge, rz: 0.048 + armBulge, cx: side * (shoulderX + 0.068), cz: -0.023 },
      { y: yScale(1.415), rx: 0.056 + shoulderExpand * 0.5, rz: 0.056 + shoulderExpand * 0.5, cx: side * shoulderX, cz: -0.024 },
    ];
  };

  const buildLegSlices = (side: -1 | 1): CrossSectionSlice[] => {
    const hipX = 0.096;
    const thighX = 0.105;
    return [
      { y: 0.00, rx: 0.040, rz: 0.084, cx: side * 0.104, cz: 0.032 },
      { y: yScale(0.10), rx: 0.030, rz: 0.032, cx: side * 0.104, cz: 0.002 },
      { y: yScale(0.32), rx: 0.050 + calfBulge, rz: 0.052 + calfBulge, cx: side * 0.105, cz: -0.008 },
      { y: yScale(0.47), rx: 0.046, rz: 0.048, cx: side * 0.105, cz: 0.004 },
      { y: yScale(0.68), rx: 0.070 + thighBulge, rz: 0.072 + thighBulge, cx: side * thighX, cz: 0.002 },
      { y: yScale(0.87), rx: 0.075, rz: 0.078, cx: side * hipX, cz: -0.006 },
    ];
  };

  const bilateralMuscleIds: MuscleGroupId[] = [
    'pectoralis',
    'anterior_deltoid',
    'lateral_deltoid',
    'posterior_deltoid',
    'biceps',
    'triceps',
    'forearms',
    'latissimus',
    'glutes',
    'quadriceps',
    'hamstrings',
    'calves',
  ];

  ([-1, 1] as const).forEach((sideNum) => {
    const sideLabel: MuscleSide = sideNum === 1 ? 'left' : 'right';
    const armSlices = buildArmSlices(sideNum);
    const legSlices = buildLegSlices(sideNum);
    const fingerLengths = [0.056, 0.066, 0.061, 0.049];
    const toeLengths = [0.036, 0.040, 0.036, 0.031, 0.025];
    void fingerLengths;
    void toeLengths;

    // Deep muscular & skeletal planes (visible only in deep mode)
    addDeepPlane(armSlices.slice(1, 5), 0, Math.PI * 2, -0.015);
    addDeepPlane(legSlices.slice(2, 6), 0, Math.PI * 2, -0.02);

    addBoneTube(
      [
        new THREE.Vector3(sideNum * 0.025, yScale(1.39), 0.052),
        new THREE.Vector3(sideNum * 0.115, yScale(1.40), 0.028),
        new THREE.Vector3(sideNum * 0.185, yScale(1.415), -0.024),
      ],
      0.008,
      10,
    );
    addBoneTube(
      [
        new THREE.Vector3(sideNum * 0.185, yScale(1.415), -0.024),
        new THREE.Vector3(sideNum * 0.320, yScale(1.245), -0.022),
        new THREE.Vector3(sideNum * 0.452, yScale(1.135), 0.065),
      ],
      0.01,
      14,
    );
    addBoneTube(
      [
        new THREE.Vector3(sideNum * 0.095, yScale(0.88), -0.002),
        new THREE.Vector3(sideNum * 0.105, yScale(0.46), 0.004),
        new THREE.Vector3(sideNum * 0.104, yScale(0.09), 0.002),
      ],
      0.014,
      16,
    );
    addShellEllipsoid(
      new THREE.Vector3(sideNum * 0.104, yScale(0.03), 0.04),
      new THREE.Vector3(0.018, 0.014, 0.045),
      10,
    );

    for (const muscleId of bilateralMuscleIds) {
      muscleEntries.push({ muscleId, side: sideLabel });
    }
  });

  // Deep abdominal core fascia + canonical muscle entry registration
  const addAbdominalLobe = (side: -1 | 1, yCenter: number, frontZ: number) => {
    const abBulge = 0.0025 + r.abdominals * 0.0065 * (1 - fatSoft * 0.45);
    const halfH = 0.022 * heightScale;
    const abSlices: CrossSectionSlice[] = [
      { y: yCenter * heightScale - halfH, rx: 0.016, rz: 0.004, cx: side * 0.032, cz: frontZ - 0.002 },
      { y: yCenter * heightScale, rx: 0.028, rz: 0.007 + abBulge, cx: side * 0.033, cz: frontZ },
      { y: yCenter * heightScale + halfH, rx: 0.017, rz: 0.004, cx: side * 0.032, cz: frontZ - 0.002 },
    ];
    const geo = buildLoftedGeometry(abSlices, seg(16), 0, Math.PI * 2, true, 0, 2, abBulge * 0.5, defSharp);
    const numericSide = side === 1 ? 1 : -1;
    attachMuscleIdAttribute(geo, MUSCLE_ID_TO_SHADER_INDEX.abdominals, numericSide);
    deepGeos.push(geo);
    muscleEntries.push({ muscleId: 'abdominals', side: side === 1 ? 'left' : 'right' });
  };
  addAbdominalLobe(-1, 1.055, 0.088);
  addAbdominalLobe(1, 1.055, 0.088);

  registerSculptedLoftMask(
    'trapezius',
    'center',
    torsoAndHeadSlices.slice(6, 10),
    Math.PI * 1.14,
    Math.PI * 1.86,
    20,
    -0.018,
    0.004,
  );
  muscleEntries.push({ muscleId: 'trapezius', side: 'center' });

  const activeBodyMat = role === 'goal' ? materials.goalBodySurface : materials.bodySurface;
  const activeMuscleMat = role === 'goal' ? materials.goalMuscleSurface : materials.muscleSurface;

  const mergedShellGeo = mergeStaticBatch(shellGeos, geometries);
  if (mergedShellGeo) {
    const shellMesh = new THREE.Mesh(mergedShellGeo, activeBodyMat);
    shellMesh.name = role === 'goal' ? 'anatomy-goal-body-surface' : 'anatomy-body-surface';
    shellMesh.renderOrder = 1;
    shellGroup.add(shellMesh);
    occlusionMeshes.push(shellMesh);
  }

  let muscleSurface: THREE.Mesh | null = null;
  const mergedMuscleGeo = mergeStaticBatch(muscleGeos, geometries, true);
  if (mergedMuscleGeo) {
    muscleSurface = new THREE.Mesh(mergedMuscleGeo, activeMuscleMat);
    muscleSurface.name =
      role === 'goal' ? 'anatomy-goal-muscle-surface-batched' : 'anatomy-muscle-surface-batched';
    muscleSurface.layers.set(1);
    muscleSurface.layers.enable(0);
    muscleSurface.renderOrder = 3;
    muscleSurface.userData.muscleIdAttribute = 'aMuscleId';
    muscleSurface.userData.muscleSideAttribute = 'aMuscleSide';
    superficialGroup.add(muscleSurface);
    pickableMeshes.push(muscleSurface);
  }

  const mergedDeepGeo = mergeStaticBatch(deepGeos, geometries);
  if (mergedDeepGeo) {
    const deepMesh = new THREE.Mesh(mergedDeepGeo, materials.deepPlane);
    deepMesh.name = 'anatomy-deep-layer';
    deepMesh.renderOrder = 2;
    deepGroup.add(deepMesh);
  }

  const mergedSkeletonGeo = mergeStaticBatch(skeletonGeos, geometries);
  if (mergedSkeletonGeo) {
    const skeletonMesh = new THREE.Mesh(mergedSkeletonGeo, materials.skeletonReference);
    skeletonMesh.name = 'anatomy-skeleton-reference';
    skeletonMesh.renderOrder = 1;
    skeletonGroup.add(skeletonMesh);
  }

  return {
    role,
    root,
    shellGroup,
    superficialGroup,
    deepGroup,
    skeletonGroup,
    muscleEntries,
    muscleSurface,
    pickableMeshes,
    occlusionMeshes,
    dispose: () => {
      geometries.forEach((g) => g.dispose());
    },
  };
}
