import * as THREE from 'three';
import type { BodyIdentityProfile } from '../../domain/body-identity';
import {
  HUMAN_MESH_BASE64,
  HUMAN_MESH_MORPH_NAMES,
  HUMAN_MESH_POS_QUANT,
} from './human-mesh-binary';

type MorphName = (typeof HUMAN_MESH_MORPH_NAMES)[number];

interface SparseMorphTable {
  count: number;
  indices: Uint16Array;
  deltas: Int16Array;
}

interface DecodedHumanMeshArchive {
  numCanon: number;
  numRenderVerts: number;
  numTriangles: number;
  basePositions: Int16Array;
  femaleDelta: Int16Array;
  posIdx: Uint16Array;
  uvs: Float32Array;
  muscleIds: Uint8Array;
  muscleSides: Int8Array;
  triIndices: Uint16Array;
  morphs: Record<MorphName, SparseMorphTable>;
}

let cachedArchive: DecodedHumanMeshArchive | null = null;

function decodeBase64Bytes(base64: string): Uint8Array {
  if (typeof Buffer !== 'undefined') {
    return Uint8Array.from(Buffer.from(base64, 'base64'));
  }
  const binary = atob(base64);
  const len = binary.length;
  const out = new Uint8Array(len);
  for (let i = 0; i < len; i += 1) {
    out[i] = binary.charCodeAt(i);
  }
  return out;
}

function getHumanMeshArchive(): DecodedHumanMeshArchive {
  if (cachedArchive) return cachedArchive;

  const bytes = decodeBase64Bytes(HUMAN_MESH_BASE64);
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let offset = 0;

  const numCanon = view.getUint32(offset, true);
  offset += 4;
  const numRenderVerts = view.getUint32(offset, true);
  offset += 4;
  const numTriangles = view.getUint32(offset, true);
  offset += 4;
  const numSparseMorphs = view.getUint32(offset, true);
  offset += 4;

  const basePositions = new Int16Array(numCanon * 3);
  for (let i = 0; i < basePositions.length; i += 1) {
    basePositions[i] = view.getInt16(offset, true);
    offset += 2;
  }

  const femaleDelta = new Int16Array(numCanon * 3);
  for (let i = 0; i < femaleDelta.length; i += 1) {
    femaleDelta[i] = view.getInt16(offset, true);
    offset += 2;
  }

  const posIdx = new Uint16Array(numRenderVerts);
  for (let i = 0; i < numRenderVerts; i += 1) {
    posIdx[i] = view.getUint16(offset, true);
    offset += 2;
  }

  const uvs = new Float32Array(numRenderVerts * 2);
  for (let i = 0; i < numRenderVerts * 2; i += 1) {
    uvs[i] = view.getUint16(offset, true) / 65535;
    offset += 2;
  }

  const muscleIds = new Uint8Array(numRenderVerts);
  muscleIds.set(bytes.subarray(offset, offset + numRenderVerts));
  offset += numRenderVerts;

  const muscleSides = new Int8Array(numRenderVerts);
  for (let i = 0; i < numRenderVerts; i += 1) {
    muscleSides[i] = view.getInt8(offset++);
  }

  const triIndices = new Uint16Array(numTriangles * 3);
  for (let i = 0; i < triIndices.length; i += 1) {
    triIndices[i] = view.getUint16(offset, true);
    offset += 2;
  }

  const morphs = {} as Record<MorphName, SparseMorphTable>;
  for (let m = 0; m < numSparseMorphs; m += 1) {
    const morphName = HUMAN_MESH_MORPH_NAMES[m]!;
    const count = view.getUint32(offset, true);
    offset += 4;
    const indices = new Uint16Array(count);
    const deltas = new Int16Array(count * 3);
    for (let k = 0; k < count; k += 1) {
      indices[k] = view.getUint16(offset, true);
      offset += 2;
      deltas[k * 3] = view.getInt16(offset, true);
      deltas[k * 3 + 1] = view.getInt16(offset + 2, true);
      deltas[k * 3 + 2] = view.getInt16(offset + 4, true);
      offset += 6;
    }
    morphs[morphName] = { count, indices, deltas };
  }

  cachedArchive = {
    numCanon,
    numRenderVerts,
    numTriangles,
    basePositions,
    femaleDelta,
    posIdx,
    uvs,
    muscleIds,
    muscleSides,
    triIndices,
    morphs,
  };
  return cachedArchive;
}

function applySparseMorph(
  canonPositions: Float32Array,
  morph: SparseMorphTable,
  weight: number,
  invQuant: number,
): void {
  if (Math.abs(weight) < 1e-4) return;
  const { count, indices, deltas } = morph;
  const scale = weight * invQuant;
  for (let k = 0; k < count; k += 1) {
    const base = (indices[k] ?? 0) * 3;
    const dBase = k * 3;
    canonPositions[base] = (canonPositions[base] ?? 0) + (deltas[dBase] ?? 0) * scale;
    canonPositions[base + 1] = (canonPositions[base + 1] ?? 0) + (deltas[dBase + 1] ?? 0) * scale;
    canonPositions[base + 2] = (canonPositions[base + 2] ?? 0) + (deltas[dBase + 2] ?? 0) * scale;
  }
}

export interface EvaluatedHumanGeometries {
  superficialGeometry: THREE.BufferGeometry;
  occlusionShellGeometry: THREE.BufferGeometry;
}

export function buildEvaluatedHumanMeshGeometries(
  identity: BodyIdentityProfile,
  shellInsetMeters = 0.0018,
): EvaluatedHumanGeometries {
  const archive = getHumanMeshArchive();
  const invQuant = 1 / HUMAN_MESH_POS_QUANT;
  const { numCanon, numRenderVerts, triIndices, posIdx } = archive;

  // 1. Evaluate canonical vertices from sex + phenotype + regional hypertrophy channels
  const canonPos = new Float32Array(numCanon * 3);
  const sexFem = identity.sex === 'female' ? 1 : 0;

  for (let i = 0; i < canonPos.length; i += 1) {
    canonPos[i] =
      ((archive.basePositions[i] ?? 0) + (archive.femaleDelta[i] ?? 0) * sexFem) * invQuant;
  }

  const muscleCoeff = Math.max(-0.22, Math.min(0.88, (identity.phenotype.muscle - 0.34) * 1.18));
  const fatCoeff = Math.max(-0.20, Math.min(0.42, (identity.phenotype.bodyFat - 0.24) * 0.45));
  applySparseMorph(canonPos, archive.morphs.muscle, muscleCoeff, invQuant);
  applySparseMorph(canonPos, archive.morphs.fat, fatCoeff, invQuant);

  const r = identity.regionalMorphs;
  const regionalWeight = (val: number, gain: number) =>
    Math.max(-0.25, Math.min(0.55, (val - 0.30) * gain));
  applySparseMorph(canonPos, archive.morphs.pectoralis, regionalWeight(r.pectoralis, 0.52), invQuant);
  applySparseMorph(canonPos, archive.morphs.deltoids, regionalWeight(r.deltoids, 0.54), invQuant);
  applySparseMorph(canonPos, archive.morphs.latissimus, regionalWeight(r.latissimus, 0.55), invQuant);
  applySparseMorph(
    canonPos,
    archive.morphs.biceps_triceps,
    regionalWeight(r.biceps * 0.62 + r.triceps * 0.38, 0.52),
    invQuant,
  );
  applySparseMorph(canonPos, archive.morphs.forearms, regionalWeight(r.forearms, 0.45), invQuant);
  applySparseMorph(canonPos, archive.morphs.abdominals, regionalWeight(r.abdominals, 0.42), invQuant);
  applySparseMorph(canonPos, archive.morphs.glutes, regionalWeight(r.glutes, 0.52), invQuant);
  applySparseMorph(
    canonPos,
    archive.morphs.quadriceps_hamstrings,
    regionalWeight(r.quadriceps * 0.62 + r.hamstrings * 0.38, 0.72),
    invQuant,
  );
  applySparseMorph(canonPos, archive.morphs.calves, regionalWeight(r.calves, 0.44), invQuant);

  // Normalize standing foot plane cleanly to y = 0.000 and match configured height
  let minY = Number.POSITIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;
  for (let i = 0; i < numCanon; i += 1) {
    const y = canonPos[i * 3 + 1] ?? 0;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
  }
  const targetHeightM = Math.max(1.45, Math.min(2.15, 1.78 * (identity.phenotype.height || 1)));
  const heightNormScale = targetHeightM / Math.max(0.5, maxY - minY);
  for (let i = 0; i < numCanon; i += 1) {
    const base = i * 3;
    canonPos[base] = (canonPos[base] ?? 0) * heightNormScale;
    canonPos[base + 1] = ((canonPos[base + 1] ?? 0) - minY) * heightNormScale;
    canonPos[base + 2] = (canonPos[base + 2] ?? 0) * heightNormScale;
  }

  // 2. Compute smooth welded vertex normals directly in canonical vertex space (zero UV seam breaks)
  const canonNormals = new Float32Array(numCanon * 3);
  for (let t = 0; t < triIndices.length; t += 3) {
    const ca = posIdx[triIndices[t] ?? 0] ?? 0;
    const cb = posIdx[triIndices[t + 1] ?? 0] ?? 0;
    const cc = posIdx[triIndices[t + 2] ?? 0] ?? 0;

    const ax = canonPos[ca * 3] ?? 0;
    const ay = canonPos[ca * 3 + 1] ?? 0;
    const az = canonPos[ca * 3 + 2] ?? 0;
    const bx = canonPos[cb * 3] ?? 0;
    const by = canonPos[cb * 3 + 1] ?? 0;
    const bz = canonPos[cb * 3 + 2] ?? 0;
    const cx = canonPos[cc * 3] ?? 0;
    const cy = canonPos[cc * 3 + 1] ?? 0;
    const cz = canonPos[cc * 3 + 2] ?? 0;

    const ux = bx - ax;
    const uy = by - ay;
    const uz = bz - az;
    const vx = cx - ax;
    const vy = cy - ay;
    const vz = cz - az;

    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;

    canonNormals[ca * 3] = (canonNormals[ca * 3] ?? 0) + nx;
    canonNormals[ca * 3 + 1] = (canonNormals[ca * 3 + 1] ?? 0) + ny;
    canonNormals[ca * 3 + 2] = (canonNormals[ca * 3 + 2] ?? 0) + nz;
    canonNormals[cb * 3] = (canonNormals[cb * 3] ?? 0) + nx;
    canonNormals[cb * 3 + 1] = (canonNormals[cb * 3 + 1] ?? 0) + ny;
    canonNormals[cb * 3 + 2] = (canonNormals[cb * 3 + 2] ?? 0) + nz;
    canonNormals[cc * 3] = (canonNormals[cc * 3] ?? 0) + nx;
    canonNormals[cc * 3 + 1] = (canonNormals[cc * 3 + 1] ?? 0) + ny;
    canonNormals[cc * 3 + 2] = (canonNormals[cc * 3 + 2] ?? 0) + nz;
  }

  for (let i = 0; i < numCanon; i += 1) {
    const base = i * 3;
    const nx = canonNormals[base]!;
    const ny = canonNormals[base + 1]!;
    const nz = canonNormals[base + 2]!;
    const len = Math.hypot(nx, ny, nz) || 1;
    canonNormals[base] = nx / len;
    canonNormals[base + 1] = ny / len;
    canonNormals[base + 2] = nz / len;
  }

  // 3. Expand to UV-split render vertices for superficial body + inset occlusion shell
  const renderPos = new Float32Array(numRenderVerts * 3);
  const renderNormals = new Float32Array(numRenderVerts * 3);
  const shellPos = new Float32Array(numRenderVerts * 3);
  const shellNormals = new Float32Array(numRenderVerts * 3);

  for (let rv = 0; rv < numRenderVerts; rv += 1) {
    const ci = posIdx[rv]!;
    const cBase = ci * 3;
    const rBase = rv * 3;
    const px = canonPos[cBase]!;
    const py = canonPos[cBase + 1]!;
    const pz = canonPos[cBase + 2]!;
    const nx = canonNormals[cBase]!;
    const ny = canonNormals[cBase + 1]!;
    const nz = canonNormals[cBase + 2]!;

    renderPos[rBase] = px;
    renderPos[rBase + 1] = py;
    renderPos[rBase + 2] = pz;
    renderNormals[rBase] = nx;
    renderNormals[rBase + 1] = ny;
    renderNormals[rBase + 2] = nz;

    shellPos[rBase] = px - nx * shellInsetMeters;
    shellPos[rBase + 1] = Math.max(0, py - ny * shellInsetMeters);
    shellPos[rBase + 2] = pz - nz * shellInsetMeters;
    shellNormals[rBase] = nx;
    shellNormals[rBase + 1] = ny;
    shellNormals[rBase + 2] = nz;
  }

  const superficialGeometry = new THREE.BufferGeometry();
  superficialGeometry.setAttribute('position', new THREE.BufferAttribute(renderPos, 3));
  superficialGeometry.setAttribute('normal', new THREE.BufferAttribute(renderNormals, 3));
  superficialGeometry.setAttribute('uv', new THREE.BufferAttribute(archive.uvs.slice(), 2));
  superficialGeometry.setAttribute(
    'aMuscleId',
    new THREE.BufferAttribute(archive.muscleIds.slice(), 1),
  );
  superficialGeometry.setAttribute(
    'aMuscleSide',
    new THREE.BufferAttribute(archive.muscleSides.slice(), 1),
  );
  superficialGeometry.setIndex(new THREE.BufferAttribute(triIndices.slice(), 1));

  const occlusionShellGeometry = new THREE.BufferGeometry();
  occlusionShellGeometry.setAttribute('position', new THREE.BufferAttribute(shellPos, 3));
  occlusionShellGeometry.setAttribute('normal', new THREE.BufferAttribute(shellNormals, 3));
  occlusionShellGeometry.setAttribute('uv', new THREE.BufferAttribute(archive.uvs.slice(), 2));
  occlusionShellGeometry.setAttribute(
    'aMuscleId',
    new THREE.BufferAttribute(new Uint8Array(numRenderVerts), 1),
  );
  occlusionShellGeometry.setAttribute(
    'aMuscleSide',
    new THREE.BufferAttribute(new Int8Array(numRenderVerts), 1),
  );
  occlusionShellGeometry.setIndex(new THREE.BufferAttribute(triIndices.slice(), 1));

  return { superficialGeometry, occlusionShellGeometry };
}
