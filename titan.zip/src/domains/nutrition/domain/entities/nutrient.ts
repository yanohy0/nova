export type NutrientId =
  | 'vitamin_a'
  | 'vitamin_c'
  | 'vitamin_d'
  | 'vitamin_e'
  | 'vitamin_k'
  | 'vitamin_b1'
  | 'vitamin_b2'
  | 'vitamin_b3'
  | 'vitamin_b5'
  | 'vitamin_b6'
  | 'vitamin_b7'
  | 'vitamin_b9'
  | 'vitamin_b12'
  | 'calcium'
  | 'copper'
  | 'iron'
  | 'phosphorus'
  | 'magnesium'
  | 'manganese'
  | 'potassium'
  | 'selenium'
  | 'sodium'
  | 'zinc';

export const MICRONUTRIENT_ORDER: readonly NutrientId[] = [
  'vitamin_a',
  'vitamin_c',
  'vitamin_d',
  'vitamin_e',
  'vitamin_k',
  'vitamin_b1',
  'vitamin_b2',
  'vitamin_b3',
  'vitamin_b5',
  'vitamin_b6',
  'vitamin_b7',
  'vitamin_b9',
  'vitamin_b12',
  'calcium',
  'copper',
  'iron',
  'phosphorus',
  'magnesium',
  'manganese',
  'potassium',
  'selenium',
  'sodium',
  'zinc',
] as const;

export type FoodSourceId = 'TBCA' | 'OPEN_FOOD_FACTS';

export type NutrientDataStatus =
  | 'quantified'
  | 'trace'
  | 'not_analyzed'
  | 'missing';

export type FoodQualityStatus =
  | 'verified_lab'
  | 'reference_database'
  | 'label_complete'
  | 'label_partial'
  | 'unverified';

export type NutrientConversionMethod =
  | 'direct'
  | 'unit_scale'
  | 'direct_rae'
  | 'tbca_re_preserved_unconverted'
  | 'preformed_niacin_only'
  | 'unavailable';

export interface FoodNutrientRecord {
  food_id: string;
  source_id: FoodSourceId;
  source_record_id: string;
  nutrient_id: NutrientId;
  original_value: number | null;
  original_unit: string;
  normalized_value: number | null;
  normalized_unit: string;
  basis_quantity: number;
  data_status: NutrientDataStatus;
  quality_status: FoodQualityStatus;
  source_version: string;
  conversion_method: NutrientConversionMethod;
}

export interface FoodMacroComposition {
  kcalPerBasis: number;
  proteinGPerBasis: number;
  carbsGPerBasis: number;
  fatGPerBasis: number;
  basisQuantityG: number;
  fiberGPerBasis?: number | null;
  saturatedFatGPerBasis?: number | null;
  cholesterolMgPerBasis?: number | null;
  sodiumMgPerBasis?: number | null;
}

export interface FoodSourceItem {
  food_id: string;
  name: string;
  source_id: FoodSourceId;
  source_record_id: string;
  source_version: string;
  quality_status: FoodQualityStatus;
  source_url?: string;
  source_group?: string;
  food_type?: string;
  state?: string;
  preparation?: string;
  search_text?: string;
  macros: FoodMacroComposition;
  micronutrients: Partial<Record<NutrientId, Omit<FoodNutrientRecord, 'food_id' | 'source_id' | 'source_record_id' | 'source_version' | 'quality_status' | 'nutrient_id'>>>;
}

export type IngredientItem = FoodSourceItem;

export interface RecipeIngredientLine {
  ingredientId: string;
  quantityG: number;
}

export interface RecipeItem {
  id: string;
  name: string;
  description: string;
  category: 'cafe' | 'almoco' | 'lanche' | 'jantar';
  imageUrl?: string;
  ingredients: RecipeIngredientLine[];
}

export interface CardapioMealSlot {
  id: string;
  dateKey: string;
  time: string;
  title: string;
  recipeId: string;
  portionScale?: number;
  status: MealConsumptionStatus;
}

export interface MealFoodPortion {
  foodId: string;
  quantityG: number;
}

export type MealConsumptionStatus =
  | 'planned'
  | 'consumed'
  | 'partial'
  | 'substituted'
  | 'skipped';

export interface MealItem {
  id: string;
  dateKey: string;
  time: string;
  title: string;
  description: string;
  recipeId?: string;
  imageUrl?: string;
  planned_quantity: number;
  consumed_quantity: number;
  planned_foods: MealFoodPortion[];
  consumed_foods: MealFoodPortion[];
  status: MealConsumptionStatus;
  substitutionNote?: string;
}

export type ReferenceProfileId =
  | 'adult_male_19_30'
  | 'adult_female_19_30'
  | 'adult_male_19_50'
  | 'adult_female_19_50'
  | 'adult_51_plus'
  | 'adult_female_51_plus'
  | 'adult_male_51_70'
  | 'adult_female_51_70'
  | 'adult_male_71_plus'
  | 'adult_female_71_plus';

export type ReferenceKind = 'RDA' | 'AI' | 'CDRR' | 'UL';

export interface DailyReferenceEntry {
  nutrientId: NutrientId;
  referenceValue: number | null;
  unit: string;
  kind: ReferenceKind | null;
  upperLimit?: number | null;
}

export interface ReferenceProfileSpec {
  id: ReferenceProfileId;
  label: string;
  systemName: string;
  systemVersion: string;
  entries: Record<NutrientId, DailyReferenceEntry>;
}
