import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { safeStorageAdapter } from '@/src/infrastructure/storage/local-storage';
import { APP_DAY_KEY } from '@/src/shared/constants/app';
import { getLocalDateKey, isValidLocalDateKey } from '@/src/shared/utils/local-date';
import { mergeNutritionPersistedState, type PersistedNutritionState } from './nutrition-persistence';
import { findRecipeById } from '../data/recipes/recipe-catalog';
import type {
  CardapioMealSlot,
  MealFoodPortion,
  MealItem,
  ReferenceProfileId,
} from '../domain/entities/nutrient';
import {
  aggregateDailyMacros,
  resolveFoodById,
  aggregateDailyMicronutrients,
  computeMealDisplayMacros,
  computePortionsMacrosWithQuality,
  getEffectiveConsumedPortions,
  resolveNutrientDisplay,
  resolveReferenceProfile,
  type ResolvedNutrientDisplay,
} from '../domain/rules/nutrition-calculator';
import {
  buildMealFromCardapioSlot,
  computeRecipeSummary,
} from '../domain/rules/recipe-engine';
import { MICRONUTRIENT_ORDER } from '../domain/entities/nutrient';
import { createFoodDiaryMeal, type FoodDiaryMealTitle } from '../domain/rules/food-diary';

export type { MealItem } from '../domain/entities/nutrient';

export interface DailyMacroGoals {
  kcal: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
}

interface NutritionState {
  activeDateKey: string;
  referenceProfileId: ReferenceProfileId;
  dailyGoals: DailyMacroGoals;
  meals: MealItem[];
  intakeDayConfirmations: string[];
  confirmIntakeDay: (dateKey: string) => { ok: true } | { ok: false; error: string };
  setActiveDateKey: (dateKey: string) => void;
  setReferenceProfileId: (profileId: ReferenceProfileId) => void;
  updateDailyGoals: (goals: Partial<DailyMacroGoals>) => void;
  confirmMealConsumed: (mealId: string) => void;
  setMealPartial: (mealId: string, portionFactor: number) => void;
  skipMeal: (mealId: string) => void;
  substituteMeal: (
    mealId: string,
    substitutedFoods: MealFoodPortion[],
    note: string,
    recipeId?: string,
    imageUrl?: string,
  ) => void;
  substituteMealWithRecipe: (mealId: string, recipeId: string) => void;
  restoreMealPlanned: (mealId: string) => void;
  toggleMealCompleted: (mealId: string) => void;
  logFoodToDiary: (foodId: string, quantityG: number, mealTitle: FoodDiaryMealTitle) => { ok: true; mealId: string } | { ok: false; error: string };
  createPlannedMeal: (title: string, time: string) => string | null;
  updatePlannedMeal: (mealId: string, values: { title?: string; time?: string }) => void;
  addFoodToPlannedMeal: (mealId: string, foodId: string, quantityG: number) => boolean;
  updatePlannedMealFood: (mealId: string, foodId: string, quantityG: number) => void;
  removeFoodFromPlannedMeal: (mealId: string, foodId: string) => void;
  deletePlannedMeal: (mealId: string) => void;
}

const INITIAL_CARDAPIO_SLOTS: CardapioMealSlot[] = [
  {
    id: 'meal-1',
    dateKey: APP_DAY_KEY,
    time: '07:30',
    title: 'Café da manhã',
    recipeId: 'rec-cafe-completo',
    status: 'planned',
  },
  {
    id: 'meal-2',
    dateKey: APP_DAY_KEY,
    time: '12:30',
    title: 'Almoço',
    recipeId: 'rec-almoco-frango',
    status: 'consumed',
  },
  {
    id: 'meal-3',
    dateKey: APP_DAY_KEY,
    time: '16:00',
    title: 'Lanche da tarde',
    recipeId: 'rec-lanche-iogurte',
    status: 'consumed',
  },
  {
    id: 'meal-4',
    dateKey: APP_DAY_KEY,
    time: '20:30',
    title: 'Jantar',
    recipeId: 'rec-jantar-salmao',
    status: 'planned',
  },
];

const INITIAL_MEALS: MealItem[] = INITIAL_CARDAPIO_SLOTS.map(buildMealFromCardapioSlot);

function withoutConfirmedMealDay(state: Pick<NutritionState, 'meals' | 'intakeDayConfirmations'>, mealId: string): string[] {
  const dateKey = state.meals.find((meal) => meal.id === mealId)?.dateKey;
  return dateKey ? state.intakeDayConfirmations.filter((confirmedDate) => confirmedDate !== dateKey) : state.intakeDayConfirmations;
}

export const useNutritionStore = create<NutritionState>()(persist<NutritionState, [], [], PersistedNutritionState>((set) => ({
  activeDateKey: APP_DAY_KEY,
  referenceProfileId: 'adult_male_19_50',
  dailyGoals: {
    kcal: 2550,
    proteinG: 170,
    carbsG: 285,
    fatG: 76,
  },
  meals: INITIAL_MEALS,
  intakeDayConfirmations: [],

  confirmIntakeDay: (dateKey) => {
    const dayMeals = useNutritionStore.getState().meals.filter((meal) => meal.dateKey === dateKey);
    if (dayMeals.length === 0 || dayMeals.some((meal) => meal.status === 'planned')) {
      return { ok: false, error: 'Registre ou pule todas as refeições do dia antes de confirmar.' };
    }
    const portions = dayMeals.flatMap(getEffectiveConsumedPortions);
    const quality = computePortionsMacrosWithQuality(portions);
    if (quality.macros.kcal < 500 || quality.unresolvedFoodIds.length > 0 || quality.lowConfidenceFoodIds.length > 0) {
      return { ok: false, error: 'O dia precisa ter ingestão registrada e alimentos com composição nutricional confiável.' };
    }
    set((state) => ({ intakeDayConfirmations: [...new Set([...state.intakeDayConfirmations, dateKey])] }));
    return { ok: true };
  },

  setActiveDateKey: (dateKey) => set((state) => isValidLocalDateKey(dateKey) ? { activeDateKey: dateKey } : state),

  setReferenceProfileId: (profileId) => set({ referenceProfileId: profileId }),

  updateDailyGoals: (goals) =>
    set((state) => ({
      dailyGoals: {
        ...state.dailyGoals,
        ...goals,
      },
    })),

  confirmMealConsumed: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        if (meal.status === 'substituted' && meal.consumed_foods.length > 0) {
          return {
            ...meal,
            status: 'consumed',
          };
        }
        return {
          ...meal,
          status: 'consumed',
          consumed_quantity: meal.planned_quantity,
          consumed_foods: meal.planned_foods.map((p) => ({ ...p })),
          substitutionNote: undefined,
        };
      }),
    })),

  setMealPartial: (mealId, portionFactor) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const safeFactor = Number.isFinite(portionFactor) ? Math.max(0.1, Math.min(2, portionFactor)) : 0.5;
        return {
          ...meal,
          status: safeFactor === 1 ? 'consumed' : 'partial',
          consumed_quantity: meal.planned_quantity * safeFactor,
          consumed_foods: meal.planned_foods.map((p) => ({
            foodId: p.foodId,
            quantityG: p.quantityG * safeFactor,
          })),
        };
      }),
    })),

  skipMeal: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) =>
        meal.id === mealId
          ? {
              ...meal,
              status: 'skipped',
              consumed_quantity: 0,
              consumed_foods: [],
            }
          : meal,
      ),
    })),

  substituteMeal: (mealId, substitutedFoods, note, recipeId, imageUrl) =>
    set((state) => {
      const validFoods = substitutedFoods.filter((food) => Number.isFinite(food.quantityG) && food.quantityG > 0 && resolveFoodById(food.foodId));
      if (validFoods.length === 0) return state;
      return ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const totalG = validFoods.reduce((sum, f) => sum + f.quantityG, 0);
        return {
          ...meal,
          status: 'substituted',
          recipeId: recipeId ?? meal.recipeId,
          imageUrl: imageUrl ?? meal.imageUrl,
          consumed_quantity: Math.round(totalG),
          consumed_foods: validFoods,
          substitutionNote: note,
        };
      }),
    });
    }),

  substituteMealWithRecipe: (mealId, recipeId) =>
    set((state) => {
      const recipe = findRecipeById(recipeId);
      if (!recipe) return state;
      const summary = computeRecipeSummary(recipe, 1);
      if (summary.dataCoveragePercent < 100 || summary.unresolvedFoodIds.length > 0) return state;
      return {
        intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
        meals: state.meals.map((meal) =>
          meal.id !== mealId
            ? meal
            : {
                ...meal,
                status: 'substituted',
                recipeId: recipe.id,
                imageUrl: recipe.imageUrl ?? meal.imageUrl,
                consumed_quantity: summary.totalGrams,
                consumed_foods: summary.portions,
                substitutionNote: recipe.name,
              },
        ),
      };
    }),

  restoreMealPlanned: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const originalSlot = INITIAL_CARDAPIO_SLOTS.find((s) => s.id === meal.id);
        if (originalSlot) {
          return {
            ...buildMealFromCardapioSlot({ ...originalSlot, status: 'planned' }),
            substitutionNote: undefined,
          };
        }
        return {
          ...meal,
          status: 'planned',
          consumed_quantity: 0,
          consumed_foods: [],
          substitutionNote: undefined,
        };
      }),
    })),

  toggleMealCompleted: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const isDone =
          meal.status === 'consumed' ||
          meal.status === 'partial' ||
          meal.status === 'substituted';
        if (isDone) {
          const originalSlot = INITIAL_CARDAPIO_SLOTS.find((s) => s.id === meal.id);
          if (originalSlot) {
            return {
              ...buildMealFromCardapioSlot({ ...originalSlot, status: 'planned' }),
              substitutionNote: undefined,
            };
          }
          return {
            ...meal,
            status: 'planned',
            consumed_quantity: 0,
            consumed_foods: [],
            substitutionNote: undefined,
          };
        }
        return {
          ...meal,
          status: 'consumed',
          consumed_quantity: meal.planned_quantity,
          consumed_foods: meal.planned_foods.map((p) => ({ ...p })),
        };
      }),
    })),

  logFoodToDiary: (foodId, quantityG, mealTitle) => {
    const state = useNutritionStore.getState();
    const food = resolveFoodById(foodId);
    if (!food) return { ok: false, error: 'Alimento não encontrado no catálogo.' };
    const nowMs = Date.now();
    const meal = createFoodDiaryMeal({
      food,
      quantityG,
      dateKey: state.activeDateKey,
      mealTitle,
      id: `food-log-${nowMs}-${state.meals.length}`,
      nowMs,
    });
    if (!meal) return { ok: false, error: 'Quantidade inválida. Registre entre 1 e 2.000 g.' };
    if (state.meals.length >= 2000) return { ok: false, error: 'Limite local de 2.000 refeições atingido. Exporte seu backup antes de remover registros antigos.' };
    set((current) => ({
      meals: [...current.meals, meal],
      intakeDayConfirmations: current.intakeDayConfirmations.filter((dateKey) => dateKey !== meal.dateKey),
    }));
    return { ok: true, mealId: meal.id };
  },

  createPlannedMeal: (title, time) => {
    const normalizedTitle = title.trim().slice(0, 80);
    if (!normalizedTitle || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return null;
    const state = useNutritionStore.getState();
    if (state.meals.length >= 2000 || state.meals.filter((meal) => meal.dateKey === state.activeDateKey).length >= 30) return null;
    const id = `custom-meal-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
    set((current) => ({ meals: [...current.meals, { id, dateKey: current.activeDateKey, time, title: normalizedTitle,
      description: 'Refeição personalizada', planned_quantity: 0, consumed_quantity: 0, planned_foods: [], consumed_foods: [], status: 'planned' }],
      intakeDayConfirmations: current.intakeDayConfirmations.filter((dateKey) => dateKey !== current.activeDateKey) }));
    return id;
  },

  updatePlannedMeal: (mealId, values) => set((state) => ({
    meals: state.meals.map((meal) => meal.id !== mealId || !meal.id.startsWith('custom-meal-') ? meal : {
      ...meal,
      title: values.title === undefined ? meal.title : values.title.trim().slice(0, 80) || meal.title,
      time: values.time === undefined || !/^([01]\d|2[0-3]):[0-5]\d$/.test(values.time) ? meal.time : values.time,
    }),
    intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
  })),

  addFoodToPlannedMeal: (mealId, foodId, quantityG) => {
    if (!Number.isFinite(quantityG) || quantityG < 1 || quantityG > 2000 || !resolveFoodById(foodId)) return false;
    const state = useNutritionStore.getState();
    const meal = state.meals.find((item) => item.id === mealId);
    if (!meal || !meal.id.startsWith('custom-meal-') || meal.planned_foods.length >= 40) return false;
    const existingQuantity = meal.planned_foods.find((portion) => portion.foodId === foodId)?.quantityG ?? 0;
    if (existingQuantity + quantityG > 2000) return false;
    set((current) => ({ meals: current.meals.map((item) => item.id !== mealId ? item : {
      ...item,
      planned_foods: [...item.planned_foods.filter((portion) => portion.foodId !== foodId), {
        foodId, quantityG: (item.planned_foods.find((portion) => portion.foodId === foodId)?.quantityG ?? 0) + quantityG,
      }],
      planned_quantity: item.planned_quantity + quantityG,
    }), intakeDayConfirmations: withoutConfirmedMealDay(current, mealId) }));
    return true;
  },

  updatePlannedMealFood: (mealId, foodId, quantityG) => {
    if (!Number.isFinite(quantityG) || quantityG < 1 || quantityG > 2000) return;
    set((state) => ({ meals: state.meals.map((meal) => {
      if (meal.id !== mealId || !meal.id.startsWith('custom-meal-')) return meal;
      const planned_foods = meal.planned_foods.map((portion) => portion.foodId === foodId ? { ...portion, quantityG } : portion);
      return { ...meal, planned_foods, planned_quantity: planned_foods.reduce((sum, portion) => sum + portion.quantityG, 0) };
    }), intakeDayConfirmations: withoutConfirmedMealDay(state, mealId) }));
  },

  removeFoodFromPlannedMeal: (mealId, foodId) => set((state) => ({ meals: state.meals.map((meal) => {
    if (meal.id !== mealId || !meal.id.startsWith('custom-meal-')) return meal;
    const planned_foods = meal.planned_foods.filter((portion) => portion.foodId !== foodId);
    return { ...meal, planned_foods, planned_quantity: planned_foods.reduce((sum, portion) => sum + portion.quantityG, 0) };
  }), intakeDayConfirmations: withoutConfirmedMealDay(state, mealId) })),

  deletePlannedMeal: (mealId) => set((state) => ({
    meals: state.meals.filter((meal) => meal.id !== mealId || !meal.id.startsWith('custom-meal-')),
    intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
  })),
}), {
  name: 'titan:nutrition:v1',
  version: 1,
  storage: createJSONStorage(() => safeStorageAdapter),
  partialize: (state) => ({
    activeDateKey: state.activeDateKey,
    referenceProfileId: state.referenceProfileId,
    dailyGoals: state.dailyGoals,
    meals: state.meals,
    intakeDayConfirmations: state.intakeDayConfirmations,
  }),
  migrate: (persisted) => mergeNutritionPersistedState(persisted, {
    activeDateKey: getLocalDateKey(),
    referenceProfileId: 'adult_male_19_50',
    dailyGoals: { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
    meals: INITIAL_MEALS,
    intakeDayConfirmations: [],
  }),
  merge: (persisted, current) => ({
    ...current,
    ...mergeNutritionPersistedState(persisted, current),
  }),
}));

export function computeNutritionTotals(
  meals: MealItem[],
  dateKey: string = getLocalDateKey(),
) {
  const totals = aggregateDailyMacros(meals, dateKey);
  const consumedMeals = meals.filter((meal) => meal.dateKey === dateKey && ['consumed', 'partial', 'substituted'].includes(meal.status));
  const consumedPortions = consumedMeals.flatMap(getEffectiveConsumedPortions);
  const quality = computePortionsMacrosWithQuality(consumedPortions);
  return {
    kcal: Math.round(totals.kcal),
    proteinG: Math.round(totals.proteinG),
    carbsG: Math.round(totals.carbsG),
    fatG: Math.round(totals.fatG),
    dataCoveragePercent: consumedMeals.length > 0 ? quality.coveragePercent : null,
    unresolvedFoodCount: quality.unresolvedFoodIds.length,
    lowConfidenceFoodCount: quality.lowConfidenceFoodIds.length,
  };
}

export function getMealMacros(meal: MealItem) {
  const macros = computeMealDisplayMacros(meal);
  return {
    kcal: Math.round(macros.kcal),
    proteinG: Math.round(macros.proteinG),
    carbsG: Math.round(macros.carbsG),
    fatG: Math.round(macros.fatG),
  };
}

export function getDailyMicronutrientDisplays(
  meals: MealItem[],
  dateKey: string,
  profileId: ReferenceProfileId,
): ResolvedNutrientDisplay[] {
  const profile = resolveReferenceProfile(profileId);
  const aggregated = aggregateDailyMicronutrients(meals, dateKey, profileId);
  return MICRONUTRIENT_ORDER.map((id) =>
    resolveNutrientDisplay(aggregated[id], profile.entries[id], profile),
  );
}


export interface DailyEnergyIntakeRecord {
  dateKey: string;
  consumedKcal: number;
  completeness: 'complete';
}

/** Only days explicitly confirmed by the user and still fully quantified are eligible for adaptive TDEE. */
export function getDailyEnergyIntakeHistory(): DailyEnergyIntakeRecord[] {
  const state = useNutritionStore.getState();
  return state.intakeDayConfirmations.flatMap((dateKey) => {
    const dayMeals = state.meals.filter((meal) => meal.dateKey === dateKey);
    if (dayMeals.length === 0 || dayMeals.some((meal) => meal.status === 'planned')) return [];
    const quality = computePortionsMacrosWithQuality(dayMeals.flatMap(getEffectiveConsumedPortions));
    if (quality.macros.kcal < 500 || quality.unresolvedFoodIds.length > 0 || quality.lowConfidenceFoodIds.length > 0) return [];
    return [{ dateKey, consumedKcal: quality.macros.kcal, completeness: 'complete' as const }];
  }).sort((a, b) => a.dateKey.localeCompare(b.dateKey));
}
