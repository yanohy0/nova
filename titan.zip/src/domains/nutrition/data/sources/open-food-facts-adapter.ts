import type { FoodSourceItem } from '../../domain/entities/nutrient';

/**
 * Open Food Facts API v3 adapter for branded / barcoded products.
 * Preserves collaborative label completeness ('label_partial') without inventing missing micronutrients.
 */
export const OPEN_FOOD_FACTS_PRODUCTS: Record<string, FoodSourceItem> = {
  'off-iogurte-proteico': {
    food_id: 'off-iogurte-proteico',
    name: 'Iogurte Proteico Natural (marca comercial)',
    source_id: 'OPEN_FOOD_FACTS',
    source_record_id: '7891025118345',
    source_version: 'OFF API v3',
    quality_status: 'label_partial',
    macros: {
      kcalPerBasis: 86,
      proteinGPerBasis: 10.5,
      carbsGPerBasis: 5.2,
      fatGPerBasis: 2.1,
      basisQuantityG: 100,
    },
    micronutrients: {
      calcium: {
        original_value: 145,
        original_unit: 'mg',
        normalized_value: 145,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 52,
        original_unit: 'mg',
        normalized_value: 52,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b12: {
        original_value: 0.45,
        original_unit: 'µg',
        normalized_value: 0.45,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_d: {
        original_value: null,
        original_unit: 'µg',
        normalized_value: null,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'missing',
        conversion_method: 'unavailable',
      },
      vitamin_k: {
        original_value: null,
        original_unit: 'µg',
        normalized_value: null,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'missing',
        conversion_method: 'unavailable',
      },
    },
  },
  'off-pasta-amendoim': {
    food_id: 'off-pasta-amendoim',
    name: 'Pasta de Amendoim Integral (sem açúcar)',
    source_id: 'OPEN_FOOD_FACTS',
    source_record_id: '7898951240019',
    source_version: 'OFF API v3',
    quality_status: 'label_partial',
    macros: {
      kcalPerBasis: 598,
      proteinGPerBasis: 26.5,
      carbsGPerBasis: 14.0,
      fatGPerBasis: 48.0,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_e: {
        original_value: 8.9,
        original_unit: 'mg',
        normalized_value: 8.9,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b3: {
        original_value: 13.4,
        original_unit: 'mg',
        normalized_value: 13.4,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'preformed_niacin_only',
      },
      magnesium: {
        original_value: 168,
        original_unit: 'mg',
        normalized_value: 168,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 649,
        original_unit: 'mg',
        normalized_value: 649,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 12,
        original_unit: 'mg',
        normalized_value: 12,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      zinc: {
        original_value: 2.9,
        original_unit: 'mg',
        normalized_value: 2.9,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
    },
  },
};

export function buildOpenFoodFactsV3Url(barcode: string): string {
  const sanitized = barcode.replace(/[^0-9]/g, '');
  return `https://world.openfoodfacts.org/api/v3/product/${sanitized}.json`;
}
