import { z } from 'zod';

export const dailyMacroGoalsSchema = z.object({
  kcal: z.number().finite().positive('Calorias devem ser maiores que zero.').max(10000),
  proteinG: z.number().finite().min(0).max(1000),
  carbsG: z.number().finite().min(0).max(1500),
  fatG: z.number().finite().min(0).max(500),
});

export const portionPercentSchema = z
  .number()
  .finite('Informe um percentual entre 10% e 200%.')
  .min(10, 'Percentual deve ficar entre 10% e 200%.')
  .max(200, 'Percentual deve ficar entre 10% e 200%.');
