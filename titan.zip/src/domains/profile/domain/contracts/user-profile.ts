import type { FitnessGoalType } from '@/src/shared/types/fitness-goal';

export type UnitSystem = 'metric' | 'imperial';

export type BiologicalSex = 'male' | 'female';

export type { FitnessGoalType };

export type DailyActivityLevel =
  | 'sedentary'
  | 'light'
  | 'moderate'
  | 'high'
  | 'very_high';

export type ProfileRmrMethod = 'mifflin_st_jeor' | 'pavlidou_2023' | 'cunningham_1980' | 'katch_mcardle' | 'ten_haaf_2014';
export type ProfileFatFreeMassSource = 'dexa' | 'bod_pod' | 'isotope_dilution' | 'validated_bioimpedance' | 'other';

export interface UserPhysiologicalProfile {
  sex: BiologicalSex;
  goal: FitnessGoalType;
  currentWeightKg: number;
  targetWeightKg: number;
  activityLevel: DailyActivityLevel;
  deadlineDateKey: string;
  heightCm: number;
  age: number;
  /** Optional measured or selected metabolic parameters; absent fields preserve V1 profile compatibility. */
  rmrMethod?: ProfileRmrMethod;
  measuredRmrKcal?: number;
  bodyFatPercent?: number;
  fatFreeMassSource?: ProfileFatFreeMassSource;
}

export interface ComputedGoalTargets {
  bmr: number;
  tdee: number;
  kcal: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
  waterMl: number;
  driProfileId: 'adult_male_19_30' | 'adult_female_19_30' | 'adult_male_19_50' | 'adult_female_19_50' | 'adult_51_plus' | 'adult_female_51_plus' | 'adult_male_51_70' | 'adult_female_51_70' | 'adult_male_71_plus' | 'adult_female_71_plus';
  calorieAdjustmentKcal: number;
  requestedCalorieAdjustmentKcal: number;
  proteinMinG: number;
  proteinMaxG: number;
  tdeeSource?: 'equation_activity' | 'equation_nasem_2023' | 'observed_adaptive';
  energyEquationVersion?: 'observed_adaptive_v1' | 'NASEM_2023_TABLE_S3' | 'HALL_2011_DYNAMIC_CORE_V1';
  bodyWeightModel?: {
    version: 'hall_2011_adult_energy_balance_core_v1';
    predictedWeightKg: number;
    targetWeightKg: number;
    absoluteTargetErrorKg: number;
    dailyModelIntakeKcal: number;
    bodyFatInitialization: 'user_supplied' | 'jackson_equation_estimate';
    converged: boolean;
  };
  tdeeActivityCategory?: 'inactive' | 'low_active' | 'active' | 'very_active';
  tdeeRangeKcal?: { lower: number; upper: number };
  energyDensityAssumptions?: { low: number; central: number; high: number };
  warnings: string[];
}

export interface UserProfilePreferences {
  unitSystem: UnitSystem;
  reducedMotionPreferred: boolean;
}
