import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { bootstrapApplication } from './app-core/bootstrap/app-bootstrap';
import App from './App.tsx';
import './index.css';

bootstrapApplication();

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('Elemento raiz #root não encontrado.');

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
