import compression from 'compression';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { isValidLocalDateKey } from './src/shared/utils/local-date.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tdeePayloadSchema = z.object({
  sex: z.enum(['male', 'female']),
  goal: z.enum(['gain_muscle', 'lose_weight', 'recomposition', 'maintain']),
  currentWeightKg: z.number().finite().positive(),
  targetWeightKg: z.number().finite().positive(),
  activityLevel: z.enum(['sedentary', 'light', 'moderate', 'high', 'very_high']),
  deadlineDateKey: z.string().refine(isValidLocalDateKey),
  heightCm: z.number().finite().positive(),
  age: z.number().finite().positive(),
});

const recalculateRecipeSchema = z.object({
  portionScale: z.number().finite().min(0.25).max(3).default(1),
});

async function bootstrapServer() {
  const app = express();
  app.use(compression());
  app.use(express.json());

  const { RECIPE_CATALOG, findRecipeById } = await import(
    './src/domains/nutrition/data/recipes/recipe-catalog.ts'
  );
  const { computeRecipeSummary, searchSubstitutionRecipes } = await import(
    './src/domains/nutrition/domain/rules/recipe-engine.ts'
  );
  const { calculatePhysiologicalGoalTargets } = await import(
    './src/domains/profile/domain/rules/goal-calculator.ts'
  );

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'titan-backend' });
  });

  // Hierarquia Cardápio -> Receitas -> Ingredientes
  app.get('/api/nutrition/recipes', (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q : '';
    const exclude = typeof req.query.exclude === 'string' ? req.query.exclude : undefined;
    const items = searchSubstitutionRecipes(q, exclude);
    res.json({ ok: true, count: items.length, recipes: items });
  });

  app.post('/api/nutrition/recipes/:id/recalculate', (req, res) => {
    const recipeId = req.params.id;
    const recipe = findRecipeById(recipeId);
    if (!recipe) {
      res.status(404).json({ ok: false, error: 'Receita não encontrada.' });
      return;
    }

    const parsed = recalculateRecipeSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ ok: false, error: 'Escala de porção inválida.' });
      return;
    }

    const summary = computeRecipeSummary(recipe, parsed.data.portionScale);
    res.json({ ok: true, data: summary });
  });

  app.get('/api/nutrition/cardapio', (_req, res) => {
    const cardapio = RECIPE_CATALOG.slice(0, 4).map((recipe) =>
      computeRecipeSummary(recipe, 1),
    );
    res.json({ ok: true, cardapio });
  });

  app.post('/api/profile/calculate-tdee', (req, res) => {
    const parsed = tdeePayloadSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({
        ok: false,
        error: parsed.error.issues[0]?.message ?? 'Parâmetros fisiológicos inválidos.',
      });
      return;
    }

    const targets = calculatePhysiologicalGoalTargets(parsed.data);
    res.json({ ok: true, targets });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use('/assets', express.static(path.join(distDir, 'assets'), { maxAge: '1y', immutable: true }));
    app.use(express.static(distDir, {
      setHeaders(res, filePath) {
        if (filePath.endsWith('index.html')) {
          res.setHeader('Cache-Control', 'no-cache');
        }
      },
    }));
    app.get('*', (_req, res) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.setHeader('Cache-Control', 'no-cache');
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build not found');
      }
    });
  }

  const port = Number(process.env.PORT ?? 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`TITAN server listening on http://0.0.0.0:${port}`);
  });
}

void bootstrapServer();
