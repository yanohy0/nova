# TITAN HYDRATION V.MAX V11.16

Aplicação de treino com biblioteca de 32 exercícios e guias técnicos, anatomia 3D interativa, nutrição com catálogo TBCA expandido, hidratação e evolução corporal. A V11.16 adiciona o core dinâmico de balanço energético de Hall (2011), densidade energética adaptativa derivada da composição corporal, configuração de RMR na interface, reconciliação de calorias de atividade e importador MET versionado com gate de licenças. Scaffolds Android Health Connect e iOS HealthKit foram criados, mas ainda exigem host nativo, permissões e testes em aparelho. OpenMetabolics não está portado.

## Validação da V11.16

- `npm run test:review`: inclui testes novos do modelo Hall, solver, densidade adaptativa, reconciliação Health Connect/HealthKit e importação de catálogo MET.
- `npm run typecheck:calculations`: typecheck estrito dos módulos de cálculo, incluindo o solver dinâmico e o serviço de integração de atividade.
- `npm run test:adaptive-simulation`: simulação sintética de 200 perfis; RMSE 91,6 kcal estável e 74,6 kcal após adaptação. Não é validação clínica.
- `npm run lint` não pôde concluir porque `vite/client` não está instalado; `npm run build` não pôde concluir porque o executável `vite` está ausente. O typecheck estrito dedicado (`typecheck:calculations`) passou.
- A sintaxe TypeScript/TSX de 162 arquivos foi transpilada sem diagnósticos. Os scaffolds nativos não foram compilados com Android SDK/Xcode ou testados em aparelhos. OpenMetabolics ainda exige port científico e validação de direitos de pesos/dados.

## Motor de cálculos V11.16

- `docs/CALCULATION_ENGINE_V11_16.md`: modelo dinâmico, equações, pressupostos, reconciliação de fontes e limites.
- `docs/REPOSITORY_RESEARCH_V11_16.md`: pesquisa de repositórios, estrelas observadas, licenças e decisões de não incorporação.
- `docs/IMPLEMENTATION_PRIORITY_V11_16.md`: o que foi adicionado e o que permanece pendente.
- `CHANGELOG_V11_16.md`: histórico da revisão.

## Executar localmente

**Requisitos:** Node.js 22.6+ e Bun (o `bun.lock` é o lockfile canônico). O comando `npm run test:anatomy` usa o type stripping nativo experimental do Node para testar módulos puros sem instalar `tsx`. Para instalar de forma reproduzível, use `bun install --frozen-lockfile`.

```bash
bun install --frozen-lockfile
cp .env.example .env
bun run dev
```

Configure `GEMINI_API_KEY` apenas quando utilizar as funções de IA. `APP_URL` deve apontar para a URL pública do app quando o ambiente exigir links de retorno.

## Comandos de qualidade

```bash
bun run lint
bun run test
bun run test:anatomy
bun run test:exercise-library
bun run test:review
bun run perf:food-search
bun run build
```

O comando `build` gera o frontend em `dist/` e compila `server.ts` para `server.js`; depois execute `bun run start` ou `node server.js` para iniciar o servidor de produção.

O build depende das dependências instaladas. Verificações estáticas dedicadas:

```bash
node scripts/check-fluid-shaders.mjs
node scripts/check-cockpit-visual-semantics.mjs
node scripts/check-titan-design-system.mjs
node scripts/check-anatomy-v9.mjs
node scripts/check-materials-v10.mjs
node scripts/check-anatomy-vmax-v11.mjs
node scripts/check-anatomy-group-contract.mjs
node --experimental-strip-types scripts/check-exercise-muscle-contract.mjs
```

## Direção visual e engenharia V9

- `DESIGN.md`: contrato visual e regras do sistema de design.
- `docs/PRODUCT_VISUAL_DIRECTION_VMAX_V7.md`: direção visual, semântica de cor, intenção dos componentes e metas de qualidade.
- `docs/REPOSITORY_RESEARCH.md`: pesquisa GitHub e decisões por repositório, incluindo deep research anatômica V9.
- `docs/COMPONENT_REALISM_PERFORMANCE_AUDIT.md`: auditoria de realismo/desempenho e histórico de validação.
- `docs/anatomy/ANATOMY_3D.md`: arquitetura 3D, referências, performance, contratos e limitações.
- `docs/anatomy/ANATOMY_VMAX_V11_2_VALIDATION.md`: validação da base V11.2.
- `docs/anatomy/ANATOMY_VMAX_V11_2_1_VALIDATION.md`: correção do catálogo exercício→músculo e Top 3 de evolução.

## Corpo 3D V.MAX V11.4

O viewer mantém quatro lotes de geometria (corpo completo, músculos de treino, camada profunda e esqueleto), seleção por atributos compactos e bitmasks inteiras no vertex shader, PBR com PMREM procedural em hardware identificado, orçamento de pixels e renderização sob demanda. A figura completa inclui cabeça, pescoço, tronco, braços, mãos, pernas e pés; a camada de seleção e os dados de treino continuam restritos aos mesmos 14 grupos musculares. UVs são preservados apenas no lote muscular para suportar o normal map procedural de fibras, enquanto os outros lotes continuam descartando UVs sem uso. O modo holográfico é single-pass no material PBR existente, com toggle Natural/Holograma, sem bloom ou render target adicional. O WebGL2 só é criado próximo da viewport, os shaders são preparados com `compileAsync` e os recursos são descartados antes de `renderer.dispose()`, seguido de `forceContextLoss()` no unmount. A geometria segue procedural: não é um atlas médico nem uma medição do corpo.

Não foi adicionado ativo anatômico externo: Human Atlas possui uma coleção de aproximadamente 33 MB comprimidos e uma referência masculina adulta; Z-Anatomy contém referências com licenças NC. A substituição exige auditoria de licença, cobertura e lateralidade, download/memória e avaliação física antes de ser segura.

## Limites de validação da V11.7

Os testes independentes de dependências e as regressões de domínio executadas nesta revisão passaram; a transpilation de sintaxe TypeScript/TSX cobriu 140 arquivos sem diagnósticos. Neste ambiente, `npm test`, `npm run lint`, `npm run build:server` e `npm run build` não puderam completar porque `node_modules` não está instalado (`tsx`, tipos `vite/client`, `esbuild` e `vite` ausentes). O build completo, o typecheck semântico integral, a persistência real em browser e testes E2E de teclado/foco/WebGL exigem dependências e navegador disponíveis. Nenhum FPS, temperatura ou benchmark mobile é declarado sem esses testes.


### Anatomy 3D V.MAX V11.2

The anatomy viewer defers WebGL2 context and body construction until it is near the viewport, precompiles PBR programs with `compileAsync`, uses compact typed GPU attributes (8-bit muscle IDs/sides, normalized 16-bit normals and safe 16-bit indices), preserves UVs only for the muscle batch that consumes the procedural fiber normal map, and resolves muscle state in the shader rather than rewriting vertex colors on the CPU. V11.2 also fixes all nine GLSL chunk-injection stage contracts, makes the fiber normal texture periodic across both UV axes, and centralizes disposal after shader/renderer failure. The complete figure remains visible while workout mapping stays at 14 stable muscle IDs. The model remains procedural; it is not a medical atlas or a validated human scan. See `docs/anatomy/ANATOMY_3D.md` for repository research, design constraints and remaining device/GPU gates.


## Patch V.MAX V11.2.1 — consistência do catálogo de treino

Naquele patch, os quatro slugs ausentes (`supino-reto`, `crucifixo`, `desenvolvimento`, `triceps-corda`) foram adicionados para cobrir os exercícios usados nos treinos iniciais. A revisão também corrigiu a divergência de panturrilhas como grupo secundário do agachamento. `EXERCISE_MUSCLE_MAP` passou a ser derivado de `EXERCISE_CATALOG`, para manter uma única fonte de verdade. Os 14 IDs musculares e o renderer não mudaram. A contagem atual, após as ampliações seguintes, é de 32 exercícios na V11.6.

O `scripts/check-exercise-muscle-contract.mjs` verifica slugs únicos, resolução de todos os exercícios dos planos, igualdade dos mapas de músculos entre treino e biblioteca e validade dos 14 IDs. Ele é executado pelos comandos de teste de anatomia e da biblioteca de exercícios.

**Evolução anatômica ainda pendente:** substituir patches musculares procedurais por malhas anatômicas selecionadas e licenciadas; isso continua como P1 e exige validação de correspondência, proporção, lateralidade e picking antes de trocar os ativos.

## V10 — Material & Texture Finish

The V10 visual pass is limited to textures, materials, optical effects, and their rendering cost. See `docs/MATERIAL_TEXTURE_EFFECT_CATALOG_VMAX_V10.md` for the complete component-by-component inventory, GitHub research, applied changes, avoided effects, and validation boundaries. No runtime dependency was added.



## Biblioteca de exercícios V.MAX V11.6

A biblioteca foi ampliada de 17 para **32 exercícios**, com guias de execução em português, dicas técnicas, erros comuns, respiração, níveis, categorias, mecânica, aliases e relações entre regressões, progressões e alternativas. A busca cobre os textos dos guias e os filtros incluem músculo, equipamento, nível, categoria e mecânica. A página mostra a origem/licença dos registros e mantém o botão de inspeção muscular no 3D.

O catálogo é uma fonte canônica exposta por `ExerciseRegistry`; o mapa para a anatomia continua sendo derivado e preserva os 14 IDs musculares. Foram importados apenas registros textuais selecionados de Yuhonas, sem imagens ou GIFs. wger, hasaneyldrm, Kinetic, exercemus, RepDB e wrkout foram comparados, com suas diferenças de licença descritas em `docs/EXERCISE_LIBRARY_RESEARCH_V11_6.md` e `THIRD_PARTY_NOTICES.md`. A importação integral dos grandes datasets permanece sujeita a deduplicação, mapeamento anatômico e auditoria de licença individual.

## V11.4 — integridade de seleção e contratos de domínio

- O picking agora verifica a distância da superfície externa visível antes de aceitar um músculo. Isso impede selecionar patches posteriores através do tronco, sem impedir a seleção de relevos musculares intencionalmente elevados. A tolerância geométrica é isolada e testada.
- A pesquisa de exercícios aceita sinônimos e termos usuais em português para os mesmos 14 grupos. Os aliases não criam IDs novos nem alteram o mapeamento dos exercícios.
- O domínio de treino consulta o catálogo por um contrato público do domínio de exercícios; a biblioteca consulta o catálogo muscular por um contrato público da anatomia.
- `npm test` não executa novamente o conjunto de anatomia no final; os checks são chamados uma vez. CI reproduz instalação, typecheck, testes e build via Bun e lockfile existente.
- Nenhuma malha anatômica de terceiros foi copiada: os candidatos encontrados têm obrigações de atribuição/share-alike ou proveniência/licença de ativos que não foram aprovadas para redistribuição. A geometria do corpo e a cabeça permanecem; o mapeamento de treino continua limitado aos 14 grupos existentes.

**Limite:** a seleção por oclusão é validada por testes determinísticos da regra de distância e pelos contratos do renderer; a compilação GLSL, renderização e interação devem continuar sendo verificadas em browsers e dispositivos físicos. Não há alegação de FPS medido ou de anatomia clínica.


## Motor de nutrição e evolução

A aba Nutrição reúne Cardápios, Receitas e Alimentos em um único espaço. O catálogo inclui 5.830 registros TBCA 7.2 elegíveis do arquivo final de nutrição, preservando dados ausentes como não analisados. A aba Evolução aceita pesagens diárias independentes e medidas corporais opcionais. Metas e tendências são estimativas, não medições clínicas; veja `docs/NUTRITION_EVOLUTION_ENGINE_VMAX_V11_5.md` para métodos, limites, licenças e validação.

## Revisão de integridade e persistência V11.12

- `CHANGELOG_V11_12.md`: endurecimento de hidratação de fichas e refeições personalizadas.
- `docs/REPOSITORY_RESEARCH_V11_12.md`: comparação de repositórios de teste, acessibilidade e qualidade com snapshot de estrelas e decisão de integração.
- `docs/IMPLEMENTATION_PRIORITY_V11_12.md`: critérios de aceite e limitações ambientais.

## Revisão sênior e engenharia React V11.11

- `CHANGELOG_V11_11.md`: editores de treino/nutrição, rastreabilidade, limites de persistência e gates ainda bloqueados.
- `docs/REPOSITORY_RESEARCH_V11_11.md`: líderes GitHub por finalidade, estrelas aproximadas, licenças e decisão de adoção.
- `docs/IMPLEMENTATION_PRIORITY_V11_11.md`: critérios de aceite e gates restantes.
- `scripts/benchmark-food-search.mjs`: benchmark repetível do índice de alimentos.
- `docs/REPOSITORY_RESEARCH_V11_9.md`: Top 5 de repositórios por função (estado, API/cache, forms, editores, workflows, rotas, auth, testes, code review e performance), licenças, decisões de adoção e não adoção.
- `docs/IMPLEMENTATION_PRIORITY_V11_9.md`: ordem de implementação V12 e critérios objetivos de aceite.
- `docs/REPOSITORY_REVIEW_V11_7.md`: revisão anterior da arquitetura e código.

## Limites de validação da V11.11

Os testes de domínio/persistência e proveniência, checks estáticos e transpilação sintática de 151 arquivos TS/TSX passaram. O benchmark local de busca (5.838 registros, 180 consultas) mediu mediana de 0,96 ms e p95 de 2,54 ms nesta execução. Não foi possível executar build, typecheck semântico oficial nem E2E: o ambiente não possui `node_modules` nem Bun e o registry npm expirou. A migração para React Router e a suíte Playwright/Vitest/RTL/MSW/axe-core exigem instalação reproduzível e regeneração do lockfile. Autenticação e sincronização multi-dispositivo permanecem bloqueadas pela ausência de backend e política de autorização. Consulte `CHANGELOG_V11_11.md` e `docs/IMPLEMENTATION_PRIORITY_V11_11.md` antes de considerar a versão homologada.


## Limites de validação da V11.12

Os testes de persistência de treino/nutrição e a suíte `test:review` passaram no Node.js 22.16.0. Checks estáticos de domínio, semântica visual, design system, contrato anatômico e catálogo TBCA também passaram. O ambiente não possui Bun nem `node_modules`, e `npm ping` falhou por indisponibilidade de DNS do registry; por isso não foi possível regenerar o lockfile, instalar Playwright/React Router/Vitest/RTL/MSW/axe-core, executar build oficial, typecheck semântico ou E2E. Nenhuma dependência foi adicionada nem lockfile alterado.
