import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/shared/graphics/fluid-shader-engine.ts', import.meta.url), 'utf8');
const errors = [];

// GLSL smoothstep is undefined when edge0 >= edge1 for literal edges.
const numericSmoothstep = /smoothstep\(\s*(-?(?:\d+\.?\d*|\.\d+))\s*,\s*(-?(?:\d+\.?\d*|\.\d+))\s*,/g;
for (const match of source.matchAll(numericSmoothstep)) {
  const edge0 = Number(match[1]);
  const edge1 = Number(match[2]);
  if (edge0 >= edge1) errors.push(`Invalid smoothstep(${edge0}, ${edge1}) at ${match.index}`);
}

for (const required of [
  'distributionGGX(',
  'geometrySchlickGGX(',
  'evaluateGGXSpecular(',
  'visibilityGGXSmithAnisotropic(',
  'distributionGGXAnisotropic(',
  'evaluateGGXAnisotropicSpecular(',
  'softboxRect(',
  'applyBeerLambert(',
  'computeDifferentialCaustic(',
  'exitFresnel',
  'linearToSrgb',
  'interpolateRatio(',
  'ENERGY_NOISE_GLSL',
]) {
  if (!source.includes(required)) errors.push(`Missing shader feature: ${required}`);
}

function template(name) {
  const match = source.match(new RegExp(`const ${name} = \x60([\\s\\S]*?)\x60;`));
  if (!match) {
    errors.push(`Could not locate GLSL source: ${name}`);
    return '';
  }
  return match[1];
}

const names = [
  'SHARED_OPTICS_GLSL',
  'DROPLET_FRAGMENT_300',
  'TANK_FRAGMENT_300',
  'ENERGY_NOISE_GLSL',
  'ENERGY_FRAGMENT_300',
  'METAL_FRAGMENT_300',
];
const shaders = Object.fromEntries(names.map((name) => [name, template(name)]));

for (const [name, raw] of Object.entries(shaders)) {
  if (!raw) continue;
  const code = raw.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
  let depth = 0;
  for (const char of code) {
    if (char === '{') depth++;
    if (char === '}') depth--;
    if (depth < 0) break;
  }
  if (depth !== 0) errors.push(`Unbalanced GLSL braces in ${name}: ${depth}`);
}

function checkDuplicateFunctions(label, raw) {
  const code = raw.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
  const counts = new Map();
  const functionPattern = /\b(?:void|float|int|bool|vec[234]|mat[234])\s+([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{/g;
  for (const match of code.matchAll(functionPattern)) {
    counts.set(match[1], (counts.get(match[1]) ?? 0) + 1);
  }
  for (const [name, count] of counts) {
    if (count > 1) errors.push(`${label} defines ${name} ${count} times`);
  }
}

checkDuplicateFunctions('droplet shader', `${shaders.SHARED_OPTICS_GLSL}\n${shaders.DROPLET_FRAGMENT_300}`);
checkDuplicateFunctions('tank shader', `${shaders.SHARED_OPTICS_GLSL}\n${shaders.TANK_FRAGMENT_300}`);
checkDuplicateFunctions('energy shader', `${shaders.ENERGY_NOISE_GLSL}\n${shaders.ENERGY_FRAGMENT_300}`);
checkDuplicateFunctions('metal shader', `${shaders.SHARED_OPTICS_GLSL}\n${shaders.METAL_FRAGMENT_300}`);

if (source.includes('dualVoronoiCaustics') || source.includes('voronoiCell(')) {
  errors.push('Water caustics should use projected differential-area concentration, not decorative Voronoi cells');
}
if (!source.includes('1.0 / 2.4') || !source.includes('0.0031308')) {
  errors.push('Linear-to-sRGB conversion should use the piecewise sRGB transfer function');
}
if (source.includes('PLASMA_FRAGMENT_300') || source.includes("kind: 'plasma'")) {
  errors.push('Legacy plasma shader path should not remain in the nutrition energy indicator');
}

const metal = shaders.METAL_FRAGMENT_300;
const metalFbmCalls = (metal.match(/\bfbm3\s*\(/g) ?? []).length;
if (metalFbmCalls !== 1) errors.push(`Macro metal shader must use one micro-noise sample; found ${metalFbmCalls}`);
if (/\bdFdx\s*\(|\bdFdy\s*\(/.test(metal)) {
  errors.push('Macro metal shader must not evaluate screen derivatives inside its divergent liquid mask');
}
if (!metal.includes('evaluateGGXAnisotropicSpecular(')) {
  errors.push('Macro metal shader is missing its anisotropic GGX reflection');
}
if (source.includes('transferToImageBitmap(')) {
  errors.push('Per-frame ImageBitmap transfer reintroduces avoidable allocation in the shared renderer');
}
if (!source.includes('drawImage(src, 0, src.height - pxH, pxW, pxH, 0, 0, pxW, pxH)')) {
  errors.push('Shared renderer is missing the direct CanvasImageSource blit path');
}

if (errors.length) {
  console.error('Fluid shader checks failed:\n' + errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log('Fluid shader static checks passed (smoothstep bounds, unique functions, optics, anisotropic GGX, noise budget, and renderer allocation path).');
}
