# TITAN native health bridge (Android)

This directory contains an Android Health Connect library module intended to be included by a future Android host (or Capacitor/React Native native wrapper). The current TITAN application is React/Vite; this module is **not** part of the browser bundle and cannot run inside Google AI Studio preview or an ordinary browser.

## Included

- Health Connect SDK `androidx.health.connect:connect-client:1.1.0` (stable line).
- Read permissions for exercise sessions, active calories and total calories. Background-read permission is an optional fragment and is not requested by default.
- Reader methods for active-calorie intervals, total-calorie intervals and exercise session metadata.
- ISO-8601 timestamps and stable Health Connect record IDs for the JS adapter.

## Host integration still required

1. Include this library module in an Android application with AGP >= 8.9.1 and `compileSdk = 36`.
2. Declare the permissions in the host app manifest and provide a privacy rationale.
3. Call the Health Connect permission request flow through an Activity Result contract; the host must not assume that permissions were granted.
4. Inject `window.titanHealthBridge` / `globalThis.titanHealthBridge` implementing the contract in `activity-reconciliation.ts`.
5. Call the JS normalizer and reconciler before any active-energy value is used.
6. Use `src/main/AndroidManifest.background-read.fragment.xml` only when the product genuinely needs background synchronization and the Play policy declaration is approved.

`grantedReadPermissions()` reports the already-granted subset; `permissionRequestContract()` supplies the Activity Result contract. The host owns launching that contract, presenting rationale and handling the returned grant set explicitly.

## Important semantics

- `ActiveCaloriesBurnedRecord` is eligible for the activity-energy reconciliation flow.
- `TotalCaloriesBurnedRecord` is retained as a non-additive audit item and excluded from active calories to avoid adding total energy on top of daily baseline expenditure.
- `ExerciseSessionRecord` has no energy value in this adapter. It is metadata, not a calorie contributor.
- Health Connect data is user-authorized and should be treated as source data with attribution/provenance. No user health record is uploaded by this module.

## Validation status

The Kotlin source is a native integration scaffold and has not been compiled against an Android SDK or exercised on a device in this web-only repository. Do not advertise Health Connect sync as active until the host bridge, permission UX, privacy review and device tests are complete.
