# TITAN native health bridge (iOS)

This is a HealthKit adapter scaffold for a future iOS host. The current repository is React/Vite and has no Xcode project, signing configuration or iOS target, so the source is not built into the web app.

## Included

- Reads `activeEnergyBurned` samples and workout metadata through HealthKit.
- Emits ISO-8601 timestamps and stable HealthKit UUIDs in the same normalized transport shape consumed by `activity-reconciliation.ts`.
- Workout metadata deliberately has no `energyKcal`; active energy samples remain the only calorie contributors. The reconciliation layer removes duplicates when the same active-energy interval is also delivered from another connected source.

## Host integration

1. Add HealthKit capability and the `NSHealthShareUsageDescription` string from `Info.plist.fragment.xml` to the host app.
2. Request only the read types actually used by the product.
3. Bridge `TitanHealthRecord` values to `globalThis.titanHealthBridge` in the WebView/native shell.
4. Run `normalizeHealthKitActivityRecords` on iOS, then call `reconcileActivityEnergyRecords`.

**Privacy caveat:** Apple intentionally does not expose whether read permission was denied. A successful `requestAuthorization` completion must not be treated as proof of access; the host should handle read failures and avoid claiming that an empty result means the user has no activity.

## Validation status

Swift source is a scaffold only; no Xcode project, code signing, entitlements or device-level HealthKit tests are included. Do not advertise HealthKit sync as active until host bridge, permission UX, App Store privacy review and device tests are complete.
