import Foundation
import HealthKit

public struct TitanHealthRecord: Codable {
    public let recordType: String
    public let id: String
    public let sourceRecordId: String
    public let startTime: String
    public let endTime: String
    public let energyKcal: Double?
    public let activityCode: String?
    public let updatedAt: String?
}

/// Native HealthKit reader. The host app must present a clear privacy purpose
/// and must not interpret a successful authorization request as proof of read consent.
public final class TitanHealthKitReader {
    private let store = HKHealthStore()
    private let iso = ISO8601DateFormatter()

    public init() {}

    public static var isAvailable: Bool { HKHealthStore.isHealthDataAvailable() }

    public func requestReadAuthorization() async throws {
        guard Self.isAvailable else { throw NSError(domain: "TitanHealthKit", code: 1) }
        guard let activeEnergy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) else {
            throw NSError(domain: "TitanHealthKit", code: 2)
        }
        let readTypes: Set<HKObjectType> = [HKObjectType.workoutType(), activeEnergy]
        // HealthKit intentionally does not reveal whether read permission was denied.
        // A successful completion means the request flow completed, not that reads are authorized.
        try await store.requestAuthorization(toShare: [], read: readTypes)
    }

    public func readActivityEnergy(start: Date, end: Date) async throws -> [TitanHealthRecord] {
        guard start < end else { throw NSError(domain: "TitanHealthKit", code: 3) }
        guard let activeEnergy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) else {
            throw NSError(domain: "TitanHealthKit", code: 2)
        }

        async let activeSamples = readSamples(type: activeEnergy, start: start, end: end)
        async let workouts = readWorkouts(start: start, end: end)
        return try await activeSamples + workouts
    }

    private func readSamples(type: HKQuantityType, start: Date, end: Date) async throws -> [TitanHealthRecord] {
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, error in
                if let error { continuation.resume(throwing: error); return }
                let records = (samples as? [HKQuantitySample] ?? []).map { sample in
                    TitanHealthRecord(
                        recordType: "ActiveCaloriesBurnedRecord",
                        id: sample.uuid.uuidString,
                        sourceRecordId: sample.uuid.uuidString,
                        startTime: self.iso.string(from: sample.startDate),
                        endTime: self.iso.string(from: sample.endDate),
                        energyKcal: sample.quantity.doubleValue(for: .kilocalorie()),
                        activityCode: nil,
                        updatedAt: self.iso.string(from: sample.endDate)
                    )
                }
                continuation.resume(returning: records)
            }
            self.store.execute(query)
        }
    }

    private func readWorkouts(start: Date, end: Date) async throws -> [TitanHealthRecord] {
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: HKObjectType.workoutType(), predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, error in
                if let error { continuation.resume(throwing: error); return }
                let records = (samples as? [HKWorkout] ?? []).map { workout in
                    TitanHealthRecord(
                        recordType: "ExerciseSessionRecord",
                        id: workout.uuid.uuidString,
                        sourceRecordId: workout.uuid.uuidString,
                        startTime: self.iso.string(from: workout.startDate),
                        endTime: self.iso.string(from: workout.endDate),
                        energyKcal: nil,
                        activityCode: String(workout.workoutActivityType.rawValue),
                        updatedAt: self.iso.string(from: workout.endDate)
                    )
                }
                continuation.resume(returning: records)
            }
            self.store.execute(query)
        }
    }
}
