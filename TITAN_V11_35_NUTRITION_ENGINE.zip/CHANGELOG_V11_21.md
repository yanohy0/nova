# TITAN V11.21.0 — Realism Closure

## Implementado

### Água e gotículas
- Criado ledger de massa para o conjunto de gotas com massa inicial, fontes, sumidouros, transferências, massa coalescida e resíduo.
- Centralizadas as alterações de massa dos corpos em `setBodyMass`.
- Coalescência agora transfere 100% da massa doadora ao sobrevivente; a gota visual reciclada é registrada como nova condensação, e não como perda invisível.
- Impacto no reservatório expõe `massTransferred`; a massa deixa explicitamente o conjunto de gotas.
- Incluída histerese advancing/receding para a linha de contato, com par leading/trailing e fator fenomenológico para pinning.
- A projeção de pressão usa par de operadores discreto coerente (divergência forward / gradiente backward), Jacobi limitado e diagnóstico de resíduo.

### Vidro e metais
- Adicionados nove anchors medidos de n/k para Ag, Cr e Au em cada conjunto (430.5–659.5 nm), obtidos da base refractiveindex.info CC0.
- Fresnel complexo de condutor com interpolação linear CPU e quadratura GLSL de três amostras por banda RGB.
- Mantidos Fresnel dielétrico, Snell/TIR, Sellmeier e Beer–Lambert existentes.

### Raios e descargas
- CPU e GLSL compartilham o envelope Heidler-type de VFX.
- Constante de normalização corrigida para pico unitário; teste agora detecta regressão de subnormalização.

### Pesquisa e documentação
- Deep research independente no GitHub para sete áreas; Firecrawl não foi usado.
- Criados spec, plan, pesquisa, verificação estática, ledger Superpowers e changelog.
- Nenhum código de repositório externo ou asset anatômico foi copiado. Só dados ópticos CC0 foram usados.
- Anatomia, SSS e iluminação ficam explicitamente no backlog com requisitos de licença/compatibilidade/GPU.

## Verificações

- `test:physics-v11-21`: testes de massa, pressão, óptica espectral, Heidler, histerese e contratos estáticos.
- `test:rendering-realism`: regressões de aparência V11.19/V11.20 mais testes V11.21.
- `test:review`: persistência, limites de domínio e testes funcionais relevantes.
- `test:adaptive-plasma`: raymarch adaptativo V11.20 preservado.
- Build, lint, suíte completa e compilação real de shaders GPU dependem de toolchain npm e driver/browser disponíveis; os resultados serão anotados separadamente no ledger. Não há alegação de aprovação antecipada.

## Limites conhecidos

- A projeção é 2D, collocated/indicial e não é uma grade MAC; o teste determinístico reduziu divergência RMS aproximadamente 43%, não a anulou.
- Menisco permanece linearizado e planar. Histerese é uma aproximação fenomenológica.
- Espectro de metais é banda RGB com nove amostras, não uma solução CIE spectral path tracing, e não caracteriza cada liga/revestimento real.
- Arcos são procedurais; Heidler é envelope VFX e não solver de DBM/streamer/MTLE.
- O corpo mantém a malha/rig atual; Open Anatomy 3D foi avaliado, mas a compatibilidade de rig não foi comprovada. SMPL-X tem licença não comercial e Z-Anatomy CC BY-SA.
- SSS continua aproximado e iluminação não foi calibrada contra HDRI/fotometria real.
