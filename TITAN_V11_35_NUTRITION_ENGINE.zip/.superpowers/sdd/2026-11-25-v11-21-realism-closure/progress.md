# V11.21 — execução Superpowers

## Workspace

- Origem: `TITAN_V11_20_ADAPTIVE_PLASMA.zip` (materializado da Library).
- Cópia isolada editável: `/mnt/data/titan_v1121_work/titan`.
- ZIP original preservado sem alteração.
- A origem não contém `.git`; portanto não foi possível criar worktree Git, branch ou commits. Não serão inventados SHAs.
- Sem agente de sub-revisão disponível; haverá revisão própria explícita.

## Rulings

- Ruling: manter React/Three.js/WebGL2/GLSL ES 3.00 — sem engine paralela ou novas dependências de runtime — por custo/compatibilidade; risco residual: CFD 3D e solver elétrico permanecem fora do escopo.
- Ruling: não substituir o corpo atual pelo GLB Open Anatomy 3D — apesar da licença CC BY 4.0, compatibilidade de rig, pesos e morphs não foi verificada; risco residual: anatomia ainda não possui toda a subdivisão muscular topológica pretendida.
- Ruling: não usar SMPL-X no produto — licença do modelo/software é limitada a pesquisa científica não comercial; risco: nenhum modelo paramétrico comercial foi integrado nesta revisão.
- Ruling: usar anchors n/k CC0 e quadratura de nove amostras em vez de espectro CIE completo — risco: resposta visual ainda é banda RGB aproximada e baseada em dados de metais puros.
- Ruling: usar par de diferenças forward/backward com Jacobi adaptativo — risco: não é MAC, solver ainda é 2D e reduz, mas não anula, divergência.
- Ruling: usar Heidler-type apenas como envelope visual — risco: sem solver Laplace/DBM, streamer ou corrente de retorno física.

## Pesquisa GitHub

- Água: SPlisHSPlasH (código Akinci 2013), WebGPU-Ocean (MLS-MPM), Clearwater, Three.js water e swek-webgl2-water.
- Óptica: PBRT-v4, refractiveindex.info CC0, Filament, Three.js, Nanairo.
- Plasma: Three.js volume renderer, VolumetricSmoke, FastNoiseLite, Three.js, Shader Park.
- Descargas: DBM, 2D-Weather-Sandbox, Thunder-Lightning, SpektrLightning, PixelFX.
- Anatomia: Open Anatomy 3D (CC BY 4.0), MakeHuman, SMPL-X (licença não comercial), Z-Anatomy (CC BY-SA 4.0), Human Reference Atlas Portal.
- Pele: Filament, Three.js SSS shader, DarkBlade Skin Shader, PBRT e PlayCanvas.
- Lighting: Three.js RectAreaLight/LTC/PMREM, Filament, PlayCanvas, LTCClustered-ManyAreaLights e Drei.
- Firecrawl não foi usado. Nenhum código/assets de terceiros copiado; somente os números n/k de Au/Ag/Cr CC0.

## TDD / RED-GREEN

- `droplet-mass-balance.test.mjs`: RED por API ausente; GREEN após ledger/integration.
- `fluid-pressure-projection.test.mjs`: RED por módulo ausente; GREEN após projeção; campo determinístico: RMS 0.30164297 -> 0.17105196 em 28 iterações; resíduo 0.08204189 e threshold 0.084459.
- `metal-optics-spectrum.test.mjs`: RED por módulo ausente; GREEN após tabela, interpolação, Fresnel e quadratura GLSL; incidência normal comparada à fórmula analítica.
- `lightning-waveform.test.mjs`: RED observado para pico 0.9710846 (constante incorreta); GREEN após normalização 0.5695701063405509 e shader sincronizado.
- `capillary-meniscus.test.mjs`: GREEN para perfil linearizado e histerese dinâmica.

## Implementação

- Criado `droplet-mass-balance.ts`, centralizadas alterações de massa, coalescência integral e evento de transferência.
- Criado `fluid-pressure-projection.ts`, Jacobi 8–28 com resíduo e diagnóstico.
- Adicionadas leading/trailing contact angles e fator de pinning a `capillary-meniscus.ts`/solver.
- Criado `metal-optics-spectrum.ts` com 9 amostras por material e interpolação; GLSL usa 3 por canal RGB.
- Criado `lightning-waveform.ts` e sincronizada função GLSL.
- Adicionados contratos estáticos `scripts/check-physics-v11-21.mjs` e scripts npm.

## Execução de verificação (25/11/2026)

**Passou:**
- `npm run test:physics-v11-21` — PASS (ledger, projeção, n/k/Fresnel, Heidler, histerese e contratos estáticos).
- `npm run test:rendering-realism` — PASS (inclui plasma adaptativo, shaders estáticos, pele, anatomia/lighting regressions e grupo V11.21).
- `npm run test:review` — PASS (persistência, datas, busca de alimentos, catálogo de 5.838 itens, cálculos de perfil/atividade e runtime hardening).
- `npm run test:adaptive-plasma` — PASS.
- `npm run typecheck:calculations` — PASS.
- `node scripts/check-rendering-realism-v11-19.mjs` — PASS sob identidade V11.21.
- `node scripts/check-fluid-shaders.mjs` — PASS.

**Bloqueado / não validado:**
- `npm test` — parou na primeira etapa por `sh: 1: tsx: not found` (node_modules ausente).
- `npm run lint` — TypeScript reportou `TS2688: Cannot find type definition file for 'vite/client'` (dependências Vite ausentes).
- `npm run build` — `sh: 1: vite: not found`.
- `npm run test:gpu-shaders` — extrator GLSL agora resolve `METAL_SPECTRAL_FRESNEL_GLSL`, mas Chromium headless excedeu timeout ao inicializar WebGL/SwiftShader. Nenhum shader foi declarado compilado.
- Rede npm não foi usada para tentar instalar dependências nesta sessão; ambiente atual não tem `node_modules`.

## Revisão final própria

- Revisada a alteração do shader de metal: o Fresnel espectral agora também alimenta os três lóbulos anisotrópicos GGX; não ficou limitado apenas ao reflexo de ambiente.
- Corrigido o contrato legado de versão V11.20 para aceitar V11.21 e o expansor de shaders para carregar a fonte GLSL importada.
- Corrigida a normalização Heidler após teste RED documentar um pico anterior de 0.971.
- Confirmado que `body.mass` é atribuído diretamente somente dentro do setter central `setBodyMass`.
- O teste de divergência demonstra redução mensurada, mas não solver MAC nem divergência zero.

## Artefato final

- ZIP: `/mnt/data/TITAN_V11_21_REALISM_CLOSURE.zip`
- SHA-256 sidecar fornecido separadamente ao lado do ZIP.
- `unzip -t`: sem erros de integridade.
- ZIP extraído em diretório limpo; `package.json` confirmou versão 11.21.0; `npm run test:physics-v11-21` passou também na cópia extraída.
