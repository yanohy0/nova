# SDD ledger — plan: docs/superpowers/plans/2026-11-25-v11-22-rendering-closure.md

Workspace: isolated extraction of V11.21 at `/mnt/data/titan_v1122_work/titan`; source archive remains untouched at `/mnt/data/titan_latest/TITAN_V11_21_REALISM_CLOSURE.zip`. Supplied ZIP has no `.git` metadata, so no Git branch/worktree/commit history is claimed. No code reviewer subagent tool is available; final review is self-review.

## Pre-flight interface scan

- Task 1 consumes `FluidVorticityGrid`-owned Float32 buffers and its pressure diagnostic; task 2 does not share state with pressure.
- Task 2 modifies the shader source contract and task 3 modifies only the dual-body composite shader; no runtime interface overlap.
- Task 4 consumes package scripts and validation from tasks 1–3.

## Task 1 — IC(0)-PCG pressure projection

- RED: strengthened `fluid-pressure-projection.test.mjs` against V11.21; Jacobi failed the ≥90% divergence reduction/≤12 iterations requirement (previous 12-step residual ≈0.0922 vs initial ≈0.30164; old 28-iteration path only ≈43% reduction).
- Implemented PCG for `A=-Laplacian`, incomplete-Cholesky zero-fill preconditioner, workspace cache by grid dimensions, fixed preconditioner for initial/subsequent residuals, true residual recomputation, and right/bottom boundary face correction.
- First IC(0) attempt was GREEN-incorrect: test showed 1 iteration and divergence worsened. Root cause: initial residual used Jacobi while later residuals used IC(0), violating the fixed-preconditioner PCG recurrence. The initial residual is now preconditioned with the same cached IC(0) factor.
- GREEN: principal field `0.30164297 → 0.01301` in 8 iterations (~95.7% reduction); four additional deterministic fields, zero field, invalid grid and finite-velocity checks pass. Factor dimensions/cache are asserted.
- Ruling: keep the 48×24 2D pressure solver; no WebGPU/SPH migration for the current UI workload. Cost if wrong: future 3D/many-particle scenes will require a separate solver.

## Task 2 — stable plasma branch identity/cadence

- RED: source contract failed because the per-node cycle seed/rate was not explicitly separated from the temporal coordinate.
- GREEN: spatial branch ID/local coordinate remain fixed from `pos3D.x`; one stable seed controls a per-node cadence in `[0.72,1.20]`, while time controls the pulse and micro-curvature. `scripts/check-lightning-branch-stability-v11-22.mjs` passes.
- Ruling: branch VFX is still procedural, not electrostatic DBM/MTLE. No code from unlicensed dielectric-breakdown research was copied. Cost if wrong: physical discharge growth remains less exact than a real electric-field solver.

## Task 3 — three-radius screen-space skin diffusion

- RED: contract test failed against two-radius V11.21 because the mid lobe was absent.
- GREEN: center + near/mid/far RGB lobes at 0.9/2.6/5.8 px in four cardinal directions; depth gate, hue gate, accepted-weight normalization and alpha protection remain. New V11.22 checker and updated legacy checker pass.
- Ruling: do not claim BSSRDF. The current compositor filters rendered color in screen space, not incident irradiance in UV space. Cost if wrong: surface-to-surface bleed/blur may remain; solve with separate irradiance-space SSS pass and material thickness data.

## Task 4 — GitHub research, gates, validation and release

- Direct GitHub repository search and file/license inspection completed for water/pressure, glass/metals, plasma/noise, lightning, anatomy, skin and studio lighting. No Firecrawl used.
- Five high-relevance references per domain documented, with runtime mismatch, license/provenance and adoption decisions. No external executable code or 3D models copied.
- Anatomy map audited: deltoid anterior/lateral/posterior remain independently supported; most other labels resolve to shared training-group topology/deformation. No fake heads created.
- Lighting contract preserved: one diffuse halo behind body, no floor/plinth/projector/contact illumination.

### Fresh verification outputs

Passed:
- `npm run test:rendering-v11-22`
- `npm run test:rendering-realism`
- `npm run test:review`
- `npm run typecheck:calculations`

The rendering-realism suite also exercises adaptive plasma marcher, fluid shaders, UV multi-Gaussian skin maps, anatomical topology/morph contracts, studio key coherence and halo/floor constraints.

Blocked/not validated:
- `npm test`: exit 127, `tsx: not found`.
- `npm run lint`: exit 2, TypeScript cannot find `vite/client` types.
- `npm run build`: exit 127, `vite: not found`.
- `npm run test:gpu-shaders`: explicit `SKIPPED`; Chromium headless could not initialize WebGL/SwiftShader (`ETIMEDOUT`). No GPU shader compilation is claimed.
- `npm ci`: cannot run because V11.21 ZIP has no `package-lock.json`.
- `npm install --ignore-scripts --no-audit --no-fund --package-lock=false --no-save --prefer-offline`: timed out; did not produce `node_modules`.
- No real hardware GPU profiling, device visual QA or 360° approval was available.

## Final review

Final review: self-review (no subagent tool). Compared workspace against extracted V11.21 base; only intended files differ (pressure solver/test, fluid grid integration, plasma shader branch cycle, skin compositor, tests/scripts, version and documentation). Re-ran the focused rendering suite, rendering-realism suite, review suite and calculation typecheck after final implementation. Full build and GPU remain explicit release gates.
