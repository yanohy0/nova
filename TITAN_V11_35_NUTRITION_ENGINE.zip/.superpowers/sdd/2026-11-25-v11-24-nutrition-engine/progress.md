# SDD ledger — V11.24 Nutrition Engine

Plan: `docs/superpowers/plans/2026-11-25-v11-24-nutrition-engine.md`
Base archive: `TITAN_V11_23_ULTRA_REALISM.zip` (source archive preserved)
Workspace: isolated copy at `/mnt/data/titan_nutrition_v1123/worktree/TITAN_V11_24_NUTRITION_ENGINE`.

## Superpowers workflow and workspace

- Read and applied the Superpowers workflow skills for brainstorming/design, writing a plan, test-driven development, executing the plan and verification before completion.
- Input ZIP has no `.git` metadata. Work was done in a separate extracted copy; no Git branch, worktree, commit or SHA is claimed.
- No independent code-review subagent is available. Final review is a documented self-review.
- No external repository code, assets or runtime dependencies were copied/added.

## Research and architectural rulings

- GitHub repository snapshot (25/11/2026): Google OR-Tools 14,457 (Apache-2.0), Mealie 13,989 (AGPL-3.0), Tandoor 8,747 (NOASSERTION), wger 7,324 (AGPL-3.0), OpenNutriTracker 3,029 (GPL-3.0), HiGHS 1,952 (MIT), Open Food Facts Server 1,219 (AGPL-3.0), FoodYou 633 (GPL-3.0), Calories-In 187 (MIT); `llmn`/`eastokes/diet-optimization` 0–2 stars, license metadata absent.

- Mealie's recipe/meal scale control informed the dedicated portion-scale UX; Calories-In's ingredient → meal → plan stats tree informed aggregation/UI review; wger's ingredient sanity checks informed the data-quality review; OpenNutriTracker's one-pass nutrient aggregation and null-preservation informed the 23-micronutrient composer; HiGHS remains the current solver.
- OR-Tools is the higher-star general optimization suite, but its C++ core and Python/C#/Java wrappers do not make it a simple browser/TypeScript drop-in; it does not justify replacing the existing HiGHS convex QP path. No repository supplies validated RMR/TDEE clinical equations. Repository stars were not treated as scientific evidence.
- Keep the local-first Vite/React architecture and current HiGHS. No backend, queue, external engine or dependency added.
- Do not auto-select Katch, Cunningham, Ten Haaf or Pavlidou from activity/FFM alone. Without a measured RMR, use Mifflin as the conservative general-adult baseline; keep population-specific equations explicit.
- Do not replace TBCA 7.2 data with TBCA 7.3 until its CC BY-NC-ND / nutrition-calculation permissions are clarified.

## RED → GREEN

- `proportional-meal-scaling.test.ts`: RED first because `scaleDayPlanProportionallyToMealTargets` did not exist; GREEN after implementation. It checks meal shares, daily target, same multiplier across all ingredients and multiple recipes, proportional mode persistence for future yield edits, locked ingredients, fully locked recipes not constraining other recipes, 0.25×–4× serving limits, 2,000 g ingredient bound, missing/unresolved/low-confidence food data, zero target and unbalanced allocations.
- `composer-micronutrient-coverage.test.ts`: RED with the original six-micronutrient aggregation; GREEN after aggregation expanded to 23 nutrients and status-preserving totals. It checks quantified, trace and not-analyzed states, plus fiber, saturated fat and cholesterol aggregation through recipe → slot → day.
- `resting-metabolic-rate.test.mjs`: RED after changing the acceptance expectations to conservative automatic selection; GREEN after automatic RMR selection was restricted to measured indirect calorimetry or Mifflin baseline.
- `target-allocation.test.ts`: verifies per-meal protein/carbohydrate/fat constraints are used only when each distribution sums to 100%.
- `composition-preview.test.ts`: verifies missing and low-confidence foods downgrade solver certificate to `approximate`.

## Implemented

1. Added explicit per-meal kcal allocation from the daily target and one shared scaling factor for all known, unlocked ingredients in each meal.
2. Locked ingredients remain unchanged and contribute fixed kcal; unknown quantities are never invented; unresolved food energy is not guessed; incomplete coverage is surfaced.
3. Scaled ingredients enter proportional mode with the current composition stored as the new base, so future recipe-yield changes preserve the established ratios.
4. Fully locked recipes do not constrain or follow scaling of other recipes in the same meal.
5. Integrated the action into the live balance panel with undo snapshot support.
6. Expanded composer micronutrient aggregation and display to all 23 supported IDs, preserving `quantified`, `trace`, `not_analyzed` and `missing` instead of coercing missing data to zero.
7. Solver certificate is downgraded to `approximate` when food composition/quantity is incomplete or source confidence is low.
8. Incomplete per-meal P/C/G allocations are excluded from QP slot targets until each nutrient distribution closes 100%.
9. RMR automatic resolver is used by the goal calculator; profile form no longer persists the auto-preview method as if it were a manual selection. Legacy explicit profile values remain compatible.
10. Adaptive TDEE no longer waits for the goals modal to open; daily intake eligibility now explicitly requires complete quantified coverage.
11. Sodium CDRR 2,300 mg no longer carries a false `upperLimit`.
12. Updated version to 11.24.0, README, changelog, GitHub research and this ledger.

## Verification — passed

- `npm run test:review` — PASS (including the new proportional-scaling and 23-micronutrient tests).
- `npm run test:rendering-v11-23` — PASS (V11.23 rendering/physics regression chain preserved).
- `npm run test:adaptive-simulation` — PASS; steady synthetic RMSE 91.6 kcal/day, adaptation RMSE 74.6 kcal/day. Synthetic results are not clinical validation.
- `tsc -p tsconfig.calc-review.json` — PASS.
- Temporary strict nutrition-domain typecheck (`tsconfig.nutrition-review.json`) — PASS; temporary config removed before packaging because its typeRoots are host-specific.
- TypeScript/TSX syntax transpilation of all modified React/store/profile files — PASS (zero transpile diagnostics).
- Direct Node 22 tests passed: target allocation, proportional scaling, proportion rail, composition preview, composer micronutrients/dietary metrics, composer state, nutrition engine (including sodium AI/CDRR), RMR, Hall body-weight model, adaptive Kalman, profile calculation engine, food diary, food search, recipe search, catalog provenance (5,838 records), activity energy and activity reconciliation.

## Blocked / not claimed

- `npm test` / the full `tsx` suite: blocked because `tsx` is absent from the supplied archive's runtime (`node_modules` is absent).
- `npm run build`: blocked because `vite` is not installed.
- `npm run lint`: blocked because `vite/client` type package is not installed.
- HiGHS WASM integration test: not executed because `highs` package is not installed in this environment. The pure QP/model and certificate tests passed.
- `recipe-and-goals.test.ts`: direct Node execution blocked by an extensionless store import (`calendar.store`); the supported `npm run test:review` chain passed.
- No browser UI, mobile device, GPU shader, real-world nutrient dataset or clinical cohort validation is claimed.
- DIAAS/PDCAAS, full micronutrient constrained optimization, remote Open Food Facts acquisition and TBCA 7.3 migration remain explicitly out of scope / gated by missing source data or licensing.

## Final self-review

- Rechecked the proportional algorithm against multi-recipe meals, locked and fully locked recipes, missing and unresolved food composition, rounding, serving limits and future yield edits.
- Rechecked that no incomplete nutrient source can yield an `optimal` certificate.
- Rechecked that micronutrient null/trace semantics survive recipe → slot → day aggregation.
- Rechecked that the automatic RMR path does not infer an athlete-specific equation from activity level alone.
- Rechecked that the original archive was not modified; final ZIP integrity and SHA-256 are verified after packaging.
