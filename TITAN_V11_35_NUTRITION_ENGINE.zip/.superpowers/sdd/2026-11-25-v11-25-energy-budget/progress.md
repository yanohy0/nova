# SDD ledger — V11.25 energy budget and nutrition data quality

Plan: `docs/superpowers/plans/2026-11-25-v11-25-energy-budget.md`
Spec: `docs/superpowers/specs/2026-11-25-energy-budget-and-target-intake-design.md`
Research: `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_25.md`

## Workspace and source preservation

- Input: V11.24 project archive, extracted to an isolated copy.
- Git base commit: `a556045c4ced875075709012016cf9014233e8b7`.
- Work branch: `feature/v11.25-energy-budget`.
- The original V11.24 ZIP was not modified.
- No third-party code was copied and no runtime dependency was added.

## Decisions

- NASEM 2023 EER and observed adaptive TDEE are total-day expenditure estimates; both already include activity/exercise in their activity category or observed energy balance.
- RMR is exposed as a component. `TDEE - RMR` is labeled an aggregate non-resting residual, not measured NEAT, exercise or TEF.
- Intake target is `TDEE + signed goal adjustment`; loss is negative, maintenance/recomposition is neutral in this version, and gain is positive.
- Exercise is added only for an explicitly exercise-excluding base and only as NET kcal. Current NASEM/adaptive sources never add logged exercise a second time.
- Macro feasibility first reduces preferred protein down to its configured minimum; only if the minimum protein+fat floor still cannot fit does the final intake target relax the planned deficit. Effective and bounded adjustments are reported separately.
- A macro validator found TBCA 7.2 record `BRC1144B` with 219 g carbohydrate/100 g. It is quarantined; no decimal is guessed or rewritten.
- Proportional meal scaling uses valid energy data as its factor basis. An unquantified ingredient is scaled by the same factor only when a valid ingredient in the meal establishes that factor; an all-invalid meal is not scaled.

## Verification results

- Baseline V11.24 `npm run test:review`: PASS before modifications.
- V11.25 `npm run test:review`: PASS after modifications, including proportional meal scaling, 23-micronutrient coverage, nutrition persistence, RMR, Hall, adaptive TDEE, activity reconciliation, data-quality quarantine and energy-budget regression.
- `npm run test:nutrition-data-quality`: PASS; 5,836 entries from the TBCA adapter scanned, exactly one anomalous entry quarantined; search, recipe aggregation, QP preparation and proportional scaling behavior tested.
- `npm run test:energy-budget-boundaries`: PASS; 1,071,840 adult sex/age/height/weight/activity combinations scanned; NASEM EER remained above Mifflin RMR in every case (minimum margin 167 kcal).
- `npm run typecheck:calculations`: PASS (strict calculation typecheck).
- Focused strict typecheck for nutrition calculation modules: PASS with temporary ambient declarations for Node built-ins; no project dependency or source file was added for those shims.
- TypeScript/TSX syntax transpilation: PASS for 10 changed TS/TSX files.
- `npm run test:adaptive-simulation`: PASS; unchanged synthetic metrics (steady RMSE 91.6 kcal, after-adaptation RMSE 74.6 kcal, synthetic interval coverage 100%). These are simulation results, not clinical validation.
- `npm run test:rendering-v11-23`: PASS.
- `npm run test:rendering-realism`: PASS.
- `git diff --check`: PASS.

## Environment gates not passed

- `npm run lint`: BLOCKED because `vite/client` type declarations are absent (`node_modules` not installed).
- `npm run build`: BLOCKED because the `vite` executable is absent (`node_modules` not installed).
- Browser E2E, native Android/iOS build, live HiGHS WASM solve and GPU/WebGL device validation were not run in this environment.

## Remaining product/science gates

- Native workout energy is not yet persisted and connected to the profile calculation. The UI does not invent workout kcal; current TDEE sources already account for activity broadly.
- Complete multi-period micronutrient constraints and infeasibility explanations remain future work; unknown nutrient values must not be treated as zero.
- DIAAS/PDCAAS requires indispensable amino-acid profiles and ileal digestibility evidence.
- Raw/cooked yield, ingredient-specific volume density and nutrient-retention factors remain incomplete.
- TBCA 7.3 commercial/use-right clearance and external clinical validation of RMR/TDEE/Hall/adaptive models remain pending.
