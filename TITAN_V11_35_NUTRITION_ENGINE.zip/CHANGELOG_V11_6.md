# TITAN V.MAX V11.6 — Exercise Intelligence Library

## Exercise data and taxonomy

- Expanded the canonical exercise catalog from 17 to 32 records, importing 15 selected text-only entries from `yuhonas/free-exercise-db` and preserving all existing exercise slugs used by workout plans.
- Enriched the original catalog entries with Portuguese execution steps, technique tips, common errors, breathing cues, level, force and mechanic metadata.
- Added aliases, regressions, progressions and alternatives with validated internal slug references.
- Added a source and license registry for the reviewed exercise datasets, with dated GitHub star snapshots and separate data/media license statements.
- Kept every anatomy reference within the existing 14 TITAN muscle IDs. Primary and secondary muscles drive the 3D highlight; stabilizers remain separately labelled descriptive metadata.
- Added record-level provenance for selected Yuhonas records (source URL, record ID, Unlicense declaration and Git blob SHA).
- Did not bundle third-party images, GIFs or videos. Gym visual media, wger media and RepDB media remain excluded pending independent rights verification.

## Exercise library experience

- Added filters for muscle, equipment, difficulty, category and movement mechanic.
- Search now includes aliases, execution steps, technical tips, common errors, breathing cues and related exercises.
- Added an expandable exercise guide with execution, breathing, tips, errors, regressions, progressions, alternatives and source/license links.
- Added a collapsed source registry and visible explanation of the 3D mapping boundary.
- Preserved the existing "Ver no 3D" action and its primary/secondary muscle contract.

## Architecture and validation

- Added a stable `ExerciseRegistry` public read boundary for library, training and anatomy consumers.
- Kept `EXERCISE_MUSCLE_MAP` derived from the canonical catalog; no independent duplicate exercise-to-muscle mapping was introduced.
- Added contract tests for 32 unique records, all 14 muscle groups, required guide fields, source hashes/licenses, related exercise references, workout seed resolution and derived 3D highlights.
- Added search/filter regression tests for aliases, accent-insensitive search, guides and all filter dimensions.

## Explicit scope limits

- The full 1,324-record `hasaneyldrm` dataset and the full wger API catalog were reviewed but not bulk-imported in this release. Their data and media licensing/provenance differ by source or record; adding unreviewed records would weaken the license and muscle-mapping guarantees.
- `kinetic-place/exercises-db` informed the richer guide structure (steps, tips, errors, regressions and progressions); its entire database and external YouTube videos were not copied.
- The full app build, strict project typecheck, browser E2E and real device validation remain unverified in this environment because the project dependencies are not installed and outbound package registry DNS is unavailable.
