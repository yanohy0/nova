# V11.27 — Fechamento de qualidade nutricional, DIAAS e preparo

## Adicionado e corrigido

- Agregação de fibra, gordura saturada e colesterol com `value`, `quantifiedCount`, `sourceCount` e `dataStatus`. Uma fonte sem valor analisado invalida o total completo em receita, refeição e dia; totais parciais não são apresentados como totais reais.
- UI passa a mostrar a cobertura real da métrica (`quantificados/fontes`), sem usar o número de ingredientes conhecidos como denominador.
- Ingredientes com quantidade ausente, alimento não resolvido, macro inválido ou métrica opcional ausente são propagados como cobertura incompleta; composição inválida recebe `invalid_value`. O estado `missing` não é reclassificado como `not_analyzed` quando um ingrediente quantificado posterior é agregado.
- Motor DIAAS na API pública: perfis de aminoácidos indispensáveis, digestibilidade ileal específica, espécie/método/referência e estado do alimento validados antes da pontuação.
- DIAAS de fonte única não é truncado em 100; dieta mista é limitada a 100 conforme orientação FAO; `untruncatedDiaas` preserva o escore bruto para auditoria.
- Conversor de preparo na API pública: identidade e estado exatos, rendimento de massa, fatores explícitos e fontes/evidências independentes para macros e micronutrientes. Cada evidência também é vinculada ao ID do alimento de origem, estado original, estado preparado e método exato.
- Fatores sem evidência ou incompatíveis não são aplicados; valores ausentes permanecem `not_analyzed`. A tabela USDA de retenção não é usada indevidamente para macronutrientes.
- Testes adversariais adicionais para agregação entre refeições, DIAAS misto, evidência de preparo, rendimento e inconsistência de composição.
- Auditor de cobertura por nutriente/fonte e snapshot reproduzível dos 5.838 alimentos do catálogo; distingue ausência TBCA (`not_analyzed`) de ausência de campo OFF (`missing`) e só conta valores quantificados com unidade canônica e base positiva.

## Mantido da V11.26 e V11.25

- 29 referências adultas DRI, com as seis novas referências mantidas como `not_analyzed` quando o catálogo não possui valores compatíveis.
- Metas diárias de micronutrientes no otimizador de dia com RDA/AI e CDRR como preferências suaves, UL aplicável como limite superior no plano de alimentos e diagnóstico de dados incompletos/conflitos.
- Meta de ingestão derivada de TDEE total + ajuste do objetivo; perda usa déficit limitado, ganho usa superávit limitado, manutenção/recomposição usam ajuste energético zero nesta versão.
- NASEM EER e TDEE adaptativo já incluem gasto diário total e não recebem calorias de treino somadas novamente.
- Escala proporcional por refeição mantém um fator comum para ingredientes quantificados/destravados e mantém ingredientes travados fixos.

## Limites não resolvidos por ausência de dados ou validação externa

- Não existe no catálogo atual conjunto completo, por alimento e estado, de aminoácidos indispensáveis e digestibilidade ileal; portanto não há DIAAS real preenchido.
- Não há mapa TBCA→USDA de alimento/corte/preparo/rendimento/retention factors com correspondência validada; portanto conversão automática cru/cozido não está ativa.
- Os seis nutrientes adicionados à referência DRI ainda não têm cobertura de alimentos quantificada nos adaptadores atuais.
- Auditor do catálogo revela outras lacunas críticas além dos seis novos campos: niacina total em mg NE tem 0% de cobertura compatível (5.785 registros com unidades incompatíveis), vitamina K 0,1%, B5 0,1%, B7 abaixo de 0,1% e selênio 82,7%. Ver `docs/research/NUTRIENT_COVERAGE_TBCA72_V11_27.json`.
- Suplementos, água, bebidas externas e fontes odontológicas ingeridas ainda não fazem parte do balanço total de exposição de micronutrientes; a tela do otimizador limita expressamente a interpretação ao plano de alimentos.
- TBCA 7.3 requer revisão jurídica/licença antes de redistribuição; nenhuma base de dados licenciada foi copiada para este pacote.
- RMR/TDEE/Hall/adaptativo não receberam validação clínica externa ou calibração contra coortes nesta revisão.
- A versão de HiGHS WASM e build Vite não foram executadas porque a instalação de dependências excedeu o limite do ambiente; ver abaixo.

## Verificação executada

- `npm run test:review`: PASS (suite de revisão, não a suíte integral `npm test`).
- Testes direcionados de cobertura de métricas dietéticas, solver de micronutrientes e DIAAS/preparo: PASS.
- `tsc -p tsconfig.calc-review.json --pretty false`: PASS.
- Orçamento energético: base que exclui exercício, mas está abaixo do RMR, é rejeitada antes de adicionar treino NET.
- `git diff --check`: PASS.
- `npm run build`: bloqueado (`vite: not found`, exit 127); `npm run lint`: bloqueado por ausência de `vite/client` (exit 2); `npm test`: bloqueado (`tsx: not found`, exit 127). A instalação de dependências excedeu o limite do ambiente e `node_modules` permaneceu indisponível. Runtime HiGHS WASM não executado.
- Simulação adaptativa existente é sintética; não é validação clínica.
