import { MotionConfig } from 'motion/react';
import { Toaster } from 'sonner';
import { AppShell } from './app-core/navigation/AppShell';
import { AppProviders } from './app-core/providers/AppProviders';

export function App() {
  return (
    <MotionConfig reducedMotion="user">
      <AppProviders>
        <AppShell />
        <Toaster
          position="top-center"
          theme="dark"
          offset={16}
          mobileOffset={{ top: 'max(12px, env(safe-area-inset-top))' }}
          toastOptions={{
            duration: 2200,
            className: 'titan-liquid-glass-toast',
            style: {
              fontSize: '13px',
              fontWeight: 600,
              fontFamily: 'var(--font-mono)',
            },
          }}
        />
      </AppProviders>
    </MotionConfig>
  );
}

export default App;
