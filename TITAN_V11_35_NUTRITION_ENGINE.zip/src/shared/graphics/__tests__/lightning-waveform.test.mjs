import assert from 'node:assert/strict';
import { heidlerLightningEnvelope } from '../lightning-waveform.ts';

assert.equal(heidlerLightningEnvelope(0), 0, 'return stroke starts at zero');
assert.equal(heidlerLightningEnvelope(-0.1), 0, 'negative phase is clamped to zero');
const values = Array.from({ length: 1001 }, (_, i) => heidlerLightningEnvelope(i / 1000));
const peak = Math.max(...values);
const peakAt = values.indexOf(peak) / 1000;
assert.ok(peak > 0.995 && peak <= 1, `Heidler envelope must reach a unit-normalized peak (got ${peak})`);
assert.ok(peakAt > 0.04 && peakAt < 0.3, 'the pulse has a fast but non-instantaneous rise');
assert.ok(heidlerLightningEnvelope(0.65) < peak * 0.15, 'the long tail decays after the return stroke');
assert.ok(heidlerLightningEnvelope(0.95) < 0.03, 'the pulse is near zero before the next cycle');
console.log('PASS: normalized Heidler return-stroke waveform');
