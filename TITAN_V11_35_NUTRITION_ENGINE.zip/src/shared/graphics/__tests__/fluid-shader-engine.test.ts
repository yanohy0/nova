import assert from 'node:assert/strict';
import { createSpringArray, interpolateRatio, stepSpringNodes } from '../fluid-shader-engine';
import {
  CardDropletSim,
  FluidVorticityGrid,
  volumeToDropletFillY,
} from '../hydration-fluid-solver';

const wave = createSpringArray(24);
assert.equal(wave.length, 24);
assert.ok(wave.every((node) => node.height === 0 && node.velocity === 0));
const center = wave[12];
assert.ok(center);
center.velocity = -3.4;

for (let i = 0; i < 240; i++) {
  stepSpringNodes(wave, 0.12, 0.2, 0.14);
}

assert.ok(wave.every((node) => Number.isFinite(node.height) && Number.isFinite(node.velocity)));
assert.ok(wave.every((node) => Math.abs(node.height) < 0.02));
assert.ok(wave.every((node) => Math.abs(node.velocity) < 0.02));

const symmetric = createSpringArray(25);
const impulse = symmetric[12];
assert.ok(impulse);
impulse.velocity = -2.5;
for (let i = 0; i < 180; i++) stepSpringNodes(symmetric, 0.12, 0.2, 0.14);
for (let i = 0; i < 12; i++) {
  assert.ok(Math.abs((symmetric[i]?.height ?? 0) - (symmetric[24 - i]?.height ?? 0)) < 1e-6);
}
console.log('Fluid spring assertions passed.');

const settleAt60Hz = Array.from({ length: 60 }, (_, index) => index).reduce<number>((value) => interpolateRatio(value, 1, 1 / 60), 0);
const settleAt30Hz = Array.from({ length: 30 }, (_, index) => index).reduce<number>((value) => interpolateRatio(value, 1, 1 / 30), 0);
assert.ok(Math.abs(settleAt60Hz - settleAt30Hz) < 1e-9, 'progress interpolation must be frame-rate independent');
assert.ok(interpolateRatio(0.4, 0.8, 0.05) > 0.4);
assert.ok(interpolateRatio(0.8, 0.4, 0.05) < 0.8);
assert.equal(interpolateRatio(0.9998, 1, 1 / 60), 1, 'tiny residuals should settle exactly');
const nearTarget = interpolateRatio(0.9993, 1, 0.05, 0.14);
assert.equal(nearTarget, 1, 'the frame that crosses the settle threshold must snap to the target');
console.log('Progress interpolation assertions passed.');

// Analytic teardrop area-integral volume conservation assertions
const y0 = volumeToDropletFillY(0);
const y25 = volumeToDropletFillY(0.25);
const y50 = volumeToDropletFillY(0.5);
const y75 = volumeToDropletFillY(0.75);
const y100 = volumeToDropletFillY(1);
assert.ok(y0 < y25 && y25 < y50 && y50 < y75 && y75 < y100, 'volumeToDropletFillY must be strictly monotonic');
const bowlRise = y50 - y25;
const neckRise = y100 - y75;
assert.ok(neckRise > bowlRise, 'narrow upper teardrop neck must rise faster per unit volume than wide belly');

// 2D Vorticity-Confinement Navier-Stokes grid stability assertions
const grid = new FluidVorticityGrid(48, 24);
assert.equal(grid.isActive(), false);
grid.injectImpulse(0.5, 0.5, 1.5, -1.2, 0.9);
assert.equal(grid.isActive(), true);
for (let i = 0; i < 60; i++) {
  grid.step(1 / 60, 0.1, 0);
}
assert.ok(grid.packedRgba.every((v) => Number.isFinite(v) && v >= 0 && v <= 255));

// Card droplet CAH + Stick-Slip + Landau-Levich simulation assertions
const cardSim = new CardDropletSim();
assert.equal(cardSim.isActive(), false);
cardSim.triggerCondensationBurst(1.0);
assert.equal(cardSim.isActive(), true);
let impactCount = 0;
for (let i = 0; i < 360; i++) {
  cardSim.step(1 / 60, 0.05, () => {
    impactCount++;
  });
}
assert.ok(impactCount >= 0);
assert.ok(cardSim.gpu.drops.every((v) => Number.isFinite(v)));

// Component-aware collider + tactile pointer + ambient condensation assertions
const colliderSim = new CardDropletSim();
colliderSim.setColliders([
  { id: 'btn-250', kind: 'ledge', xMin: 0.35, yMin: 0.24, xMax: 0.72, yMax: 0.36 },
  { id: 'tank-1', kind: 'tank-pool', xMin: 0.28, yMin: 0.56, xMax: 0.94, yMax: 0.88 },
]);
colliderSim.setAmbientCondensation(true);
assert.equal(colliderSim.isActive(), true);
colliderSim.applyPointerSweep(0.50, 0.14, 0.02, 0.15, true);
let tankHit = false;
for (let i = 0; i < 420; i++) {
  colliderSim.step(1 / 60, 0.02, (evt) => {
    if (evt.target === 'tank' && evt.strength > 0.5) {
      tankHit = true;
    }
  });
}
assert.equal(tankHit, true, 'sliding droplets must collide and splash into tank-pool collider');
colliderSim.shakeCollider('btn-250');
assert.ok((colliderSim.gpu.obstacleWetness[0] ?? 0) > 0.5, 'shakeCollider must wet the obstacle rim');
assert.ok(colliderSim.gpu.obstacles.every((v) => Number.isFinite(v)));
console.log('SOTA hydration fluid solver assertions passed.');

