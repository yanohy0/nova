export interface PressureProjectionWorkspace {
  divergence: Float32Array;
  pressure: Float32Array;
  pressureResidual: Float32Array;
  pressurePreconditioned: Float32Array;
  pressureDirection: Float32Array;
  pressureProduct: Float32Array;
  preconditionerInverseDiagonal: Float32Array;
  preconditionerForward: Float32Array;
  preconditionerWidth?: number;
  preconditionerHeight?: number;
  preconditionerReady?: boolean;
}

export interface PressureProjectionOptions {
  minIterations?: number;
  maxIterations?: number;
  relativeTolerance?: number;
}

export interface PressureProjectionDiagnostics {
  iterations: number;
  divergenceRmsBefore: number;
  divergenceRmsAfter: number;
  poissonResidualRms: number;
  converged: boolean;
}

function assertGrid(u: Float32Array, v: Float32Array, width: number, height: number, workspace: PressureProjectionWorkspace): void {
  const size = width * height;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 3 || height < 3 ||
      u.length !== size || v.length !== size || workspace.divergence.length !== size ||
      workspace.pressure.length !== size || workspace.pressureResidual.length !== size ||
      workspace.pressurePreconditioned.length !== size || workspace.pressureDirection.length !== size ||
      workspace.pressureProduct.length !== size || workspace.preconditionerInverseDiagonal.length !== size ||
      workspace.preconditionerForward.length !== size) {
    throw new RangeError('Pressure projection buffers must match a rectangular grid of at least 3x3');
  }
}

function divergenceRms(divergence: Float32Array, width: number, height: number): number {
  let sum = 0;
  let count = 0;
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const value = divergence[y * width + x] ?? 0;
      sum += value * value;
      count++;
    }
  }
  return Math.sqrt(sum / Math.max(1, count));
}

function interiorDot(a: Float32Array, b: Float32Array, width: number, height: number): number {
  let sum = 0;
  for (let y = 1; y < height - 1; y++) {
    const row = y * width;
    for (let x = 1; x < width - 1; x++) {
      const i = row + x;
      sum += (a[i] ?? 0) * (b[i] ?? 0);
    }
  }
  return sum;
}

function buildIncompleteCholeskyZeroFill(
  inverseDiagonal: Float32Array,
  width: number,
  height: number,
): void {
  inverseDiagonal.fill(0);
  // IC(0) for the five-point SPD negative Laplacian. The fixed stencil keeps
  // the factor sparse: no fill outside the original left/down pattern.
  for (let y = 1; y < height - 1; y++) {
    const row = y * width;
    for (let x = 1; x < width - 1; x++) {
      const i = row + x;
      const left = x > 1 ? (inverseDiagonal[i - 1] ?? 0) : 0;
      const down = y > 1 ? (inverseDiagonal[i - width] ?? 0) : 0;
      const denominator = Math.max(0.25, 4 - left - down);
      inverseDiagonal[i] = 1 / denominator;
    }
  }
}

function applyIncompleteCholeskyPreconditioner(
  residual: Float32Array,
  output: Float32Array,
  inverseDiagonal: Float32Array,
  forward: Float32Array,
  width: number,
  height: number,
): void {
  forward.fill(0);
  output.fill(0);
  // Forward solve L*y = r, with L's diagonal sqrt(1 / inverseDiagonal).
  for (let y = 1; y < height - 1; y++) {
    const row = y * width;
    for (let x = 1; x < width - 1; x++) {
      const i = row + x;
      const rootDiagonal = Math.sqrt(inverseDiagonal[i] ?? 0);
      let value = residual[i] ?? 0;
      if (x > 1) value += Math.sqrt(inverseDiagonal[i - 1] ?? 0) * (forward[i - 1] ?? 0);
      if (y > 1) value += Math.sqrt(inverseDiagonal[i - width] ?? 0) * (forward[i - width] ?? 0);
      forward[i] = value * rootDiagonal;
    }
  }
  // Backward solve L^T*z = y.
  for (let y = height - 2; y >= 1; y--) {
    const row = y * width;
    for (let x = width - 2; x >= 1; x--) {
      const i = row + x;
      const rootDiagonal = Math.sqrt(inverseDiagonal[i] ?? 0);
      let value = forward[i] ?? 0;
      if (x < width - 2) value += rootDiagonal * (output[i + 1] ?? 0);
      if (y < height - 2) value += rootDiagonal * (output[i + width] ?? 0);
      output[i] = value * rootDiagonal;
    }
  }
}

function applyNegativeLaplacian(
  input: Float32Array,
  output: Float32Array,
  width: number,
  height: number,
): void {
  output.fill(0);
  for (let y = 1; y < height - 1; y++) {
    const row = y * width;
    for (let x = 1; x < width - 1; x++) {
      const i = row + x;
      output[i] = 4 * (input[i] ?? 0) - (input[i - 1] ?? 0) -
        (input[i + 1] ?? 0) - (input[i - width] ?? 0) - (input[i + width] ?? 0);
    }
  }
}

/**
 * Cell-indexed 2D projection using the compatible forward-divergence /
 * backward-gradient operator pair. The pressure system A=-Laplacian is solved
 * with incomplete-Cholesky zero-fill preconditioned conjugate gradient (IC(0)-PCG).
 * The factor is cached in the caller-owned workspace for the current grid dimensions.
 * The zero border is
 * a Dirichlet pressure boundary; boundary faces used by interior divergence
 * are corrected too. This is still a compact cell-indexed UI grid, not MAC CFD.
 */
export function projectIncompressibleVelocity2D(
  u: Float32Array,
  v: Float32Array,
  width: number,
  height: number,
  workspace: PressureProjectionWorkspace,
  options: PressureProjectionOptions = {},
): PressureProjectionDiagnostics {
  assertGrid(u, v, width, height, workspace);
  const minIterations = Math.max(1, Math.min(64, Math.floor(options.minIterations ?? 4)));
  const maxIterations = Math.max(minIterations, Math.min(64, Math.floor(options.maxIterations ?? 32)));
  const tolerance = Math.max(1e-5, Math.min(0.5, options.relativeTolerance ?? 0.05));
  const {
    divergence,
    pressure,
    pressureResidual,
    pressurePreconditioned,
    pressureDirection,
    pressureProduct,
  } = workspace;

  pressure.fill(0);
  pressureResidual.fill(0);
  pressurePreconditioned.fill(0);
  pressureDirection.fill(0);
  pressureProduct.fill(0);

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = y * width + x;
      divergence[i] = -((u[i + 1] ?? 0) - (u[i] ?? 0) + (v[i + width] ?? 0) - (v[i] ?? 0));
    }
  }

  const before = divergenceRms(divergence, width, height);
  if (before <= 1e-12) {
    divergence.fill(0);
    return {
      iterations: 0,
      divergenceRmsBefore: before,
      divergenceRmsAfter: before,
      poissonResidualRms: 0,
      converged: true,
    };
  }

  // x0=0 => r0=b. Build and apply the same fixed IC(0) preconditioner
  // for the initial residual and every subsequent residual. Mixing Jacobi on
  // the first iteration with IC(0) later violates the fixed-M PCG recurrence.
  pressureResidual.set(divergence);
  if (!workspace.preconditionerReady || workspace.preconditionerWidth !== width || workspace.preconditionerHeight !== height) {
    buildIncompleteCholeskyZeroFill(workspace.preconditionerInverseDiagonal, width, height);
    workspace.preconditionerWidth = width;
    workspace.preconditionerHeight = height;
    workspace.preconditionerReady = true;
  }
  applyIncompleteCholeskyPreconditioner(
    pressureResidual,
    pressurePreconditioned,
    workspace.preconditionerInverseDiagonal,
    workspace.preconditionerForward,
    width,
    height,
  );
  pressureDirection.set(pressurePreconditioned);

  let rho = interiorDot(pressureResidual, pressurePreconditioned, width, height);
  let residual = before;
  let iterations = 0;
  const residualThreshold = Math.max(1e-6, before * tolerance);

  for (let iteration = 0; iteration < maxIterations; iteration++) {
    applyNegativeLaplacian(pressureDirection, pressureProduct, width, height);
    const denominator = interiorDot(pressureDirection, pressureProduct, width, height);
    if (!Number.isFinite(denominator) || denominator <= 1e-20 || !Number.isFinite(rho) || rho <= 1e-24) break;

    const alpha = rho / denominator;
    if (!Number.isFinite(alpha)) break;
    for (let y = 1; y < height - 1; y++) {
      const row = y * width;
      for (let x = 1; x < width - 1; x++) {
        const i = row + x;
        pressure[i] = (pressure[i] ?? 0) + alpha * (pressureDirection[i] ?? 0);
        pressureResidual[i] = (pressureResidual[i] ?? 0) - alpha * (pressureProduct[i] ?? 0);
      }
    }
    iterations = iteration + 1;
    residual = divergenceRms(pressureResidual, width, height);
    if (iterations >= minIterations && residual <= residualThreshold) break;

    applyIncompleteCholeskyPreconditioner(
      pressureResidual,
      pressurePreconditioned,
      workspace.preconditionerInverseDiagonal,
      workspace.preconditionerForward,
      width,
      height,
    );
    const rhoNext = interiorDot(pressureResidual, pressurePreconditioned, width, height);
    if (!Number.isFinite(rhoNext) || rhoNext <= 1e-24) break;
    const beta = rhoNext / rho;
    for (let y = 1; y < height - 1; y++) {
      const row = y * width;
      for (let x = 1; x < width - 1; x++) {
        const i = row + x;
        pressureDirection[i] = (pressurePreconditioned[i] ?? 0) + beta * (pressureDirection[i] ?? 0);
      }
    }
    rho = rhoNext;
  }

  // Re-evaluate the true Poisson residual from A*p before reporting convergence;
  // the recursively updated CG residual can drift slightly in Float32 storage.
  applyNegativeLaplacian(pressure, pressureProduct, width, height);
  for (let y = 1; y < height - 1; y++) {
    const row = y * width;
    for (let x = 1; x < width - 1; x++) {
      const i = row + x;
      pressureResidual[i] = (divergence[i] ?? 0) - (pressureProduct[i] ?? 0);
    }
  }
  residual = divergenceRms(pressureResidual, width, height);

  // Correct all faces adjacent to the interior domain, including right and
  // bottom boundary faces. Omitting those faces leaves a large residual at
  // the last interior row/column even when the Poisson equation is solved.
  for (let y = 1; y < height - 1; y++) {
    const row = y * width;
    for (let x = 1; x < width; x++) {
      const i = row + x;
      u[i] = (u[i] ?? 0) - ((pressure[i] ?? 0) - (pressure[i - 1] ?? 0));
    }
  }
  for (let y = 1; y < height; y++) {
    const row = y * width;
    for (let x = 1; x < width - 1; x++) {
      const i = row + x;
      v[i] = (v[i] ?? 0) - ((pressure[i] ?? 0) - (pressure[i - width] ?? 0));
    }
  }

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = y * width + x;
      divergence[i] = -((u[i + 1] ?? 0) - (u[i] ?? 0) + (v[i + width] ?? 0) - (v[i] ?? 0));
    }
  }
  const after = divergenceRms(divergence, width, height);
  return {
    iterations,
    divergenceRmsBefore: before,
    divergenceRmsAfter: after,
    poissonResidualRms: residual,
    converged: residual <= residualThreshold,
  };
}
