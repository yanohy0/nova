export interface LocalDateParts {
  year: number;
  month: number;
  day: number;
}

export interface LocalDayDescriptor {
  key: string;
  shortLabel: string;
  fullLabel: string;
}

const WEEKDAYS_FULL = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'] as const;
const WEEKDAYS_SHORT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'] as const;
const MONTHS_SHORT = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'] as const;

export function parseLocalDateKey(dateKey: string): LocalDateParts | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return null;
  const [year, month, day] = dateKey.split('-').map(Number);
  if (!year || !month || !day || month < 1 || month > 12 || day < 1 || day > 31) return null;
  const date = new Date(0);
  date.setUTCHours(12, 0, 0, 0);
  date.setUTCFullYear(year, month - 1, day);
  if (
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() !== month - 1 ||
    date.getUTCDate() !== day
  ) return null;
  return { year, month, day };
}

export function isValidLocalDateKey(dateKey: string): boolean {
  return parseLocalDateKey(dateKey) !== null;
}

export function getLocalDateKey(date: Date = new Date()): string {
  if (Number.isNaN(date.getTime())) throw new RangeError('Invalid date supplied.');
  const year = String(date.getFullYear()).padStart(4, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function toUtcDate(parts: LocalDateParts): Date {
  const date = new Date(0);
  date.setUTCHours(12, 0, 0, 0);
  date.setUTCFullYear(parts.year, parts.month - 1, parts.day);
  return date;
}

export function shiftLocalDateKey(dateKey: string, offsetDays: number): string | null {
  const parts = parseLocalDateKey(dateKey);
  if (!parts || !Number.isInteger(offsetDays)) return null;
  const date = toUtcDate(parts);
  date.setUTCDate(date.getUTCDate() + offsetDays);
  return `${String(date.getUTCFullYear()).padStart(4, '0')}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
}

export function formatLocalDateLabel(dateKey: string): Omit<LocalDayDescriptor, 'key'> {
  const parts = parseLocalDateKey(dateKey);
  if (!parts) throw new RangeError(`Invalid local date key: ${dateKey}`);
  const weekdayIndex = toUtcDate(parts).getUTCDay();
  const weekdayFull = WEEKDAYS_FULL[weekdayIndex] ?? 'Dia';
  const weekdayShort = WEEKDAYS_SHORT[weekdayIndex] ?? 'Dia';
  const monthShort = MONTHS_SHORT[parts.month - 1] ?? 'mês';
  return {
    shortLabel: `${weekdayShort} · ${parts.day}`,
    fullLabel: `${weekdayFull}, ${parts.day} ${monthShort}`,
  };
}

export function buildRecentLocalDayDescriptors(
  today: Date = new Date(),
  count = 5,
): LocalDayDescriptor[] {
  if (!Number.isInteger(count) || count < 1 || count > 31) {
    throw new RangeError('Day descriptor count must be an integer between 1 and 31.');
  }
  const todayKey = getLocalDateKey(today);
  return Array.from({ length: count }, (_, index) => {
    const key = shiftLocalDateKey(todayKey, index - count + 1);
    if (!key) throw new RangeError(`Unable to calculate local date from ${todayKey}`);
    return { key, ...formatLocalDateLabel(key) };
  });
}
