export function yieldToMain(): Promise<void> {
  if (typeof globalThis !== 'undefined') {
    const nav = globalThis as unknown as {
      scheduler?: { yield?: () => Promise<void> };
    };
    if (typeof nav.scheduler?.yield === 'function') {
      return nav.scheduler.yield();
    }
  }
  return new Promise((resolve) => setTimeout(resolve, 0));
}

const pendingYieldQueue: Array<() => void> = [];
let drainingQueue = false;

async function drainYieldQueue(): Promise<void> {
  if (drainingQueue) return;
  drainingQueue = true;
  try {
    let frameStart = performance.now();
    while (pendingYieldQueue.length > 0) {
      const task = pendingYieldQueue.shift();
      if (task) task();
      if (performance.now() - frameStart >= 6) {
        await yieldToMain();
        frameStart = performance.now();
      }
    }
  } finally {
    drainingQueue = false;
  }
}

export function enqueueYieldingTask<T>(
  work: () => T,
  signal: { cancelled: boolean },
): Promise<T | null> {
  return new Promise((resolve) => {
    pendingYieldQueue.push(() => {
      if (signal.cancelled) {
        resolve(null);
        return;
      }
      resolve(work());
    });
    void drainYieldQueue();
  });
}
