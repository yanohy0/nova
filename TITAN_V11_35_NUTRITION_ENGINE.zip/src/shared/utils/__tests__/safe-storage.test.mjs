import assert from 'node:assert/strict';
import { safeStorageAdapter } from '../../../infrastructure/storage/local-storage.ts';

const previousWindow = globalThis.window;
try {
  Object.defineProperty(globalThis, 'window', {
    configurable: true,
    value: {
      localStorage: {
        getItem: (key) => {
          if (key === 'titan:safe-storage-overwrite-test') return 'old-local-value';
          if (key === 'titan:safe-storage-test') return 'stale-local-after-removal';
          return null;
        },
        setItem: () => { throw new Error('storage denied'); },
        removeItem: () => { throw new Error('storage denied'); },
      },
    },
  });
  safeStorageAdapter.setItem('titan:safe-storage-test', 'saved-in-memory');
  assert.equal(safeStorageAdapter.getItem('titan:safe-storage-test'), 'saved-in-memory');
  safeStorageAdapter.removeItem('titan:safe-storage-test');
  assert.equal(safeStorageAdapter.getItem('titan:safe-storage-test'), null);

  safeStorageAdapter.setItem('titan:safe-storage-overwrite-test', 'new-memory-value');
  assert.equal(safeStorageAdapter.getItem('titan:safe-storage-overwrite-test'), 'new-memory-value', 'the in-memory write must override stale readable localStorage data');
  safeStorageAdapter.removeItem('titan:safe-storage-overwrite-test');
} finally {
  if (previousWindow === undefined) delete globalThis.window;
  else Object.defineProperty(globalThis, 'window', { configurable: true, value: previousWindow });
}
console.log('Safe storage tests passed.');
