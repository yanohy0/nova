export const TITAN_BACKUP_FORMAT = 'titan-local-backup' as const;
export const TITAN_BACKUP_VERSION = 1 as const;

export const BACKUP_STORAGE_KEYS = [
  'titan:profile:v1',
  'titan:training:v1',
  'titan:nutrition:v1',
  'titan:evolution:v1',
  'titan:hydration:v1',
] as const;

export interface BackupStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface TitanBackupEnvelope {
  format: typeof TITAN_BACKUP_FORMAT;
  schemaVersion: typeof TITAN_BACKUP_VERSION;
  createdAt: string;
  stores: Partial<Record<(typeof BACKUP_STORAGE_KEYS)[number], string>>;
}

export type BackupParseResult =
  | { ok: true; value: TitanBackupEnvelope }
  | { ok: false; error: string };

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isPersistedStore(value: unknown): boolean {
  return isRecord(value) && isRecord(value.state) &&
    typeof value.version === 'number' && Number.isInteger(value.version) && value.version >= 0;
}

export function createTitanBackup(storage: BackupStorage, createdAt = new Date().toISOString()): TitanBackupEnvelope {
  const stores: TitanBackupEnvelope['stores'] = {};
  for (const key of BACKUP_STORAGE_KEYS) {
    const value = storage.getItem(key);
    if (value === null) continue;
    const parsed: unknown = JSON.parse(value);
    if (!isPersistedStore(parsed)) throw new Error(`O registro ${key} não possui o formato de persistência esperado.`);
    stores[key] = value;
  }
  if (Object.keys(stores).length === 0) throw new Error('Ainda não há registros locais para exportar.');
  return {
    format: TITAN_BACKUP_FORMAT,
    schemaVersion: TITAN_BACKUP_VERSION,
    createdAt,
    stores,
  };
}

export function parseTitanBackup(raw: string): BackupParseResult {
  if (raw.length > 25 * 1024 * 1024) return { ok: false, error: 'Arquivo muito grande. O limite de backup é 25 MB.' };
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return { ok: false, error: 'O arquivo não contém JSON válido.' };
  }
  if (!isRecord(parsed) || parsed.format !== TITAN_BACKUP_FORMAT || parsed.schemaVersion !== TITAN_BACKUP_VERSION) {
    return { ok: false, error: 'Formato ou versão de backup não reconhecidos.' };
  }
  if (typeof parsed.createdAt !== 'string' || Number.isNaN(Date.parse(parsed.createdAt)) || !isRecord(parsed.stores)) {
    return { ok: false, error: 'Metadados do backup inválidos.' };
  }

  const stores: TitanBackupEnvelope['stores'] = {};
  const allowedKeys = new Set<string>(BACKUP_STORAGE_KEYS);
  for (const [key, value] of Object.entries(parsed.stores)) {
    if (!allowedKeys.has(key)) return { ok: false, error: `O backup contém um armazenamento não permitido: ${key}.` };
    if (typeof value !== 'string') return { ok: false, error: `O conteúdo do armazenamento ${key} é inválido.` };
    let persisted: unknown;
    try {
      persisted = JSON.parse(value);
    } catch {
      return { ok: false, error: `O conteúdo do armazenamento ${key} não é JSON válido.` };
    }
    if (!isPersistedStore(persisted)) return { ok: false, error: `O conteúdo do armazenamento ${key} não possui estado persistido válido.` };
    stores[key as keyof typeof stores] = value;
  }
  if (Object.keys(stores).length === 0) return { ok: false, error: 'O backup não contém dados para restaurar.' };
  return {
    ok: true,
    value: {
      format: TITAN_BACKUP_FORMAT,
      schemaVersion: TITAN_BACKUP_VERSION,
      createdAt: parsed.createdAt,
      stores,
    },
  };
}

/** Validate the entire backup before changing storage, and roll back if a write fails. */
export function restoreTitanBackup(backup: TitanBackupEnvelope, storage: BackupStorage): { ok: true } | { ok: false; error: string } {
  const previous = new Map<string, string | null>();
  for (const key of BACKUP_STORAGE_KEYS) previous.set(key, storage.getItem(key));
  try {
    for (const key of BACKUP_STORAGE_KEYS) {
      const value = backup.stores[key];
      if (value === undefined) storage.removeItem(key);
      else storage.setItem(key, value);
    }
    return { ok: true };
  } catch {
    for (const key of BACKUP_STORAGE_KEYS) {
      const oldValue = previous.get(key);
      try {
        if (oldValue === null || oldValue === undefined) storage.removeItem(key);
        else storage.setItem(key, oldValue);
      } catch {
        // Best-effort rollback. The caller must show the restore failure clearly.
      }
    }
    return { ok: false, error: 'Não foi possível gravar o backup. Os dados anteriores foram restaurados quando possível.' };
  }
}
