import assert from 'node:assert/strict';
import {
  BACKUP_STORAGE_KEYS,
  createTitanBackup,
  parseTitanBackup,
  restoreTitanBackup,
} from '../titan-backup.ts';

class MemoryStorage {
  values = new Map();
  getItem(key) { return this.values.get(key) ?? null; }
  setItem(key, value) { this.values.set(key, value); }
  removeItem(key) { this.values.delete(key); }
}
const storage = new MemoryStorage();
const persistedProfile = JSON.stringify({ state: { profile: { age: 31 } }, version: 1 });
storage.setItem(BACKUP_STORAGE_KEYS[0], persistedProfile);
storage.setItem('unrelated:key', 'not included');
const backup = createTitanBackup(storage, '2026-11-23T12:00:00.000Z');
assert.deepEqual(Object.keys(backup.stores), [BACKUP_STORAGE_KEYS[0]]);
const parsed = parseTitanBackup(JSON.stringify(backup));
assert.equal(parsed.ok, true);
assert.equal(parsed.value.createdAt, '2026-11-23T12:00:00.000Z');

storage.setItem(BACKUP_STORAGE_KEYS[0], JSON.stringify({ state: { profile: { age: 45 } }, version: 1 }));
storage.setItem(BACKUP_STORAGE_KEYS[1], JSON.stringify({ state: { plans: [] }, version: 1 }));
const restored = restoreTitanBackup(parsed.value, storage);
assert.deepEqual(restored, { ok: true });
assert.equal(storage.getItem(BACKUP_STORAGE_KEYS[0]), persistedProfile);
assert.equal(storage.getItem(BACKUP_STORAGE_KEYS[1]), null, 'restore removes known stores absent from the backup');

assert.equal(parseTitanBackup('{bad json').ok, false);
assert.equal(parseTitanBackup(JSON.stringify({ ...backup, schemaVersion: 99 })).ok, false);
assert.equal(parseTitanBackup(JSON.stringify({ ...backup, stores: { 'evil:key': '{}' } })).ok, false);
assert.equal(parseTitanBackup(JSON.stringify({ ...backup, stores: { [BACKUP_STORAGE_KEYS[0]]: 'not-json' } })).ok, false);
assert.equal(parseTitanBackup(JSON.stringify({ ...backup, stores: { [BACKUP_STORAGE_KEYS[0]]: JSON.stringify({ state: null, version: 1 }) } })).ok, false);
// A failed write must trigger best-effort restoration of the previous local state.
class FailingStorage extends MemoryStorage {
  failNextWrite = true;
  setItem(key, value) {
    if (this.failNextWrite) {
      this.failNextWrite = false;
      throw new Error('simulated quota error');
    }
    super.setItem(key, value);
  }
}
const failingStorage = new FailingStorage();
failingStorage.values.set(BACKUP_STORAGE_KEYS[0], 'old-profile');
const failedRestore = restoreTitanBackup(parsed.value, failingStorage);
assert.equal(failedRestore.ok, false);
assert.equal(failingStorage.getItem(BACKUP_STORAGE_KEYS[0]), 'old-profile', 'restore failure attempts rollback');
console.log('TITAN backup tests passed.');
