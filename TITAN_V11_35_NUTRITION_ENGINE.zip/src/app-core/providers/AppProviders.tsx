import type { ReactNode } from 'react';
import { AppErrorBoundary } from '../error-boundaries/AppErrorBoundary';

export function AppProviders({ children }: { children: ReactNode }) {
  return <AppErrorBoundary>{children}</AppErrorBoundary>;
}
