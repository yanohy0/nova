import { Component, type ErrorInfo, type ReactNode } from 'react';
import { reportError } from '@/src/infrastructure/monitoring/error-reporter';
import { Button } from '@/src/shared/ui/Button';
import { Surface } from '@/src/shared/ui/Surface';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

export class AppErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    reportError(error, {
      source: 'error-boundary',
      componentStack: info.componentStack ?? undefined,
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[100dvh] bg-[var(--titan-bg-canvas)] text-[var(--titan-text-primary)] flex items-center justify-center p-6">
          <Surface className="max-w-md w-full p-6 space-y-4">
            <h1 className="text-lg font-semibold">Ocorreu uma interrupção inesperada</h1>
            <p className="text-sm text-[var(--titan-text-secondary)]">
              Os dados registrados na sessão permanecem preservados localmente.
            </p>
            <Button
              variant="primary"
              fullWidth
              onClick={() => this.setState({ hasError: false })}
            >
              Tentar recuperar visualização
            </Button>
          </Surface>
        </div>
      );
    }

    return this.props.children;
  }
}
