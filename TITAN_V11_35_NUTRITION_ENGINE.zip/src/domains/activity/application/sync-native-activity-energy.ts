import {
  getNativeHealthPlatformBridge,
  normalizeHealthConnectActivityRecords,
  normalizeHealthKitActivityRecords,
  reconcileActivityEnergyRecords,
  type HealthConnectActivityRecordInput,
  type HealthKitActivityRecordInput,
  type ReconciledActivityEnergy,
} from '../domain/rules/activity-reconciliation.ts';

export type NativeActivitySyncResult =
  | { status: 'bridge_unavailable'; platform: null; reconciliation: null; warnings: string[] }
  | { status: 'platform_unavailable'; platform: string; reconciliation: null; warnings: string[] }
  | { status: 'synced'; platform: string; reconciliation: ReconciledActivityEnergy; warnings: string[] };

/**
 * Pull native records only after the platform adapter has completed its
 * permission flow. This service reconciles imports but deliberately does not
 * add session calories to the adaptive TDEE (which already observes total body
 * energy balance and would otherwise double-count movement).
 */
export async function syncNativeActivityEnergy(
  startIso: string,
  endIso: string,
): Promise<NativeActivitySyncResult> {
  const start = Date.parse(startIso);
  const end = Date.parse(endIso);
  if (!Number.isFinite(start) || !Number.isFinite(end) || start >= end || end - start > 366 * 24 * 60 * 60 * 1000) {
    throw new RangeError('Informe um intervalo ISO válido de até 366 dias para sincronizar atividade.');
  }
  const bridge = getNativeHealthPlatformBridge();
  if (!bridge) {
    return { status: 'bridge_unavailable', platform: null, reconciliation: null,
      warnings: ['Nenhuma ponte nativa foi injetada; sincronização de sensores não está disponível no navegador/preview.'] };
  }
  if (!await bridge.isAvailable()) {
    return { status: 'platform_unavailable', platform: bridge.platform, reconciliation: null,
      warnings: ['Health Connect/HealthKit não está disponível neste aparelho ou host.'] };
  }
  await bridge.requestReadAuthorization();
  const payload = await bridge.readActivityEnergy(startIso, endIso);
  const normalized = bridge.platform === 'android_health_connect'
    ? normalizeHealthConnectActivityRecords(payload as unknown as HealthConnectActivityRecordInput[])
    : normalizeHealthKitActivityRecords(payload as unknown as HealthKitActivityRecordInput[]);
  const reconciliation = reconcileActivityEnergyRecords(normalized);
  return {
    status: 'synced', platform: bridge.platform, reconciliation,
    warnings: [
      ...reconciliation.warnings,
      'Calorias ativas reconciliadas são usadas para histórico de atividade; não são somadas automaticamente ao TDEE adaptativo, que já infere o gasto total a partir da ingestão e da tendência de peso.',
      ...(bridge.platform === 'ios_healthkit' ? ['HealthKit não revela ao app se a permissão de leitura foi negada; uma lista vazia não prova ausência de atividade.'] : []),
    ],
  };
}
