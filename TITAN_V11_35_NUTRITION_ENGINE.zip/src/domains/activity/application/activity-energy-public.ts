export {
  validateActivityMetCatalog,
  estimateActivityEnergy,
} from '../domain/rules/activity-energy';
export type {
  ActivityEnergyInput,
  ActivityEnergyEstimate,
  ActivityMetEntry,
  ActivityMetCatalogValidation,
  MetMeasurementStatus,
} from '../domain/rules/activity-energy';
export { integrateOpenMetabolicsPower } from '../domain/rules/openmetabolics-bridge';
export type {
  OpenMetabolicsPowerSample,
  OpenMetabolicsSessionInput,
  OpenMetabolicsSessionEstimate,
} from '../domain/rules/openmetabolics-bridge';

export { reconcileActivityEnergyRecords, normalizeHealthConnectActivityRecords, normalizeHealthKitActivityRecords, getNativeHealthPlatformBridge } from '../domain/rules/activity-reconciliation';
export type { ImportedActivityEnergyRecord, ReconciledActivityEnergy, ActivityOrigin, ActivityRecordKind, ActivityEnergyKind, ActivityMeasurementQuality, HealthConnectActivityRecordInput, HealthKitActivityRecordInput, HealthPlatformBridge } from '../domain/rules/activity-reconciliation';
export { validateVersionedActivityMetCatalog, selectMetEntry } from '../domain/rules/activity-met-catalog';
export type { VersionedActivityMetCatalog, MetCatalogImportResult } from '../domain/rules/activity-met-catalog';
export { syncNativeActivityEnergy } from './sync-native-activity-energy';
export type { NativeActivitySyncResult } from './sync-native-activity-energy';
