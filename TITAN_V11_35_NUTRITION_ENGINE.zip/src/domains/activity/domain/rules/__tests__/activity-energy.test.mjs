import assert from 'node:assert/strict';
import { validateActivityMetCatalog, estimateActivityEnergy } from '../activity-energy.ts';
import { integrateOpenMetabolicsPower } from '../openmetabolics-bridge.ts';
import { estimateRestingMetabolicRate } from '../../../../profile/domain/rules/resting-metabolic-rate.ts';
const catalogCheck = validateActivityMetCatalog([
  { code: 'strength-vigorous', category: 'Resistance training', label: 'Vigorous resistance training', met: 6.0, ageMin: 19, ageMax: 59, sourceName: 'Example licensed catalogue', sourceVersion: '1.0', sourceUrl: 'https://example.org/met.csv', sourceLicense: 'CC-BY-4.0', measurementStatus: 'measured' },
  { code: 'strength-vigorous', category: 'Resistance training', label: 'Duplicate', met: 6.0, ageMin: 19, ageMax: 59, sourceName: 'Example', sourceVersion: '1', sourceUrl: 'https://example.org', sourceLicense: 'CC-BY-4.0', measurementStatus: 'measured' },
  { code: 'bad-met', category: 'Walking', label: 'Invalid MET', met: 90, ageMin: 19, ageMax: 59, sourceName: 'Example', sourceVersion: '1', sourceUrl: 'https://example.org', sourceLicense: 'CC-BY-4.0', measurementStatus: 'measured' },
]);
assert.equal(catalogCheck.validEntries.length, 1);
assert.equal(catalogCheck.rejectedEntries.length, 2);
const rmr = estimateRestingMetabolicRate({ sex: 'male', age: 30, heightCm: 180, weightKg: 80 });
const strengthEntry = catalogCheck.validEntries[0];
const lift = estimateActivityEnergy({ activityEntry: strengthEntry, age: 30, sex: 'male', heightCm: 180, weightKg: 80, durationMinutes: 60, restingMetabolicRate: rmr });
assert.equal(lift.standardMet, 6);
assert.equal(lift.measurementStatus, 'measured');
assert.throws(() => estimateActivityEnergy({ activityEntry: strengthEntry, age: 65, weightKg: 80, durationMinutes: 30 }), /faixa etária/i);
assert.throws(() => estimateActivityEnergy({ activityEntry: { ...strengthEntry, sourceLicense: '' }, age: 30, weightKg: 80, durationMinutes: 30 }), /proveniência ou licença/i);
assert.equal(lift.grossKcal, 504);
assert.equal(lift.netKcal, 430);
assert.ok(lift.compendiumCorrectedMet > lift.standardMet);
assert.ok(lift.personalizedIntensityRatio > lift.standardMet);
assert.ok(Math.abs(lift.compendiumCorrectedMet - 6.49) < 0.05);
const run = estimateActivityEnergy({ activityCode: 'run-5mph', activityLabel: 'Running 5 mph', met: 8.5, weightKg: 80, durationMinutes: 30 });
assert.equal(run.standardMet, 8.5);
assert.equal(run.compendiumCorrectedMet, null);
assert.equal(run.personalizedIntensityRatio, null);
assert.throws(() => estimateActivityEnergy({ activityCode: 'missing', met: 0, weightKg: 80, durationMinutes: 30 }), /MET deve estar/i);
assert.throws(() => estimateActivityEnergy({ activityCode: 'strength', met: 6, weightKg: 20, durationMinutes: 30 }), /Peso ou duração/i);
const sensor = integrateOpenMetabolicsPower({
  modelId: 'openmetabolics_xgboost', modelVersion: 'reference-model-2026', modelArtifactSha256: 'a'.repeat(64), placement: 'front_pocket',
  sensorSamplingHz: 50, sensorCoveragePercent: 99, durationSeconds: 60, modelBaselinePowerW: 120,
  samples: Array.from({ length: 7 }, (_, index) => ({ timestampMs: index * 10_000, estimatedPowerW: 100 })),
});
assert.equal(sensor.grossKcal, 1);
assert.equal(sensor.sampleCount, 7);
assert.ok(sensor.netKcal >= 0);
assert.throws(() => integrateOpenMetabolicsPower({
  modelId: 'openmetabolics_xgboost', modelVersion: 'x', modelArtifactSha256: 'b'.repeat(64), placement: 'other', sensorSamplingHz: 50,
  sensorCoveragePercent: 100, durationSeconds: 60, modelBaselinePowerW: 120,
  samples: [{ timestampMs: 0, estimatedPowerW: 100 }, { timestampMs: 60_000, estimatedPowerW: 100 }],
}), /bolso frontal/i);
assert.throws(() => integrateOpenMetabolicsPower({
  modelId: 'openmetabolics_xgboost', modelVersion: 'x', modelArtifactSha256: 'b'.repeat(64), placement: 'front_pocket', sensorSamplingHz: 25,
  sensorCoveragePercent: 100, durationSeconds: 60, modelBaselinePowerW: 120,
  samples: [{ timestampMs: 0, estimatedPowerW: 100 }, { timestampMs: 60_000, estimatedPowerW: 100 }],
}), /50 Hz/i);
console.log('PASS external MET catalog validation, individual net-RMR and OpenMetabolics native bridge');
