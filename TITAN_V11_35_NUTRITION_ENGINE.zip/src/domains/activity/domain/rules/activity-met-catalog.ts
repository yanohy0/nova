import { validateActivityMetCatalog, type ActivityMetEntry } from './activity-energy.ts';

export interface VersionedActivityMetCatalog {
  schemaVersion: '1.0.0';
  catalogId: string;
  catalogVersion: string;
  publishedAt?: string;
  sourceName: string;
  sourceVersion: string;
  sourceUrl: string;
  sourceLicense: string;
  sourceCitation?: string;
  entries: ActivityMetEntry[];
}

// Licenses that permit redistribution/modification in the intended app bundle.
// Non-commercial, no-derivatives, custom and unknown licenses must not be embedded.
const DISTRIBUTABLE_LICENSES = new Set([
  'CC0-1.0', 'CC-BY-4.0', 'CC-BY-3.0', 'ODC-BY-1.0', 'ODbL-1.0',
  'MIT', 'Apache-2.0', 'BSD-2-Clause', 'BSD-3-Clause', 'Unlicense',
]);

export interface MetCatalogImportResult {
  catalog: VersionedActivityMetCatalog | null;
  errors: string[];
  warnings: string[];
}

/** Strict import gate: one source/version/license is enforced across the entire catalog. */
export function validateVersionedActivityMetCatalog(raw: unknown): MetCatalogImportResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { catalog: null, errors: ['catalog_not_object'], warnings };
  const value = raw as Record<string, unknown>;
  if (value.schemaVersion !== '1.0.0') errors.push('unsupported_schema_version');
  for (const key of ['catalogId', 'catalogVersion', 'sourceName', 'sourceVersion', 'sourceUrl', 'sourceLicense'] as const) {
    if (typeof value[key] !== 'string' || !value[key].trim()) errors.push(`missing_${key}`);
  }
  if (typeof value.sourceUrl === 'string' && !/^https:\/\//i.test(value.sourceUrl)) errors.push('source_url_must_be_https');
  const sourceLicense = typeof value.sourceLicense === 'string' ? value.sourceLicense.trim() : '';
  if (sourceLicense && !DISTRIBUTABLE_LICENSES.has(sourceLicense)) {
    errors.push('license_not_approved_for_redistribution_or_derivatives');
  }
  const rawEntries = Array.isArray(value.entries) ? value.entries : [];
  if (!rawEntries.length) errors.push('catalog_entries_empty');
  const validated = validateActivityMetCatalog(rawEntries);
  if (validated.rejectedEntries.length) errors.push(...validated.rejectedEntries.map((item) => `entry_${item.index}_${item.reason}`));
  validated.validEntries.forEach((entry, index) => {
    if (entry.sourceName !== value.sourceName || entry.sourceVersion !== value.sourceVersion ||
        entry.sourceUrl !== value.sourceUrl || entry.sourceLicense !== sourceLicense) {
      errors.push(`entry_${index}_source_metadata_mismatch`);
    }
  });
  if (typeof value.publishedAt === 'string' && !Number.isFinite(Date.parse(value.publishedAt))) errors.push('invalid_published_at');
  if (sourceLicense === 'ODbL-1.0') warnings.push('ODbL exige cumprir atribuição e compartilhamento sob a mesma licença quando aplicável; confirme obrigações de base derivada antes de publicar.');
  if (errors.length) return { catalog: null, errors, warnings };
  return {
    catalog: {
      schemaVersion: '1.0.0', catalogId: value.catalogId as string, catalogVersion: value.catalogVersion as string,
      sourceName: value.sourceName as string, sourceVersion: value.sourceVersion as string, sourceUrl: value.sourceUrl as string,
      sourceLicense, entries: validated.validEntries,
      ...(typeof value.publishedAt === 'string' ? { publishedAt: value.publishedAt } : {}),
      ...(typeof value.sourceCitation === 'string' ? { sourceCitation: value.sourceCitation } : {}),
    },
    errors, warnings,
  };
}

export function selectMetEntry(catalog: VersionedActivityMetCatalog, code: string): ActivityMetEntry | null {
  return catalog.entries.find((entry) => entry.code.toLowerCase() === code.trim().toLowerCase()) ?? null;
}
