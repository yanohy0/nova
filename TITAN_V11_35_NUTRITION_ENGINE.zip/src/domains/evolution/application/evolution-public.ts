import {
  calculateWeightTrend,
  computeCumulativeComparison,
  computeEvolutionCockpitIndicator,
  computeObservedDeltas,
  computeLatestObservedDeltas,
  sortMeasurementsChronologically,
  type CumulativeEvolutionComparison,
  type EvolutionCockpitIndicator,
  type ObservedMeasurementDeltas,
  type WeightTrendEstimate,
} from '../domain/rules/evolution-metrics';
import { useEvolutionStore } from '../state/evolution.store';

export type {
  CumulativeEvolutionComparison,
  EvolutionCockpitIndicator,
  ObservedMeasurementDeltas,
  WeightTrendEstimate,
};

export {
  calculateWeightTrend,
  computeCumulativeComparison,
  computeEvolutionCockpitIndicator,
  computeObservedDeltas,
  computeLatestObservedDeltas,
  sortMeasurementsChronologically,
  useEvolutionStore,
};
