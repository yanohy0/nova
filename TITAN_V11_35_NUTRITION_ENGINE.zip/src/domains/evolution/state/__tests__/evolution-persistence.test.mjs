import assert from 'node:assert/strict';
import { mergeEvolutionPersistedState } from '../evolution-persistence.ts';

const current = { records: [{ id: 'seed', dateKey: '2026-11-07', dateLabel: '07 NOV', weightKg: 78.6 }] };
const valid = { id: 'm-2026-11-23-1', dateKey: '2026-11-23', dateLabel: 'wrong label', weightKg: 79.4, waistCm: 80 };
const merged = mergeEvolutionPersistedState({ records: [valid, { id: 'm-1', dateKey: '2026-11-07', dateLabel: '07 NOV', weightKg: 78.6 }] }, current);
assert.equal(merged.records.length, 1, 'legacy seeded measurements must not enter observed history');
assert.equal(merged.records[0].dateKey, '2026-11-23');
assert.equal(merged.records[0].dateLabel, '23 NOV', 'date labels must be regenerated from validated date keys');
assert.equal(merged.records[0].waistCm, 80);
assert.deepEqual(
  mergeEvolutionPersistedState({ records: [{ ...valid, dateKey: '2026-02-30' }] }, current),
  { records: [] },
  'impossible dates must be discarded',
);
assert.deepEqual(
  mergeEvolutionPersistedState({ records: [{ ...valid, weightKg: Number.NaN }] }, current),
  { records: [] },
  'non-finite measurements must be discarded',
);
assert.equal(
  mergeEvolutionPersistedState({ records: [valid, { ...valid, weightKg: 90 }] }, current).records.length,
  1,
  'duplicate record IDs must be removed deterministically',
);
assert.deepEqual(mergeEvolutionPersistedState({ records: 'broken' }, current), current);
console.log('Evolution persistence tests passed.');
