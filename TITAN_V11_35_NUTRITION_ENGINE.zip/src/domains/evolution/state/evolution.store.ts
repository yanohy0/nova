import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { safeStorageAdapter } from '@/src/infrastructure/storage/local-storage';
import { APP_DAY_KEY } from '@/src/shared/constants/app';
import { getLocalDateKey, isValidLocalDateKey, shiftLocalDateKey } from '@/src/shared/utils/local-date';
import { mergeEvolutionPersistedState, type PersistedEvolutionState } from './evolution-persistence';
import type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';

export type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';
import {
  measurementEntrySchema,
  type MeasurementEntryInput,
} from '../schemas/measurement.schema';

function formatDateLabel(dateKey: string): string {
  const [year, month, day] = dateKey.split('-').map(Number);
  return new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short' })
    .format(new Date(year!, month! - 1, day!, 12))
    .replace('.', '')
    .toUpperCase();
}

const DAY_MINUS_14 = shiftLocalDateKey(APP_DAY_KEY, -14) ?? APP_DAY_KEY;
const DAY_MINUS_7 = shiftLocalDateKey(APP_DAY_KEY, -7) ?? APP_DAY_KEY;

const INITIAL_EVOLUTION_RECORDS: BodyMeasurementRecord[] = [
  {
    id: 'evo-seed-1',
    dateKey: DAY_MINUS_14,
    dateLabel: formatDateLabel(DAY_MINUS_14),
    weightKg: 78.3,
    waistCm: 81.2,
    chestCm: 102.0,
    armCm: 38.0,
    thighCm: 58.0,
  },
  {
    id: 'evo-seed-2',
    dateKey: DAY_MINUS_7,
    dateLabel: formatDateLabel(DAY_MINUS_7),
    weightKg: 78.7,
    waistCm: 80.8,
    chestCm: 102.5,
    armCm: 38.2,
    thighCm: 58.3,
  },
  {
    id: 'evo-seed-3',
    dateKey: APP_DAY_KEY,
    dateLabel: formatDateLabel(APP_DAY_KEY),
    weightKg: 79.1,
    waistCm: 80.5,
    chestCm: 103.0,
    armCm: 38.5,
    thighCm: 58.5,
  },
];

interface EvolutionState {
  records: BodyMeasurementRecord[];
  logMeasurement: (
    entry: MeasurementEntryInput,
    dateKey?: string,
  ) => { ok: true } | { ok: false; error: string };
}

export const useEvolutionStore = create<EvolutionState>()(persist<EvolutionState, [], [], PersistedEvolutionState>((set) => ({
  records: INITIAL_EVOLUTION_RECORDS,
  logMeasurement: (entry, dateKey = getLocalDateKey()) => {
    if (!isValidLocalDateKey(dateKey)) return { ok: false, error: 'Data da medição inválida.' };
    const parsed = measurementEntrySchema.safeParse(entry);
    if (!parsed.success) {
      return { ok: false, error: parsed.error.issues[0]?.message ?? 'Medida inválida' };
    }
    set((state) => ({
      records: [
        ...state.records,
        {
          id: `m-${dateKey}-${Date.now()}`,
          dateKey,
          dateLabel: formatDateLabel(dateKey),
          ...parsed.data,
        },
      ],
    }));
    return { ok: true };
  },
}), {
  name: 'titan:evolution:v1',
  version: 1,
  storage: createJSONStorage(() => safeStorageAdapter),
  partialize: (state) => ({ records: state.records }),
  migrate: (persisted) => mergeEvolutionPersistedState(persisted, { records: INITIAL_EVOLUTION_RECORDS }),
  merge: (persisted, current) => ({
    ...current,
    ...mergeEvolutionPersistedState(persisted, current),
  }),
}));
