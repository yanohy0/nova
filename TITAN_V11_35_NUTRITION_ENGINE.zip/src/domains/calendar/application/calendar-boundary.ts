import { getLocalDateKey, isValidLocalDateKey } from '../../../shared/utils/local-date.ts';

/** Returns the earliest real record date, falling back to today when history is empty. */
export function getFirstRecordDateKey(
  dateKeys: readonly string[],
  fallbackDateKey = getLocalDateKey(),
): string {
  const firstRecordDateKey = dateKeys
    .filter(isValidLocalDateKey)
    .slice()
    .sort((a, b) => a.localeCompare(b))[0];

  if (firstRecordDateKey) return firstRecordDateKey;
  return isValidLocalDateKey(fallbackDateKey) ? fallbackDateKey : getLocalDateKey();
}
