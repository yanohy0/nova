import assert from 'node:assert/strict';
import { getFirstRecordDateKey } from '../calendar-boundary.ts';

assert.equal(
  getFirstRecordDateKey(['2026-11-21', '2026-11-07', '2026-11-14']),
  '2026-11-07',
  'calendar should start at the earliest actual record rather than a fixed release date',
);
assert.equal(
  getFirstRecordDateKey(['invalid', '2026-02-30', '2026-11-20'], '2026-11-23'),
  '2026-11-20',
  'invalid dates should not move the calendar boundary',
);
assert.equal(getFirstRecordDateKey([], '2026-11-23'), '2026-11-23');
console.log('Calendar first-record date tests passed.');
