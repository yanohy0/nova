import type { MuscleGroupId } from '@/src/shared/types/common';

export const ANATOMY_SHADER_CONTRACT = {
  attributeMuscleId: 'aMuscleId',
  uniformActiveMusclesMask: 'uActiveMusclesMask',
} as const;

export const MUSCLE_ID_TO_SHADER_INDEX: Record<MuscleGroupId, number> = {
  pectoralis: 1,
  anterior_deltoid: 2,
  lateral_deltoid: 3,
  posterior_deltoid: 4,
  biceps: 5,
  triceps: 6,
  forearms: 7,
  abdominals: 8,
  latissimus: 9,
  trapezius: 10,
  glutes: 11,
  quadriceps: 12,
  hamstrings: 13,
  calves: 14,
};

export const MUSCLE_SHADER_INDEX_TO_ID: Record<number, MuscleGroupId> = Object.fromEntries(
  Object.entries(MUSCLE_ID_TO_SHADER_INDEX).map(([id, index]) => [index, id]),
) as Record<number, MuscleGroupId>;

export function computeActiveMusclesMask(muscles: MuscleGroupId[]): number {
  return muscles.reduce((mask, id) => {
    const bit = 1 << MUSCLE_ID_TO_SHADER_INDEX[id];
    return mask | bit;
  }, 0);
}
