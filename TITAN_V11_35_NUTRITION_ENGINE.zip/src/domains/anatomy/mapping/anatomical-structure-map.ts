import type { MuscleGroupId } from '@/src/shared/types/common';

export interface AnatomicalStructureEntry {
  structureId: string;
  label: string;
  latinName: string;
  canonicalMuscleId: string;
  trainingGroupId: MuscleGroupId;
  /** Primary morphological role in regional hypertrophy sculpting. */
  /** Current topology granularity; substructure labels do not imply separate mesh assets. */
  geometryStatus: 'independent-training-group' | 'shared-training-group';
  /** Current deformation granularity; independent means a stable training-group morph, not per-head physiology. */
  deformationStatus: 'independent-training-group' | 'shared-training-group';
  regionFamily:
    | 'chest'
    | 'shoulder'
    | 'arm_anterior'
    | 'arm_posterior'
    | 'forearm'
    | 'back_lat'
    | 'back_trap'
    | 'core'
    | 'glute'
    | 'thigh_anterior'
    | 'thigh_posterior'
    | 'lower_leg';
}

/**
 * Intermediate anatomical correspondence layer (Anatomy Atlas / Human Atlas -> TITAN 14 groups).
 * Preserves the 14 stable training IDs across exercise-library and training stores while
 * allowing fine-grained anatomical subdivision and muscle belly shaping.
 */
export const ANATOMICAL_STRUCTURE_MAP: readonly AnatomicalStructureEntry[] = [
  {
    structureId: 'pectoralis_major_clavicular',
    label: 'Peitoral Maior (Clavicular)',
    latinName: 'Pectoralis major pars clavicularis',
    canonicalMuscleId: 'pectoralis_major',
    trainingGroupId: 'pectoralis',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'chest',
  },
  {
    structureId: 'pectoralis_major_sternal',
    label: 'Peitoral Maior (Esternocostal)',
    latinName: 'Pectoralis major pars sternocostalis',
    canonicalMuscleId: 'pectoralis_major',
    trainingGroupId: 'pectoralis',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'chest',
  },
  {
    structureId: 'deltoid_anterior',
    label: 'Deltoide Anterior',
    latinName: 'Deltoideus pars clavicularis',
    canonicalMuscleId: 'deltoid_anterior',
    trainingGroupId: 'anterior_deltoid',
    geometryStatus: 'independent-training-group',
    deformationStatus: 'independent-training-group',
    regionFamily: 'shoulder',
  },
  {
    structureId: 'deltoid_lateral',
    label: 'Deltoide Lateral',
    latinName: 'Deltoideus pars acromialis',
    canonicalMuscleId: 'deltoid_lateral',
    trainingGroupId: 'lateral_deltoid',
    geometryStatus: 'independent-training-group',
    deformationStatus: 'independent-training-group',
    regionFamily: 'shoulder',
  },
  {
    structureId: 'deltoid_posterior',
    label: 'Deltoide Posterior',
    latinName: 'Deltoideus pars spinalis',
    canonicalMuscleId: 'deltoid_posterior',
    trainingGroupId: 'posterior_deltoid',
    geometryStatus: 'independent-training-group',
    deformationStatus: 'independent-training-group',
    regionFamily: 'shoulder',
  },
  {
    structureId: 'biceps_brachii_long',
    label: 'Bíceps Braquial (Cabeça Longa/Curta)',
    latinName: 'Biceps brachii & Brachialis',
    canonicalMuscleId: 'biceps_brachii',
    trainingGroupId: 'biceps',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'arm_anterior',
  },
  {
    structureId: 'triceps_brachii_heads',
    label: 'Tríceps Braquial (Longa/Lateral/Medial)',
    latinName: 'Triceps brachii',
    canonicalMuscleId: 'triceps_brachii',
    trainingGroupId: 'triceps',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'arm_posterior',
  },
  {
    structureId: 'brachioradialis_flexors',
    label: 'Braquiorradial e Flexores/Extensores',
    latinName: 'Brachioradialis & Carpi flexores',
    canonicalMuscleId: 'forearm_compartment',
    trainingGroupId: 'forearms',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'forearm',
  },
  {
    structureId: 'rectus_abdominis_obliques',
    label: 'Reto Abdominal e Oblíquos Externos',
    latinName: 'Rectus abdominis & Obliquus externus',
    canonicalMuscleId: 'abdominal_wall',
    trainingGroupId: 'abdominals',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'core',
  },
  {
    structureId: 'latissimus_dorsi_teres',
    label: 'Latíssimo do Dorso e Redondo Maior',
    latinName: 'Latissimus dorsi & Teres major',
    canonicalMuscleId: 'latissimus_dorsi',
    trainingGroupId: 'latissimus',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'back_lat',
  },
  {
    structureId: 'trapezius_upper_mid',
    label: 'Trapézio Superior e Médio',
    latinName: 'Trapezius pars descendens & transversa',
    canonicalMuscleId: 'trapezius',
    trainingGroupId: 'trapezius',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'back_trap',
  },
  {
    structureId: 'gluteus_maximus_medius',
    label: 'Glúteo Máximo e Médio',
    latinName: 'Gluteus maximus & medius',
    canonicalMuscleId: 'gluteal_group',
    trainingGroupId: 'glutes',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'glute',
  },
  {
    structureId: 'quadriceps_femoris_heads',
    label: 'Reto Femoral, Vasto Lateral e Medial',
    latinName: 'Rectus femoris, Vastus lateralis & medialis',
    canonicalMuscleId: 'quadriceps_group',
    trainingGroupId: 'quadriceps',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'thigh_anterior',
  },
  {
    structureId: 'hamstrings_complex',
    label: 'Bíceps Femoral e Semitendíneo',
    latinName: 'Biceps femoris & Semitendinosus',
    canonicalMuscleId: 'hamstring_group',
    trainingGroupId: 'hamstrings',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'thigh_posterior',
  },
  {
    structureId: 'gastrocnemius_soleus',
    label: 'Gastrocnêmio Medial/Lateral e Sóleo',
    latinName: 'Triceps surae',
    canonicalMuscleId: 'calf_group',
    trainingGroupId: 'calves',
    geometryStatus: 'shared-training-group',
    deformationStatus: 'shared-training-group',
    regionFamily: 'lower_leg',
  },
];

export function getAnatomicalSubstructuresForGroup(
  trainingGroupId: MuscleGroupId,
): AnatomicalStructureEntry[] {
  return ANATOMICAL_STRUCTURE_MAP.filter(
    (entry) => entry.trainingGroupId === trainingGroupId,
  );
}
