import assert from 'node:assert/strict';
import {
  computeBodyIdentitySignature,
  createDefaultCurrentBodyProfile,
  getMuscleGroupMorphLevel,
  getDeltoidMorphWeightsByShaderIndex,
} from '../body-identity.ts';

const identity = createDefaultCurrentBodyProfile();
identity.regionalMorphs = {
  ...identity.regionalMorphs,
  anteriorDeltoid: 0.12,
  lateralDeltoid: 0.48,
  posteriorDeltoid: 0.86,
};

assert.equal(getMuscleGroupMorphLevel(identity, 'anterior_deltoid'), 0.12, 'anterior deltoid reads its own deformation channel');
assert.equal(getMuscleGroupMorphLevel(identity, 'lateral_deltoid'), 0.48, 'lateral deltoid reads its own deformation channel');
assert.equal(getMuscleGroupMorphLevel(identity, 'posterior_deltoid'), 0.86, 'posterior deltoid reads its own deformation channel');
const shaderWeights = getDeltoidMorphWeightsByShaderIndex(identity);
assert.equal(shaderWeights.get(2), 0.12, 'canonical anterior shader ID 2 receives anterior weight');
assert.equal(shaderWeights.get(3), 0.48, 'canonical lateral shader ID 3 receives lateral weight');
assert.equal(shaderWeights.get(4), 0.86, 'canonical posterior shader ID 4 receives posterior weight');

const baseline = createDefaultCurrentBodyProfile();
const changed = createDefaultCurrentBodyProfile();
changed.regionalMorphs = { ...changed.regionalMorphs, anteriorDeltoid: 0.99 };
assert.notEqual(computeBodyIdentitySignature(baseline), computeBodyIdentitySignature(changed), 'a single deltoid-head change invalidates the cached body geometry signature');

const legacy = createDefaultCurrentBodyProfile();
legacy.regionalMorphs = { ...legacy.regionalMorphs };
delete legacy.regionalMorphs.anteriorDeltoid;
assert.equal(getMuscleGroupMorphLevel(legacy, 'anterior_deltoid'), legacy.regionalMorphs.deltoids, 'legacy profiles fall back to shared deltoid morph');
console.log('PASS: independent anterior/lateral/posterior deltoid deformation channels');
