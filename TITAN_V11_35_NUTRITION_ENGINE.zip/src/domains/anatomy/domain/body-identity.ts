import type { MuscleGroupId } from '@/src/shared/types/common';
import { MUSCLE_ID_TO_SHADER_INDEX } from '../mapping/anatomy-identifiers.ts';

export type BodyCalibrationSource = 'scan' | 'measurements' | 'template';
export type BodyCalibrationStatus = 'calibrated' | 'estimated';
export type BodyComparisonMode = 'dual' | 'current' | 'goal';
export type BodyRole = 'current' | 'goal';

export interface BodyPhenotypeParams {
  muscle: number;
  weight: number;
  height: number;
  bodyFat: number;
  shoulderWaistRatio: number;
}

export interface BodyLocalChanges {
  chestThickness: number;
  backWidth: number;
  shoulderWidth: number;
  upperArmVolume: number;
  forearmVolume: number;
  thighVolume: number;
  calfVolume: number;
}

export interface RegionalMuscleMorphs {
  pectoralis: number;
  deltoids: number;
  /** Independent head weights; optional for backward-compatible persisted profiles. */
  anteriorDeltoid?: number;
  lateralDeltoid?: number;
  posteriorDeltoid?: number;
  biceps: number;
  triceps: number;
  forearms: number;
  latissimus: number;
  trapezius: number;
  abdominals: number;
  glutes: number;
  quadriceps: number;
  hamstrings: number;
  calves: number;
}

export interface BodyIdentityProfile {
  source: BodyCalibrationSource;
  model: 'anny-soma';
  sex?: 'male' | 'female';
  phenotype: BodyPhenotypeParams;
  localChanges: BodyLocalChanges;
  regionalMorphs: RegionalMuscleMorphs;
  calibrationStatus: BodyCalibrationStatus;
}

export interface DualBodyInput {
  current: BodyIdentityProfile;
  goal: BodyIdentityProfile;
  sharedPose: 'neutral-anatomical';
}

export interface ProfileBodyDerivationInput {
  sex?: 'male' | 'female';
  goal?: 'gain_muscle' | 'lose_weight' | 'recomposition' | 'maintain';
  currentWeightKg?: number | null;
  targetWeightKg?: number | null;
  heightCm?: number | null;
  waistCm?: number | null;
  bodyFatPercent?: number | null;
  profileConfigured?: boolean;
  hasObservedMeasurements?: boolean;
}

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value));
}

function clampRange(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function createDefaultCurrentBodyProfile(): BodyIdentityProfile {
  return {
    source: 'template',
    model: 'anny-soma',
    phenotype: {
      muscle: 0.34,
      weight: 0.45,
      height: 1.0,
      bodyFat: 0.38,
      shoulderWaistRatio: 0.42,
    },
    localChanges: {
      chestThickness: 0.30,
      backWidth: 0.30,
      shoulderWidth: 0.34,
      upperArmVolume: 0.28,
      forearmVolume: 0.28,
      thighVolume: 0.34,
      calfVolume: 0.30,
    },
    regionalMorphs: {
      pectoralis: 0.26,
      deltoids: 0.28,
      anteriorDeltoid: 0.28,
      lateralDeltoid: 0.28,
      posteriorDeltoid: 0.28,
      biceps: 0.24,
      triceps: 0.25,
      forearms: 0.24,
      latissimus: 0.25,
      trapezius: 0.22,
      abdominals: 0.22,
      glutes: 0.28,
      quadriceps: 0.30,
      hamstrings: 0.26,
      calves: 0.26,
    },
    calibrationStatus: 'estimated',
  };
}

export function createDefaultGoalBodyProfile(): BodyIdentityProfile {
  return {
    source: 'measurements',
    model: 'anny-soma',
    phenotype: {
      muscle: 0.84,
      weight: 0.64,
      height: 1.0,
      bodyFat: 0.16,
      shoulderWaistRatio: 0.86,
    },
    localChanges: {
      chestThickness: 0.84,
      backWidth: 0.86,
      shoulderWidth: 0.88,
      upperArmVolume: 0.85,
      forearmVolume: 0.72,
      thighVolume: 0.82,
      calfVolume: 0.74,
    },
    regionalMorphs: {
      pectoralis: 0.86,
      deltoids: 0.90,
      anteriorDeltoid: 0.90,
      lateralDeltoid: 0.90,
      posteriorDeltoid: 0.90,
      biceps: 0.84,
      triceps: 0.86,
      forearms: 0.70,
      latissimus: 0.88,
      trapezius: 0.78,
      abdominals: 0.82,
      glutes: 0.78,
      quadriceps: 0.86,
      hamstrings: 0.80,
      calves: 0.76,
    },
    calibrationStatus: 'estimated',
  };
}

export function createDefaultDualBodyInput(): DualBodyInput {
  return {
    current: createDefaultCurrentBodyProfile(),
    goal: createDefaultGoalBodyProfile(),
    sharedPose: 'neutral-anatomical',
  };
}

export function deriveDualBodyInput(input: ProfileBodyDerivationInput): DualBodyInput {
  const heightCm = Number.isFinite(input.heightCm) && (input.heightCm ?? 0) > 100 ? input.heightCm! : 178;
  const currentWeightKg =
    Number.isFinite(input.currentWeightKg) && (input.currentWeightKg ?? 0) > 30 ? input.currentWeightKg! : 78;
  const targetWeightKg =
    Number.isFinite(input.targetWeightKg) && (input.targetWeightKg ?? 0) > 30 ? input.targetWeightKg! : currentWeightKg + 4;

  const heightScale = clampRange(heightCm / 178, 0.88, 1.12);
  const heightMeters = heightCm / 100;
  const bmi = currentWeightKg / (heightMeters * heightMeters);
  const weightNorm = clamp01((bmi - 18.5) / 14);
  const isFemale = input.sex === 'female';
  const defaultBodyFat = isFemale ? 0.42 : 0.34;
  const bodyFatNorm =
    Number.isFinite(input.bodyFatPercent) && input.bodyFatPercent !== null
      ? clamp01((input.bodyFatPercent! - (isFemale ? 14 : 7)) / 24)
      : clamp01(defaultBodyFat + (weightNorm - 0.38) * 0.55);

  const currentMuscle = clamp01(0.32 + (1 - bodyFatNorm) * 0.22);
  const calibrationStatus: BodyCalibrationStatus =
    input.hasObservedMeasurements || (input.profileConfigured && Number.isFinite(input.waistCm))
      ? 'calibrated'
      : 'estimated';
  const source: BodyCalibrationSource = input.hasObservedMeasurements
    ? 'measurements'
    : input.profileConfigured
      ? 'measurements'
      : 'template';

  const current: BodyIdentityProfile = {
    source,
    model: 'anny-soma',
    sex: isFemale ? 'female' : 'male',
    phenotype: {
      muscle: currentMuscle,
      weight: weightNorm,
      height: heightScale,
      bodyFat: bodyFatNorm,
      shoulderWaistRatio: isFemale ? 0.36 : 0.44,
    },
    localChanges: {
      chestThickness: clamp01(currentMuscle * 0.85),
      backWidth: clamp01(currentMuscle * 0.82),
      shoulderWidth: clamp01(currentMuscle * 0.90),
      upperArmVolume: clamp01(currentMuscle * 0.78),
      forearmVolume: clamp01(currentMuscle * 0.74),
      thighVolume: clamp01(currentMuscle * 0.88),
      calfVolume: clamp01(currentMuscle * 0.80),
    },
    regionalMorphs: {
      pectoralis: clamp01(currentMuscle * 0.72),
      deltoids: clamp01(currentMuscle * 0.76),
      anteriorDeltoid: clamp01(currentMuscle * 0.76),
      lateralDeltoid: clamp01(currentMuscle * 0.76),
      posteriorDeltoid: clamp01(currentMuscle * 0.76),
      biceps: clamp01(currentMuscle * 0.68),
      triceps: clamp01(currentMuscle * 0.70),
      forearms: clamp01(currentMuscle * 0.65),
      latissimus: clamp01(currentMuscle * 0.72),
      trapezius: clamp01(currentMuscle * 0.64),
      abdominals: clamp01(0.28 * (1 - bodyFatNorm * 0.5)),
      glutes: clamp01(isFemale ? currentMuscle * 0.92 : currentMuscle * 0.76),
      quadriceps: clamp01(currentMuscle * 0.84),
      hamstrings: clamp01(currentMuscle * 0.76),
      calves: clamp01(currentMuscle * 0.74),
    },
    calibrationStatus,
  };

  // Goal body always represents a meaningfully more developed, defined physique —
  // never a uniform duplicate of current body.
  const deltaKg = targetWeightKg - currentWeightKg;
  const hypertrophyGain =
    input.goal === 'lose_weight'
      ? 0.34
      : input.goal === 'maintain'
        ? 0.38
        : input.goal === 'recomposition'
          ? 0.46
          : clampRange(0.46 + Math.max(0, deltaKg) * 0.025, 0.45, 0.62);

  const goalMuscle = clamp01(Math.max(0.76, currentMuscle + hypertrophyGain));
  const goalBodyFat = clamp01(
    input.goal === 'lose_weight'
      ? Math.min(current.phenotype.bodyFat - 0.22, 0.14)
      : Math.min(current.phenotype.bodyFat - 0.14, isFemale ? 0.20 : 0.14),
  );
  const goalWeightNorm = clamp01((targetWeightKg / (heightMeters * heightMeters) - 18.5) / 14);

  const goal: BodyIdentityProfile = {
    source,
    model: 'anny-soma',
    sex: isFemale ? 'female' : 'male',
    phenotype: {
      muscle: goalMuscle,
      weight: Math.max(weightNorm * 0.92, goalWeightNorm),
      height: heightScale,
      bodyFat: goalBodyFat,
      shoulderWaistRatio: isFemale ? 0.68 : 0.88,
    },
    localChanges: {
      chestThickness: clamp01(isFemale ? 0.64 : 0.86),
      backWidth: clamp01(isFemale ? 0.72 : 0.88),
      shoulderWidth: clamp01(isFemale ? 0.74 : 0.90),
      upperArmVolume: clamp01(isFemale ? 0.68 : 0.86),
      forearmVolume: clamp01(isFemale ? 0.56 : 0.74),
      thighVolume: clamp01(isFemale ? 0.88 : 0.84),
      calfVolume: clamp01(0.76),
    },
    regionalMorphs: {
      pectoralis: clamp01(isFemale ? 0.62 : 0.88),
      deltoids: clamp01(isFemale ? 0.74 : 0.92),
      anteriorDeltoid: clamp01(isFemale ? 0.74 : 0.92),
      lateralDeltoid: clamp01(isFemale ? 0.74 : 0.92),
      posteriorDeltoid: clamp01(isFemale ? 0.74 : 0.92),
      biceps: clamp01(isFemale ? 0.66 : 0.86),
      triceps: clamp01(isFemale ? 0.68 : 0.88),
      forearms: clamp01(isFemale ? 0.54 : 0.72),
      latissimus: clamp01(isFemale ? 0.74 : 0.90),
      trapezius: clamp01(isFemale ? 0.58 : 0.80),
      abdominals: clamp01(0.84),
      glutes: clamp01(isFemale ? 0.94 : 0.80),
      quadriceps: clamp01(isFemale ? 0.88 : 0.88),
      hamstrings: clamp01(isFemale ? 0.84 : 0.82),
      calves: clamp01(0.78),
    },
    calibrationStatus,
  };

  return {
    current,
    goal,
    sharedPose: 'neutral-anatomical',
  };
}

export function getMuscleGroupMorphLevel(
  identity: BodyIdentityProfile,
  muscleId: MuscleGroupId,
): number {
  switch (muscleId) {
    case 'pectoralis':
      return identity.regionalMorphs.pectoralis;
    case 'anterior_deltoid':
      return identity.regionalMorphs.anteriorDeltoid ?? identity.regionalMorphs.deltoids;
    case 'lateral_deltoid':
      return identity.regionalMorphs.lateralDeltoid ?? identity.regionalMorphs.deltoids;
    case 'posterior_deltoid':
      return identity.regionalMorphs.posteriorDeltoid ?? identity.regionalMorphs.deltoids;
    case 'biceps':
      return identity.regionalMorphs.biceps;
    case 'triceps':
      return identity.regionalMorphs.triceps;
    case 'forearms':
      return identity.regionalMorphs.forearms;
    case 'latissimus':
      return identity.regionalMorphs.latissimus;
    case 'trapezius':
      return identity.regionalMorphs.trapezius;
    case 'abdominals':
      return identity.regionalMorphs.abdominals;
    case 'glutes':
      return identity.regionalMorphs.glutes;
    case 'quadriceps':
      return identity.regionalMorphs.quadriceps;
    case 'hamstrings':
      return identity.regionalMorphs.hamstrings;
    case 'calves':
      return identity.regionalMorphs.calves;
  }
}

/** Returns the three independent deltoid weights keyed by the stable shader IDs stored in the base mesh. */
export function getDeltoidMorphWeightsByShaderIndex(identity: BodyIdentityProfile): ReadonlyMap<number, number> {
  return new Map([
    [MUSCLE_ID_TO_SHADER_INDEX.anterior_deltoid, getMuscleGroupMorphLevel(identity, 'anterior_deltoid')],
    [MUSCLE_ID_TO_SHADER_INDEX.lateral_deltoid, getMuscleGroupMorphLevel(identity, 'lateral_deltoid')],
    [MUSCLE_ID_TO_SHADER_INDEX.posterior_deltoid, getMuscleGroupMorphLevel(identity, 'posterior_deltoid')],
  ]);
}

export function computeBodyIdentitySignature(identity: BodyIdentityProfile): string {
  const p = identity.phenotype;
  const l = identity.localChanges;
  const r = identity.regionalMorphs;
  return [
    identity.sex ?? 'male',
    p.muscle, p.weight, p.height, p.bodyFat, p.shoulderWaistRatio,
    l.chestThickness, l.backWidth, l.shoulderWidth, l.upperArmVolume, l.forearmVolume, l.thighVolume, l.calfVolume,
    r.pectoralis, r.deltoids,
    r.anteriorDeltoid ?? r.deltoids, r.lateralDeltoid ?? r.deltoids, r.posteriorDeltoid ?? r.deltoids,
    r.biceps, r.triceps, r.forearms, r.latissimus, r.trapezius,
    r.abdominals, r.glutes, r.quadriceps, r.hamstrings, r.calves,
  ]
    .map((v) => (typeof v === 'string' ? v : v.toFixed(3)))
    .join(':');
}
