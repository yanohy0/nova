export interface SparseMorphTable {
  count: number;
  indices: Uint16Array;
  deltas: Int16Array;
}

/** Applies a sparse position morph with independent weights for canonical muscle IDs. */
export function applySparseMorphByMuscleRegion(
  canonPositions: Float32Array,
  morph: SparseMorphTable,
  defaultWeight: number,
  regionWeights: ReadonlyMap<number, number>,
  canonicalMuscleIds: Uint8Array,
  invQuant: number,
): void {
  const { count, indices, deltas } = morph;
  for (let k = 0; k < count; k += 1) {
    const vertexIndex = indices[k] ?? 0;
    const muscleId = canonicalMuscleIds[vertexIndex] ?? 0;
    const weight = regionWeights.get(muscleId) ?? defaultWeight;
    if (Math.abs(weight) < 1e-4) continue;
    const base = vertexIndex * 3;
    const dBase = k * 3;
    const scale = weight * invQuant;
    canonPositions[base] = (canonPositions[base] ?? 0) + (deltas[dBase] ?? 0) * scale;
    canonPositions[base + 1] = (canonPositions[base + 1] ?? 0) + (deltas[dBase + 1] ?? 0) * scale;
    canonPositions[base + 2] = (canonPositions[base + 2] ?? 0) + (deltas[dBase + 2] ?? 0) * scale;
  }
}
