import assert from 'node:assert/strict';
import { applySparseMorphByMuscleRegion } from '../sparse-morph.ts';

const positions = new Float32Array(4 * 3);
const morph = {
  count: 4,
  indices: new Uint16Array([0, 1, 2, 3]),
  deltas: new Int16Array([
    100, 0, 0,
    100, 0, 0,
    100, 0, 0,
    100, 0, 0,
  ]),
};
const canonicalMuscleIds = new Uint8Array([2, 3, 4, 0]);
const weights = new Map([[2, 0.1], [3, 0.5], [4, 0.9]]);
applySparseMorphByMuscleRegion(positions, morph, 0.25, weights, canonicalMuscleIds, 0.01);
const displacementX = [...positions.filter((_v, i) => i % 3 === 0)];
for (const [index, expected] of [0.1, 0.5, 0.9, 0.25].entries()) assert.ok(Math.abs(displacementX[index] - expected) < 1e-6, `vertex ${index} uses its canonical-region weight`);
assert.equal(positions.filter((_v, i) => i % 3 === 1 || i % 3 === 2).some(v => v !== 0), false, 'all three axes are updated only by their respective sparse deltas');
console.log('PASS: sparse morph applies independent weights by canonical anatomy region');
