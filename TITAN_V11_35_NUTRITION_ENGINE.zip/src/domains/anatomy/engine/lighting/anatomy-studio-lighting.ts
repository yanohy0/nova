/** Shared direction contract for the physical studio key and the custom anatomy shader. */
export const ANATOMY_KEY_LIGHT_DIRECTION = [-0.50, 0.65, 0.57] as const;
export const ANATOMY_KEY_LIGHT_TARGET = [0, 1.15, 0] as const;
export const ANATOMY_KEY_LIGHT_DISTANCE = 4.2;
