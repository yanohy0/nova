import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../../../../../../');
const shader = fs.readFileSync(path.join(root, 'src/domains/anatomy/engine/shaders/anatomy-material-shader.ts'), 'utf8');
const materials = fs.readFileSync(path.join(root, 'src/domains/anatomy/engine/materials/anatomy-materials.ts'), 'utf8');
const renderer = fs.readFileSync(path.join(root, 'src/domains/anatomy/engine/renderer/anatomy-renderer.ts'), 'utf8');
assert.match(shader, /uniform\s+vec3\s+uKeyLightDirection/, 'shader declares one key direction uniform');
assert.doesNotMatch(shader, /normalize\(vec3\(-2\.05,\s*3\.55,\s*2\.15\)\)/, 'shader no longer hardcodes a direction independent of the rig');
assert.match(shader, /vec3 titanKeyDir = normalize\(uKeyLightDirection\)/, 'shader derives its light vector from the shared key uniform');
assert.match(shader, /dot\(titanNormalW,\s*titanKeyDir\)/, 'surface response samples the shared key direction');
assert.match(materials, /uKeyLightDirection:\s*\{\s*value:/, 'both body material roles receive the key light uniform');
assert.match(renderer, /ANATOMY_KEY_LIGHT_DIRECTION/, 'renderer positions its key light from the shared direction contract');
const rig = fs.readFileSync(path.join(root, 'src/domains/anatomy/engine/lighting/anatomy-studio-lighting.ts'), 'utf8');
assert.match(rig, /ANATOMY_KEY_LIGHT_DIRECTION/, 'single source of truth exists for the studio key vector');
console.log('PASS: anatomy shader and studio rig share the same key-light direction');
