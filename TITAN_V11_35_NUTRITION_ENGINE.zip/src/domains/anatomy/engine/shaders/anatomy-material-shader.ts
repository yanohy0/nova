import type * as THREE from 'three';

export interface AnatomyShaderUniforms {
  uActiveMusclesMask: { value: number };
  uPrimaryMusclesMask: { value: number };
  uSecondaryMusclesMask: { value: number };
  uSelectedMuscleIndex: { value: number };
  uSelectedMuscleSide: { value: number };
  uSelectedSideAny: { value: number };
  uHasSelection: { value: number };
  uMuscleRestingColor: { value: THREE.Color };
  uMuscleDimmedColor: { value: THREE.Color };
  uMusclePrimaryColor: { value: THREE.Color };
  uMuscleSecondaryColor: { value: THREE.Color };
  uMuscleSelectedColor: { value: THREE.Color };
  uSweepY: { value: number };
  uHologramMode: { value: number };
  uHologramTint: { value: THREE.Color };
  uHologramAccent: { value: THREE.Color };
  uScanPhase?: { value: number };
  uTime?: { value: number };
  uBodyRole?: { value: number }; // 0 = current, 1 = goal
  uBacklightOrigin?: { value: THREE.Vector3 };
  uSkinScatteringMap: { value: THREE.Texture };
  uKeyLightDirection: { value: THREE.Vector3 };
}

type AnatomyMaterialRole = 'body' | 'muscle';

function replaceShaderChunk(source: string, chunkName: string, replacement: string, stage: 'vertex' | 'fragment'): string {
  const token = `#include <${chunkName}>`;
  const occurrences = source.split(token).length - 1;
  if (occurrences !== 1) {
    throw new Error(`TITAN anatomy shader patch expected exactly one ${stage} <${chunkName}> chunk; found ${occurrences}`);
  }
  return source.replace(token, replacement);
}

/**
 * Adds anatomy-specific PBR + SSS wrap + holographic character shading to Three.js MeshStandardMaterial.
 * Preserves workout primary/secondary highlights when a muscle is manually selected by layering
 * the selection contour additively instead of dimming or overwriting workout colors.
 */
export function applyAnatomyMaterialEnhancements(
  material: THREE.MeshStandardMaterial,
  uniforms: AnatomyShaderUniforms,
  role: AnatomyMaterialRole,
): void {
  const scanPhase = uniforms.uScanPhase ?? { value: 0 };
  const timeUniform = uniforms.uTime ?? { value: 0 };
  const bodyRole = uniforms.uBodyRole ?? { value: 0 };
  const backlightOrigin = uniforms.uBacklightOrigin ?? {
    value: { x: 0, y: 1.65, z: -1.15 } as unknown as THREE.Vector3,
  };

  material.onBeforeCompile = (shader) => {
    shader.uniforms.uSweepY = uniforms.uSweepY;
    shader.uniforms.uHologramMode = uniforms.uHologramMode;
    shader.uniforms.uHologramTint = uniforms.uHologramTint;
    shader.uniforms.uHologramAccent = uniforms.uHologramAccent;
    shader.uniforms.uScanPhase = scanPhase;
    shader.uniforms.uTime = timeUniform;
    shader.uniforms.uBodyRole = bodyRole;
    shader.uniforms.uBacklightOrigin = backlightOrigin;
    shader.uniforms.uSkinScatteringMap = uniforms.uSkinScatteringMap;
    shader.uniforms.uKeyLightDirection = uniforms.uKeyLightDirection;

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'common',
      `#include <common>
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;
varying vec3 vAnatomyLocalPos;
varying float vSkinThickness;
${role === 'muscle' ? `
attribute float aMuscleId;
attribute float aMuscleSide;
uniform int uActiveMusclesMask;
uniform int uPrimaryMusclesMask;
uniform int uSecondaryMusclesMask;
uniform int uSelectedMuscleIndex;
uniform float uSelectedMuscleSide;
uniform float uSelectedSideAny;
uniform float uHasSelection;
uniform vec3 uMuscleRestingColor;
uniform vec3 uMuscleDimmedColor;
uniform vec3 uMusclePrimaryColor;
uniform vec3 uMuscleSecondaryColor;
uniform vec3 uMuscleSelectedColor;
varying vec3 vMuscleColor;
varying float vMuscleActive;
varying float vMuscleSelected;
varying float vMusclePrimary;
varying float vMuscleSecondary;
varying float vIsMuscleZone;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'begin_vertex',
      `#include <begin_vertex>
${role === 'muscle' ? `
int titanMuscleId = int(aMuscleId + 0.5);
float titanIsActive = float((uActiveMusclesMask >> titanMuscleId) & 1);
float titanIsPrimary = float((uPrimaryMusclesMask >> titanMuscleId) & 1);
float titanIsSecondary = float((uSecondaryMusclesMask >> titanMuscleId) & 1);
float titanIsSelected = (titanMuscleId > 0 && titanMuscleId == uSelectedMuscleIndex) ? 1.0 : 0.0;
float titanSideMatch = 1.0 - step(0.5, abs(aMuscleSide - uSelectedMuscleSide));
titanSideMatch = mix(titanSideMatch, 1.0, uSelectedSideAny);
titanIsSelected *= titanSideMatch * uHasSelection;
vec3 titanWorkoutColor = mix(uMuscleRestingColor, uMuscleSecondaryColor, titanIsSecondary);
titanWorkoutColor = mix(titanWorkoutColor, uMusclePrimaryColor, titanIsPrimary);
// Selection never erases workout colors: workout highlight remains primary/secondary,
// while selection adds a dedicated contour & rim highlight in the fragment stage.
vMuscleColor = titanWorkoutColor;
vMuscleActive = max(titanIsPrimary, titanIsSecondary);
vMuscleSelected = titanIsSelected;
vMusclePrimary = titanIsPrimary;
vMuscleSecondary = titanIsSecondary;
vIsMuscleZone = titanMuscleId > 0 ? 1.0 : 0.0;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'project_vertex',
      `vec4 titanWorldPos4 = modelMatrix * vec4(transformed, 1.0);
vAnatomyWorldY = titanWorldPos4.y;
vAnatomyWorldPos = titanWorldPos4.xyz;
vAnatomyWorldNormal = normalize(mat3(transpose(inverse(modelMatrix))) * objectNormal);
vAnatomyLocalPos = transformed;
float titanLocalY = transformed.y;
float titanAbsX = abs(transformed.x);
float titanTorsoThickness = smoothstep(0.84, 1.00, titanLocalY) * (1.0 - smoothstep(1.42, 1.56, titanLocalY)) * (1.0 - smoothstep(0.13, 0.31, titanAbsX));
float titanUpperLimbThinness = smoothstep(0.19, 0.29, titanAbsX) * smoothstep(0.82, 0.96, titanLocalY) * (1.0 - smoothstep(1.47, 1.58, titanLocalY));
float titanLowerLimbRegion = 1.0 - smoothstep(0.62, 0.94, titanLocalY);
float titanHeadThinness = smoothstep(1.48, 1.63, titanLocalY);
float titanThicknessM = mix(0.0068, 0.0180, titanTorsoThickness);
titanThicknessM = mix(titanThicknessM, 0.0061, titanUpperLimbThinness * 0.88);
titanThicknessM = mix(titanThicknessM, 0.0092, titanLowerLimbRegion * 0.64);
titanThicknessM = mix(titanThicknessM, 0.0062, titanHeadThinness * 0.92);
vSkinThickness = clamp(titanThicknessM, 0.0048, 0.0200);
#include <project_vertex>`,
      'vertex',
    );

    if (role === 'muscle') {
      shader.uniforms.uActiveMusclesMask = uniforms.uActiveMusclesMask;
      shader.uniforms.uPrimaryMusclesMask = uniforms.uPrimaryMusclesMask;
      shader.uniforms.uSecondaryMusclesMask = uniforms.uSecondaryMusclesMask;
      shader.uniforms.uSelectedMuscleIndex = uniforms.uSelectedMuscleIndex;
      shader.uniforms.uSelectedMuscleSide = uniforms.uSelectedMuscleSide;
      shader.uniforms.uSelectedSideAny = uniforms.uSelectedSideAny;
      shader.uniforms.uHasSelection = uniforms.uHasSelection;
      shader.uniforms.uMuscleRestingColor = uniforms.uMuscleRestingColor;
      shader.uniforms.uMuscleDimmedColor = uniforms.uMuscleDimmedColor;
      shader.uniforms.uMusclePrimaryColor = uniforms.uMusclePrimaryColor;
      shader.uniforms.uMuscleSecondaryColor = uniforms.uMuscleSecondaryColor;
      shader.uniforms.uMuscleSelectedColor = uniforms.uMuscleSelectedColor;

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>
uniform float uSweepY;
uniform float uHologramMode;
uniform vec3 uHologramTint;
uniform vec3 uHologramAccent;
uniform vec3 uMuscleSelectedColor;
uniform float uScanPhase;
uniform float uTime;
uniform float uBodyRole;
uniform vec3 uBacklightOrigin;
uniform sampler2D uSkinScatteringMap;
uniform vec3 uKeyLightDirection;
varying vec3 vMuscleColor;
varying float vMuscleActive;
varying float vMuscleSelected;
varying float vMusclePrimary;
varying float vMuscleSecondary;
varying float vIsMuscleZone;
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;
varying vec3 vAnatomyLocalPos;
varying float vSkinThickness;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>
float titanSweepGate = smoothstep(-0.08, 0.02, uSweepY) * (1.0 - smoothstep(1.82, 1.92, uSweepY));
float titanSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 10.0, 2.0)) * titanSweepGate;
vec3 titanNormalW = normalize(vAnatomyWorldNormal);
vec3 titanNormalStep = fwidth(titanNormalW);
float titanPosStep = max(0.0011, length(fwidth(vAnatomyWorldPos)));
float titanCurvature = smoothstep(0.06, 0.84, clamp(length(titanNormalStep) / titanPosStep * 0.056, 0.0, 1.0));
float titanCavityAO = mix(0.30, 1.16, 1.0 - titanCurvature * 0.78);
vec3 titanKeyDir = normalize(uKeyLightDirection);
float titanRawDot = dot(titanNormalW, titanKeyDir);
float titanKeyNdotL = clamp(titanRawDot * 0.5 + 0.5, 0.0, 1.0);
// Penner pre-integrated multi-scale RGB wrap lighting + studio ridge catchlight & hemoglobin scatter
vec3 titanWrapRgb = clamp((vec3(titanRawDot) + vec3(0.46, 0.24, 0.14)) / vec3(1.46, 1.24, 1.14), 0.0, 1.0);
float titanWrapDiffuse = titanWrapRgb.g;
float titanTerminatorSSS = pow(clamp(1.0 - abs(titanRawDot - 0.06), 0.0, 1.0), 2.3);
vec3 titanChiaroscuroRgb = mix(vec3(0.30, 0.28, 0.30), vec3(1.36, 1.34, 1.32), pow(titanWrapRgb, vec3(1.22, 1.48, 1.66)));
float titanRidgeCatch = pow(max(dot(titanNormalW, normalize(vec3(0.46, 0.54, -0.70))), 0.0), 3.6) * 0.32;
// Feather linear vertex muscle masks into organic anatomical bellies and fascial septa
float titanSmoothActive = smoothstep(0.14, 0.86, vMuscleActive);
float titanSmoothZone = smoothstep(0.16, 0.84, vIsMuscleZone);
float titanMaskEdge = clamp((abs(dFdx(vMuscleActive)) + abs(dFdy(vMuscleActive))) * 1.15, 0.0, 1.0);
float titanZoneEdge = clamp((abs(dFdx(vIsMuscleZone)) + abs(dFdy(vIsMuscleZone))) * 0.95, 0.0, 1.0);
float titanFasciaSeptum = exp(-pow((titanSmoothActive - 0.50) * 4.4, 2.0)) * 0.30 + exp(-pow((titanSmoothZone - 0.50) * 4.6, 2.0)) * 0.22;
// Longitudinal myofibril striation relief localized strictly to anatomical muscle zones
float titanFiberMicro = sin(vAnatomyWorldY * 275.0 + vAnatomyWorldPos.x * 118.0) * 0.052 * titanSmoothZone;
vec3 titanSkinBase = diffuseColor.rgb;
float titanMuscleRestBlend = titanSmoothZone * 0.34;
vec3 titanDermalSSS = vec3(0.135, 0.032, 0.018) * titanTerminatorSSS * mix(1.0, 0.55, uHologramMode);
vec3 titanSculptedBase = mix(
  titanSkinBase * (0.62 - titanMuscleRestBlend * 0.34) * titanCavityAO * titanChiaroscuroRgb + titanDermalSSS + uHologramTint * (0.022 * titanKeyNdotL + titanRidgeCatch * 0.048),
  vMuscleColor * (1.0 + titanFiberMicro) * titanCavityAO * mix(vec3(0.62), vec3(1.28), pow(titanWrapRgb, vec3(1.08, 1.20, 1.30))),
  titanSmoothActive * 0.96
);
diffuseColor.rgb = titanSculptedBase * (1.0 - titanMaskEdge * 0.24 - titanZoneEdge * 0.14 - titanFasciaSeptum) + vec3(0.020, 0.017, 0.013) * titanSweep;
if (uHologramMode > 0.5) {
  float titanMuscleLift = mix(0.68, 1.16, titanSmoothActive);
  vec3 titanObsidianHolo = diffuseColor.rgb * mix(0.56, 0.42, titanSmoothZone) * titanCavityAO * titanChiaroscuroRgb + uHologramTint * (0.024 + 0.050 * titanWrapDiffuse + 0.040 * titanSmoothZone * titanWrapDiffuse + titanRidgeCatch * 0.08);
  vec3 titanHoloSurface = mix(
    titanObsidianHolo,
    vMuscleColor * (1.0 + titanFiberMicro * 1.5) * titanMuscleLift * titanCavityAO * mix(0.66, 1.28, titanWrapDiffuse) + uHologramTint * (0.036 * titanWrapDiffuse),
    titanSmoothActive
  );
  diffuseColor.rgb = titanHoloSurface * (1.0 - titanMaskEdge * 0.20 - titanFasciaSeptum * 0.78);
}
`,
        'fragment',
      );

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>
vec3 titanViewDir = normalize(vViewPosition);
vec3 titanNormal = normalize(normal);
float titanNdotV = max(dot(titanNormal, titanViewDir), 0.0);
float titanHoloCoreRim = pow(1.0 - titanNdotV, 2.05);
float titanHoloFresnel = pow(1.0 - titanNdotV, 3.15);
float titanHoloSharpRim = pow(1.0 - titanNdotV, 5.2);
vec3 titanWorldViewDir = normalize(cameraPosition - vAnatomyWorldPos);
vec3 titanBackLightDir = normalize(uBacklightOrigin - vAnatomyWorldPos);
vec3 titanWorldNormal = normalize(vAnatomyWorldNormal);
float titanBackFacing = max(dot(-titanWorldNormal, titanBackLightDir), 0.0);
float titanLightToView = max(dot(-titanBackLightDir, titanWorldViewDir), 0.0);
float titanBackWrap = pow(titanBackFacing, 1.55) * (0.34 + 0.66 * pow(titanLightToView, 2.0));
float titanRimDirectional = 0.48 + 0.52 * smoothstep(-0.35, 0.78, dot(normalize(vAnatomyWorldNormal), normalize(vec3(0.45, 0.48, -0.75))));
float titanDepthAtten = mix(0.94, 1.04, clamp(titanRimDirectional * 0.62 + titanBackFacing * 0.38, 0.0, 1.0));
float titanSmoothActiveE = smoothstep(0.14, 0.86, vMuscleActive);
float titanSmoothPrimaryE = smoothstep(0.16, 0.84, vMusclePrimary);
float titanSmoothSecondaryE = smoothstep(0.16, 0.84, vMuscleSecondary);
vec3 titanBioSSSColor = mix(vec3(0.62, 0.15, 0.085), mix(uHologramTint, uHologramAccent, 0.34), clamp(uHologramMode, 0.0, 1.0));
vec3 titanUvScatteringAlbedo = texture2D(uSkinScatteringMap, vMapUv).rgb;
vec3 titanScatteringTint = mix(titanUvScatteringAlbedo, titanBioSSSColor, clamp(uHologramMode, 0.0, 1.0));
// Local multi-lobe RGB diffusion profile: red spreads farther than green/blue.
// The UV-prefiltered map supplies low-frequency reflectance; incident-light diffusion remains a real-time directional/thin-region approximation, not a full UV-space SSS solve.
float titanScatterDistance = clamp(1.0 - titanBackFacing, 0.0, 1.0);
// Regional optical path estimate in meters: thicker torso tissue attenuates blue/green more than red.
// This regional optical-path estimate modulates transmission; it is not a full transport solve.
float titanOpticalPathM = clamp(vSkinThickness / max(0.30 + 0.70 * titanBackFacing, 0.30), 0.004, 0.040);
vec3 titanSkinTransmittance = exp(-titanOpticalPathM * vec3(18.0, 31.0, 47.0));
float titanDiffusionScale = clamp(vSkinThickness / 0.012, 0.62, 1.42);
vec3 titanDiffusionWide = exp(-pow(vec3(titanScatterDistance) / (vec3(0.92, 0.60, 0.38) * titanDiffusionScale), vec3(2.0)));
vec3 titanDiffusionNear = exp(-pow(vec3(titanScatterDistance) / (vec3(0.42, 0.28, 0.18) * titanDiffusionScale), vec3(2.0)));
vec3 titanDiffusionProfile = titanDiffusionWide * vec3(0.56, 0.34, 0.20) + titanDiffusionNear * vec3(0.18, 0.24, 0.24);
vec3 titanBioSSS = titanScatteringTint * titanBackWrap * titanSkinTransmittance * titanDiffusionProfile * 0.108;
vec3 titanDermalBounce = vec3(0.072, 0.024, 0.016) * pow(1.0 - titanNdotV, 2.3) * (1.0 - uHologramMode) * 0.45;
vec3 titanSSS = titanBioSSS + titanDermalBounce;
totalEmissiveRadiance += titanSSS;
if (uHologramMode > 0.5) {
  float titanScanCoord = vAnatomyWorldY * 360.0 - uTime * 1.55 + uScanPhase;
  float titanHoloScanSignal = 0.5 + 0.5 * cos(titanScanCoord);
  float titanHoloBand = pow(titanHoloScanSignal, 15.0);
  float titanTopoLine = pow(0.5 + 0.5 * cos(vAnatomyWorldPos.x * 210.0 + vAnatomyWorldPos.z * 88.0), 20.0);
  float titanScanWave = pow(0.5 + 0.5 * cos(vAnatomyWorldY * 5.2 - uTime * 0.85 + uScanPhase), 16.0);
  float titanEdgeGate = 0.08 + 0.92 * smoothstep(0.10, 0.68, titanHoloCoreRim);
  float titanHoloScan = (titanHoloBand * 0.46 + titanTopoLine * 0.32 + titanScanWave * 0.22) * titanEdgeGate;
  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 26.0, 2.0));
  vec3 titanHoloBaseEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.22, 0.86, titanHoloFresnel));
  vec3 titanLineColor = mix(uHologramTint * 1.12, vMuscleColor, titanSmoothActiveE * 0.78);
  float titanFasciaGlow = exp(-pow((titanSmoothActiveE - 0.52) * 4.5, 2.0)) * titanSmoothActiveE;
  vec3 titanWorkoutGlow = vMuscleColor * (
    titanSmoothPrimaryE * (0.34 + titanHoloCoreRim * 0.72) +
    titanSmoothSecondaryE * (0.22 + titanHoloCoreRim * 0.52) +
    titanFasciaGlow * 0.28
  );
  vec3 titanHoloEdge = mix(titanHoloBaseEdge, vMuscleColor, titanSmoothActiveE * 0.62);
  float titanRoleRimBoost = mix(0.84, 1.02, uBodyRole);
  totalEmissiveRadiance += titanHoloEdge * (
    titanHoloCoreRim * 0.072 +
    titanHoloFresnel * titanRoleRimBoost * titanRimDirectional * titanDepthAtten +
    titanHoloSharpRim * 0.74 * titanRimDirectional +
    titanHoloSweep * 0.58
  ) + titanLineColor * (titanHoloScan * (0.20 + titanSmoothActiveE * 0.16))
    + titanWorkoutGlow;
  // Selection adds a crisp champagne/white contour without erasing primary/secondary workout colors.
  float titanSelectionContour = smoothstep(0.16, 0.84, titanHoloFresnel) * 1.38 + 0.24;
  totalEmissiveRadiance += uMuscleSelectedColor * (smoothstep(0.18, 0.82, vMuscleSelected) * titanSelectionContour);
}`,
        'fragment',
      );
    } else {
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>
uniform float uHologramMode;
uniform float uSweepY;
uniform vec3 uHologramTint;
uniform vec3 uHologramAccent;
uniform float uScanPhase;
uniform float uTime;
uniform float uBodyRole;
uniform vec3 uBacklightOrigin;
uniform sampler2D uSkinScatteringMap;
uniform vec3 uKeyLightDirection;
varying float vAnatomyWorldY;
varying vec3 vAnatomyWorldPos;
varying vec3 vAnatomyWorldNormal;
varying vec3 vAnatomyLocalPos;
varying float vSkinThickness;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>
vec3 titanNormalW = normalize(vAnatomyWorldNormal);
vec3 titanNormalStep = fwidth(titanNormalW);
float titanPosStep = max(0.0011, length(fwidth(vAnatomyWorldPos)));
float titanCurvature = smoothstep(0.06, 0.84, clamp(length(titanNormalStep) / titanPosStep * 0.056, 0.0, 1.0));
float titanCavityAO = mix(0.30, 1.16, 1.0 - titanCurvature * 0.78);
vec3 titanKeyDir = normalize(uKeyLightDirection);
float titanRawDot = dot(titanNormalW, titanKeyDir);
float titanKeyNdotL = clamp(titanRawDot * 0.5 + 0.5, 0.0, 1.0);
vec3 titanWrapRgb = clamp((vec3(titanRawDot) + vec3(0.46, 0.24, 0.14)) / vec3(1.46, 1.24, 1.14), 0.0, 1.0);
float titanWrapDiffuse = titanWrapRgb.g;
float titanTerminatorSSS = pow(clamp(1.0 - abs(titanRawDot - 0.06), 0.0, 1.0), 2.3);
vec3 titanChiaroscuroRgb = mix(vec3(0.30, 0.28, 0.30), vec3(1.36, 1.34, 1.32), pow(titanWrapRgb, vec3(1.22, 1.48, 1.66)));
float titanRidgeCatch = pow(max(dot(titanNormalW, normalize(vec3(0.46, 0.54, -0.70))), 0.0), 3.6) * 0.32;
if (uHologramMode > 0.5) {
  vec3 titanHoloSurface = diffuseColor.rgb * 0.48 * titanCavityAO * titanChiaroscuroRgb + uHologramTint * (0.022 + 0.048 * titanWrapDiffuse + titanRidgeCatch * 0.075);
  diffuseColor.rgb = titanHoloSurface;
} else {
  diffuseColor.rgb = diffuseColor.rgb * titanCavityAO * titanChiaroscuroRgb + vec3(0.135, 0.032, 0.018) * titanTerminatorSSS;
}`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>
vec3 titanViewDir = normalize(vViewPosition);
vec3 titanNormal = normalize(normal);
float titanNdotV = max(dot(titanNormal, titanViewDir), 0.0);
float titanHoloCoreRim = pow(1.0 - titanNdotV, 2.05);
float titanHoloFresnel = pow(1.0 - titanNdotV, 3.15);
float titanHoloSharpRim = pow(1.0 - titanNdotV, 5.2);
vec3 titanWorldViewDir = normalize(cameraPosition - vAnatomyWorldPos);
vec3 titanBackLightDir = normalize(uBacklightOrigin - vAnatomyWorldPos);
vec3 titanWorldNormal = normalize(vAnatomyWorldNormal);
float titanBackFacing = max(dot(-titanWorldNormal, titanBackLightDir), 0.0);
float titanLightToView = max(dot(-titanBackLightDir, titanWorldViewDir), 0.0);
float titanBackWrap = pow(titanBackFacing, 1.55) * (0.34 + 0.66 * pow(titanLightToView, 2.0));
float titanRimDirectional = 0.48 + 0.52 * smoothstep(-0.35, 0.78, dot(normalize(vAnatomyWorldNormal), normalize(vec3(0.45, 0.48, -0.75))));
float titanDepthAtten = mix(0.94, 1.04, clamp(titanRimDirectional * 0.62 + titanBackFacing * 0.38, 0.0, 1.0));
vec3 titanBioSSSColor = mix(vec3(0.62, 0.15, 0.085), mix(uHologramTint, uHologramAccent, 0.34), clamp(uHologramMode, 0.0, 1.0));
vec3 titanUvScatteringAlbedo = texture2D(uSkinScatteringMap, vMapUv).rgb;
vec3 titanScatteringTint = mix(titanUvScatteringAlbedo, titanBioSSSColor, clamp(uHologramMode, 0.0, 1.0));
float titanScatterDistance = clamp(1.0 - titanBackFacing, 0.0, 1.0);
float titanOpticalPathM = clamp(vSkinThickness / max(0.30 + 0.70 * titanBackFacing, 0.30), 0.004, 0.040);
vec3 titanSkinTransmittance = exp(-titanOpticalPathM * vec3(18.0, 31.0, 47.0));
float titanDiffusionScale = clamp(vSkinThickness / 0.012, 0.62, 1.42);
vec3 titanDiffusionWide = exp(-pow(vec3(titanScatterDistance) / (vec3(0.92, 0.60, 0.38) * titanDiffusionScale), vec3(2.0)));
vec3 titanDiffusionNear = exp(-pow(vec3(titanScatterDistance) / (vec3(0.42, 0.28, 0.18) * titanDiffusionScale), vec3(2.0)));
vec3 titanDiffusionProfile = titanDiffusionWide * vec3(0.56, 0.34, 0.20) + titanDiffusionNear * vec3(0.18, 0.24, 0.24);
totalEmissiveRadiance += titanScatteringTint * titanBackWrap * titanSkinTransmittance * titanDiffusionProfile * 0.108;
if (uHologramMode > 0.5) {
  float titanScanCoord = vAnatomyWorldY * 360.0 - uTime * 1.55 + uScanPhase;
  float titanHoloScanSignal = 0.5 + 0.5 * cos(titanScanCoord);
  float titanHoloBand = pow(titanHoloScanSignal, 15.0);
  float titanTopoLine = pow(0.5 + 0.5 * cos(vAnatomyWorldPos.x * 210.0 + vAnatomyWorldPos.z * 88.0), 20.0);
  float titanScanWave = pow(0.5 + 0.5 * cos(vAnatomyWorldY * 5.2 - uTime * 0.85 + uScanPhase), 16.0);
  float titanEdgeGate = 0.08 + 0.92 * smoothstep(0.10, 0.68, titanHoloCoreRim);
  float titanHoloScan = (titanHoloBand * 0.46 + titanTopoLine * 0.32 + titanScanWave * 0.22) * titanEdgeGate;
  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 26.0, 2.0));
  vec3 titanHoloEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.22, 0.86, titanHoloFresnel));
  float titanRoleRimBoost = mix(0.84, 1.02, uBodyRole);
  totalEmissiveRadiance += titanHoloEdge * (
    titanHoloCoreRim * 0.072 +
    titanHoloFresnel * titanRoleRimBoost * titanRimDirectional * titanDepthAtten +
    titanHoloSharpRim * 0.70 * titanRimDirectional +
    titanHoloSweep * 0.54
  ) + uHologramTint * (titanHoloScan * 0.20);
}`,
        'fragment',
      );
    }
  };

  material.customProgramCacheKey = () => `titan-anatomy-${role}-pbr-v11.3-single-pass-worldy`;
}
