import type { BiologicalSex } from '../contracts/user-profile';

export type AdultBmiCategory =
  | 'underweight'
  | 'normal'
  | 'overweight'
  | 'obesity_class_1'
  | 'obesity_class_2'
  | 'obesity_class_3';

export interface BodyCompositionInput {
  weightKg: number;
  heightCm: number;
  age: number;
  waistCm?: number;
  neckCm?: number;
  hipCm?: number;
  sex?: BiologicalSex;
}

export interface BodyCompositionMetrics {
  bmi: number;
  bmiCategory: AdultBmiCategory | 'not_classified_for_age';
  waistToHeightRatio: number | null;
  bodyFatPercent: number | null;
  relativeFatMassPercent: number | null;
  bodyFatMethodDifferencePercent: number | null;
  fatMassKg: number | null;
  leanMassKg: number | null;
  ffmi: number | null;
}

function assertPositiveFinite(value: number, label: string): void {
  if (!Number.isFinite(value) || value <= 0) throw new RangeError(`${label} precisa ser um número positivo e finito.`);
}

function assertBiologicalSex(value: unknown): asserts value is BiologicalSex {
  if (value !== 'male' && value !== 'female') throw new RangeError('Sexo de referência inválido para a equação antropométrica.');
}

export function classifyAdultBmi(bmi: number): AdultBmiCategory {
  if (!Number.isFinite(bmi) || bmi <= 0) throw new RangeError('IMC inválido.');
  if (bmi < 18.5) return 'underweight';
  if (bmi < 25) return 'normal';
  if (bmi < 30) return 'overweight';
  if (bmi < 35) return 'obesity_class_1';
  if (bmi < 40) return 'obesity_class_2';
  return 'obesity_class_3';
}

/** Adult screening estimate. BMI is not a direct measure of body fat or muscle. */
export function calculateBmi(weightKg: number, heightCm: number): number {
  assertPositiveFinite(weightKg, 'Peso');
  assertPositiveFinite(heightCm, 'Altura');
  const heightM = heightCm / 100;
  return Number((weightKg / (heightM * heightM)).toFixed(1));
}

/** Waist-to-height ratio; interpreted as a screening indicator, not a diagnosis. */
export function calculateWaistToHeightRatio(waistCm: number, heightCm: number): number {
  assertPositiveFinite(waistCm, 'Circunferência da cintura');
  assertPositiveFinite(heightCm, 'Altura');
  if (waistCm >= heightCm * 2) throw new RangeError('A relação cintura/altura está fora de uma faixa plausível; confira as medidas.');
  return Number((waistCm / heightCm).toFixed(3));
}

/**
 * U.S. Navy circumference estimate. Measurements are received in centimetres
 * and converted to inches because the published equation constants use inches.
 * It requires neck + waist, and hip circumference for the female equation.
 */
export function estimateBodyFatNavy(input: {
  sex: BiologicalSex;
  heightCm: number;
  waistCm: number;
  neckCm: number;
  hipCm?: number;
}): number {
  assertBiologicalSex(input.sex);
  assertPositiveFinite(input.heightCm, 'Altura');
  assertPositiveFinite(input.waistCm, 'Cintura');
  assertPositiveFinite(input.neckCm, 'Pescoço');
  const heightIn = input.heightCm / 2.54;
  const waistIn = input.waistCm / 2.54;
  const neckIn = input.neckCm / 2.54;
  let estimate: number;

  if (input.sex === 'male') {
    if (waistIn <= neckIn) throw new RangeError('A medida da cintura deve ser maior que a do pescoço.');
    estimate = 86.010 * Math.log10(waistIn - neckIn) - 70.041 * Math.log10(heightIn) + 36.76;
  } else {
    if (input.hipCm === undefined) throw new RangeError('A medida do quadril é necessária para esta equação.');
    assertPositiveFinite(input.hipCm, 'Quadril');
    const hipIn = input.hipCm / 2.54;
    if (waistIn + hipIn <= neckIn) throw new RangeError('As medidas de cintura e quadril são incompatíveis com a medida do pescoço.');
    estimate = 163.205 * Math.log10(waistIn + hipIn - neckIn) - 97.684 * Math.log10(heightIn) - 78.387;
  }

  if (!Number.isFinite(estimate) || estimate < 2 || estimate > 60) {
    throw new RangeError('A estimativa ficou fora da faixa plausível; confira as medidas ou não use este método para este perfil.');
  }
  return Number(estimate.toFixed(1));
}

/**
 * Relative Fat Mass (RFM), a second waist/height-based estimate developed
 * against DXA in US adult NHANES samples. It is an estimator, not a direct
 * measure, and population transferability is not guaranteed.
 */
export function estimateRelativeFatMass(input: {
  sex: BiologicalSex;
  heightCm: number;
  waistCm: number;
  age?: number;
}): number {
  assertBiologicalSex(input.sex);
  if (input.age !== undefined && (!Number.isFinite(input.age) || input.age < 20 || input.age > 120)) {
    throw new RangeError('RFM deve ser usada apenas como estimativa antropométrica adulta (20 anos ou mais).');
  }
  assertPositiveFinite(input.heightCm, 'Altura');
  assertPositiveFinite(input.waistCm, 'Circunferência da cintura');
  if (input.waistCm >= input.heightCm * 2) {
    throw new RangeError('A relação cintura/altura está fora de uma faixa plausível; confira as medidas.');
  }
  const sexOffset = input.sex === 'female' ? 12 : 0;
  const estimate = 64 - (20 * input.heightCm / input.waistCm) + sexOffset;
  if (!Number.isFinite(estimate) || estimate < 2 || estimate > 60) {
    throw new RangeError('A estimativa RFM ficou fora da faixa plausível; confira as medidas ou não use este método para este perfil.');
  }
  return Number(estimate.toFixed(1));
}

export function calculateBodyComposition(input: BodyCompositionInput): BodyCompositionMetrics {
  if (!Number.isFinite(input.age) || input.age < 1 || input.age > 120) {
    throw new RangeError('Idade precisa ser um número finito entre 1 e 120 anos.');
  }
  const bmi = calculateBmi(input.weightKg, input.heightCm);
  const waistToHeightRatio = input.waistCm === undefined
    ? null
    : calculateWaistToHeightRatio(input.waistCm, input.heightCm);
  const bodyFatPercent = input.sex && input.waistCm !== undefined && input.neckCm !== undefined
    ? estimateBodyFatNavy({
        sex: input.sex,
        heightCm: input.heightCm,
        waistCm: input.waistCm,
        neckCm: input.neckCm,
        hipCm: input.hipCm,
      })
    : null;

  const relativeFatMassPercent = input.sex && input.waistCm !== undefined
    ? estimateRelativeFatMass({ sex: input.sex, heightCm: input.heightCm, waistCm: input.waistCm, age: input.age })
    : null;
  const bodyFatMethodDifferencePercent = bodyFatPercent !== null && relativeFatMassPercent !== null
    ? Number(Math.abs(bodyFatPercent - relativeFatMassPercent).toFixed(1))
    : null;
  const fatMassKg = bodyFatPercent === null ? null : Number((input.weightKg * bodyFatPercent / 100).toFixed(1));
  const leanMassKg = fatMassKg === null ? null : Number((input.weightKg - fatMassKg).toFixed(1));
  const heightM = input.heightCm / 100;
  const ffmi = leanMassKg === null ? null : Number((leanMassKg / (heightM * heightM)).toFixed(1));

  return {
    bmi,
    bmiCategory: input.age >= 20 ? classifyAdultBmi(bmi) : 'not_classified_for_age',
    waistToHeightRatio,
    bodyFatPercent,
    relativeFatMassPercent,
    bodyFatMethodDifferencePercent,
    fatMassKg,
    leanMassKg,
    ffmi,
  };
}
