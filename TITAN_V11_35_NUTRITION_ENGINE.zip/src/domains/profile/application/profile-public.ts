import { parseLocaleNumber } from '@/src/shared/utils/formatters';
import type {
  BiologicalSex,
  ComputedGoalTargets,
  EnergyBudgetSummary,
  DailyActivityLevel,
  FitnessGoalType,
  UserPhysiologicalProfile,
} from '../domain/contracts/user-profile';
import {
  ACTIVITY_LEVEL_OPTIONS,
  calculatePhysiologicalGoalTargets,
  estimateNASEM2023Eer,
  resolveDriProfileId,
  GOAL_OPTIONS,
} from '../domain/rules/goal-calculator';
export type { GoalCalculationContext } from '../domain/rules/goal-calculator';
import { profileGoalsSchema } from '../schemas/profile-goals.schema';
import { calculateBodyComposition, calculateBmi, calculateWaistToHeightRatio, estimateBodyFatNavy, estimateRelativeFatMass } from '../domain/rules/body-composition';
import { estimateAdaptiveTdee, type AdaptiveTdeeEstimate, type DailyEnergyIntakeRecord } from '../domain/rules/adaptive-energy';
import { estimateRestingMetabolicRate, resolveAutomaticRmrMethod } from '../domain/rules/resting-metabolic-rate';
import { useProfileStore } from '../state/profile.store';
export { estimateRestingMetabolicRate, resolveAutomaticRmrMethod };
export type { AutomaticRmrSelection, RestingMetabolicRateInput, RestingMetabolicRateEstimate, RestingMetabolicRateMethod, FatFreeMassSource } from '../domain/rules/resting-metabolic-rate';

export type { AdaptiveTdeeEstimate, DailyEnergyIntakeRecord };
export { resolveDailyEnergyBudget } from '../domain/rules/energy-budget';
export type { DailyEnergyBudget, DailyEnergyBudgetInput, EnergyExpenditureBasis, ExerciseEnergyAccounting } from '../domain/rules/energy-budget';

export type {
  BiologicalSex,
  ComputedGoalTargets,
  EnergyBudgetSummary,
  DailyActivityLevel,
  FitnessGoalType,
  UserPhysiologicalProfile,
};

export function validateProfileGoals(raw: {
  sex: BiologicalSex;
  goal: FitnessGoalType;
  currentWeightKg: string;
  targetWeightKg: string;
  activityLevel: DailyActivityLevel;
  deadlineDateKey: string;
  heightCm: string;
  age: string;
  rmrMethod?: UserPhysiologicalProfile['rmrMethod'];
  measuredRmrKcal?: string;
  bodyFatPercent?: string;
  fatFreeMassSource?: UserPhysiologicalProfile['fatFreeMassSource'];
}):
  | { ok: true; data: UserPhysiologicalProfile }
  | { ok: false; error: string } {
  if (
    raw.currentWeightKg.trim() === '' ||
    raw.targetWeightKg.trim() === '' ||
    raw.heightCm.trim() === '' ||
    raw.age.trim() === ''
  ) {
    return {
      ok: false,
      error: 'Preencha peso atual, peso desejado, altura e idade.',
    };
  }

  const parsed = profileGoalsSchema.safeParse({
    sex: raw.sex,
    goal: raw.goal,
    currentWeightKg: parseLocaleNumber(raw.currentWeightKg),
    targetWeightKg: parseLocaleNumber(raw.targetWeightKg),
    activityLevel: raw.activityLevel,
    deadlineDateKey: raw.deadlineDateKey,
    heightCm: parseLocaleNumber(raw.heightCm),
    age: parseLocaleNumber(raw.age),
    ...(raw.rmrMethod ? { rmrMethod: raw.rmrMethod } : {}),
    ...(raw.measuredRmrKcal?.trim() ? { measuredRmrKcal: parseLocaleNumber(raw.measuredRmrKcal) } : {}),
    ...(raw.bodyFatPercent?.trim() ? { bodyFatPercent: parseLocaleNumber(raw.bodyFatPercent) } : {}),
    ...(raw.fatFreeMassSource ? { fatFreeMassSource: raw.fatFreeMassSource } : {}),
  });

  if (!parsed.success) {
    return {
      ok: false,
      error: parsed.error.issues[0]?.message ?? 'Dados fisiológicos inválidos.',
    };
  }

  if (parsed.data.bodyFatPercent !== undefined && parsed.data.fatFreeMassSource === undefined) {
    return { ok: false, error: 'Informe a origem do percentual de gordura corporal para registrar a composição com proveniência.' };
  }
  if (!parsed.data.measuredRmrKcal && ['cunningham_1980', 'katch_mcardle'].includes(parsed.data.rmrMethod ?? 'mifflin_st_jeor') &&
      (parsed.data.bodyFatPercent === undefined || parsed.data.fatFreeMassSource === undefined)) {
    return { ok: false, error: 'Cunningham e Katch–McArdle exigem percentual de gordura e origem da composição corporal, ou informe RMR medido.' };
  }
  return { ok: true, data: parsed.data };
}

export {
  ACTIVITY_LEVEL_OPTIONS,
  estimateAdaptiveTdee,
  calculatePhysiologicalGoalTargets,
  estimateNASEM2023Eer,
  resolveDriProfileId,
  GOAL_OPTIONS,
  calculateBodyComposition,
  calculateBmi,
  calculateWaistToHeightRatio,
  estimateBodyFatNavy,
  estimateRelativeFatMass,
  useProfileStore,
};
