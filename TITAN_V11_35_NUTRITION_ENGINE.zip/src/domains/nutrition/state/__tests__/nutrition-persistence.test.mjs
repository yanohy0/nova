import assert from 'node:assert/strict';
import { mergeNutritionPersistedState } from '../nutrition-persistence.ts';

const defaultMeal = {
  id: 'default', dateKey: '2026-11-23', time: '08:00', title: 'Café', description: 'Ovos',
  planned_quantity: 100, consumed_quantity: 0,
  planned_foods: [{ foodId: 'egg', quantityG: 100 }], consumed_foods: [], status: 'planned',
};
const fallback = {
  activeDateKey: '2026-11-23', referenceProfileId: 'adult_male_19_50',
  dailyGoals: { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
  meals: [defaultMeal], intakeDayConfirmations: [],
};
const validMeal = { ...defaultMeal, id: 'saved', status: 'consumed', consumed_quantity: 100,
  consumed_foods: [{ foodId: 'egg', quantityG: 100 }] };
const merged = mergeNutritionPersistedState({
  activeDateKey: '2026-11-22', referenceProfileId: 'adult_female_19_50',
  dailyGoals: { kcal: 2300, proteinG: 140, carbsG: 250, fatG: 70 },
  meals: [validMeal, { ...validMeal, id: 'bad-date', dateKey: '2026-02-30' }, { ...validMeal, id: 'bad-meal', consumed_quantity: Number.NaN },
    { ...validMeal, id: 'bad-description', description: { text: 'not a string' } }],
  intakeDayConfirmations: ['2026-11-22', '2026-99-90', '2026-11-22'],
}, fallback);
assert.equal(merged.activeDateKey, '2026-11-22');
assert.equal(merged.referenceProfileId, 'adult_female_19_50');
const ageSpecific = mergeNutritionPersistedState({ referenceProfileId: 'adult_female_19_30' }, fallback);
assert.equal(ageSpecific.referenceProfileId, 'adult_female_19_30');
assert.equal(merged.dailyGoals.kcal, 2300);
assert.deepEqual(merged.meals.map((meal) => meal.id), ['saved']);
assert.deepEqual(merged.intakeDayConfirmations, ['2026-11-22']);
const corrupt = mergeNutritionPersistedState({ activeDateKey: 'not-a-date', referenceProfileId: 'fake', dailyGoals: {}, meals: [null] }, fallback);
assert.equal(corrupt.activeDateKey, fallback.activeDateKey);
assert.equal(corrupt.referenceProfileId, fallback.referenceProfileId);
assert.deepEqual(corrupt.meals, []);
assert.deepEqual(corrupt.dailyGoals, fallback.dailyGoals);

const legacyBreakfast = { ...defaultMeal, id: 'meal-1', title: 'Café da manhã', recipeId: 'rec-cafe-completo', status: 'consumed', consumed_quantity: 100, consumed_foods: [{ foodId: 'egg', quantityG: 100 }] };
const legacyPriorDay = { ...defaultMeal, id: 'meal-prev-1', title: 'Almoço (dia anterior)', status: 'consumed', consumed_quantity: 100, consumed_foods: [{ foodId: 'egg', quantityG: 100 }] };
const cleanedLegacy = mergeNutritionPersistedState({ meals: [legacyBreakfast, legacyPriorDay] }, fallback);
assert.equal(cleanedLegacy.meals.length, 1, 'hard-coded prior-day consumption is removed');
assert.equal(cleanedLegacy.meals[0].status, 'planned', 'the old pre-checked breakfast is restored to planned');
assert.equal(cleanedLegacy.meals[0].consumed_foods.length, 0);

console.log('Nutrition persistence tests passed.');

const customMeal = { ...defaultMeal, id: 'custom-meal-test-1', title: 'Pós-treino', time: '18:30',
  planned_foods: [{ foodId: 'egg', quantityG: 120 }, { foodId: 'rice', quantityG: 150 }] };
const customMealMerged = mergeNutritionPersistedState({ meals: [customMeal] }, fallback);
assert.equal(customMealMerged.meals[0].id, 'custom-meal-test-1', 'custom meals survive persistence');
assert.equal(customMealMerged.meals[0].planned_foods.length, 2, 'custom meal ingredients survive persistence');
const oversizedCustomMeal = { ...customMeal, id: 'custom-meal-invalid', planned_foods: Array.from({ length: 41 }, (_, index) => ({ foodId: `food-${index}`, quantityG: 10 })) };
const boundedMeals = mergeNutritionPersistedState({ meals: [customMeal, oversizedCustomMeal] }, fallback);
assert.deepEqual(boundedMeals.meals.map((meal) => meal.id), ['custom-meal-test-1'], 'meals with oversized ingredient arrays are rejected');

const unsafeMediaMeals = mergeNutritionPersistedState({ meals: [
  { ...customMeal, id: 'unsafe-js-image', imageUrl: 'javascript:alert(1)' },
  { ...customMeal, id: 'oversized-title', title: 'x'.repeat(81) },
  { ...customMeal, id: 'unsafe-protocol-relative', imageUrl: '//evil.example/image.png' },
  { ...customMeal, id: 'safe-local-image', imageUrl: '/src/assets/images/meal_chicken_rice_bowl_1795297143937.jpg' },
] }, fallback);
assert.deepEqual(unsafeMediaMeals.meals.map((meal) => meal.id), ['safe-local-image'], 'unsafe image URLs and oversized meal labels are rejected');

const supplementEntry = {
  id: 'supplement-mg-1', dateKey: '2026-11-23', time: '08:15', productName: 'Magnésio quelato',
  nutrientId: 'magnesium', amount: 200, unit: 'mg', chemicalForm: 'unspecified',
  sourceName: 'Rótulo informado pelo usuário', sourceVersion: 'manual-entry-v1',
  sourceRecordId: 'label-mg-1', recordedAt: '2026-11-23T11:15:00.000Z',
};
const withSupplement = mergeNutritionPersistedState({ supplementMicronutrientIntakes: [
  supplementEntry,
  { ...supplementEntry, id: 'invalid-chemical-form', chemicalForm: 'unknown' },
  { ...supplementEntry, amount: 999 },
  { ...supplementEntry, id: 'unsafe-url', sourceUrl: 'javascript:alert(1)' },
] }, fallback);
assert.deepEqual(withSupplement.supplementMicronutrientIntakes.map((entry) => entry.id), ['supplement-mg-1']);
const legacyWithoutSupplements = mergeNutritionPersistedState({}, fallback);
assert.deepEqual(legacyWithoutSupplements.supplementMicronutrientIntakes, []);
