import assert from 'node:assert/strict';
import {
  buildMealFromCardapioSlot,
  computeRecipeSummary,
  searchSubstitutionRecipes,
} from '../domain/rules/recipe-engine';
import { findRecipeById } from '../data/recipes/recipe-catalog';
import { calculatePhysiologicalGoalTargets } from '../../profile/domain/rules/goal-calculator';
import { INITIAL_FIRST_RECORD_DATE_KEY } from '../../calendar/state/calendar.store';

// 1. Camada Receita -> Ingredientes calcula macros automaticamente
const almocoRecipe = findRecipeById('rec-almoco-frango');
assert.ok(almocoRecipe);
const almocoSummary = computeRecipeSummary(almocoRecipe, 1);
assert.equal(almocoSummary.totalGrams, 400);
assert.equal(almocoSummary.macros.kcal, 620);

// 2. Camada Cardápio -> Receita hidrata refeição sem perder composição de ingredientes
const meal = buildMealFromCardapioSlot({
  id: 'slot-test',
  dateKey: '2026-11-21',
  time: '12:30',
  title: 'Almoço',
  recipeId: 'rec-almoco-frango',
  status: 'planned',
});
assert.equal(meal.planned_foods.length, 1);
assert.equal(meal.planned_quantity, 400);
assert.equal(meal.status, 'planned');

// 3. Pesquisa de substituição filtra por ingrediente e exclui receita atual
const salmonMatches = searchSubstitutionRecipes('salmão', 'rec-almoco-frango');
assert.equal(salmonMatches.length, 0, 'the only legacy salmon template uses an unverified composite dish and must not be selectable as a substitution');

// 4. Cálculo fisiológico de metas (Mifflin-St Jeor)
const gainPlan = calculatePhysiologicalGoalTargets(
  {
    sex: 'male',
    goal: 'gain_muscle',
    currentWeightKg: 79.1,
    targetWeightKg: 82.0,
    activityLevel: 'moderate',
    deadlineDateKey: '2027-02-20',
    heightCm: 179,
    age: 29,
  },
  '2026-11-21',
);
assert.ok(gainPlan.kcal > gainPlan.tdee);
assert.ok(gainPlan.proteinG >= 140 && gainPlan.proteinG <= gainPlan.proteinMaxG);

// 5. Data do primeiro registro está armazenada explicitamente
assert.equal(INITIAL_FIRST_RECORD_DATE_KEY, '2026-11-07');

// Recipe engine must not round ingredient masses before the nutrition calculation.
const fractionalRecipe = {
  id: 'fractional-test', name: 'Teste fracionário', description: '', category: 'lanche' as const,
  ingredients: [{ ingredientId: 'tbca-banana-prata', quantityG: 37.25 }],
};
const fractionalSummary = computeRecipeSummary(fractionalRecipe, 1.1);
assert.equal(fractionalSummary.portions[0]?.quantityG, 40.975);
assert.equal(fractionalSummary.dataCoveragePercent, 100);
