import assert from 'node:assert/strict';
import { createFoodDiaryMeal } from '../food-diary.ts';
import { mergeNutritionPersistedState } from '../../../state/nutrition-persistence.ts';

const food = {
  food_id: 'tbca:001',
  name: 'Arroz cozido',
  source_id: 'TBCA',
  source_record_id: '001',
  source_version: '2026',
  quality_status: 'reference_database',
  macros: {
    kcalPerBasis: 128,
    proteinGPerBasis: 2.5,
    carbsGPerBasis: 28.1,
    fatGPerBasis: 0.2,
    basisQuantityG: 100,
  },
  micronutrients: {},
};
const meal = createFoodDiaryMeal({
  food,
  quantityG: 150,
  dateKey: '2026-11-23',
  mealTitle: 'Almoço',
  id: 'food-log-1',
  nowMs: new Date(2026, 10, 23, 12, 30).getTime(),
});
assert.ok(meal);
assert.equal(meal.status, 'consumed');
assert.equal(meal.dateKey, '2026-11-23');
assert.equal(meal.time, '12:30');
assert.deepEqual(meal.consumed_foods, [{ foodId: 'tbca:001', quantityG: 150 }]);
assert.deepEqual(meal.planned_foods, meal.consumed_foods);
const persisted = mergeNutritionPersistedState({ meals: [meal] }, {
  activeDateKey: '2026-11-23', referenceProfileId: 'adult_male_19_50',
  dailyGoals: { kcal: 2500, proteinG: 150, carbsG: 280, fatG: 75 },
  meals: [], intakeDayConfirmations: [],
});
assert.equal(persisted.meals.length, 1, 'a food-diary item is retained by nutrition persistence');
assert.equal(persisted.meals[0].id, 'food-log-1');
assert.deepEqual(persisted.meals[0].consumed_foods, [{ foodId: 'tbca:001', quantityG: 150 }]);
assert.equal(createFoodDiaryMeal({ food, quantityG: 0, dateKey: '2026-11-23', mealTitle: 'Almoço', id: 'bad', nowMs: 1000 }), null);
assert.equal(createFoodDiaryMeal({ food, quantityG: 2001, dateKey: '2026-11-23', mealTitle: 'Almoço', id: 'bad', nowMs: 1000 }), null);
assert.equal(createFoodDiaryMeal({ food, quantityG: 100, dateKey: '2026-02-30', mealTitle: 'Almoço', id: 'bad', nowMs: 1000 }), null);
console.log('Food diary tests passed.');
