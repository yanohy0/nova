import assert from 'node:assert/strict';
import { computePortionsMacrosWithQuality } from '../nutrition-calculator.ts';
import { validateFoodMacroComposition } from '../food-data-quality.ts';
import { computeIngredientNutritionImpact, computeRecipeNutrition, prepareQPModel, scaleDayPlanProportionallyToMealTargets } from '../cardapio-composer-engine.ts';
import { TBCA_FOODS } from '../../../data/sources/tbca-adapter.ts';

const baseFood = {
  food_id: 'test-food', name: 'Food test', source_id: 'TBCA', source_record_id: 'test-1',
  source_version: 'test', quality_status: 'reference_database',
  macros: { kcalPerBasis: 150, proteinGPerBasis: 10, carbsGPerBasis: 20, fatGPerBasis: 5, basisQuantityG: 100 },
  micronutrients: {},
};
assert.equal(validateFoodMacroComposition(baseFood).valid, true);
assert.equal(validateFoodMacroComposition({ ...baseFood, macros: { ...baseFood.macros, basisQuantityG: 0 } }).valid, false);
assert.equal(validateFoodMacroComposition({ ...baseFood, macros: { ...baseFood.macros, kcalPerBasis: Number.NaN } }).valid, false);
assert.equal(validateFoodMacroComposition({ ...baseFood, macros: { ...baseFood.macros, proteinGPerBasis: -1 } }).valid, false);
assert.equal(validateFoodMacroComposition({ ...baseFood, macros: { ...baseFood.macros, proteinGPerBasis: 50, carbsGPerBasis: 50, fatGPerBasis: 20 } }).valid, false, 'mass balance >105g per 100g must be rejected');
assert.equal(validateFoodMacroComposition({ ...baseFood, macros: { ...baseFood.macros, fatGPerBasis: 5, saturatedFatGPerBasis: 6 } }).valid, false, 'saturated fat cannot exceed total fat');
const energyMismatch = validateFoodMacroComposition({ ...baseFood, macros: { ...baseFood.macros, kcalPerBasis: 400 } });
assert.equal(energyMismatch.valid, true, 'Atwater mismatch is a warning, not automatic rejection');
assert.ok(energyMismatch.warnings.length > 0);

const catalog = Object.values(TBCA_FOODS);
const invalidCatalogFoods = catalog.filter((food) => !validateFoodMacroComposition(food).valid);
assert.deepEqual(invalidCatalogFoods.map((food) => food.food_id), ['tbca:BRC1144B'], 'the known TBCA record with 219g carbohydrate per 100g must be quarantined rather than silently corrected');
assert.ok(validateFoodMacroComposition(invalidCatalogFoods[0]).errors.includes('protein_carbohydrate_fat_mass_exceeds_105g_per_100g'));

const invalidFoodId = 'tbca:BRC1144B';
const portionQuality = computePortionsMacrosWithQuality([{ foodId: invalidFoodId, quantityG: 100 }]);
assert.deepEqual(portionQuality.unresolvedFoodIds, [invalidFoodId]);
assert.deepEqual(portionQuality.lowConfidenceFoodIds, [invalidFoodId]);
const recipeSummary = computeRecipeNutrition({
  id: 'invalid-source-test', name: 'Invalid source test', description: '', category: 'almoco',
  baseServings: 1, targetServings: 1, adjustmentMode: 'flexible',
  ingredients: [{ id: 'invalid-ingredient', foodId: invalidFoodId, baseQuantityG: 100, currentQuantityG: 100,
    quantityStatus: 'known', mode: 'flexible', minQuantityG: null, maxQuantityG: null }],
});
assert.deepEqual(recipeSummary.unresolvedFoodIds, [invalidFoodId]);
assert.equal(recipeSummary.coveragePercent, 0, 'invalid composition must not count as quantified mass');
const impact = computeIngredientNutritionImpact({
  id: 'invalid-ingredient', foodId: invalidFoodId, baseQuantityG: 100, currentQuantityG: 100,
  quantityStatus: 'known', mode: 'flexible', minQuantityG: null, maxQuantityG: null,
}, 1);
assert.equal(impact.calculable, false);
assert.ok(impact.reason.includes('Composição nutricional inconsistente'));
const dayPlan = { dateKey: '2026-11-25', slots: [{ id: 'slot-1', time: '12:00', title: 'Almoço', recipes: [
  { id: 'recipe-invalid', name: 'Receita com fonte inválida', category: 'almoco', baseServings: 1, targetServings: 1,
    adjustmentMode: 'flexible', ingredients: [{ id: 'invalid-ingredient', foodId: invalidFoodId, baseQuantityG: 100,
      currentQuantityG: 100, quantityStatus: 'known', mode: 'flexible', minQuantityG: null, maxQuantityG: null }] },
]}] };
const qpModel = prepareQPModel(dayPlan, { kcal: 500, proteinG: 20, carbsG: 50, fatG: 10 });
assert.equal(qpModel.vars.length, 0, 'QP must not create a decision variable from invalid macro data');
assert.deepEqual(qpModel.beforeSummary.unresolvedFoodIds, [invalidFoodId]);
const proportionalOnlyInvalid = scaleDayPlanProportionallyToMealTargets(dayPlan, {
  kcal: 500, proteinG: 20, carbsG: 50, fatG: 10,
}, [{ slotId: 'slot-1', energySharePercent: 100 }]);
assert.equal(proportionalOnlyInvalid.slots[0].status, 'no_scalable_energy');
assert.equal(proportionalOnlyInvalid.proposedDayPlan.slots[0].recipes[0].ingredients[0].currentQuantityG, 100,
  'an all-invalid meal must not change its ingredient quantity without a valid energy basis');
const mixedDay = structuredClone(dayPlan);
mixedDay.slots[0].recipes[0].ingredients.push({ id: 'valid-ingredient', foodId: 'tbca:BRC0001C',
  baseQuantityG: 100, currentQuantityG: 100, quantityStatus: 'known', mode: 'flexible',
  minQuantityG: null, maxQuantityG: null });
const mixedProportional = scaleDayPlanProportionallyToMealTargets(mixedDay, {
  kcal: 500, proteinG: 20, carbsG: 50, fatG: 10,
}, [{ slotId: 'slot-1', energySharePercent: 100 }]);
assert.equal(mixedProportional.proposedDayPlan.slots[0].recipes[0].ingredients[0].currentQuantityG,
  mixedProportional.proposedDayPlan.slots[0].recipes[0].ingredients[1].currentQuantityG,
  'an unknown ingredient keeps the same scale factor when a valid ingredient provides the meal energy basis');
assert.ok(mixedProportional.slots[0].hasIncompleteNutritionData);
console.log(`food-macro-validation.test.mjs PASS (${catalog.length} TBCA adapter entries checked; 1 quarantined source record)`);
