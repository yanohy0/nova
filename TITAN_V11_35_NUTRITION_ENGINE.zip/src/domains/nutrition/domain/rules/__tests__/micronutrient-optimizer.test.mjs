import assert from 'node:assert/strict';
import { aggregateDailyMicronutrients, buildDailyMicronutrientTargets, normalizeNutrientEntry, resolveFoodById } from '../nutrition-calculator.ts';
import { computeRecipeNutrition, prepareQPModel, buildComposerDayFromMeals } from '../cardapio-composer-engine.ts';
import { buildHighsQPModelLP } from '../../../application/highs-lp-builder.ts';
import { resolveMicronutrientResidualScales } from '../micronutrient-optimization-scales.ts';

const male = buildDailyMicronutrientTargets('adult_male_19_30');
const sodium = male.find((target) => target.nutrientId === 'sodium');
const iron = male.find((target) => target.nutrientId === 'iron');
const vitaminA = male.find((target) => target.nutrientId === 'vitamin_a');
const magnesium = male.find((target) => target.nutrientId === 'magnesium');

assert.equal(sodium?.minimum, 1500);
assert.equal(sodium?.preferredMaximum, 2300, 'CDRR is a preferred ceiling, not a UL');
assert.equal(sodium?.upperLimit, null, 'CDRR must never be re-labelled as a UL');
assert.equal(male.length, 29, 'adult planning includes all 29 reference nutrients represented by this engine');
const choline = male.find((target) => target.nutrientId === 'choline');
const iodine = male.find((target) => target.nutrientId === 'iodine');
const chloride = male.find((target) => target.nutrientId === 'chloride');
const molybdenum = male.find((target) => target.nutrientId === 'molybdenum');
const chromium = male.find((target) => target.nutrientId === 'chromium');
const fluoride = male.find((target) => target.nutrientId === 'fluoride');
assert.deepEqual([choline?.minimum, choline?.upperLimit, choline?.unit], [550, 3500, 'mg']);
assert.deepEqual([iodine?.minimum, iodine?.upperLimit, iodine?.unit], [150, 1100, 'µg']);
assert.deepEqual([chloride?.minimum, chloride?.upperLimit, chloride?.unit], [2300, null, 'mg'], 'chloride has an AI but no established NASEM UL');
assert.deepEqual([molybdenum?.minimum, molybdenum?.upperLimit, molybdenum?.unit], [45, 2000, 'µg']);
assert.deepEqual([chromium?.minimum, chromium?.upperLimit, chromium?.unit], [35, null, 'µg']);
assert.deepEqual([fluoride?.minimum, fluoride?.upperLimit, fluoride?.unit], [4, 10, 'mg']);
assert.equal(iron?.upperLimit, 45);
assert.equal(vitaminA?.upperLimit, null, 'total RAE must not be compared with a preformed-retinol UL');
assert.equal(magnesium?.upperLimit, null, 'food magnesium must not be compared with a supplement-only UL');

const day = buildComposerDayFromMeals('2026-11-25', [{
  id: 'test-meal',
  dateKey: '2026-11-25',
  time: '12:00',
  title: 'Ovo',
  description: '',
  planned_quantity: 140,
  consumed_quantity: 0,
  planned_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 140 }],
  consumed_foods: [],
  status: 'planned',
}]);
const model = prepareQPModel(day, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, {
  micronutrientTargets: male,
});
assert.deepEqual(resolveMicronutrientResidualScales({ minimum: 30, preferredMaximum: 120, upperLimit: 300 }), {
  minimum: 30,
  preferredMaximum: 120,
}, 'lower and upper soft residuals must be normalized independently; UL is feasibility-only');
const independentlyScaledModel = {
  ...model,
  micronutrientConstraints: [{
    nutrientId: 'sodium', unit: 'mg', minimum: 30, minimumKind: 'RDA',
    preferredMaximum: 120, upperLimit: 300, fixedValue: 0,
    coefficients: model.vars.map(() => 1), status: 'applied',
  }],
};
const scaledLp = buildHighsQPModelLP(independentlyScaledModel, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, false).lpText;
assert.match(scaledLp, /1\.7777777778 mlo_0\^2/, 'HiGHS lower-side slack uses the RDA/AI scale');
assert.match(scaledLp, /0\.1111111111 mhi_0\^2/, 'HiGHS upper-side slack uses the preferred-maximum scale, not the minimum or UL');
assert.ok(model.micronutrientConstraints.length === male.length);
assert.ok(model.micronutrientConstraints.some((item) => item.status === 'applied'));
assert.ok(model.micronutrientConstraints.every((item) => item.status !== 'applied' || item.coefficients.length === model.vars.length));
assert.equal(model.micronutrientConstraints.find((item) => item.nutrientId === 'vitamin_c')?.status, 'applied', 'canonical TBCA ovo mexido row supplies a quantified vitamin C value of 0 mg; do not inherit the old mismatched biscuit code’s trace status');

const slotModel = prepareQPModel(day, { kcal: 600, proteinG: 35, carbsG: 60, fatG: 20 }, {
  scopeSlotId: day.slots[0].id,
  micronutrientTargets: male,
});
assert.ok(slotModel.micronutrientConstraints.every((item) => item.status === 'not_applicable_scope'));

const legacyTargets = buildDailyMicronutrientTargets('adult_51_plus');
const legacyModel = prepareQPModel(day, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, {
  micronutrientTargets: legacyTargets,
});
assert.equal(legacyModel.micronutrientConstraints.find((item) => item.nutrientId === 'chromium')?.status, 'no_reference',
  'a broad legacy profile without an AI, RDA, CDRR or UL must not report missing food coverage as a skipped nutrient target');

// NASEM UL age bands must match their actual adult reference groups.
const { DRI_REFERENCE_PROFILES } = await import('../../../data/references/dri-profiles.ts');
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_30.entries.vitamin_d.upperLimit, 100);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_19_30.entries.vitamin_d.upperLimit, 100);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_19_30.entries.choline.referenceValue, 425);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_19_30.entries.chromium.referenceValue, 25);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_19_30.entries.fluoride.referenceValue, 3);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_50.entries.chloride.referenceValue, 2300);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_50.entries.chromium.referenceValue, 35);
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.choline.referenceValue, null, 'sex-specific AI must not be guessed for a legacy profile without sex');
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.iodine.referenceValue, 150);
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.molybdenum.referenceValue, 45);
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.fluoride.referenceValue, null, 'sex-specific AI must not be guessed for a legacy profile without sex');
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.choline.referenceValue, 550);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.vitamin_a.referenceValue, 900);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.magnesium.referenceValue, 420);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.vitamin_b6.referenceValue, 1.7);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_71_plus.entries.vitamin_a.referenceValue, 900);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_71_plus.entries.vitamin_d.referenceValue, 20);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_71_plus.entries.sodium.referenceValue, 1500);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_71_plus.entries.fluoride.referenceValue, 4);
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.chloride.upperLimit ?? null, null, 'chloride must not inherit the sodium UL or a fictitious upper limit');
for (const [profileId, profile] of Object.entries(DRI_REFERENCE_PROFILES)) {
  assert.equal(profile.entries.chloride.upperLimit ?? null, null, `${profileId} chloride must have no invented UL`);
}
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.choline.upperLimit, 3500);
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.fluoride.upperLimit, 10);
for (const [profileId, profile] of Object.entries(DRI_REFERENCE_PROFILES)) {
  assert.equal(Object.keys(profile.entries).length, 29, `${profileId} must define all 29 nutrient references, with null for unsupported sex/age-specific values`);
}
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.chromium.referenceValue, 30);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_70.entries.chromium.referenceValue, 20);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_70.entries.vitamin_a.referenceValue, 700);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_71_plus.entries.vitamin_a.referenceValue, 700);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_71_plus.entries.vitamin_d.referenceValue, 20);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.chloride.referenceValue, 2000);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_71_plus.entries.chloride.referenceValue, 1800);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.sodium.referenceValue, 1500);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_70.entries.sodium.referenceValue, 1500);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_71_plus.entries.sodium.referenceValue, 1500);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_71_plus.entries.sodium.referenceValue, 1500);
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.sodium.referenceValue, 1500, '2019 NASEM sodium AI is 1500 mg for all adults 19+');
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_plus.entries.sodium.referenceValue, 1500, '2019 NASEM sodium AI is 1500 mg for all adult sexes/ages');
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.vitamin_d.referenceValue, null, 'legacy 51+ profile must not guess the vitamin D RDA transition at age 71');
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.magnesium.referenceValue, null, 'legacy 51+ profile must not guess the sex-specific magnesium RDA');
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.calcium.referenceValue, null, 'legacy 51+ profile must not guess the male calcium RDA transition at age 71');
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.vitamin_a.referenceValue, null, 'legacy 51+ profile must not guess the sex-specific vitamin A RDA');
assert.ok(Object.values(DRI_REFERENCE_PROFILES).every((profile) => /1997–2023/.test(profile.systemVersion)), 'reference system must disclose multiple nutrient-specific DRI editions rather than one misleading year');
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.chloride.referenceValue, null, 'ambiguous 51+ compatibility profile must not guess between 51–70 and >70');
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_70.entries.phosphorus.upperLimit, 4000);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_71_plus.entries.phosphorus.upperLimit, 3000);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_plus.entries.phosphorus.upperLimit ?? null, null,
  'the broad 51+ legacy group cannot safely receive a 51–70 or 71+ phosphorus UL');
assert.equal(buildDailyMicronutrientTargets('adult_51_plus').length, 29,
  'legacy 51+ profiles must provide every nutrient entry');
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.phosphorus.referenceValue, 700);
assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.phosphorus.upperLimit ?? null, null);

// The pure TypeScript optimizer must project a flexible ingredient under a feasible hard UL.
const { solveNutritionalBalanceQP } = await import('../cardapio-composer-engine.ts');
const vitaminDHardCap = [{
  nutrientId: 'vitamin_d',
  unit: 'µg',
  minimum: null,
  minimumKind: null,
  preferredMaximum: null,
  upperLimit: 1.3,
  upperLimitScope: 'total_intake',
}];
const projected = solveNutritionalBalanceQP(day, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, {
  micronutrientTargets: vitaminDHardCap,
});
const projectedVitaminD = projected.micronutrientResults.find((item) => item.nutrientId === 'vitamin_d');
assert.equal(projectedVitaminD?.status, 'applied');
assert.equal(projectedVitaminD?.withinUpperLimit, true);
assert.ok(projectedVitaminD?.afterValue !== null && projectedVitaminD.afterValue <= 1.3);
assert.notEqual(projected.certificate, 'approximate', 'an active but feasible UL must be included in the stationarity certificate, not treated as a failed box-only KKT check');


const incompatibleUlModel = prepareQPModel(day, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, {
  micronutrientTargets: [{
    nutrientId: 'vitamin_b9', unit: 'µg DFE', minimum: null, minimumKind: null,
    preferredMaximum: null, upperLimit: 1000, upperLimitUnit: 'µg', upperLimitScope: 'total_intake',
  }],
});
assert.equal(incompatibleUlModel.micronutrientConstraints[0].upperLimit, null,
  'a folic-acid UL expressed in µg cannot constrain a DFE target expressed in µg DFE');
assert.equal(incompatibleUlModel.micronutrientConstraints[0].status, 'no_reference');
const incompatibleUlLp = buildHighsQPModelLP(incompatibleUlModel, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, false).lpText;
assert.doesNotMatch(incompatibleUlLp, /micro_ul_0:/,
  'the QP builder must not emit a hard UL constraint across incompatible nutrient bases');

// Locked portions that already exceed a hard UL must be reported as an infeasible conflict.
const lockedDay = structuredClone(day);
lockedDay.slots[0].recipes[0].ingredients[0].mode = 'locked';
const lockedModel = prepareQPModel(lockedDay, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, {
  micronutrientTargets: [{ ...vitaminDHardCap[0], upperLimit: 1.0 }],
});
assert.equal(lockedModel.micronutrientConstraints[0].status, 'infeasible_upper_limit');
const { buildOptimizationProposalFromSolution, getOptimizationProposalBlockReason } = await import('../cardapio-composer-engine.ts');
const lockedConflictProposal = buildOptimizationProposalFromSolution(
  lockedDay,
  { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 },
  lockedModel,
  [],
  0,
  { solverEngine: 'regression-test' },
);
const lockedConflictVitaminD = lockedConflictProposal.micronutrientResults.find((item) => item.nutrientId === 'vitamin_d');
assert.equal(lockedConflictVitaminD?.status, 'infeasible_upper_limit');
assert.ok(lockedConflictVitaminD?.beforeValue !== null && lockedConflictVitaminD.beforeValue > 1.0,
  'complete data must remain visible when a locked portion exceeds the UL');
assert.ok(lockedConflictVitaminD?.afterValue !== null && lockedConflictVitaminD.afterValue > 1.0);
assert.equal(lockedConflictVitaminD?.withinUpperLimit, false);
assert.match(getOptimizationProposalBlockReason(lockedConflictProposal) ?? '', /limite superior/i,
  'a proposal violating an applicable UL must be blocked at domain level');
assert.equal(getOptimizationProposalBlockReason(projected), null, 'a proposal within every applicable UL remains applicable');

// Units must match the actual DRI quantity, not merely the nutrient name.
const niacinTarget = male.find((target) => target.nutrientId === 'vitamin_b3');
const folateTarget = male.find((target) => target.nutrientId === 'vitamin_b9');
assert.equal(niacinTarget?.unit, 'mg NE', 'DRI niacin is expressed as niacin equivalents');
assert.equal(folateTarget?.unit, 'µg DFE', 'DRI folate is expressed as dietary folate equivalents');
assert.equal(male.every((target) => target.unit.length > 0), true);
const { MICRONUTRIENT_CHEMISTRY } = await import('../../../data/chemistry/micronutrient-chemistry.ts');
assert.equal(Object.keys(MICRONUTRIENT_CHEMISTRY).length, 29);

const { TBCA_FOODS } = await import('../../../data/sources/tbca-adapter.ts');
const { OPEN_FOOD_FACTS_PRODUCTS } = await import('../../../data/sources/open-food-facts-adapter.ts');
for (const nutrientId of ['choline', 'iodine', 'chloride', 'molybdenum', 'chromium', 'fluoride']) {
  const tbcaQuantified = Object.values(TBCA_FOODS).filter((food) =>
    food.micronutrients?.[nutrientId]?.data_status === 'quantified' && food.micronutrients[nutrientId]?.normalized_value !== null,
  );
  const offQuantified = Object.values(OPEN_FOOD_FACTS_PRODUCTS).filter((food) =>
    food.micronutrients?.[nutrientId]?.data_status === 'quantified' && food.micronutrients[nutrientId]?.normalized_value !== null,
  );
  assert.equal(tbcaQuantified.length, 0, `${nutrientId}: current TBCA adapter has no quantified values; keep the gap visible`);
  assert.equal(offQuantified.length, 0, `${nutrientId}: current OFF adapter has no quantified values; keep the gap visible`);
}

// Exact preparation-state records remain distinct; do not invent a generic raw-to-cooked factor.
const rawBanana = TBCA_FOODS['tbca:BRC0275C'];
const cookedBanana = TBCA_FOODS['tbca:BRC0192C'];
assert.equal(rawBanana?.state, 'cru');
assert.equal(cookedBanana?.state, 'cozido');
assert.notEqual(rawBanana?.food_id, cookedBanana?.food_id);
for (const target of male) {
  assert.equal(MICRONUTRIENT_CHEMISTRY[target.nutrientId]?.canonicalUnit, target.unit, `${target.nutrientId} chemistry unit must match DRI unit`);
}
const eggSingleRecipe = computeRecipeNutrition({
  id: 'single-source-dri-unit', name: 'Unidade incompatível', category: 'cafe',
  baseServings: 1, targetServings: 1, adjustmentMode: 'balanced',
  ingredients: [{ id: 'egg', foodId: 'tbca-ovo-mexido', displayName: 'Ovo', baseQuantityG: 100, currentQuantityG: 100, quantityStatus: 'known', mode: 'flexible' }],
});
assert.equal(eggSingleRecipe.micronutrients.vitamin_b3.value, null, 'preformed niacin cannot be displayed as niacin equivalents');
assert.equal(eggSingleRecipe.micronutrients.vitamin_b3.dataStatus, 'unit_mismatch');
assert.equal(eggSingleRecipe.micronutrients.vitamin_b9.value, 34.8, 'canonical TBCA ovo mexido reports folate directly in µg DFE');
assert.equal(eggSingleRecipe.micronutrients.vitamin_b9.dataStatus, 'quantified');

const consumedEggDay = [{
  id: 'consumed-egg', dateKey: '2026-11-25', time: '12:00', title: 'Ovo', description: '',
  planned_quantity: 140, consumed_quantity: 140,
  planned_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 140 }],
  consumed_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 140 }], status: 'consumed',
}];
const eggMicros = aggregateDailyMicronutrients(consumedEggDay, '2026-11-25', 'adult_male_19_30');
assert.equal(eggMicros.vitamin_b3.consumedValue, null, 'preformed niacin alone cannot satisfy total niacin equivalents');
assert.equal(eggMicros.vitamin_b3.dataStatus, 'unit_mismatch');
assert.equal(eggMicros.vitamin_b9.consumedValue, 48.72, '140 g of canonical ovo mexido contributes 48.72 µg DFE');
assert.equal(eggMicros.vitamin_b9.dataStatus, 'quantified');

const exactUnitModel = prepareQPModel(day, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, {
  micronutrientTargets: [niacinTarget, folateTarget].filter(Boolean),
});
assert.equal(exactUnitModel.micronutrientConstraints.find((item) => item.nutrientId === 'vitamin_b3')?.status, 'insufficient_data');
assert.match(exactUnitModel.micronutrientConstraints.find((item) => item.nutrientId === 'vitamin_b3')?.reason ?? '', /unidade DRI/i);
assert.equal(exactUnitModel.micronutrientConstraints.find((item) => item.nutrientId === 'vitamin_b9')?.status, 'applied', 'canonical egg folate already uses the DRI unit µg DFE');

// Canonical egg and avocado records both use µg DFE; compatible values can be summed.
const mixedFolateRecipe = computeRecipeNutrition({
  id: 'mixed-folate-units', name: 'Fontes com unidades diferentes', category: 'almoco',
  baseServings: 1, targetServings: 1, adjustmentMode: 'balanced',
  ingredients: [
    { id: 'egg-folate', foodId: 'tbca-ovo-mexido', displayName: 'Ovo', baseQuantityG: 100, currentQuantityG: 100, quantityStatus: 'known', mode: 'flexible' },
    { id: 'avocado-folate', foodId: 'tbca:BRC0001C', displayName: 'Abacate', baseQuantityG: 100, currentQuantityG: 100, quantityStatus: 'known', mode: 'flexible' },
  ],
});
assert.equal(mixedFolateRecipe.micronutrients.vitamin_b9.value, 76.3, 'canonical egg and avocado folate values are both expressed in µg DFE');
assert.equal(mixedFolateRecipe.micronutrients.vitamin_b9.dataStatus, 'quantified');
assert.equal(mixedFolateRecipe.micronutrients.vitamin_k.value, null, 'one food without a vitamin K measurement makes the recipe total incomplete');
assert.equal(mixedFolateRecipe.micronutrients.vitamin_k.dataStatus, 'not_analyzed');

const mixedUnitDay = [{
  id: 'mixed-folate-day', dateKey: '2026-11-25', time: '12:00', title: 'Fontes mistas', description: '',
  planned_quantity: 200, consumed_quantity: 200,
  planned_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 100 }, { foodId: 'tbca:BRC0001C', quantityG: 100 }],
  consumed_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 100 }, { foodId: 'tbca:BRC0001C', quantityG: 100 }], status: 'consumed',
}];
const mixedDayMicros = aggregateDailyMicronutrients(mixedUnitDay, '2026-11-25', 'adult_male_19_30');
assert.equal(mixedDayMicros.vitamin_b9.consumedValue, 76.3, 'compatible µg DFE values are summed in the daily ledger');
assert.equal(mixedDayMicros.vitamin_b9.dataStatus, 'quantified');
assert.equal(mixedDayMicros.vitamin_k.consumedValue, null, 'a quantified egg and an unanalyzed avocado cannot be summed into a complete daily total');
assert.equal(mixedDayMicros.vitamin_k.dataStatus, 'not_analyzed');

// Six added adult DRI references have no compatible value in the current TBCA adapter.
// They must remain unknown, not zero, and cannot enter the optimizer until source coverage exists.
for (const nutrientId of ['choline', 'iodine', 'chloride', 'molybdenum', 'chromium', 'fluoride']) {
  assert.equal(mixedDayMicros[nutrientId].consumedValue, null, `${nutrientId} must not be fabricated as zero`);
  assert.equal(mixedDayMicros[nutrientId].dataStatus, 'not_analyzed', `${nutrientId} must remain visibly not analyzed`);
}

const unknownFoodDay = [{
  id: 'unknown-food-day', dateKey: '2026-11-25', time: '12:00', title: 'Alimento não resolvido', description: '',
  planned_quantity: 240, consumed_quantity: 240,
  planned_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 140 }, { foodId: 'food-id-not-in-catalog', quantityG: 100 }],
  consumed_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 140 }, { foodId: 'food-id-not-in-catalog', quantityG: 100 }], status: 'consumed',
}];
const unknownFoodMicros = aggregateDailyMicronutrients(unknownFoodDay, '2026-11-25', 'adult_male_19_30');
assert.equal(unknownFoodMicros.vitamin_d.consumedValue, null, 'an unresolved food cannot be silently excluded from a complete daily total');
assert.equal(unknownFoodMicros.vitamin_d.dataStatus, 'missing');


// HiGHS model must encode soft DRI slacks separately from hard total-intake UL constraints.
const highsTargets = [{
  nutrientId: 'vitamin_d', unit: 'µg', minimum: 0.5, minimumKind: 'RDA',
  preferredMaximum: 1.0, upperLimit: 1.3, upperLimitScope: 'total_intake',
}];
const highsModel = prepareQPModel(day, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, { micronutrientTargets: highsTargets });
const highsLp = buildHighsQPModelLP(highsModel, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, false).lpText;
assert.match(highsLp, /micro_min_0:/, 'RDA lower target must be a soft minimum with slack');
assert.match(highsLp, /micro_preferred_0:/, 'CDRR-style preference must be a soft ceiling with slack');
assert.match(highsLp, /micro_ul_0:/, 'true UL must be a hard upper inequality');
assert.match(highsLp, /0 <= mlo_0/);
assert.match(highsLp, /0 <= mhi_0/);
const excludedLp = buildHighsQPModelLP(exactUnitModel, { kcal: 2200, proteinG: 140, carbsG: 240, fatG: 70 }, false).lpText;
assert.doesNotMatch(excludedLp, /micro_(min|preferred|ul)_0:/i, 'the unit-incompatible niacin source must not enter the solver constraints');
assert.match(excludedLp, /micro_min_1:/, 'the newly corrected egg folate value is already in µg DFE and can enter the solver constraints');

// A source marked quantified must still pass numeric and per-basis validation.
const validEggSource = resolveFoodById('tbca-ovo-mexido');
const negativeNutrientFood = {
  ...validEggSource,
  micronutrients: {
    ...validEggSource.micronutrients,
    vitamin_c: {
      ...validEggSource.micronutrients.vitamin_c,
      original_value: -1,
      normalized_value: -1,
      data_status: 'quantified',
    },
  },
};
assert.equal(normalizeNutrientEntry(negativeNutrientFood, 'vitamin_c').data_status, 'invalid_value',
  'negative nutrient source values must never be treated as quantified intake');
const invalidBasisFood = {
  ...validEggSource,
  micronutrients: {
    ...validEggSource.micronutrients,
    vitamin_c: {
      ...validEggSource.micronutrients.vitamin_c,
      original_value: 1,
      normalized_value: 1,
      basis_quantity: 0,
      data_status: 'quantified',
    },
  },
};
assert.equal(normalizeNutrientEntry(invalidBasisFood, 'vitamin_c').data_status, 'invalid_value',
  'non-positive nutrient basis must invalidate the record');

console.log('micronutrient-optimizer tests passed');
