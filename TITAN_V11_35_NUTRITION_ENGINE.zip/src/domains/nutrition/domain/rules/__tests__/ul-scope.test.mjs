import assert from 'node:assert/strict';
import { resolveNutrientDisplay, resolveReferenceProfile } from '../nutrition-calculator.ts';

const profile = resolveReferenceProfile('adult_male_19_50');
const quantifiedFoodExposure = {
  nutrientId: 'magnesium', consumedValue: 300, unit: 'mg', dataStatus: 'quantified',
  contributions: [], hasUnquantifiedSources: false,
};
const supplementOnlyReference = {
  nutrientId: 'magnesium', referenceValue: 420, unit: 'mg', kind: 'RDA',
  upperLimit: 350, upperLimitScope: 'supplements_only',
};
const supplementLimitDisplay = resolveNutrientDisplay(quantifiedFoodExposure, supplementOnlyReference, profile);
assert.equal(supplementLimitDisplay.limitValue, null,
  'supplement-only magnesium UL cannot be evaluated against food-only intake');
assert.equal(supplementLimitDisplay.isLimitExceeded, false);
assert.equal(supplementLimitDisplay.limitKind, null);

const preformedOnlyReference = {
  nutrientId: 'vitamin_a', referenceValue: 900, unit: 'µg RAE', kind: 'RDA',
  upperLimit: 3000, upperLimitScope: 'preformed_only',
};
const vitaminAFoodExposure = { ...quantifiedFoodExposure, nutrientId: 'vitamin_a', unit: 'µg RAE', consumedValue: 2500 };
const preformedDisplay = resolveNutrientDisplay(vitaminAFoodExposure, preformedOnlyReference, profile);
assert.equal(preformedDisplay.limitValue, null,
  'preformed retinol UL cannot be compared with an undifferentiated vitamin A RAE total');
const totalIntakeDisplay = resolveNutrientDisplay(quantifiedFoodExposure, { ...supplementOnlyReference, upperLimit: 400, upperLimitScope: 'total_intake' }, profile);
assert.equal(totalIntakeDisplay.limitValue, 400, 'total-intake UL remains visible as a food exposure floor');
console.log('UL source-scope tests passed.');

const adult = resolveReferenceProfile('adult_male_19_50');
assert.equal(adult.entries.magnesium.upperLimit, 350);
assert.equal(adult.entries.magnesium.upperLimitScope, 'supplements_and_medications');
assert.equal(adult.entries.vitamin_a.upperLimit, 3000);
assert.equal(adult.entries.vitamin_a.upperLimitScope, 'preformed_only');
assert.equal(adult.entries.vitamin_b9.upperLimit, 1000);
assert.equal(adult.entries.vitamin_b9.upperLimitUnit, 'µg');
assert.equal(adult.entries.vitamin_b9.unit, 'µg DFE', 'folic-acid UL must not inherit the DFE unit');
assert.equal(adult.entries.vitamin_b3.upperLimit, 35);
assert.equal(adult.entries.vitamin_b3.upperLimitUnit, 'mg');
assert.equal(adult.entries.vitamin_e.upperLimit, 1000);
assert.equal(adult.entries.vitamin_e.upperLimitScope, 'supplements_and_fortified_foods');
const magnesiumSupplementReference = adult.entries.magnesium;
const magnesiumFoodDisplay = resolveNutrientDisplay(quantifiedFoodExposure, magnesiumSupplementReference, profile);
assert.equal(magnesiumFoodDisplay.limitValue, null, 'supplement/medication magnesium UL cannot be evaluated against food-only intake');
