/** Independent residual scales for the two soft sides of a micronutrient target. */
export interface MicronutrientResidualBounds {
  minimum: number | null;
  preferredMaximum: number | null;
  upperLimit?: number | null;
}

function positiveScale(value: number | null | undefined): number {
  return typeof value === 'number' && Number.isFinite(value) && value > 1 ? value : 1;
}

/**
 * RDA/AI shortfall and CDRR/preferred-ceiling excess are separate residuals.
 * A hard UL is feasibility-only and must never distort either soft objective weight.
 */
export function resolveMicronutrientResidualScales(
  bounds: MicronutrientResidualBounds,
): { minimum: number; preferredMaximum: number } {
  return {
    minimum: positiveScale(bounds.minimum),
    preferredMaximum: positiveScale(bounds.preferredMaximum),
  };
}
