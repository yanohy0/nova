import { validateFoodMacroComposition } from './food-data-quality.ts';
import type {
  FoodSourceItem,
  FoodMacroComposition,
  FoodNutrientRecord,
  NutrientId,
} from '../entities/nutrient.ts';

export const FOOD_PREPARATION_RETENTION_V1 = 'explicit-food-method-retention-v1';

type MacroName = 'kcal' | 'proteinG' | 'carbsG' | 'fatG';
type OptionalMacroName = 'fiberG' | 'saturatedFatG' | 'cholesterolMg' | 'sodiumMg';
type MacroRetentionFactors = Record<MacroName, number> & Partial<Record<OptionalMacroName, number>>;

export interface FoodPreparationRetentionProvenance {
  sourceName: string;
  sourceVersion: string;
  referenceUrl: string;
  retentionCode: string;
  yieldReference: string;
  retentionMethod: 'true_retention' | 'apparent_retention';
}

export interface FoodPreparationFactorEvidence {
  sourceName: string;
  sourceVersion: string;
  sourceFoodId: string;
  sourceState: string;
  preparedState: string;
  preparation: string;
  referenceUrl: string;
  retentionCode: string;
  retentionMethod: 'true_retention' | 'apparent_retention';
}

export interface FoodPreparationTransform {
  id: string;
  sourceFoodId: string;
  sourceState: string;
  preparedFoodId: string;
  preparedFoodName: string;
  preparedState: string;
  preparation: string;
  /** Cooked/prepared mass divided by raw/starting mass as a ratio (not a percentage). */
  weightYieldFactor: number;
  /** Retention values are ratios, not percentages; missing factors invalidate required macro conversion. */
  macroRetentionFactors: Partial<MacroRetentionFactors>;
  /** Evidence must be specific to macro factors; USDA micronutrient retention tables are not macro evidence. */
  macroRetentionEvidence: FoodPreparationFactorEvidence;
  /** Nutrient-specific retention; missing factors intentionally produce not_analyzed. */
  micronutrientRetentionFactors: Partial<Record<NutrientId, number>>;
  micronutrientRetentionEvidence: Partial<Record<NutrientId, FoodPreparationFactorEvidence>>;
  provenance: FoodPreparationRetentionProvenance;
}

export interface PreparedFoodCompositionResult {
  status: 'derived' | 'invalid_input';
  food: (FoodSourceItem & {
    preparation_conversion: {
      method: typeof FOOD_PREPARATION_RETENTION_V1;
      sourceFoodId: string;
      startingWeightG: number;
      preparedWeightG: number;
      yieldFactor: number;
      provenance: FoodPreparationRetentionProvenance;
      macroRetentionEvidence: FoodPreparationFactorEvidence;
      micronutrientRetentionEvidence: Partial<Record<NutrientId, FoodPreparationFactorEvidence>>;
      warnings: string[];
    };
  }) | null;
  preparedWeightG: number | null;
  reasons: string[];
}

function isFiniteNonNegative(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0;
}

function isValidRetentionFactor(
  value: unknown,
  method: FoodPreparationRetentionProvenance['retentionMethod'],
): value is number {
  if (!isFiniteNonNegative(value) || value > 2) return false;
  return method === 'apparent_retention' || value <= 1;
}

function invalidResult(reason: string): PreparedFoodCompositionResult {
  return { status: 'invalid_input', food: null, preparedWeightG: null, reasons: [reason] };
}

function hasFactorEvidence(evidence: FoodPreparationFactorEvidence | undefined): evidence is FoodPreparationFactorEvidence {
  return Boolean(evidence &&
    typeof evidence.sourceName === 'string' && evidence.sourceName.trim() &&
    typeof evidence.sourceVersion === 'string' && evidence.sourceVersion.trim() &&
    typeof evidence.sourceFoodId === 'string' && evidence.sourceFoodId.trim() &&
    typeof evidence.sourceState === 'string' && evidence.sourceState.trim() &&
    typeof evidence.preparedState === 'string' && evidence.preparedState.trim() &&
    typeof evidence.preparation === 'string' && evidence.preparation.trim() &&
    typeof evidence.referenceUrl === 'string' && /^https?:\/\//i.test(evidence.referenceUrl) &&
    typeof evidence.retentionCode === 'string' && evidence.retentionCode.trim() &&
    ['true_retention', 'apparent_retention'].includes(evidence.retentionMethod));
}

function matchesTransformEvidence(
  evidence: FoodPreparationFactorEvidence | undefined,
  transform: FoodPreparationTransform,
): evidence is FoodPreparationFactorEvidence {
  return hasFactorEvidence(evidence) &&
    evidence.sourceFoodId === transform.sourceFoodId &&
    evidence.sourceState === transform.sourceState &&
    evidence.preparedState === transform.preparedState &&
    evidence.preparation === transform.preparation;
}

function derivePer100g(valuePerBasis: number, basisQuantityG: number, inputWeightG: number, retention: number, preparedWeightG: number): number {
  const retainedTotal = (valuePerBasis / basisQuantityG) * inputWeightG * retention;
  return (retainedTotal / preparedWeightG) * 100;
}

/**
 * Derives a prepared-food composition only from explicit mass-yield and nutrient-retention evidence.
 * It does not apply a generic raw-to-cooked factor and does not fill missing nutrient factors.
 */
export function derivePreparedFoodComposition(
  rawFood: FoodSourceItem,
  startingWeightG: number,
  transform: FoodPreparationTransform,
): PreparedFoodCompositionResult {
  if (!rawFood || !rawFood.macros || !rawFood.micronutrients || !transform ||
      !transform.macroRetentionFactors || !transform.micronutrientRetentionFactors ||
      !transform.micronutrientRetentionEvidence || !transform.provenance) {
    return invalidResult('Alimento original ou configuração de preparo incompleta.');
  }
  const rawMacroQuality = validateFoodMacroComposition(rawFood);
  if (!rawMacroQuality.valid) {
    return invalidResult(`Composição original inválida: ${rawMacroQuality.errors.join(', ')}.`);
  }
  if (!Number.isFinite(startingWeightG) || startingWeightG <= 0) {
    return invalidResult('A massa inicial deve ser finita e maior que zero.');
  }
  if (!Number.isFinite(rawFood.macros.basisQuantityG) || rawFood.macros.basisQuantityG <= 0) {
    return invalidResult('A base de massa da composição original é inválida.');
  }
  if (!Number.isFinite(transform.weightYieldFactor) || transform.weightYieldFactor <= 0 || transform.weightYieldFactor > 5) {
    return invalidResult('O fator de rendimento deve ser explícito, finito e maior que zero.');
  }
  if (!transform.id.trim() || !transform.preparedFoodId.trim() || !transform.preparedFoodName.trim() ||
      !transform.preparedState.trim() || !transform.preparation.trim()) {
    return invalidResult('A identidade do alimento preparado, o estado e o método de preparo são obrigatórios.');
  }
  if (!transform.sourceFoodId.trim() || !transform.sourceState.trim() ||
      rawFood.food_id !== transform.sourceFoodId || (rawFood.state ?? '') !== transform.sourceState) {
    return invalidResult('A regra de rendimento/retenção não corresponde ao ID e ao estado exatos do alimento original.');
  }
  if (!transform.provenance.sourceName.trim() || !transform.provenance.sourceVersion.trim() ||
      !/^https?:\/\//i.test(transform.provenance.referenceUrl) || !transform.provenance.retentionCode.trim() ||
      !transform.provenance.yieldReference.trim() ||
      !['true_retention', 'apparent_retention'].includes(transform.provenance.retentionMethod)) {
    return invalidResult('A proveniência do mapa de preparo e do rendimento deve identificar fonte, versão, código e referência.');
  }
  if (!matchesTransformEvidence(transform.macroRetentionEvidence, transform)) {
    return invalidResult('Os fatores de kcal/proteína/carboidratos/gordura exigem fonte, versão, referência e código de evidência próprios.');
  }
  if (transform.macroRetentionEvidence.retentionMethod !== transform.provenance.retentionMethod) {
    return invalidResult('O método de retenção dos macronutrientes não corresponde ao método declarado no mapa.');
  }
  const macroKeys: MacroName[] = ['kcal', 'proteinG', 'carbsG', 'fatG'];
  for (const key of macroKeys) {
    const factor = transform.macroRetentionFactors[key];
    if (!isValidRetentionFactor(factor, transform.macroRetentionEvidence.retentionMethod)) {
      return invalidResult(`Fator de retenção ausente ou inválido para ${key}.`);
    }
  }
  for (const [key, factor] of Object.entries(transform.macroRetentionFactors)) {
    if (!isValidRetentionFactor(factor, transform.macroRetentionEvidence.retentionMethod)) {
      return invalidResult(`Fator de retenção inválido para ${key}.`);
    }
  }
  for (const [nutrientId, factor] of Object.entries(transform.micronutrientRetentionFactors)) {
    if (!isFiniteNonNegative(factor)) {
      return invalidResult(`Fator de retenção inválido para ${nutrientId}.`);
    }
    const evidence = transform.micronutrientRetentionEvidence[nutrientId as NutrientId];
    if (hasFactorEvidence(evidence) && evidence.retentionMethod === transform.provenance.retentionMethod &&
        !isValidRetentionFactor(factor, evidence.retentionMethod)) {
      return invalidResult(`Fator de retenção incompatível com a evidência para ${nutrientId}.`);
    }
  }
  const macroValues = [
    rawFood.macros.kcalPerBasis,
    rawFood.macros.proteinGPerBasis,
    rawFood.macros.carbsGPerBasis,
    rawFood.macros.fatGPerBasis,
  ];
  if (macroValues.some((value) => !isFiniteNonNegative(value))) {
    return invalidResult('A composição de macronutrientes original contém valores inválidos.');
  }

  const preparedWeightG = startingWeightG * transform.weightYieldFactor;
  if (!Number.isFinite(preparedWeightG) || preparedWeightG <= 0) {
    return invalidResult('O rendimento gerou uma massa preparada inválida.');
  }
  const macroFactor = transform.macroRetentionFactors;
  const macroComposition: FoodMacroComposition = {
    kcalPerBasis: derivePer100g(rawFood.macros.kcalPerBasis, rawFood.macros.basisQuantityG, startingWeightG, macroFactor.kcal!, preparedWeightG),
    proteinGPerBasis: derivePer100g(rawFood.macros.proteinGPerBasis, rawFood.macros.basisQuantityG, startingWeightG, macroFactor.proteinG!, preparedWeightG),
    carbsGPerBasis: derivePer100g(rawFood.macros.carbsGPerBasis, rawFood.macros.basisQuantityG, startingWeightG, macroFactor.carbsG!, preparedWeightG),
    fatGPerBasis: derivePer100g(rawFood.macros.fatGPerBasis, rawFood.macros.basisQuantityG, startingWeightG, macroFactor.fatG!, preparedWeightG),
    basisQuantityG: 100,
  };
  const optionalMacroKeys: Array<{
    source: OptionalMacroName;
    target: 'fiberGPerBasis' | 'saturatedFatGPerBasis' | 'cholesterolMgPerBasis' | 'sodiumMgPerBasis';
  }> = [
    { source: 'fiberG', target: 'fiberGPerBasis' },
    { source: 'saturatedFatG', target: 'saturatedFatGPerBasis' },
    { source: 'cholesterolMg', target: 'cholesterolMgPerBasis' },
    { source: 'sodiumMg', target: 'sodiumMgPerBasis' },
  ];
  const optionalMacroWarnings: string[] = [];
  for (const { source, target } of optionalMacroKeys) {
    const rawValue = rawFood.macros[
      source === 'fiberG' ? 'fiberGPerBasis' :
        source === 'saturatedFatG' ? 'saturatedFatGPerBasis' :
          source === 'cholesterolMg' ? 'cholesterolMgPerBasis' : 'sodiumMgPerBasis'
    ];
    if (rawValue === undefined) continue;
    const factor = macroFactor[source];
    if (!isFiniteNonNegative(rawValue) || factor === undefined) {
      macroComposition[target] = null;
      optionalMacroWarnings.push(`${source}: ausente fator explícito; composição preparada não calculada.`);
      continue;
    }
    macroComposition[target] = derivePer100g(rawValue, rawFood.macros.basisQuantityG, startingWeightG, factor, preparedWeightG);
  }

  const micronutrients: FoodSourceItem['micronutrients'] = {};
  for (const [id, nutrient] of Object.entries(rawFood.micronutrients) as [NutrientId, FoodSourceItem['micronutrients'][NutrientId]][]) {
    if (!nutrient) continue;
    const factor = transform.micronutrientRetentionFactors[id];
    const factorEvidence = transform.micronutrientRetentionEvidence[id];
    const hasMatchingFactorEvidence = matchesTransformEvidence(factorEvidence, transform) && factorEvidence.retentionMethod === transform.provenance.retentionMethod;
    const normalized = nutrient.normalized_value;
    const quantifiedButInvalid = nutrient.data_status === 'quantified' && (
      !isFiniteNonNegative(normalized) || !isFiniteNonNegative(nutrient.basis_quantity) || nutrient.basis_quantity <= 0 ||
      typeof nutrient.normalized_unit !== 'string' || nutrient.normalized_unit.trim().length === 0
    );
    const canTransform = nutrient.data_status === 'quantified' && !quantifiedButInvalid &&
      isFiniteNonNegative(normalized) && isFiniteNonNegative(nutrient.basis_quantity) && nutrient.basis_quantity > 0 &&
      typeof nutrient.normalized_unit === 'string' && nutrient.normalized_unit.trim().length > 0 &&
      hasMatchingFactorEvidence && isValidRetentionFactor(factor, factorEvidence.retentionMethod);
    const next: FoodSourceItem['micronutrients'][NutrientId] = {
      ...nutrient,
      basis_quantity: 100,
      normalized_value: canTransform
        ? derivePer100g(normalized!, nutrient.basis_quantity, startingWeightG, factor!, preparedWeightG)
        : null,
      data_status: canTransform ? 'quantified' : quantifiedButInvalid ? 'invalid_value' :
        nutrient.data_status === 'invalid_value' ? 'invalid_value' :
          nutrient.data_status === 'unit_mismatch' ? 'unit_mismatch' :
            nutrient.data_status === 'trace' ? 'trace' :
              nutrient.data_status === 'missing' ? 'missing' : 'not_analyzed',
      conversion_method: canTransform ? 'preparation_retention' : 'unavailable',
    };
    micronutrients[id] = next;
  }

  const food = {
    ...rawFood,
    food_id: transform.preparedFoodId,
    name: transform.preparedFoodName,
    source_record_id: `derived:${rawFood.source_record_id}:${transform.id}`,
    source_version: `${rawFood.source_version}|${transform.provenance.sourceVersion}|${transform.id}`,
    state: transform.preparedState,
    preparation: transform.preparation,
    macros: macroComposition,
    micronutrients,
    preparation_conversion: {
      method: FOOD_PREPARATION_RETENTION_V1,
      sourceFoodId: rawFood.food_id,
      startingWeightG,
      preparedWeightG,
      yieldFactor: transform.weightYieldFactor,
      provenance: { ...transform.provenance },
      macroRetentionEvidence: { ...transform.macroRetentionEvidence },
      micronutrientRetentionEvidence: Object.fromEntries(
        Object.entries(transform.micronutrientRetentionEvidence).map(([id, evidence]) => [id, { ...evidence }]),
      ),
      warnings: [],
    },
  };
  const preparedMacroQuality = validateFoodMacroComposition(food);
  if (!preparedMacroQuality.valid) {
    return invalidResult(`Composição preparada inválida: ${preparedMacroQuality.errors.join(', ')}.`);
  }

  const warnings = [
    ...rawMacroQuality.warnings,
    ...preparedMacroQuality.warnings,
    ...optionalMacroWarnings,
    ...Object.keys(transform.micronutrientRetentionFactors)
      .filter((nutrientId) => !matchesTransformEvidence(transform.micronutrientRetentionEvidence[nutrientId as NutrientId], transform))
      .map((nutrientId) => `${nutrientId}: fator informado sem evidência de fonte/código; nutriente mantido como não analisado.`),
    ...Object.entries(transform.macroRetentionFactors)
      .filter(([, factor]) => typeof factor === 'number' && factor > 1)
      .map(([macro]) => `${macro}: fator de retenção acima de 100%; revisar método e referência antes de uso produtivo.`),
    ...Object.entries(transform.micronutrientRetentionFactors)
    .filter(([, factor]) => typeof factor === 'number' && factor > 1)
    .map(([nutrientId]) => `${nutrientId}: fator de retenção acima de 100%; revisar método e referência antes de uso produtivo.`),
  ];

  food.preparation_conversion.warnings = warnings;

  return { status: 'derived', food, preparedWeightG, reasons: warnings };
}
