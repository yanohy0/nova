import { useMemo, useState } from 'react';
import { MICRONUTRIENT_ORDER, type NutrientId } from '../domain/entities/nutrient';
import { aggregateSupplementMicronutrientExposure, getAllowedSupplementChemicalForms, type SupplementChemicalForm } from '../domain/rules/supplement-intake';
import { resolveReferenceProfile } from '../domain/rules/nutrition-calculator';
import { useNutritionStore } from '../state/nutrition.store';

const NUTRIENT_LABELS: Record<NutrientId, string> = {
  vitamin_a: 'Vitamina A', vitamin_c: 'Vitamina C', vitamin_d: 'Vitamina D', vitamin_e: 'Vitamina E', vitamin_k: 'Vitamina K',
  vitamin_b1: 'Vitamina B1', vitamin_b2: 'Vitamina B2', vitamin_b3: 'Vitamina B3', vitamin_b5: 'Vitamina B5',
  vitamin_b6: 'Vitamina B6', vitamin_b7: 'Vitamina B7', vitamin_b9: 'Vitamina B9', vitamin_b12: 'Vitamina B12',
  calcium: 'Cálcio', copper: 'Cobre', iron: 'Ferro', phosphorus: 'Fósforo', magnesium: 'Magnésio', manganese: 'Manganês',
  potassium: 'Potássio', selenium: 'Selênio', sodium: 'Sódio', zinc: 'Zinco', choline: 'Colina', iodine: 'Iodo',
  chloride: 'Cloreto', molybdenum: 'Molibdênio', chromium: 'Cromo', fluoride: 'Flúor',
};
const FORM_LABELS: Record<SupplementChemicalForm, string> = {
  retinol: 'Retinol', retinyl_acetate: 'Acetato de retinila', retinyl_palmitate: 'Palmitato de retinila',
  beta_carotene: 'Betacaroteno', folic_acid: 'Ácido fólico', methylfolate: 'Metilfolato', food_folate: 'Folato alimentar',
  synthetic_niacin: 'Niacina sintética', nicotinic_acid: 'Ácido nicotínico', niacinamide: 'Nicotinamida',
  synthetic_vitamin_d: 'Vitamina D sintética', natural_alpha_tocopherol: 'Alfa-tocoferol natural',
  synthetic_alpha_tocopherol: 'Alfa-tocoferol sintético', magnesium_salt: 'Sal de magnésio',
  synthetic_form: 'Outra forma sintética', other: 'Outra forma', unspecified: 'Não informado',
};

export function SupplementMicronutrientPanel() {
  const activeDateKey = useNutritionStore((state) => state.activeDateKey);
  const referenceProfileId = useNutritionStore((state) => state.referenceProfileId);
  const entries = useNutritionStore((state) => state.supplementMicronutrientIntakes);
  const addEntry = useNutritionStore((state) => state.addSupplementMicronutrientIntake);
  const removeEntry = useNutritionStore((state) => state.removeSupplementMicronutrientIntake);
  const [productName, setProductName] = useState('');
  const [nutrientId, setNutrientId] = useState<NutrientId>('magnesium');
  const [amount, setAmount] = useState('');
  const [unit, setUnit] = useState('mg');
  const [chemicalForm, setChemicalForm] = useState<SupplementChemicalForm>('unspecified');
  const [time, setTime] = useState('08:00');
  const [error, setError] = useState<string | null>(null);
  const todayEntries = useMemo(() => entries.filter((entry) => entry.dateKey === activeDateKey)
    .sort((a, b) => a.time.localeCompare(b.time)), [entries, activeDateKey]);
  const allowedForms = useMemo(() => getAllowedSupplementChemicalForms(nutrientId), [nutrientId]);
  const referenceProfile = useMemo(() => resolveReferenceProfile(referenceProfileId), [referenceProfileId]);
  const supplementSummaries = useMemo(() => [...new Set(todayEntries.map((entry) => entry.nutrientId))]
    .map((id) => {
      const reference = referenceProfile.entries[id];
      return aggregateSupplementMicronutrientExposure(
        todayEntries, activeDateKey, id, reference.upperLimitUnit ?? reference.unit, 'supplements_only',
      );
    }), [todayEntries, activeDateKey, referenceProfile]);

  const onAdd = () => {
    const parsedAmount = Number(amount.replace(',', '.'));
    const now = new Date();
    const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto
      ? crypto.randomUUID()
      : `supp-${now.getTime()}-${Math.random().toString(36).slice(2, 9)}`;
    const entry = {
      id, dateKey: activeDateKey, time, productName: productName.trim(), nutrientId,
      amount: parsedAmount, unit, chemicalForm, sourceName: 'Rótulo informado pelo usuário',
      sourceVersion: 'manual-entry-v1', sourceRecordId: id, recordedAt: now.toISOString(),
    };
    if (!addEntry(entry)) {
      setError('Confira produto, quantidade e horário. O limite de registros deste dia pode ter sido atingido.');
      return;
    }
    setProductName('');
    setAmount('');
    setError(null);
  };

  return (
    <section className="rounded-xl border border-[var(--titan-border)] bg-[var(--titan-panel)] p-4 space-y-3" aria-labelledby="supplement-intake-heading">
      <div>
        <h2 id="supplement-intake-heading" className="text-sm font-semibold">Suplementos e medicamentos · micronutrientes</h2>
        <p className="text-xs text-[var(--titan-muted)] mt-1">Registro separado da ingestão alimentar. Formas químicas e unidades são preservadas; dados não informados não viram zero.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2">
        <input className="titan-input lg:col-span-2" value={productName} onChange={(event) => setProductName(event.target.value)} placeholder="Suplemento ou medicamento" aria-label="Suplemento ou medicamento" maxLength={160} />
        <select className="titan-input" value={nutrientId} onChange={(event) => { setNutrientId(event.target.value as NutrientId); setChemicalForm('unspecified'); }} aria-label="Micronutriente">
          {MICRONUTRIENT_ORDER.map((id) => <option key={id} value={id}>{NUTRIENT_LABELS[id]}</option>)}
        </select>
        <input className="titan-input" inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="Quantidade" aria-label="Quantidade" />
        <select className="titan-input" value={unit} onChange={(event) => setUnit(event.target.value)} aria-label="Unidade">
          {['mg', 'µg', 'g', 'IU', 'µg RAE', 'µg DFE', 'mg NE'].map((value) => <option key={value}>{value}</option>)}
        </select>
        <input className="titan-input" type="time" value={time} onChange={(event) => setTime(event.target.value)} aria-label="Horário" />
        <select className="titan-input sm:col-span-2" value={chemicalForm} onChange={(event) => setChemicalForm(event.target.value as SupplementChemicalForm)} aria-label="Forma química">
          {allowedForms.map((form) => <option key={form} value={form}>{FORM_LABELS[form]}</option>)}
        </select>
        <button type="button" onClick={onAdd} className="rounded-lg bg-[var(--titan-accent)] px-3 py-2 text-xs font-semibold text-white">Adicionar registro</button>
      </div>
      {error && <p className="text-xs text-[var(--titan-status-warning)]" role="alert">{error}</p>}
      {supplementSummaries.length > 0 && (
        <div className="rounded-lg border border-[var(--titan-border)] p-3 space-y-2" aria-label="Subtotal de micronutrientes dos suplementos">
          <div>
            <h3 className="text-xs font-semibold">Subtotal registrado em suplementos</h3>
            <p className="text-[11px] text-[var(--titan-muted)]">Não é o total alimentar do dia e não determina, isoladamente, excesso ou segurança frente ao UL.</p>
          </div>
          <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {supplementSummaries.map((summary) => {
              const value = summary.status === 'supplement_component_only' && summary.value !== null
                ? `${summary.value.toLocaleString('pt-BR')} ${summary.unit}`
                : summary.status === 'unit_mismatch'
                  ? 'Unidade não comparável'
                  : summary.status === 'form_unresolved'
                    ? 'Forma química não resolvida'
                    : 'Parcela não quantificável';
              return <li key={summary.nutrientId} className="flex justify-between gap-2 text-xs"><span>{NUTRIENT_LABELS[summary.nutrientId]}</span><strong className="text-right">{value}</strong></li>;
            })}
          </ul>
        </div>
      )}
      {todayEntries.length === 0 ? <p className="text-xs text-[var(--titan-muted)]">Nenhum suplemento registrado nesta data.</p> : (
        <ul className="divide-y divide-[var(--titan-border)]">
          {todayEntries.map((entry) => (
            <li key={entry.id} className="flex items-center justify-between gap-3 py-2 text-xs">
              <span className="min-w-0"><strong>{entry.time} · {entry.productName}</strong><span className="block text-[var(--titan-muted)]">{NUTRIENT_LABELS[entry.nutrientId]}: {entry.amount} {entry.unit} · {FORM_LABELS[entry.chemicalForm]}</span></span>
              <button type="button" onClick={() => removeEntry(entry.id)} className="shrink-0 rounded-md border border-[var(--titan-border)] px-2 py-1">Remover</button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
