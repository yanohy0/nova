import { memo, useMemo } from 'react';
import { formatLocalDateLabel, parseLocalDateKey, shiftLocalDateKey } from '@/src/shared/utils/local-date';
import type { CardapioPlan } from '../../../domain/entities/nutrient';
import { computeDayNutrition } from '../../../domain/rules/cardapio-composer-engine';

interface ComposerDayRailProps {
  plan: CardapioPlan;
  activeDateKey: string;
  onSelectDateKey: (dateKey: string) => void;
}

export const ComposerDayRail = memo(function ComposerDayRail({
  plan,
  activeDateKey,
  onSelectDateKey,
}: ComposerDayRailProps) {
  const days = useMemo(() => {
    const start = plan.startDateKey;
    const keys: string[] = [];
    for (let offset = 0; offset < 7; offset += 1) {
      const shifted = shiftLocalDateKey(start, offset);
      if (shifted) keys.push(shifted);
    }
    if (!keys.includes(activeDateKey)) {
      keys.push(activeDateKey);
      keys.sort();
    }
    return keys.slice(0, 7).map((key) => {
      const descriptor = formatLocalDateLabel(key);
      const parts = parseLocalDateKey(key);
      const [shortWeekday] = descriptor.shortLabel.split(' · ');
      const dayPlan = plan.days[key];
      const kcal = dayPlan ? Math.round(computeDayNutrition(dayPlan).macros.kcal) : 0;
      const ratio = plan.targets.kcal > 0 ? Math.min(100, Math.round((kcal / plan.targets.kcal) * 100)) : 0;
      return {
        key,
        weekday: (shortWeekday ?? 'DIA').toUpperCase(),
        dayNum: parts ? String(parts.day).padStart(2, '0') : '--',
        fullLabel: descriptor.fullLabel,
        kcal,
        ratio,
      };
    });
  }, [activeDateKey, plan.days, plan.startDateKey, plan.targets.kcal]);

  const activeDescriptor = useMemo(() => formatLocalDateLabel(activeDateKey), [activeDateKey]);

  return (
    <section aria-label="Dias do plano" className="space-y-2">
      <div className="flex items-center justify-between gap-2 text-[11px] font-mono-metric text-[var(--titan-text-muted)] uppercase tracking-[0.12em]">
        <span>{activeDescriptor.fullLabel}</span>
        <span>{activeDateKey}</span>
      </div>

      <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
        {days.map((day) => {
          const isSelected = day.key === activeDateKey;
          return (
            <button
              key={day.key}
              type="button"
              onClick={() => onSelectDateKey(day.key)}
              aria-current={isSelected ? 'date' : undefined}
              aria-label={`${day.fullLabel}: ${day.kcal} kcal planejadas`}
              className={`min-h-[54px] flex flex-col items-center justify-between rounded-xl border px-1.5 py-2 transition-colors ${
                isSelected
                  ? 'border-[var(--titan-champagne)]/70 bg-[var(--titan-surface-raised)] text-[var(--titan-text-primary)]'
                  : 'border-[var(--titan-border-subtle)] bg-[var(--titan-surface)] text-[var(--titan-text-secondary)] hover:border-[var(--titan-accent)]/40'
              }`}
            >
              <span className="text-[10px] font-semibold tracking-[0.08em] text-[var(--titan-text-muted)]">
                {day.weekday}
              </span>
              <span className="text-sm sm:text-base font-semibold font-mono-metric leading-none">
                {day.dayNum}
              </span>
              <span
                aria-hidden="true"
                className="w-full h-[2px] rounded-full bg-[var(--titan-surface-inset)] overflow-hidden mt-1"
              >
                <span
                  className={`block h-full ${
                    isSelected ? 'bg-[var(--titan-champagne)]' : 'bg-[var(--titan-accent)]/60'
                  }`}
                  style={{ width: `${day.ratio}%` }}
                />
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
});
