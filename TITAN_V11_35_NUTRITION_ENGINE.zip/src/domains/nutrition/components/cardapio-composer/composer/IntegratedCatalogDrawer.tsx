import { memo, useDeferredValue, useEffect, useMemo, useState } from 'react';
import { Apple, ArrowLeftRight, BookOpen, Plus, Search, X } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import { RECIPE_CATALOG } from '../../../data/recipes/recipe-catalog';
import {
  ensureSharedFoodSearchIndexReady,
  getSharedFoodSearchIndex,
} from '../../../data/sources/food-search-index';
import { evaluateRecipeIngredientEligibility } from '../../../domain/rules/food-ingredient-policy';
import { searchFoodIndex } from '../../../domain/rules/food-search';
import { useSharedFoodSearchVersion } from '../../../application/use-shared-food-search-version.ts';
import { computeRecipeSummary, isEligibleRecipeTemplate } from '../../../domain/rules/recipe-engine';
import { createRecipeSearchEntry, searchRecipeIndex } from '../../../domain/rules/recipe-search';
import type { FoodDiaryMealTitle } from '../../../domain/rules/food-diary';
import type { ComposerMealSlot } from '../../../domain/entities/nutrient';

const RECIPE_INDEX = RECIPE_CATALOG.filter(isEligibleRecipeTemplate).map((recipe) => {
  const summary = computeRecipeSummary(recipe);
  const searchEntry = createRecipeSearchEntry(recipe, [
    recipe.name,
    recipe.description,
    ...recipe.ingredients.map((ingredient) => ingredient.ingredientId),
    ...summary.ingredientNames,
  ]);
  return { ...searchEntry, summary };
});

const DIARY_MEAL_OPTIONS: readonly FoodDiaryMealTitle[] = [
  'Café da manhã',
  'Almoço',
  'Lanche',
  'Jantar',
];

export type CatalogMode = 'none' | 'recipes' | 'foods';

interface IntegratedCatalogDrawerProps {
  mode: Exclude<CatalogMode, 'none'>;
  activeSlot?: ComposerMealSlot;
  activeDateKey: string;
  onChangeMode: (mode: CatalogMode) => void;
  onSwapSlotRecipe: (slotId: string, currentRecipeId: string, catalogRecipeId: string) => void;
  onAddSlotRecipe: (slotId: string, catalogRecipeId: string) => void;
  onAddFoodToSlot: (slotId: string, recipeId: string, foodId: string, quantityG: number) => boolean;
  onLogFoodToDiary: (
    foodId: string,
    quantityG: number,
    mealTitle: FoodDiaryMealTitle,
  ) => { ok: true } | { ok: false; error: string };
}

export const IntegratedCatalogDrawer = memo(function IntegratedCatalogDrawer({
  mode,
  activeSlot,
  activeDateKey,
  onChangeMode,
  onSwapSlotRecipe,
  onAddSlotRecipe,
  onAddFoodToSlot,
  onLogFoodToDiary,
}: IntegratedCatalogDrawerProps) {
  const [recipeQuery, setRecipeQuery] = useState('');
  const [foodQuery, setFoodQuery] = useState('');
  const [foodGrams, setFoodGrams] = useState(100);
  const [diaryMealTitle, setDiaryMealTitle] = useState<FoodDiaryMealTitle>('Lanche');
  const [feedback, setFeedback] = useState<string | null>(null);
  const catalogVersion = useSharedFoodSearchVersion();

  const deferredRecipeQuery = useDeferredValue(recipeQuery);
  const deferredFoodQuery = useDeferredValue(foodQuery);

  useEffect(() => {
    if (mode !== 'foods') return;
    void ensureSharedFoodSearchIndexReady();
  }, [mode]);

  const filteredRecipes = useMemo(() => {
    const matches = new Set(searchRecipeIndex(RECIPE_INDEX, deferredRecipeQuery));
    return RECIPE_INDEX.filter((entry) => matches.has(entry.item));
  }, [deferredRecipeQuery]);

  const foodIndex = useMemo(
    () => (mode === 'foods' ? getSharedFoodSearchIndex() : null),
    [mode, catalogVersion],
  );
  const filteredFoods = useMemo(
    () => (foodIndex ? searchFoodIndex(foodIndex, deferredFoodQuery, 30) : []),
    [deferredFoodQuery, foodIndex],
  );

  const primaryRecipe = activeSlot?.recipes[0];
  const validGrams = Number.isFinite(foodGrams) && foodGrams >= 1 && foodGrams <= 2000;

  return (
    <Surface data-elevation="2" className="p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <div role="tablist" aria-label="Acervo integrado do Composer" className="titan-segmented">
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'recipes'}
              onClick={() => {
                setFeedback(null);
                onChangeMode('recipes');
              }}
              className={`titan-segment !min-h-[36px] !px-3 !text-xs ${mode === 'recipes' ? 'is-active' : ''}`}
            >
              <BookOpen className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Receitas ({RECIPE_INDEX.length})</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'foods'}
              onClick={() => {
                setFeedback(null);
                onChangeMode('foods');
              }}
              className={`titan-segment !min-h-[36px] !px-3 !text-xs ${mode === 'foods' ? 'is-active' : ''}`}
            >
              <Apple className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Alimentos TBCA / OFF</span>
            </button>
          </div>
          {activeSlot && (
            <span className="text-[11px] font-mono-metric text-[var(--titan-champagne)]">
              Alvo: {activeSlot.time} · {activeSlot.title}
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={() => onChangeMode('none')}
          aria-label="Fechar acervo integrado"
          className="min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {feedback && (
        <p className="text-xs text-[var(--titan-champagne)]" role="status">
          {feedback}
        </p>
      )}

      {mode === 'recipes' ? (
        <div className="space-y-3">
          <div className="relative">
            <Search
              className="w-4 h-4 text-[var(--titan-text-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={recipeQuery}
              onChange={(event) => setRecipeQuery(event.target.value)}
              placeholder="Buscar receita ou ingrediente para compor a refeição"
              aria-label="Buscar receita no acervo"
              className="w-full min-h-[44px] pl-9 pr-3 rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] text-sm text-[var(--titan-text-primary)]"
            />
          </div>
          <p className="text-[11px] text-[var(--titan-text-muted)]">
            Apenas modelos cujas linhas correspondem a ingredientes elegíveis. Pratos compostos legados ficam preservados em históricos, mas não entram em novas montagens.
          </p>

          <div className="max-h-72 overflow-y-auto divide-y divide-[var(--titan-border-subtle)] rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)]">
            {filteredRecipes.length === 0 ? (
              <p className="p-4 text-xs text-[var(--titan-text-muted)] text-center">
                Nenhuma receita encontrada.
              </p>
            ) : (
              filteredRecipes.map(({ item: recipe, summary }) => (
                <div
                  key={recipe.id}
                  className="p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-[var(--titan-text-primary)]">
                      {recipe.name}
                    </p>
                    <p className="text-[11px] text-[var(--titan-text-secondary)] truncate">
                      {summary.ingredientNames.join(' · ')}
                    </p>
                    <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] mt-0.5">
                      {Math.round(summary.macros.kcal)} kcal · P {summary.macros.proteinG.toFixed(1)} g ·{' '}
                      {summary.totalGrams.toFixed(0)} g · cobertura {summary.dataCoveragePercent.toFixed(0)}%
                    </p>
                  </div>

                  {activeSlot && (
                    <div className="flex items-center gap-1.5 shrink-0">
                      {primaryRecipe && (
                        <button
                          type="button"
                          onClick={() => {
                            onSwapSlotRecipe(activeSlot.id, primaryRecipe.id, recipe.id);
                            setFeedback(`"${recipe.name}" aplicada em ${activeSlot.title}.`);
                          }}
                          className="titan-button titan-button--primary !min-h-[40px] !px-3 !text-xs"
                        >
                          <ArrowLeftRight className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Usar</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          onAddSlotRecipe(activeSlot.id, recipe.id);
                          setFeedback(`"${recipe.name}" adicionada como acompanhamento em ${activeSlot.title}.`);
                        }}
                        className="titan-button titan-button--secondary !min-h-[40px] !px-3 !text-xs"
                      >
                        <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Acompanhamento</span>
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-[1fr_110px_140px] gap-2.5 items-end">
            <label className="text-xs text-[var(--titan-text-secondary)]">
              Buscar alimento TBCA / OFF ({foodIndex?.length.toLocaleString('pt-BR') ?? 0} itens)
              <div className="relative mt-1">
                <Search
                  className="w-4 h-4 text-[var(--titan-text-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  type="search"
                  value={foodQuery}
                  onChange={(event) => setFoodQuery(event.target.value)}
                  placeholder="Ex.: arroz integral, frango, aveia"
                  className="w-full min-h-[44px] pl-9 pr-3 rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] text-sm text-[var(--titan-text-primary)]"
                />
              </div>
            </label>

            <label className="text-xs text-[var(--titan-text-secondary)]">
              Porção (g)
              <BufferedNumberInput
                min={1}
                max={2000}
                step={5}
                value={foodGrams}
                onCommit={setFoodGrams}
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>

            <label className="text-xs text-[var(--titan-text-secondary)]">
              Avulso ({activeDateKey})
              <select
                value={diaryMealTitle}
                onChange={(event) => setDiaryMealTitle(event.target.value as FoodDiaryMealTitle)}
                className="mt-1 w-full min-h-[44px] rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2.5 text-xs text-[var(--titan-text-primary)]"
              >
                {DIARY_MEAL_OPTIONS.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <p className="text-[11px] text-[var(--titan-text-muted)]">
            Dados sem valor analítico permanecem como não analisados (nunca convertidos em zero).
          </p>

          <div className="max-h-72 overflow-y-auto divide-y divide-[var(--titan-border-subtle)] rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)]">
            {filteredFoods.length === 0 ? (
              <p className="p-4 text-xs text-[var(--titan-text-muted)] text-center">
                Nenhum alimento encontrado.
              </p>
            ) : (
              filteredFoods.map((food) => {
                const ingredientEligibility = evaluateRecipeIngredientEligibility(food);
                return (
                <div
                  key={food.food_id}
                  className="p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-[var(--titan-text-primary)]">
                      {food.name}
                    </p>
                    <p className="text-[11px] text-[var(--titan-text-muted)]">
                      {food.source_id === 'TITAN_LEGACY' ? 'Registro local legado' : food.source_id} · Reg. {food.source_record_id} · {food.quality_status}
                    </p>
                    {activeSlot && primaryRecipe && !ingredientEligibility.eligible && (
                      <p className="text-[10px] text-[var(--titan-warning)] mt-0.5">
                        Preparação composta / registro não canônico: disponível apenas para lançamento avulso.
                      </p>
                    )}
                    <p className="text-[11px] font-mono-metric text-[var(--titan-text-secondary)] mt-0.5">
                      {food.macros.kcalPerBasis.toFixed(1)} kcal / {food.macros.basisQuantityG} g ·{' '}
                      <span className="text-[var(--titan-accent)]">
                        P {food.macros.proteinGPerBasis.toFixed(1)} g
                      </span>{' '}
                      ·{' '}
                      <span className="text-[var(--titan-info)]">
                        C {food.macros.carbsGPerBasis.toFixed(1)} g
                      </span>{' '}
                      ·{' '}
                      <span className="text-[var(--titan-copper)]">
                        G {food.macros.fatGPerBasis.toFixed(1)} g
                      </span>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    {activeSlot && primaryRecipe && (
                      <button
                        type="button"
                        disabled={!validGrams || !ingredientEligibility.eligible}
                        title={!ingredientEligibility.eligible ? 'Preparação composta ou registro não canônico: disponível somente para lançamento avulso.' : undefined}
                        onClick={() => {
                          if (onAddFoodToSlot(activeSlot.id, primaryRecipe.id, food.food_id, foodGrams)) {
                            setFeedback(
                              `${food.name} (${foodGrams} g) adicionado em ${activeSlot.title}.`,
                            );
                          }
                        }}
                        className="titan-button titan-button--primary !min-h-[40px] !px-3 !text-xs disabled:opacity-45"
                      >
                        <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Na refeição</span>
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={!validGrams}
                      onClick={() => {
                        const result = onLogFoodToDiary(food.food_id, foodGrams, diaryMealTitle);
                        setFeedback(
                          result.ok
                            ? `${food.name} (${foodGrams} g) registrado em ${diaryMealTitle}.`
                            : result.error,
                        );
                      }}
                      className="titan-button titan-button--secondary !min-h-[40px] !px-3 !text-xs disabled:opacity-45"
                    >
                      <span>No dia</span>
                    </button>
                  </div>
                </div>
              );
              })
            )}
          </div>
        </div>
      )}
    </Surface>
  );
});
