import assert from 'node:assert/strict';
import {
  buildInitialComposerPlans,
  buildOriginalBaselineDayPlan,
  cloneCardapioPlan,
  computeCompositionDiff,
  computeWeeklyPlanSummary,
} from '../../../domain/rules/cardapio-composer-engine.ts';
import { mergeNutritionPersistedState } from '../../../state/nutrition-persistence.ts';

const anchorDate = '2026-11-25';
const plans = buildInitialComposerPlans(
  anchorDate,
  { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
  [],
);

assert.equal(plans.length, 2);
const planA = plans[0]!;
const planB = cloneCardapioPlan(planA);
planB.id = 'plan-cloned';
planB.name = 'Cópia isolada';

// Mutating cloned plan B must NEVER leak into plan A
const dayB = planB.days[anchorDate]!;
dayB.slots[0]!.recipes[0]!.ingredients[0]!.currentQuantityG = 220;
assert.notEqual(
  planA.days[anchorDate]!.slots[0]!.recipes[0]!.ingredients[0]!.currentQuantityG,
  220,
  'Independent plans must never share mutable ingredient references',
);

// Composition diff must catch the gram modification and slotDiffs
const diff = computeCompositionDiff(planA.days[anchorDate]!, dayB);
assert.ok(diff.ingredientDiffs.some((row) => Math.abs(row.deltaGrams) > 0));
assert.ok(diff.deltaMacros.kcal > 0);
assert.equal(diff.slotDiffs.length, dayB.slots.length);
assert.ok(diff.slotDiffs[0]!.deltaKcal > 0);

// Baseline 1x helper resets deviations to 0%
const baselineDay = buildOriginalBaselineDayPlan(dayB);
const baselineDiff = computeCompositionDiff(baselineDay, dayB);
assert.equal(baselineDiff.baselineDeviationPercent, 0);

// Weekly summary averages across all configured days
const weekly = computeWeeklyPlanSummary(planA);
assert.ok(weekly.dayCount >= 1);
assert.ok(weekly.avgMacros.kcal > 0);

// Persistence validation accepts valid plans (including optional P/C/G shares) and filters corrupted entries
const planWithMacros = cloneCardapioPlan(planA);
planWithMacros.mealAllocations = planWithMacros.mealAllocations.map((a) => ({
  ...a,
  proteinSharePercent: a.energySharePercent,
  carbsSharePercent: null,
  fatSharePercent: a.energySharePercent,
}));

const fallback = {
  activeDateKey: anchorDate,
  referenceProfileId: 'adult_male_19_50' as const,
  dailyGoals: { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
  meals: [],
  intakeDayConfirmations: [],
  composerPlans: plans,
  activeComposerPlanId: planA.id,
};

const persistedValid = mergeNutritionPersistedState(
  {
    composerPlans: [planWithMacros, { id: 'corrupt-plan', name: '' }],
    activeComposerPlanId: planA.id,
  },
  fallback,
);
assert.equal(persistedValid.composerPlans?.length, 1);
assert.equal(persistedValid.activeComposerPlanId, planA.id);

console.log('composer-state.test.ts passed.');
