import assert from 'node:assert/strict';
import {
  buildComposerDayFromMeals,
  buildDefaultMealAllocations,
  computeDayNutrition,
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
} from '../../../domain/rules/cardapio-composer-engine.ts';

const day = buildComposerDayFromMeals('2026-11-25', []);
const baselineSummary = computeDayNutrition(day);

// Lock one specific ingredient (index 0 of slot 0) and ask solver to hit a higher calorie/protein target
const lockedId = day.slots[0]!.recipes[0]!.ingredients[0]!.id;
const lockedOriginalG = day.slots[0]!.recipes[0]!.ingredients[0]!.currentQuantityG;
day.slots[0]!.recipes[0]!.ingredients[0]!.mode = 'locked';

const target = {
  kcal: Math.round(baselineSummary.macros.kcal + 240),
  proteinG: Math.round(baselineSummary.macros.proteinG + 20),
  carbsG: Math.round(baselineSummary.macros.carbsG + 20),
  fatG: Math.round(baselineSummary.macros.fatG + 8),
};

const mealAllocations = buildDefaultMealAllocations(day.slots);
const proposal = solveNutritionalBalanceQP(day, target, {
  goalFocus: 'balanced',
  mealAllocations,
});

assert.ok(['optimal', 'feasible', 'approximate'].includes(proposal.certificate));
assert.ok(proposal.adjustedCount > 0, 'QP solver must adjust flexible ingredients');
assert.equal(proposal.lockedCount, 1, 'Locked count must be preserved accurately');

// Verify locked ingredient did NOT change inside proposedDayPlan
const proposedLockedG = proposal.proposedDayPlan.slots[0]!.recipes[0]!.ingredients.find(
  (i) => i.id === lockedId,
)?.currentQuantityG;
assert.equal(proposedLockedG, lockedOriginalG, 'Locked ingredient quantity must remain invariant');

// Verify proposed plan moved closer to target kcal than baseline
const beforeError = Math.abs(baselineSummary.macros.kcal - target.kcal);
const afterError = Math.abs(proposal.afterMacros.kcal - target.kcal);
assert.ok(afterError < beforeError, 'QP optimization must reduce target calorie error');

// Verify discrete substitution proposals are ranked independently
const subs = proposeDiscreteSubstitutions(day, { ...target, kcal: 1750, carbsG: 180 }, 3);
assert.ok(subs.length >= 1, 'Discrete substitution recommender should propose catalog swaps');

console.log('composition-preview.test.ts passed.');

// Incomplete food composition must downgrade an apparently successful optimization.
const incompleteDay = structuredClone(day);
incompleteDay.slots[0]!.recipes[0]!.ingredients.push({
  id: 'unresolved-nutrition',
  foodId: 'food-not-in-catalog',
  displayName: 'Alimento sem composição',
  baseQuantityG: 40,
  currentQuantityG: 40,
  quantityStatus: 'known',
  mode: 'flexible',
});
const incompleteProposal = solveNutritionalBalanceQP(incompleteDay, target, {
  goalFocus: 'balanced',
  mealAllocations,
});
assert.equal(incompleteProposal.certificate, 'approximate');
assert.ok(incompleteProposal.explanation.includes('sem composição'));

const lowConfidenceDay = structuredClone(day);
lowConfidenceDay.slots[0]!.recipes[0]!.ingredients.push({
  id: 'partial-label-food',
  foodId: 'off-iogurte-proteico',
  displayName: 'Iogurte proteico',
  baseQuantityG: 100,
  currentQuantityG: 100,
  quantityStatus: 'known',
  mode: 'flexible',
});
const lowConfidenceProposal = solveNutritionalBalanceQP(lowConfidenceDay, target, {
  goalFocus: 'balanced',
  mealAllocations,
});
assert.equal(lowConfidenceProposal.certificate, 'approximate');
