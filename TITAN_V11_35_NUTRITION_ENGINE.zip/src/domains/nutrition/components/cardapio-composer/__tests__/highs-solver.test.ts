import assert from 'node:assert/strict';
import {
  solveDiscreteSubstitutionsWithHighsMIP,
  solveNutritionalBalanceWithHighsQP,
} from '../../../application/highs-nutrition-solver.ts';
import {
  buildDefaultMealAllocations,
  buildInitialComposerPlans,
  computeDayNutrition,
} from '../../../domain/rules/cardapio-composer-engine.ts';

async function main() {
  const plans = buildInitialComposerPlans(
    '2026-11-25',
    { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
    [],
  );
  const plan = plans[0]!;
  const day = plan.days['2026-11-25']!;
  const targets = {
    kcal: 2450,
    proteinG: 175,
    carbsG: 260,
    fatG: 72,
    kcalMin: 2350,
    kcalMax: 2550,
    sourceLabel: 'Meta de teste HiGHS',
  };

  const allocations = buildDefaultMealAllocations(day.slots).map((a) => ({
    ...a,
    proteinSharePercent: a.energySharePercent,
  }));
  const qpProposal = await solveNutritionalBalanceWithHighsQP(day, targets, {
    goalFocus: 'balanced',
    mealAllocations: allocations,
  });

  assert.equal(qpProposal.solverEngine, 'HiGHS QP (WASM)');
  assert.ok(
    qpProposal.certificate === 'optimal' || qpProposal.certificate === 'feasible',
    `Expected optimal/feasible certificate, got ${qpProposal.certificate}`,
  );
  assert.ok(qpProposal.changes.length > 0, 'QP should evaluate flexible variables');

  const beforeDist = Math.abs(qpProposal.beforeMacros.kcal - targets.kcal);
  const afterDist = Math.abs(qpProposal.afterMacros.kcal - targets.kcal);
  assert.ok(
    afterDist <= beforeDist + 10,
    `Expected HiGHS QP to stay at or reduce kcal gap (before=${beforeDist}, after=${afterDist})`,
  );

  for (const ch of qpProposal.changes) {
    assert.ok(ch.proposedQuantityG > 0, 'Proposed quantity must be positive');
  }

  // Test infeasible corridor relaxation warning gracefully falls back without crashing
  const infeasibleCorridorProposal = await solveNutritionalBalanceWithHighsQP(day, {
    kcal: 2450,
    proteinG: 175,
    carbsG: 260,
    fatG: 72,
    kcalMin: 500,
    kcalMax: 520,
  });
  assert.equal(infeasibleCorridorProposal.solverEngine, 'HiGHS QP (WASM)');
  assert.equal(infeasibleCorridorProposal.certificate, 'approximate');

  // Test Level 3 Binary MILP
  const mip = await solveDiscreteSubstitutionsWithHighsMIP(day, {
    kcal: 2200,
    proteinG: 165,
    carbsG: 210,
    fatG: 68,
  });
  assert.ok(Array.isArray(mip.singleSlotSwaps), 'Should compute single slot swaps');
  if (mip.jointProposal) {
    assert.equal(mip.jointProposal.solverEngine, 'HiGHS MILP (WASM)');
    assert.ok(mip.jointProposal.swaps.length >= 1, 'Joint MILP swaps should be non-empty');
    assert.ok(
      mip.jointProposal.targetGapAfter < mip.jointProposal.targetGapBefore,
      'MILP must strictly improve normalized target gap',
    );
  }

  const recheck = computeDayNutrition(qpProposal.proposedDayPlan);
  assert.ok(Math.abs(recheck.macros.kcal - qpProposal.afterMacros.kcal) < 1);
  console.log('highs-solver.test.ts PASSED', {
    qpEngine: qpProposal.solverEngine,
    certificate: qpProposal.certificate,
    durationMs: qpProposal.solveDurationMs,
    mipSwaps: mip.jointProposal?.swaps.length ?? 0,
  });
}

main();
