import assert from 'node:assert/strict';
import {
  buildComposerDayFromMeals,
  buildDefaultMealAllocations,
  applyYieldScaleToRecipe,
  computeDayNutrition,
  computeSlotNutrition,
  scaleDayPlanProportionallyToMealTargets,
} from '../../../domain/rules/cardapio-composer-engine.ts';

const day = buildComposerDayFromMeals('2026-11-25', []);
const allocations = buildDefaultMealAllocations(day.slots);
const targets = { kcal: 2500, proteinG: 170, carbsG: 280, fatG: 75 };
const proposal = scaleDayPlanProportionallyToMealTargets(day, targets, allocations);

assert.equal(proposal.slots.length, 4);
assert.ok(Math.abs(proposal.afterMacros.kcal - targets.kcal) < 2.5, 'all meal targets should remain within the 0.5 g portion-rounding tolerance of the daily energy target');
assert.equal(proposal.slots.reduce((sum, slot) => sum + slot.targetKcal, 0), targets.kcal);

const breakfastBefore = day.slots[0]!;
const breakfastAfter = proposal.proposedDayPlan.slots[0]!;
const beforeIngredients = breakfastBefore.recipes[0]!.ingredients;
const afterIngredients = breakfastAfter.recipes[0]!.ingredients;
const commonFactor = afterIngredients[0]!.currentQuantityG! / beforeIngredients[0]!.currentQuantityG!;
for (let i = 1; i < beforeIngredients.length; i += 1) {
  const ratio = afterIngredients[i]!.currentQuantityG! / beforeIngredients[i]!.currentQuantityG!;
  assert.ok(Math.abs(ratio - commonFactor) < 0.01, 'all unlocked food quantities in one meal must use the same scale factor');
}
assert.ok(Math.abs(breakfastAfter.recipes[0]!.targetServings - commonFactor) < 0.01, 'recipe yield must track the common scale factor');
assert.ok(afterIngredients.every((ingredient) => ingredient.mode === 'proportional'), 'scaled unlocked ingredients remain in proportional mode for future yield changes');
const futureYield = applyYieldScaleToRecipe(breakfastAfter.recipes[0]!, breakfastAfter.recipes[0]!.targetServings * 1.25);
const futureRatios = futureYield.ingredients.map((ingredient, index) => ingredient.currentQuantityG! / afterIngredients[index]!.currentQuantityG!);
assert.ok(futureRatios.every((ratio) => Math.abs(ratio - futureRatios[0]!) < 0.01), 'future yield edits must preserve the newly established ingredient ratios');

const lockedDay = structuredClone(day);
const locked = lockedDay.slots[0]!.recipes[0]!.ingredients[0]!;
locked.mode = 'locked';
const lockedBefore = locked.currentQuantityG;
const lockedProposal = scaleDayPlanProportionallyToMealTargets(lockedDay, { ...targets, kcal: 2800 }, allocations);
const lockedAfter = lockedProposal.proposedDayPlan.slots[0]!.recipes[0]!.ingredients[0]!;
assert.equal(lockedAfter.currentQuantityG, lockedBefore, 'locked ingredients must not be scaled');
assert.ok(lockedProposal.slots[0]!.lockedIngredientCount >= 1);

const incompleteDay = structuredClone(day);
incompleteDay.slots[0]!.recipes[0]!.ingredients.push({
  id: 'unknown-quantity',
  foodId: 'food-not-in-catalog',
  displayName: 'Alimento sem cadastro',
  baseQuantityG: null,
  currentQuantityG: null,
  quantityStatus: 'to_taste',
  mode: 'flexible',
});
incompleteDay.slots[0]!.recipes[0]!.ingredients.push({
  id: 'low-confidence-off',
  foodId: 'off-iogurte-proteico',
  displayName: 'Iogurte proteico',
  baseQuantityG: 100,
  currentQuantityG: 100,
  quantityStatus: 'known',
  mode: 'flexible',
});
incompleteDay.slots[0]!.recipes[0]!.ingredients.push({
  id: 'unresolved-known-food',
  foodId: 'food-not-in-catalog',
  displayName: 'Alimento sem composição',
  baseQuantityG: 50,
  currentQuantityG: 50,
  quantityStatus: 'known',
  mode: 'flexible',
});
const incompleteProposal = scaleDayPlanProportionallyToMealTargets(incompleteDay, targets, allocations);
assert.ok(incompleteProposal.slots[0]!.unquantifiedIngredientCount >= 1);
assert.ok(incompleteProposal.slots[0]!.nutritionCoveragePercent < 100);
assert.equal(incompleteProposal.slots[0]!.hasIncompleteNutritionData, true);
assert.ok(incompleteProposal.slots[0]!.lowConfidenceIngredientCount >= 1);

const unbalanced = allocations.map((allocation, index) =>
  index === 0 ? { ...allocation, energySharePercent: 5 } : allocation,
);
assert.throws(
  () => scaleDayPlanProportionallyToMealTargets(day, targets, unbalanced),
  /somar 100%/i,
  'the proportional planner must refuse incomplete daily allocation',
);


const multiRecipeDay = structuredClone(day);
const secondRecipe = structuredClone(multiRecipeDay.slots[0]!.recipes[0]!);
secondRecipe.id = 'second-breakfast-recipe';
secondRecipe.name = 'Segunda receita do café';
secondRecipe.ingredients = secondRecipe.ingredients.map((ingredient, index) => ({
  ...ingredient,
  id: `second-${index}`,
}));
multiRecipeDay.slots[0]!.recipes.push(secondRecipe);
const multiRecipeProposal = scaleDayPlanProportionallyToMealTargets(multiRecipeDay, targets, allocations);
const multiBefore = multiRecipeDay.slots[0]!.recipes.flatMap((recipe) => recipe.ingredients);
const multiAfter = multiRecipeProposal.proposedDayPlan.slots[0]!.recipes.flatMap((recipe) => recipe.ingredients);
const multiFactor = multiAfter[0]!.currentQuantityG! / multiBefore[0]!.currentQuantityG!;
for (let index = 1; index < multiBefore.length; index += 1) {
  const factor = multiAfter[index]!.currentQuantityG! / multiBefore[index]!.currentQuantityG!;
  assert.ok(Math.abs(factor - multiFactor) < 0.01, 'all recipes in the same meal must share one proportional factor');
}


const preScaledDay = structuredClone(day);
preScaledDay.slots[0]!.recipes[0] = applyYieldScaleToRecipe(preScaledDay.slots[0]!.recipes[0]!, 2);
const preScaledBefore = preScaledDay.slots[0]!.recipes[0]!;
const preScaledProposal = scaleDayPlanProportionallyToMealTargets(preScaledDay, targets, allocations);
const preScaledAfter = preScaledProposal.proposedDayPlan.slots[0]!.recipes[0]!;
assert.equal(preScaledAfter.baseServings, preScaledBefore.targetServings, 'the current yield becomes the new base yield');
assert.ok(Math.abs(preScaledAfter.targetServings / preScaledAfter.baseServings - preScaledProposal.slots[0]!.scaleFactor) < 0.0001);
const preScaledFutureYield = applyYieldScaleToRecipe(preScaledAfter, preScaledAfter.targetServings * 1.2);
const preScaledRatios = preScaledFutureYield.ingredients.map((ingredient, index) => ingredient.currentQuantityG! / preScaledAfter.ingredients[index]!.currentQuantityG!);
assert.ok(preScaledRatios.every((ratio) => Math.abs(ratio - 1.2) < 0.01));

const lockedRecipeDay = structuredClone(day);
const lockedRecipe = structuredClone(lockedRecipeDay.slots[0]!.recipes[0]!);
lockedRecipe.id = 'fixed-recipe';
lockedRecipe.name = 'Receita travada';
lockedRecipe.targetServings = 4;
lockedRecipe.ingredients = lockedRecipe.ingredients.map((ingredient, index) => ({
  ...ingredient,
  id: `fixed-${index}`,
  mode: 'locked' as const,
}));
lockedRecipeDay.slots[0]!.recipes.push(lockedRecipe);
const lockedRecipeBefore = lockedRecipeDay.slots[0]!.recipes[1]!;
const lockedRecipeProposal = scaleDayPlanProportionallyToMealTargets(lockedRecipeDay, { ...targets, kcal: 7000 }, allocations);
const lockedRecipeAfter = lockedRecipeProposal.proposedDayPlan.slots[0]!.recipes[1]!;
assert.equal(lockedRecipeAfter.targetServings, lockedRecipeBefore.targetServings, 'a fully locked recipe must not constrain or follow the scaling of other recipes in the meal');
assert.deepEqual(lockedRecipeAfter.ingredients.map((item) => item.currentQuantityG), lockedRecipeBefore.ingredients.map((item) => item.currentQuantityG));
assert.ok(lockedRecipeProposal.slots[0]!.scaleFactor > 1);

const boundedProposal = scaleDayPlanProportionallyToMealTargets(day, { ...targets, kcal: 15000 }, allocations);
assert.equal(boundedProposal.slots[0]!.status, 'limited_by_serving_or_mass_bounds');
assert.ok(boundedProposal.proposedDayPlan.slots[0]!.recipes[0]!.targetServings <= 4);


const infeasibleBoundsDay = structuredClone(day);
const infeasibleRecipe = infeasibleBoundsDay.slots[0]!.recipes[0]!;
infeasibleRecipe.targetServings = 0.25;
infeasibleRecipe.ingredients = infeasibleRecipe.ingredients.map((ingredient, index) => ({
  ...ingredient,
  mode: index === 0 ? 'flexible' as const : 'locked' as const,
  currentQuantityG: index === 0 ? 2500 : ingredient.currentQuantityG,
}));
const infeasibleBoundsProposal = scaleDayPlanProportionallyToMealTargets(infeasibleBoundsDay, targets, allocations);
assert.equal(infeasibleBoundsProposal.slots[0]!.status, 'limited_by_serving_or_mass_bounds');
assert.equal(infeasibleBoundsProposal.slots[0]!.scaleFactor, 1, 'incompatible bounds must not break the shared ingredient ratio');
assert.equal(infeasibleBoundsProposal.proposedDayPlan.slots[0]!.recipes[0]!.ingredients[0]!.currentQuantityG, 2500);

const fullyLockedDay = structuredClone(day);
for (const slot of fullyLockedDay.slots) {
  for (const recipe of slot.recipes) {
    for (const ingredient of recipe.ingredients) ingredient.mode = 'locked';
  }
}
const fullyLockedProposal = scaleDayPlanProportionallyToMealTargets(fullyLockedDay, targets, allocations);
assert.ok(fullyLockedProposal.slots.every((slot) => slot.status === 'no_scalable_energy'));
assert.throws(() => scaleDayPlanProportionallyToMealTargets(day, { ...targets, kcal: 0 }, allocations), /maior que zero/i);

const before = computeDayNutrition(day);
assert.ok(Math.abs(before.macros.kcal - proposal.beforeMacros.kcal) < 0.001);
assert.ok(proposal.afterMacros.kcal > 0);
console.log('proportional-meal-scaling.test.ts passed.');
