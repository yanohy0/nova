import { memo, useState } from 'react';
import { BookmarkPlus, Trash2 } from 'lucide-react';
import type { CompositionVariant } from '../../../domain/entities/nutrient';

interface VariantSwitcherProps {
  variants: readonly CompositionVariant[];
  activeVariantId?: string | null;
  onSaveSnapshot: (name: string) => void;
  onActivateVariant: (variantId: string) => void;
  onDeleteVariant: (variantId: string) => void;
}

export const VariantSwitcher = memo(function VariantSwitcher({
  variants,
  activeVariantId,
  onSaveSnapshot,
  onActivateVariant,
  onDeleteVariant,
}: VariantSwitcherProps) {
  const [nameDraft, setNameDraft] = useState('');

  const handleSave = () => {
    const clean = nameDraft.trim();
    if (!clean) return;
    onSaveSnapshot(clean);
    setNameDraft('');
  };

  return (
    <div className="space-y-3 pt-2 border-t border-[var(--titan-border-subtle)]">
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-[var(--titan-text-secondary)]">
          Variantes do cardápio ({variants.length})
        </h3>
        <span className="text-[10px] text-[var(--titan-text-muted)]">
          Receitas base preservadas
        </span>
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          maxLength={80}
          value={nameDraft}
          onChange={(event) => setNameDraft(event.target.value)}
          placeholder="Nome da variante (ex.: Dia de treino)"
          aria-label="Nome da nova variante"
          className="flex-1 min-w-0 rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-[var(--titan-text-primary)]"
        />
        <button
          type="button"
          disabled={!nameDraft.trim()}
          onClick={handleSave}
          className="titan-button titan-button--secondary !min-h-[44px] !px-3 !text-xs disabled:opacity-45 shrink-0"
        >
          <BookmarkPlus className="w-4 h-4" aria-hidden="true" />
          <span>Salvar</span>
        </button>
      </div>

      {variants.length > 0 && (
        <div className="space-y-1.5 max-h-48 overflow-y-auto">
          {variants.map((variant) => {
            const isActive = variant.id === activeVariantId;
            return (
              <div
                key={variant.id}
                className={`flex items-center justify-between gap-2 rounded-xl border px-3 py-2 ${
                  isActive
                    ? 'border-[var(--titan-champagne)]/65 bg-[var(--titan-surface-raised)]'
                    : 'border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)]'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onActivateVariant(variant.id)}
                  className="min-w-0 flex-1 text-left"
                >
                  <span className="block text-xs font-semibold text-[var(--titan-text-primary)] truncate">
                    {variant.name}
                  </span>
                  <span className="block text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
                    {Math.round(variant.macros.kcal)} kcal · P {variant.macros.proteinG.toFixed(0)} g · D{' '}
                    {variant.weightedDeviationPercent.toFixed(1)}%
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteVariant(variant.id)}
                  aria-label={`Excluir variante ${variant.name}`}
                  className="min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-lg text-[var(--titan-text-muted)] hover:text-[var(--titan-status-error)]"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
});
