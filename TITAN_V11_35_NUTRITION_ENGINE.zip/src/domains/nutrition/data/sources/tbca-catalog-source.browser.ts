export type CompactTbcaCatalogRow = [
  string,
  string,
  string | null,
  string | null,
  string | null,
  string | null,
  string | null,
  [number, number, number, number, number, number | null, number | null, number | null, number | null],
  Array<number | null>,
];

let cachedRows: CompactTbcaCatalogRow[] | null = null;
let pendingPromise: Promise<CompactTbcaCatalogRow[]> | null = null;

export function readInitialCompactTbcaCatalogSync(): CompactTbcaCatalogRow[] {
  return cachedRows ?? [];
}

export function isCompactTbcaCatalogLoaded(): boolean {
  return cachedRows !== null;
}

export async function ensureCompactTbcaCatalogAsync(): Promise<CompactTbcaCatalogRow[]> {
  if (cachedRows) {
    return cachedRows;
  }
  if (!pendingPromise) {
    pendingPromise = import('./tbca-catalog.compact.json')
      .then((mod) => {
        const rows = (mod.default ?? mod) as CompactTbcaCatalogRow[];
        cachedRows = rows;
        return rows;
      })
      .catch((error) => {
        pendingPromise = null;
        throw error;
      });
  }
  return pendingPromise;
}
