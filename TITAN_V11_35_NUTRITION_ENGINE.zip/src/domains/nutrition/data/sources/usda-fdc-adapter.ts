import {
  MICRONUTRIENT_ORDER,
  type FoodNutrientDerivationComponent,
  type FoodSourceItem,
  type NutrientId,
} from '../../domain/entities/nutrient.ts';
import { validateFoodMacroComposition } from '../../domain/rules/food-data-quality.ts';
import { USDA_FDC_GENERATED_CATALOG } from './usda-fdc-catalog.generated.ts';

export type USDAFdcDataType = 'Foundation' | 'SR Legacy' | 'Survey (FNDDS)' | 'Experimental';
export interface USDAFdcImportOptions {
  releaseVersion: string;
  dataType: USDAFdcDataType;
  sourceUrl?: string;
  datasetSha256?: string;
}
export interface USDAFdcQuarantinedNutrient {
  fdcId: string;
  nutrientId: number | null;
  nutrientNumber: string | null;
  nutrientName: string;
  amount: number | null;
  unit: string;
  reason: 'unknown_nutrient' | 'name_or_unit_mismatch' | 'invalid_amount' | 'unsupported_semantic_mapping' | 'duplicate_conflict' | 'id_number_mismatch';
}
export interface USDAFdcImportResult {
  foods: FoodSourceItem[];
  rejectedFoods: Array<{ fdcId: string | null; description: string; reason: string }>;
  quarantinedNutrients: USDAFdcQuarantinedNutrient[];
}

interface NutrientSpec { fdcId: number; number: string; name: string; sourceUnit: string; normalizedUnit: string; nutrientId: NutrientId; scale: number }
interface MacroMetricSpec { fdcId: number; number: string; name: string; sourceUnit: string }
const NUTRIENT_SPECS: readonly NutrientSpec[] = [
  { fdcId: 1106, number: '320', name: 'Vitamin A, RAE', sourceUnit: 'µg', normalizedUnit: 'µg RAE', nutrientId: 'vitamin_a', scale: 1 },
  { fdcId: 1162, number: '401', name: 'Vitamin C, total ascorbic acid', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'vitamin_c', scale: 1 },
  { fdcId: 1114, number: '328', name: 'Vitamin D (D2 + D3)', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'vitamin_d', scale: 1 },
  { fdcId: 1109, number: '323', name: 'Vitamin E (alpha-tocopherol)', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'vitamin_e', scale: 1 },
  { fdcId: 1165, number: '404', name: 'Thiamin', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'vitamin_b1', scale: 1 },
  { fdcId: 1166, number: '405', name: 'Riboflavin', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'vitamin_b2', scale: 1 },
  { fdcId: 1170, number: '410', name: 'Pantothenic acid', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'vitamin_b5', scale: 1 },
  { fdcId: 1175, number: '415', name: 'Vitamin B-6', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'vitamin_b6', scale: 1 },
  { fdcId: 1176, number: '416', name: 'Biotin', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'vitamin_b7', scale: 1 },
  { fdcId: 1190, number: '435', name: 'Folate, DFE', sourceUnit: 'µg', normalizedUnit: 'µg DFE', nutrientId: 'vitamin_b9', scale: 1 },
  { fdcId: 1178, number: '418', name: 'Vitamin B-12', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'vitamin_b12', scale: 1 },
  { fdcId: 1087, number: '301', name: 'Calcium, Ca', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'calcium', scale: 1 },
  { fdcId: 1098, number: '312', name: 'Copper, Cu', sourceUnit: 'mg', normalizedUnit: 'µg', nutrientId: 'copper', scale: 1000 },
  { fdcId: 1089, number: '303', name: 'Iron, Fe', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'iron', scale: 1 },
  { fdcId: 1091, number: '305', name: 'Phosphorus, P', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'phosphorus', scale: 1 },
  { fdcId: 1090, number: '304', name: 'Magnesium, Mg', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'magnesium', scale: 1 },
  { fdcId: 1101, number: '315', name: 'Manganese, Mn', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'manganese', scale: 1 },
  { fdcId: 1092, number: '306', name: 'Potassium, K', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'potassium', scale: 1 },
  { fdcId: 1103, number: '317', name: 'Selenium, Se', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'selenium', scale: 1 },
  { fdcId: 1093, number: '307', name: 'Sodium, Na', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'sodium', scale: 1 },
  { fdcId: 1095, number: '309', name: 'Zinc, Zn', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'zinc', scale: 1 },
  { fdcId: 1096, number: '310', name: 'Chromium, Cr', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'chromium', scale: 1 },
  { fdcId: 1099, number: '313', name: 'Fluoride, F', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'fluoride', scale: 1 },
  { fdcId: 1100, number: '314', name: 'Iodine, I', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'iodine', scale: 1 },
  { fdcId: 1102, number: '316', name: 'Molybdenum, Mo', sourceUnit: 'µg', normalizedUnit: 'µg', nutrientId: 'molybdenum', scale: 1 },
  { fdcId: 1180, number: '421', name: 'Choline, total', sourceUnit: 'mg', normalizedUnit: 'mg', nutrientId: 'choline', scale: 1 },
];
const MACRO_METRIC_SPECS: readonly MacroMetricSpec[] = [
  { fdcId: 1079, number: '291', name: 'Fiber, total dietary', sourceUnit: 'g' },
  { fdcId: 1258, number: '606', name: 'Fatty acids, total saturated', sourceUnit: 'g' },
  { fdcId: 1253, number: '601', name: 'Cholesterol', sourceUnit: 'mg' },
];
const MACRO_METRIC_NUMBERS = new Set(MACRO_METRIC_SPECS.map((spec) => spec.number));
const NIACIN_COMPONENT_NUMBERS = new Set(['406', '407', '409', '501']);
const NON_MICRONUTRIENT_NUMBERS = new Set(['203', '204', '205', '208', '957', '958', ...MACRO_METRIC_NUMBERS, ...NIACIN_COMPONENT_NUMBERS]);
const UNSUPPORTED_SEMANTIC_MAPPINGS = new Map<string, string>([
  ['430', 'Filoquinona (vitamina K1) não representa automaticamente a ingestão total de vitamina K.'],
]);
interface FdcNiacinComponentSpec { fdcId: number; number: string; name: string; sourceUnit: string }
interface FdcNiacinComponentLookup { found: boolean; valid: boolean; amount: number | null; row: NonNullable<ReturnType<typeof readNutrient>> | null }
const FDC_NIACIN_COMPONENTS = {
  preformed: { fdcId: 1167, number: '406', name: 'Niacin', sourceUnit: 'mg' },
  tryptophanDerived: { fdcId: 1168, number: '407', name: 'Niacin from tryptophan, determined', sourceUnit: 'mg' },
  totalEquivalent: { fdcId: 1169, number: '409', name: 'Niacin equivalent N406 +N407', sourceUnit: 'mg' },
  tryptophan: { fdcId: 1210, number: '501', name: 'Tryptophan', sourceUnit: 'g' },
} as const satisfies Record<string, FdcNiacinComponentSpec>;
const NIACIN_EQUIVALENT_REFERENCE_URL = 'https://ods.od.nih.gov/factsheets/Niacin-HealthProfessional/';
const SPEC_BY_NUMBER = new Map(NUTRIENT_SPECS.map((spec) => [spec.number, spec]));
const REGISTERED_USDA_FOODS: Record<string, FoodSourceItem> = {};

function isOfficialFdcUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname.toLowerCase() === 'fdc.nal.usda.gov' &&
      !url.username && !url.password;
  } catch {
    return false;
  }
}
const USDA_FDC_CATALOG_LISTENERS = new Set<() => void>();

export function onUsdaFdcCatalogUpdated(listener: () => void): () => void {
  USDA_FDC_CATALOG_LISTENERS.add(listener);
  return () => USDA_FDC_CATALOG_LISTENERS.delete(listener);
}

type UnknownRecord = Record<string, unknown>;
function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
const FDC_DATA_TYPE_ENVELOPES: Readonly<Record<string, USDAFdcDataType>> = {
  FoundationFoods: 'Foundation',
  SRLegacyFoods: 'SR Legacy',
  SurveyFoods: 'Survey (FNDDS)',
  ExperimentalFoods: 'Experimental',
};
function getFoodRows(raw: unknown): { rows: unknown[]; envelopeType: USDAFdcDataType | null } {
  if (Array.isArray(raw)) return { rows: raw, envelopeType: null };
  if (!isRecord(raw)) return { rows: [], envelopeType: null };
  for (const [key, dataType] of Object.entries(FDC_DATA_TYPE_ENVELOPES)) {
    if (Array.isArray(raw[key])) return { rows: raw[key] as unknown[], envelopeType: dataType };
  }
  for (const key of ['foods', 'FoodDataCentral']) {
    if (Array.isArray(raw[key])) return { rows: raw[key] as unknown[], envelopeType: null };
  }
  return { rows: [], envelopeType: null };
}
function readNutrient(row: unknown): { id: number | null; number: string | null; name: string; unit: string; amount: number | null } | null {
  if (!isRecord(row)) return null;
  const nutrient = isRecord(row.nutrient) ? row.nutrient : row;
  const id = typeof nutrient.id === 'number' && Number.isInteger(nutrient.id) ? nutrient.id : null;
  const number = typeof nutrient.number === 'string' && nutrient.number.trim() ? nutrient.number.trim() : null;
  const name = typeof nutrient.name === 'string' ? nutrient.name.trim() : '';
  const unit = typeof nutrient.unitName === 'string' ? nutrient.unitName.trim() : '';
  const amount = typeof row.amount === 'number' && Number.isFinite(row.amount) ? row.amount : null;
  return { id, number, name, unit, amount };
}
interface ExactNutrientLookup { found: boolean; amount: number | null; conflict: boolean }
function findExact(rows: readonly unknown[], fdcId: number, number: string, name: string, unit: string): ExactNutrientLookup {
  const matchingRows = rows.flatMap((row) => {
    const item = readNutrient(row);
    return item?.id === fdcId || item?.number === number ? [item] : [];
  });
  if (matchingRows.length === 0) return { found: false, amount: null, conflict: false };
  const validRows = matchingRows.filter((item) => item.id === fdcId && item.number === number &&
    item.name === name && item.unit.toLowerCase() === unit.toLowerCase() && item.amount !== null && item.amount >= 0);
  if (validRows.length !== matchingRows.length) return { found: true, amount: null, conflict: true };
  const distinctAmounts = new Set(validRows.map((item) => item.amount));
  if (distinctAmounts.size !== 1) return { found: true, amount: null, conflict: true };
  return { found: true, amount: validRows[0]!.amount, conflict: false };
}

function readExactNiacinComponent(
  rows: readonly unknown[],
  spec: FdcNiacinComponentSpec,
  fdcId: string,
  quarantinedNutrients: USDAFdcQuarantinedNutrient[],
): FdcNiacinComponentLookup {
  const matchingRows = rows.flatMap((row) => {
    const item = readNutrient(row);
    return item?.id === spec.fdcId || item?.number === spec.number ? [item] : [];
  });
  if (matchingRows.length === 0) return { found: false, valid: false, amount: null, row: null };

  const invalidRows = matchingRows.filter((item) =>
    item.id !== spec.fdcId || item.number !== spec.number || item.name !== spec.name ||
    item.unit.toLowerCase() !== spec.sourceUnit.toLowerCase() || item.amount === null || item.amount < 0);
  if (invalidRows.length > 0) {
    for (const item of matchingRows) {
      const rowIsInvalid = invalidRows.includes(item);
      const reason: USDAFdcQuarantinedNutrient['reason'] = !rowIsInvalid
        ? 'duplicate_conflict'
        : item.amount === null || item.amount < 0
          ? 'invalid_amount'
          : item.id !== spec.fdcId || item.number !== spec.number
            ? 'id_number_mismatch'
            : 'name_or_unit_mismatch';
      quarantinedNutrients.push({
        fdcId, nutrientId: item.id, nutrientNumber: item.number, nutrientName: item.name,
        amount: item.amount, unit: item.unit, reason,
      });
    }
    return { found: true, valid: false, amount: null, row: null };
  }

  const amounts = new Set(matchingRows.map((item) => item.amount));
  if (amounts.size > 1) {
    for (const item of matchingRows) quarantinedNutrients.push({
      fdcId, nutrientId: item.id, nutrientNumber: item.number, nutrientName: item.name,
      amount: item.amount, unit: item.unit, reason: 'duplicate_conflict',
    });
    return { found: true, valid: false, amount: null, row: null };
  }

  return { found: true, valid: true, amount: matchingRows[0]!.amount, row: matchingRows[0]! };
}

function quarantineUnpairedNiacinComponent(
  component: FdcNiacinComponentLookup,
  fdcId: string,
  quarantinedNutrients: USDAFdcQuarantinedNutrient[],
): void {
  if (!component.found || !component.valid || !component.row) return;
  quarantinedNutrients.push({
    fdcId, nutrientId: component.row.id, nutrientNumber: component.row.number,
    nutrientName: component.row.name, amount: component.row.amount,
    unit: component.row.unit, reason: 'unsupported_semantic_mapping',
  });
}

function quarantineInvalidNiacinDerivationComponents(
  components: readonly FdcNiacinComponentLookup[],
  fdcId: string,
  quarantinedNutrients: USDAFdcQuarantinedNutrient[],
): void {
  for (const component of components) {
    if (!component.found || !component.valid || !component.row) continue;
    quarantinedNutrients.push({
      fdcId, nutrientId: component.row.id, nutrientNumber: component.row.number,
      nutrientName: component.row.name, amount: component.row.amount,
      unit: component.row.unit, reason: 'invalid_amount',
    });
  }
}

function niacinComponentEvidence(
  component: FdcNiacinComponentLookup,
  spec: FdcNiacinComponentSpec,
): FoodNutrientDerivationComponent {
  if (!component.valid || component.amount === null || !component.row) throw new TypeError('Componente USDA de niacina inválido.');
  return {
    fdc_nutrient_id: spec.fdcId,
    nutrient_number: spec.number,
    nutrient_name: spec.name,
    value: component.amount,
    unit: spec.sourceUnit,
  };
}

function resolveNiacinEquivalent(
  rows: readonly unknown[],
  fdcId: string,
  quarantinedNutrients: USDAFdcQuarantinedNutrient[],
): FoodSourceItem['micronutrients']['vitamin_b3'] | undefined {
  const direct = readExactNiacinComponent(rows, FDC_NIACIN_COMPONENTS.totalEquivalent, fdcId, quarantinedNutrients);
  if (direct.valid && direct.amount !== null) {
    return {
      original_value: direct.amount, original_unit: 'mg',
      normalized_value: direct.amount, normalized_unit: 'mg NE', basis_quantity: 100,
      data_status: 'quantified', conversion_method: 'direct',
      source_evidence: niacinComponentEvidence(direct, FDC_NIACIN_COMPONENTS.totalEquivalent),
    };
  }

  const preformed = readExactNiacinComponent(rows, FDC_NIACIN_COMPONENTS.preformed, fdcId, quarantinedNutrients);
  const tryptophanDerived = readExactNiacinComponent(rows, FDC_NIACIN_COMPONENTS.tryptophanDerived, fdcId, quarantinedNutrients);
  let measuredEquivalentOverflow = false;
  if (preformed.valid && preformed.amount !== null && tryptophanDerived.valid && tryptophanDerived.amount !== null) {
    const normalizedValue = Number((preformed.amount + tryptophanDerived.amount).toFixed(6));
    if (Number.isFinite(normalizedValue)) {
      return {
        original_value: preformed.amount,
        original_unit: 'mg',
        normalized_value: normalizedValue,
        normalized_unit: 'mg NE',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'niacin_equivalent_from_components',
        derivation: {
          method: 'niacin_equivalent_sum_406_407',
          formula: 'mg NE = FDC 406 (mg) + FDC 407 (mg)',
          reference_url: NIACIN_EQUIVALENT_REFERENCE_URL,
          basis_quantity_g: 100,
          components: [
            niacinComponentEvidence(preformed, FDC_NIACIN_COMPONENTS.preformed),
            niacinComponentEvidence(tryptophanDerived, FDC_NIACIN_COMPONENTS.tryptophanDerived),
          ],
        },
      };
    }
    measuredEquivalentOverflow = true;
  }

  if (measuredEquivalentOverflow) {
    quarantineInvalidNiacinDerivationComponents([preformed, tryptophanDerived], fdcId, quarantinedNutrients);
    return undefined;
  }

  const tryptophan = readExactNiacinComponent(rows, FDC_NIACIN_COMPONENTS.tryptophan, fdcId, quarantinedNutrients);
  if (preformed.valid && preformed.amount !== null && tryptophan.valid && tryptophan.amount !== null) {
    const tryptophanMg = tryptophan.amount * 1000;
    const normalizedValue = Number((preformed.amount + (tryptophanMg / 60)).toFixed(6));
    if (Number.isFinite(tryptophanMg) && Number.isFinite(normalizedValue)) {
      return {
        original_value: preformed.amount,
        original_unit: 'mg',
        normalized_value: normalizedValue,
        normalized_unit: 'mg NE',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'niacin_equivalent_from_components',
        derivation: {
          method: 'niacin_equivalent_1_to_60',
          formula: 'mg NE = mg niacin + (g tryptophan × 1000 / 60)',
          reference_url: NIACIN_EQUIVALENT_REFERENCE_URL,
          basis_quantity_g: 100,
          components: [
            niacinComponentEvidence(preformed, FDC_NIACIN_COMPONENTS.preformed),
            niacinComponentEvidence(tryptophan, FDC_NIACIN_COMPONENTS.tryptophan),
          ],
        },
      };
    }
    quarantineInvalidNiacinDerivationComponents([preformed, tryptophanDerived, tryptophan], fdcId, quarantinedNutrients);
    return undefined;
  }

  quarantineUnpairedNiacinComponent(preformed, fdcId, quarantinedNutrients);
  quarantineUnpairedNiacinComponent(tryptophanDerived, fdcId, quarantinedNutrients);
  quarantineUnpairedNiacinComponent(tryptophan, fdcId, quarantinedNutrients);
  return undefined;
}

function readOptionalMacro(
  rows: readonly unknown[],
  spec: MacroMetricSpec,
  fdcId: string,
  quarantinedNutrients: USDAFdcQuarantinedNutrient[],
): number | null | undefined {
  const lookup = findExact(rows, spec.fdcId, spec.number, spec.name, spec.sourceUnit);
  if (!lookup.found) return undefined;
  if (!lookup.conflict) return lookup.amount;

  const matchingRows = rows.flatMap((row) => {
    const item = readNutrient(row);
    return item?.id === spec.fdcId || item?.number === spec.number ? [item] : [];
  });
  const allValuesValid = matchingRows.every((item) => item.amount !== null && item.amount >= 0);
  const allIdentifiersMatch = matchingRows.every((item) => item.id === spec.fdcId && item.number === spec.number);
  const allLabelsMatch = matchingRows.every((item) => item.name === spec.name && item.unit.toLowerCase() === spec.sourceUnit.toLowerCase());
  const reason = !allValuesValid ? 'invalid_amount' : !allIdentifiersMatch ? 'id_number_mismatch' : !allLabelsMatch ? 'name_or_unit_mismatch' : 'duplicate_conflict';
  for (const item of matchingRows) quarantinedNutrients.push({
    fdcId, nutrientId: item.id, nutrientNumber: item.number, nutrientName: item.name, amount: item.amount, unit: item.unit, reason,
  });
  return null;
}

/** Strict offline parser for USDA JSON exports. Unknown nutrient IDs and changed units are quarantined, never guessed. */
export function parseUsdaFdcFoods(raw: unknown, options: USDAFdcImportOptions): USDAFdcImportResult {
  if (!options || typeof options.releaseVersion !== 'string' || !options.releaseVersion.trim() || options.releaseVersion.length > 80 ||
      !['Foundation', 'SR Legacy', 'Survey (FNDDS)', 'Experimental'].includes(options.dataType) ||
      (options.sourceUrl !== undefined && (typeof options.sourceUrl !== 'string' || !isOfficialFdcUrl(options.sourceUrl))) ||
      (options.datasetSha256 !== undefined && (typeof options.datasetSha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(options.datasetSha256)))) {
    throw new RangeError('Metadados do dataset USDA inválidos: tipo, versão e URL HTTPS devem ser identificáveis.');
  }
  const foods: FoodSourceItem[] = [];
  const rejectedFoods: USDAFdcImportResult['rejectedFoods'] = [];
  const quarantinedNutrients: USDAFdcQuarantinedNutrient[] = [];
  const envelope = getFoodRows(raw);
  const fdcIdCounts = new Map<string, number>();
  for (const value of envelope.rows) {
    if (!isRecord(value) || typeof value.fdcId !== 'number' || !Number.isInteger(value.fdcId) || value.fdcId <= 0) continue;
    const id = String(value.fdcId);
    fdcIdCounts.set(id, (fdcIdCounts.get(id) ?? 0) + 1);
  }
  if (envelope.envelopeType && envelope.envelopeType !== options.dataType) {
    rejectedFoods.push({ fdcId: null, description: '', reason: 'dataset_envelope_data_type_mismatch' });
    return { foods, rejectedFoods, quarantinedNutrients };
  }
  for (const value of envelope.rows) {
    if (!isRecord(value)) { rejectedFoods.push({ fdcId: null, description: '', reason: 'food_record_not_object' }); continue; }
    const fdcId = typeof value.fdcId === 'number' && Number.isInteger(value.fdcId) && value.fdcId > 0 ? String(value.fdcId) : null;
    const description = typeof value.description === 'string' ? value.description.trim() : '';
    if (fdcId && (fdcIdCounts.get(fdcId) ?? 0) > 1) {
      rejectedFoods.push({ fdcId, description, reason: 'duplicate_fdc_id' });
      continue;
    }
    if (!fdcId || !description) {
      rejectedFoods.push({ fdcId, description, reason: 'missing_fdc_id_or_description' });
      continue;
    }
    if (typeof value.dataType === 'string' && value.dataType !== options.dataType) {
      rejectedFoods.push({ fdcId, description, reason: 'dataset_data_type_mismatch' });
      continue;
    }
    const rows = Array.isArray(value.foodNutrients) ? value.foodNutrients : [];
    const proteinResult = findExact(rows, 1003, '203', 'Protein', 'g');
    const fatResult = findExact(rows, 1004, '204', 'Total lipid (fat)', 'g');
    const carbsResult = findExact(rows, 1005, '205', 'Carbohydrate, by difference', 'g');
    const specificEnergy = findExact(rows, 2048, '958', 'Energy (Atwater Specific Factors)', 'kcal');
    const atwaterGeneralEnergy = findExact(rows, 2047, '957', 'Energy (Atwater General Factors)', 'kcal');
    const generalEnergy = findExact(rows, 1008, '208', 'Energy', 'kcal');
    const energyResult = specificEnergy.found ? specificEnergy : atwaterGeneralEnergy.found ? atwaterGeneralEnergy : generalEnergy;
    const macroResults = [proteinResult, fatResult, carbsResult, energyResult];
    if (macroResults.some((result) => result.conflict)) {
      rejectedFoods.push({ fdcId, description, reason: 'duplicate_macro_conflict' });
      continue;
    }
    const protein = proteinResult.amount;
    const fat = fatResult.amount;
    const carbs = carbsResult.amount;
    const energy = energyResult.amount;
    const fiber = readOptionalMacro(rows, MACRO_METRIC_SPECS[0]!, fdcId, quarantinedNutrients);
    const saturatedFat = readOptionalMacro(rows, MACRO_METRIC_SPECS[1]!, fdcId, quarantinedNutrients);
    const cholesterol = readOptionalMacro(rows, MACRO_METRIC_SPECS[2]!, fdcId, quarantinedNutrients);
    if (protein === null || fat === null || carbs === null || energy === null ||
        protein > 100 || fat > 100 || carbs > 100 || energy > 1000) {
      rejectedFoods.push({ fdcId, description, reason: 'required_macro_or_energy_missing' });
      continue;
    }
    const micronutrients: FoodSourceItem['micronutrients'] = {};
    const niacinEquivalent = resolveNiacinEquivalent(rows, fdcId, quarantinedNutrients);
    if (niacinEquivalent) micronutrients.vitamin_b3 = niacinEquivalent;
    const rowsByNumber = new Map<string, NonNullable<ReturnType<typeof readNutrient>>[]>();
    for (const nutrientRow of rows) {
      const item = readNutrient(nutrientRow);
      if (!item || !item.number || NON_MICRONUTRIENT_NUMBERS.has(item.number)) continue;
      const group = rowsByNumber.get(item.number) ?? [];
      group.push(item);
      rowsByNumber.set(item.number, group);
    }
    for (const [nutrientNumber, items] of rowsByNumber) {
      const spec = SPEC_BY_NUMBER.get(nutrientNumber);
      if (!spec) {
        const unsupportedReason = UNSUPPORTED_SEMANTIC_MAPPINGS.get(nutrientNumber);
        for (const item of items) quarantinedNutrients.push({
          fdcId, nutrientId: item.id, nutrientNumber: item.number, nutrientName: item.name, amount: item.amount,
          unit: item.unit, reason: item.amount === null ? 'invalid_amount' : unsupportedReason ? 'unsupported_semantic_mapping' : 'unknown_nutrient',
        });
        continue;
      }
      const validItems = items.filter((item) => item.id === spec.fdcId && item.number === spec.number &&
        item.name === spec.name && item.unit.toLowerCase() === spec.sourceUnit.toLowerCase() &&
        item.amount !== null && item.amount >= 0);
      const allRowsValid = validItems.length === items.length;
      const uniqueAmounts = new Set(validItems.map((item) => item.amount));
      const duplicateConflict = items.length > 1 && (!allRowsValid || uniqueAmounts.size > 1);
      if (duplicateConflict) {
        for (const item of items) quarantinedNutrients.push({
          fdcId, nutrientId: item.id, nutrientNumber: item.number, nutrientName: item.name, amount: item.amount,
          unit: item.unit, reason: items.some((row) => row.id !== spec.fdcId || row.number !== spec.number) ? 'id_number_mismatch' : 'duplicate_conflict',
        });
        micronutrients[spec.nutrientId] = {
          original_value: null, original_unit: spec.sourceUnit, normalized_value: null,
          normalized_unit: spec.normalizedUnit, basis_quantity: 100, data_status: 'unit_mismatch',
          conversion_method: 'unavailable',
        };
        continue;
      }
      if (!allRowsValid) {
        const item = items[0]!;
        const reason = item.amount === null ? 'invalid_amount' : item.id !== spec.fdcId ? 'id_number_mismatch' : 'name_or_unit_mismatch';
        quarantinedNutrients.push({
          fdcId, nutrientId: item.id, nutrientNumber: item.number, nutrientName: item.name,
          amount: item.amount, unit: item.unit, reason,
        });
        micronutrients[spec.nutrientId] = {
          original_value: item.amount, original_unit: item.unit, normalized_value: null,
          normalized_unit: spec.normalizedUnit, basis_quantity: 100, data_status: 'unit_mismatch',
          conversion_method: 'unavailable',
        };
        continue;
      }
      const amount = validItems[0]!.amount!;
      micronutrients[spec.nutrientId] = {
        original_value: amount, original_unit: spec.sourceUnit,
        normalized_value: Number((amount * spec.scale).toFixed(6)), normalized_unit: spec.normalizedUnit,
        basis_quantity: 100, data_status: 'quantified',
        conversion_method: spec.scale === 1 ? 'direct' : 'unit_scale',
      };
    }
    // Rows without a readable nutrient ID cannot be associated safely with a canonical nutrient.
    for (const nutrientRow of rows) {
      const item = readNutrient(nutrientRow);
      if (item && (item.id === null || item.number === null) && (item.name || item.amount !== null)) quarantinedNutrients.push({
        fdcId, nutrientId: item.id, nutrientNumber: item.number, nutrientName: item.name, amount: item.amount, unit: item.unit,
        reason: item.amount === null ? 'invalid_amount' : 'unknown_nutrient',
      });
    }
    const sourceUrl = `https://fdc.nal.usda.gov/food-details/${fdcId}/nutrients`;
    foods.push({
      food_id: `usda-fdc:${fdcId}`,
      name: description,
      source_id: 'USDA_FDC',
      source_record_id: fdcId,
      source_version: `USDA FDC ${options.dataType} ${options.releaseVersion}${options.datasetSha256 ? ` sha256:${options.datasetSha256.toLowerCase()}` : ''}`,
      quality_status: 'reference_database',
      source_url: sourceUrl,
      food_type: options.dataType,
      macros: {
        kcalPerBasis: energy,
        proteinGPerBasis: protein,
        carbsGPerBasis: carbs,
        fatGPerBasis: fat,
        basisQuantityG: 100,
        ...(fiber !== undefined ? { fiberGPerBasis: fiber } : {}),
        ...(saturatedFat !== undefined ? { saturatedFatGPerBasis: saturatedFat } : {}),
        ...(cholesterol !== undefined ? { cholesterolMgPerBasis: cholesterol } : {}),
        ...(micronutrients.sodium ? { sodiumMgPerBasis: micronutrients.sodium.normalized_value } : {}),
      },
      micronutrients,
    });
  }
  return { foods, rejectedFoods, quarantinedNutrients };
}

function isValidRegisteredUsdaFood(food: unknown): food is FoodSourceItem {
  if (!isRecord(food)) return false;
  const sourceRecordId = typeof food.source_record_id === 'string' ? food.source_record_id : '';
  const dataType = food.food_type;
  const macros = food.macros;
  if (food.source_id !== 'USDA_FDC' || !/^\d+$/.test(sourceRecordId) ||
      food.food_id !== `usda-fdc:${sourceRecordId}` || typeof food.name !== 'string' || !food.name.trim() ||
      !['Foundation', 'SR Legacy', 'Survey (FNDDS)', 'Experimental'].includes(String(dataType)) ||
      typeof food.source_version !== 'string' || !food.source_version.startsWith(`USDA FDC ${String(dataType)} `) ||
      typeof food.source_url !== 'string' || food.source_url !== `https://fdc.nal.usda.gov/food-details/${sourceRecordId}/nutrients` ||
      food.quality_status !== 'reference_database' || !isRecord(macros)) return false;
  const typedFood = food as unknown as FoodSourceItem;
  if (typedFood.macros.basisQuantityG !== 100 || !validateFoodMacroComposition(typedFood).valid) return false;
  if (!isRecord(food.micronutrients)) return false;
  const validStatuses = new Set(['quantified', 'trace', 'not_analyzed', 'unit_mismatch', 'invalid_value', 'missing']);
  const validConversions = new Set(['direct', 'unit_scale', 'direct_rae', 'tbca_re_preserved_unconverted', 'preformed_niacin_only', 'niacin_equivalent_from_components', 'preparation_retention', 'unavailable']);
  for (const [nutrientId, rawRecord] of Object.entries(food.micronutrients)) {
    if (!MICRONUTRIENT_ORDER.includes(nutrientId as NutrientId) || !isRecord(rawRecord)) return false;
    if (typeof rawRecord.original_unit !== 'string' || !rawRecord.original_unit.trim() ||
        typeof rawRecord.normalized_unit !== 'string' || !rawRecord.normalized_unit.trim() ||
        rawRecord.basis_quantity !== 100 || !validStatuses.has(String(rawRecord.data_status)) ||
        !validConversions.has(String(rawRecord.conversion_method))) return false;
    if (rawRecord.original_value !== null && (typeof rawRecord.original_value !== 'number' || !Number.isFinite(rawRecord.original_value) || rawRecord.original_value < 0)) return false;
    if (rawRecord.normalized_value !== null && (typeof rawRecord.normalized_value !== 'number' || !Number.isFinite(rawRecord.normalized_value) || rawRecord.normalized_value < 0)) return false;
    if (rawRecord.data_status === 'quantified' && rawRecord.normalized_value === null) return false;
    if (rawRecord.data_status !== 'quantified' && rawRecord.normalized_value !== null) return false;
    const hasSourceEvidence = rawRecord.source_evidence !== undefined;
    const isNiacinEquivalent = nutrientId === 'vitamin_b3' && rawRecord.normalized_unit === 'mg NE';
    const isDirectNiacinEquivalent = isNiacinEquivalent && rawRecord.conversion_method === 'direct';
    if (isNiacinEquivalent && !isDirectNiacinEquivalent && rawRecord.conversion_method !== 'niacin_equivalent_from_components') return false;
    if (isDirectNiacinEquivalent && !hasSourceEvidence) return false;
    if (hasSourceEvidence) {
      const evidence = rawRecord.source_evidence;
      if (!isDirectNiacinEquivalent || !isRecord(evidence) ||
          evidence.fdc_nutrient_id !== 1169 || evidence.nutrient_number !== '409' ||
          evidence.nutrient_name !== 'Niacin equivalent N406 +N407' || evidence.unit !== 'mg' ||
          typeof evidence.value !== 'number' || !Number.isFinite(evidence.value) || evidence.value < 0 ||
          rawRecord.original_unit !== 'mg' || rawRecord.original_value !== evidence.value ||
          rawRecord.data_status !== 'quantified' || rawRecord.normalized_value !== evidence.value ||
          rawRecord.basis_quantity !== 100) return false;
    }
    const hasDerivation = rawRecord.derivation !== undefined;
    if (rawRecord.conversion_method === 'niacin_equivalent_from_components' && !hasDerivation) return false;
    if (hasDerivation) {
      if (nutrientId !== 'vitamin_b3' || rawRecord.conversion_method !== 'niacin_equivalent_from_components' ||
          rawRecord.normalized_unit !== 'mg NE' || rawRecord.data_status !== 'quantified' || !isRecord(rawRecord.derivation)) return false;
      const derivation = rawRecord.derivation;
      if (derivation.basis_quantity_g !== 100 || derivation.reference_url !== NIACIN_EQUIVALENT_REFERENCE_URL ||
          !Array.isArray(derivation.components) || derivation.components.length !== 2 ||
          typeof derivation.formula !== 'string') return false;
      const components = derivation.components;
      const validEvidenceComponent = (component: unknown): boolean => isRecord(component) &&
        typeof component.fdc_nutrient_id === 'number' && Number.isInteger(component.fdc_nutrient_id) &&
        typeof component.nutrient_number === 'string' && typeof component.nutrient_name === 'string' &&
        typeof component.value === 'number' && Number.isFinite(component.value) && component.value >= 0 &&
        typeof component.unit === 'string';
      if (!components.every(validEvidenceComponent)) return false;
      const componentIds = components.map((component) => (component as UnknownRecord).fdc_nutrient_id);
      const first = components[0] as UnknownRecord;
      const second = components[1] as UnknownRecord;
      const niacinPair = derivation.method === 'niacin_equivalent_1_to_60' &&
        derivation.formula === 'mg NE = mg niacin + (g tryptophan × 1000 / 60)' &&
        componentIds[0] === 1167 && componentIds[1] === 1210 &&
        first.nutrient_number === '406' && first.nutrient_name === 'Niacin' && first.unit === 'mg' &&
        second.nutrient_number === '501' && second.nutrient_name === 'Tryptophan' && second.unit === 'g' &&
        rawRecord.original_unit === 'mg' && rawRecord.original_value === first.value &&
        rawRecord.normalized_value === Number((first.value as number + ((second.value as number * 1000) / 60)).toFixed(6));
      const measuredEquivalentPair = derivation.method === 'niacin_equivalent_sum_406_407' &&
        derivation.formula === 'mg NE = FDC 406 (mg) + FDC 407 (mg)' &&
        componentIds[0] === 1167 && componentIds[1] === 1168 &&
        first.nutrient_number === '406' && first.nutrient_name === 'Niacin' && first.unit === 'mg' &&
        second.nutrient_number === '407' && second.nutrient_name === 'Niacin from tryptophan, determined' && second.unit === 'mg' &&
        rawRecord.original_unit === 'mg' && rawRecord.original_value === first.value &&
        rawRecord.normalized_value === Number(((first.value as number) + (second.value as number)).toFixed(6));
      if (!niacinPair && !measuredEquivalentPair) return false;
    }
  }
  return true;
}

/**
 * Register a complete validated batch. `merge` is the safe default so a new
 * FDC data type does not erase foods registered by a previous batch. `replace`
 * is explicit for activating a complete replacement snapshot.
 */
export function registerUsdaFdcFoods(
  foods: readonly FoodSourceItem[],
  mode: 'merge' | 'replace' = 'merge',
): void {
  if (!Array.isArray(foods) || !foods.every(isValidRegisteredUsdaFood) || !['merge', 'replace'].includes(mode)) {
    throw new TypeError('Registro USDA inválido: revalide origem FDC, proveniência, unidade-base, macros, micronutrientes e modo.');
  }
  const ids = new Set(foods.map((food) => food.food_id));
  if (ids.size !== foods.length) throw new TypeError('Registro USDA inválido: FDC IDs duplicados no catálogo.');
  if (mode === 'replace') {
    for (const key of Object.keys(REGISTERED_USDA_FOODS)) delete REGISTERED_USDA_FOODS[key];
  }
  for (const food of foods) REGISTERED_USDA_FOODS[food.food_id] = food;
  if (foods.length > 0 || mode === 'replace') {
    for (const listener of USDA_FDC_CATALOG_LISTENERS) listener();
  }
}
export function getRegisteredUsdaFdcFood(foodId: string): FoodSourceItem | undefined {
  return REGISTERED_USDA_FOODS[foodId] ?? USDA_FDC_GENERATED_CATALOG.find((food) => food.food_id === foodId);
}
export function getRegisteredUsdaFdcFoods(): readonly FoodSourceItem[] {
  const dynamicIds = new Set(Object.keys(REGISTERED_USDA_FOODS));
  return [
    ...USDA_FDC_GENERATED_CATALOG.filter((food) => !dynamicIds.has(food.food_id)),
    ...Object.values(REGISTERED_USDA_FOODS),
  ];
}
