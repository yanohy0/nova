import { useEffect } from 'react';
import { useNutritionStore } from '../state/nutrition.store';
import { resolveDriProfileId, useProfileStore } from '@/src/domains/profile/application/profile-public';
import { CardapioComposer } from '../components/cardapio-composer/CardapioComposer';
import { SupplementMicronutrientPanel } from '../components/SupplementMicronutrientPanel';

export type NutritionSection = 'cardapio' | 'receitas' | 'alimentos';

interface NutritionWorkspaceProps {
  section?: NutritionSection;
  onSectionChange?: (section: NutritionSection) => void;
}

export function NutritionWorkspace({
  section,
  onSectionChange,
}: NutritionWorkspaceProps = {}) {
  const setReferenceProfileId = useNutritionStore((s) => s.setReferenceProfileId);
  const physiologicalProfile = useProfileStore((s) => s.profile);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const driProfileId = resolveDriProfileId(physiologicalProfile.sex, physiologicalProfile.age);

  useEffect(() => {
    if (!profileConfigured) return;
    setReferenceProfileId(driProfileId);
  }, [profileConfigured, driProfileId, setReferenceProfileId]);

  return (
    <div className="space-y-4">
      {!profileConfigured && (
        <p className="text-[11px] text-[var(--titan-status-warning)]" role="note">
          Configure sexo e idade em Metas para interpretar as referências de micronutrientes. Os valores iniciais são apenas parâmetros temporários.
        </p>
      )}
      <SupplementMicronutrientPanel />
      <CardapioComposer
        initialCatalogScope={section}
        onResetCatalogScope={() => onSectionChange?.('cardapio')}
      />
    </div>
  );
}

/** Compatibility export for the existing lazy route; CardapioComposer replaces all nutrition tabs. */
export const CardapioScreen = NutritionWorkspace;
