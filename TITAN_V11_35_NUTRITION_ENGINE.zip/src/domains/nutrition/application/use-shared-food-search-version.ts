import { useSyncExternalStore } from 'react';
import { getSharedFoodSearchVersion, subscribeSharedFoodSearchVersion } from '../data/sources/food-search-index.ts';

export function useSharedFoodSearchVersion(): number {
  return useSyncExternalStore(
    subscribeSharedFoodSearchVersion,
    getSharedFoodSearchVersion,
    getSharedFoodSearchVersion,
  );
}
