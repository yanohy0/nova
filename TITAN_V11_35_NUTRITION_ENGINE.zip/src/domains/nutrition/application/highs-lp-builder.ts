import type { NutritionTargets } from '../domain/entities/nutrient.ts';
import type { PreparedQPModel } from '../domain/rules/cardapio-composer-engine.ts';
import { resolveMicronutrientResidualScales } from '../domain/rules/micronutrient-optimization-scales.ts';

function formatLpNum(val: number): string {
  if (Math.abs(val) < 1e-12) return '0';
  const fixed = Number(val.toFixed(10));
  return Object.is(fixed, -0) ? '0' : String(fixed);
}

function formatLinearTerms(terms: Array<{ coeff: number; name: string }>): string {
  const parts: string[] = [];
  for (const { coeff, name } of terms) {
    if (!Number.isFinite(coeff) || Math.abs(coeff) < 1e-12) continue;
    const absCoeff = Math.abs(coeff);
    const sign = coeff < 0 ? '-' : parts.length === 0 ? '' : '+';
    const coeffStr = Math.abs(absCoeff - 1) < 1e-12 ? '' : `${formatLpNum(absCoeff)} `;
    parts.push(`${sign} ${coeffStr}${name}`.trim());
  }
  return parts.length > 0 ? parts.join(' ') : '0 x0';
}


export function buildHighsQPModelLP(
  model: PreparedQPModel,
  targets: NutritionTargets,
  enforceCorridors: boolean,
): { lpText: string; hasActiveCorridors: boolean } {
  const { lambda, weights, scales, fixedTotals, vars, slotTargets } = model;
  // Scale the quadratic objective by 10,000 so Hessian entries sit in [1e-3, 10]
  // instead of ~1e-7 (which can stall HiGHS active-set tolerances). Constant
  // positive scaling of f(x) leaves the convex minimizer x* strictly unchanged.
  const OBJ_SCALE = 10_000;
  const invScale2 = {
    kcal: (OBJ_SCALE * 2 * weights.kcal) / (scales.kcal * scales.kcal),
    proteinG: (OBJ_SCALE * 2 * weights.proteinG) / (scales.proteinG * scales.proteinG),
    carbsG: (OBJ_SCALE * 2 * weights.carbsG) / (scales.carbsG * scales.carbsG),
    fatG: (OBJ_SCALE * 2 * weights.fatG) / (scales.fatG * scales.fatG),
  };

  const quadTerms: string[] = [
    `${formatLpNum(invScale2.kcal)} rk^2`,
    `${formatLpNum(invScale2.proteinG)} rp^2`,
    `${formatLpNum(invScale2.carbsG)} rc^2`,
    `${formatLpNum(invScale2.fatG)} rf^2`,
  ];

  const constraints: string[] = [];
  const freeVars: string[] = ['rk', 'rp', 'rc', 'rf'];
  const micronutrientBounds: string[] = [];

  const buildDailyBalanceRow = (
    name: string,
    resVar: string,
    fixedVal: number,
    targetVal: number,
    getter: (idx: number) => number,
  ) => {
    const terms: Array<{ coeff: number; name: string }> = [];
    for (let i = 0; i < vars.length; i += 1) {
      terms.push({ coeff: getter(i), name: `x${i}` });
    }
    terms.push({ coeff: -1, name: resVar });
    constraints.push(` ${name}: ${formatLinearTerms(terms)} = ${formatLpNum(targetVal - fixedVal)}`);
  };

  buildDailyBalanceRow('bal_kcal', 'rk', fixedTotals.kcal, targets.kcal, (i) => vars[i]!.kcalPerG);
  buildDailyBalanceRow('bal_p', 'rp', fixedTotals.proteinG, targets.proteinG, (i) => vars[i]!.proteinPerG);
  buildDailyBalanceRow('bal_c', 'rc', fixedTotals.carbsG, targets.carbsG, (i) => vars[i]!.carbsPerG);
  buildDailyBalanceRow('bal_f', 'rf', fixedTotals.fatG, targets.fatG, (i) => vars[i]!.fatPerG);

  // Proximal deviation constraints d_i = x_i - refG_i
  for (let i = 0; i < vars.length; i += 1) {
    const v = vars[i]!;
    const denom = v.refG + 25;
    const twoLambdaOverDenom2 = (OBJ_SCALE * 2 * lambda) / (denom * denom);
    quadTerms.push(`${formatLpNum(twoLambdaOverDenom2)} d${i}^2`);
    constraints.push(` prox_${i}: d${i} - x${i} = ${formatLpNum(-v.refG)}`);
    freeVars.push(`d${i}`);
  }

  // Meal target allocation residuals (energy + optional P/C/G)
  const slotMacroWeight = 0.28;
  slotTargets.forEach((st, sIdx) => {
    const varIndices: number[] = [];
    for (let i = 0; i < vars.length; i += 1) {
      if (vars[i]!.slotId === st.slotId) varIndices.push(i);
    }
    if (varIndices.length === 0) return;

    const addSlotRow = (
      resName: string,
      weight: number,
      scale: number,
      fixedVal: number,
      targetVal: number,
      getter: (idx: number) => number,
    ) => {
      const qCoeff = (OBJ_SCALE * 2 * weight) / (scale * scale);
      quadTerms.push(`${formatLpNum(qCoeff)} ${resName}^2`);
      const terms: Array<{ coeff: number; name: string }> = varIndices.map((idx) => ({
        coeff: getter(idx),
        name: `x${idx}`,
      }));
      terms.push({ coeff: -1, name: resName });
      constraints.push(` c_${resName}: ${formatLinearTerms(terms)} = ${formatLpNum(targetVal - fixedVal)}`);
      freeVars.push(resName);
    };

    addSlotRow(
      `msk_${sIdx}`,
      st.weightKcal,
      st.scaleKcal,
      st.fixedKcal,
      st.targetKcal,
      (i) => vars[i]!.kcalPerG,
    );

    if (st.targetProteinG !== null) {
      addSlotRow(
        `msp_${sIdx}`,
        slotMacroWeight,
        st.scaleProteinG,
        st.fixedProteinG,
        st.targetProteinG,
        (i) => vars[i]!.proteinPerG,
      );
    }
    if (st.targetCarbsG !== null) {
      addSlotRow(
        `msc_${sIdx}`,
        slotMacroWeight,
        st.scaleCarbsG,
        st.fixedCarbsG,
        st.targetCarbsG,
        (i) => vars[i]!.carbsPerG,
      );
    }
    if (st.targetFatG !== null) {
      addSlotRow(
        `msf_${sIdx}`,
        slotMacroWeight,
        st.scaleFatG,
        st.fixedFatG,
        st.targetFatG,
        (i) => vars[i]!.fatPerG,
      );
    }
  });

  const microSoftWeight = 0.08;
  model.micronutrientConstraints.forEach((constraint, cIdx) => {
    if (constraint.status !== 'applied') return;
    const residualScales = resolveMicronutrientResidualScales(constraint);
    const lowerQuadraticCoefficient = (OBJ_SCALE * 2 * microSoftWeight) /
      (residualScales.minimum * residualScales.minimum);
    const upperQuadraticCoefficient = (OBJ_SCALE * 2 * microSoftWeight) /
      (residualScales.preferredMaximum * residualScales.preferredMaximum);
    const ingredientTerms = vars.map((_, index) => ({
      coeff: constraint.coefficients[index] ?? 0,
      name: `x${index}`,
    }));

    if (constraint.minimum !== null) {
      const slack = `mlo_${cIdx}`;
      quadTerms.push(`${formatLpNum(lowerQuadraticCoefficient)} ${slack}^2`);
      constraints.push(
        ` micro_min_${cIdx}: ${formatLinearTerms([...ingredientTerms, { coeff: 1, name: slack }])} >= ${formatLpNum(constraint.minimum - constraint.fixedValue)}`,
      );
      micronutrientBounds.push(` 0 <= ${slack}`);
    }
    if (constraint.preferredMaximum !== null) {
      const slack = `mhi_${cIdx}`;
      quadTerms.push(`${formatLpNum(upperQuadraticCoefficient)} ${slack}^2`);
      constraints.push(
        ` micro_preferred_${cIdx}: ${formatLinearTerms([...ingredientTerms, { coeff: -1, name: slack }])} <= ${formatLpNum(constraint.preferredMaximum - constraint.fixedValue)}`,
      );
      micronutrientBounds.push(` 0 <= ${slack}`);
    }
    if (constraint.upperLimit !== null) {
      constraints.push(
        ` micro_ul_${cIdx}: ${formatLinearTerms(ingredientTerms)} <= ${formatLpNum(constraint.upperLimit - constraint.fixedValue)}`,
      );
    }
  });

  // Bounds section
  const bounds: string[] = [...micronutrientBounds];
  for (let i = 0; i < vars.length; i += 1) {
    const v = vars[i]!;
    bounds.push(` ${formatLpNum(v.minG)} <= x${i} <= ${formatLpNum(v.maxG)}`);
  }

  let hasActiveCorridors = false;
  const formatResidualBound = (
    name: string,
    targetVal: number,
    minVal: number | null | undefined,
    maxVal: number | null | undefined,
  ): string => {
    if (!enforceCorridors || (minVal == null && maxVal == null)) {
      return ` ${name} free`;
    }
    const lb = minVal != null && Number.isFinite(minVal) ? minVal - targetVal : null;
    const ub = maxVal != null && Number.isFinite(maxVal) ? maxVal - targetVal : null;
    if (lb !== null && ub !== null) {
      if (lb <= ub) {
        hasActiveCorridors = true;
        return ` ${formatLpNum(lb)} <= ${name} <= ${formatLpNum(ub)}`;
      }
      return ` ${name} free`;
    }
    if (lb !== null) {
      hasActiveCorridors = true;
      return ` ${formatLpNum(lb)} <= ${name}`;
    }
    if (ub !== null) {
      hasActiveCorridors = true;
      return ` ${name} <= ${formatLpNum(ub)}`;
    }
    return ` ${name} free`;
  };

  const corridorMap: Record<string, string> = {
    rk: formatResidualBound('rk', targets.kcal, targets.kcalMin, targets.kcalMax),
    rp: formatResidualBound('rp', targets.proteinG, targets.proteinMinG, targets.proteinMaxG),
    rc: formatResidualBound('rc', targets.carbsG, targets.carbsMinG, targets.carbsMaxG),
    rf: formatResidualBound('rf', targets.fatG, targets.fatMinG, targets.fatMaxG),
  };

  for (const fv of freeVars) {
    bounds.push(corridorMap[fv] ?? ` ${fv} free`);
  }

  const lpText = [
    'Minimize',
    ` obj: [ ${quadTerms.join(' + ')} ] / 2`,
    'Subject To',
    ...constraints,
    'Bounds',
    ...bounds,
    'End',
  ].join('\n');

  return { lpText, hasActiveCorridors };
}

