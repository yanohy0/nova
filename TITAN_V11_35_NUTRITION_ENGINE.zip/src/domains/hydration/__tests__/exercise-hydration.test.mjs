import assert from 'node:assert/strict';
import { calculateExerciseHydration } from '../domain/rules/exercise-hydration.ts';

const estimate = calculateExerciseHydration({
  preExerciseWeightKg: 80,
  postExerciseWeightKg: 79.2,
  fluidIntakeMl: 500,
  urineOutputMl: 0,
  durationMinutes: 60,
});
assert.equal(estimate.estimatedSweatLossMl, 1300);
assert.equal(estimate.sweatRateMlPerHour, 1300);
assert.equal(estimate.netBodyMassLossPercent, 1);
assert.deepEqual(estimate.postExerciseReplacementRangeMl, { lower: 800, upper: 1200 });
assert.deepEqual(estimate.preExerciseFluidRangeMl, { lower: 400, upper: 800 });
assert.equal(estimate.interpretation, 'usable_measurement');

const bodyMassGain = calculateExerciseHydration({
  preExerciseWeightKg: 80, postExerciseWeightKg: 80.2, fluidIntakeMl: 500, urineOutputMl: 0, durationMinutes: 60,
});
assert.equal(bodyMassGain.interpretation, 'body_mass_gain_review');
assert.equal(bodyMassGain.netFluidDeficitMl, 0);
assert.ok(bodyMassGain.warnings.some((warning) => warning.includes('hiper-hidratação')));

const invalidBalance = calculateExerciseHydration({
  preExerciseWeightKg: 80, postExerciseWeightKg: 80.2, fluidIntakeMl: 0, urineOutputMl: 0, durationMinutes: 60,
});
assert.equal(invalidBalance.interpretation, 'invalid_fluid_balance');
assert.equal(invalidBalance.sweatRateMlPerHour, 0);
assert.throws(() => calculateExerciseHydration({ preExerciseWeightKg: 80, postExerciseWeightKg: 79, fluidIntakeMl: -1, urineOutputMl: 0, durationMinutes: 60 }), /não negativo/);
assert.throws(() => calculateExerciseHydration({ preExerciseWeightKg: 80, postExerciseWeightKg: 79, fluidIntakeMl: 0, urineOutputMl: 0, durationMinutes: 5 }), /10 minutos/);

console.log('PASS exercise hydration balance, sweat rate, replacement range and overhydration guard');
