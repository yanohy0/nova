import assert from 'node:assert/strict';
import { getHydrationSummary } from '../domain/rules/hydration-summary';
import { logValidatedWater } from '../application/hydration-actions';
import { waterAmountSchema } from '../schemas/hydration.schema';
import { useHydrationStore } from '../state/hydration.store';

const DAY_A = '2026-11-21';
const DAY_B = '2026-11-22';

const store = useHydrationStore.getState();
const beforeSummary = getHydrationSummary(store.entries, store.dailyGoalMl, DAY_A);

// 1. Adding 250 ml updates active day total immediately
store.logWater(250, DAY_A);
const afterAdd = getHydrationSummary(
  useHydrationStore.getState().entries,
  store.dailyGoalMl,
  DAY_A,
);
assert.equal(afterAdd.currentMl, beforeSummary.currentMl + 250);

// 2. Correcting last entry recalculates active day total
useHydrationStore.getState().correctLastEntry(150, DAY_A);
const afterCorrect = getHydrationSummary(
  useHydrationStore.getState().entries,
  store.dailyGoalMl,
  DAY_A,
);
assert.equal(afterCorrect.currentMl, beforeSummary.currentMl + 150);

// 3. Entry on another date does not leak into DAY_A and DAY_B starts with hasRecords === false
useHydrationStore.getState().logWater(300, DAY_B);
const dayASummary = getHydrationSummary(
  useHydrationStore.getState().entries,
  store.dailyGoalMl,
  DAY_A,
);
const dayBSummary = getHydrationSummary(
  useHydrationStore.getState().entries,
  store.dailyGoalMl,
  DAY_B,
);
assert.equal(dayASummary.currentMl, beforeSummary.currentMl + 150);
assert.equal(dayBSummary.currentMl, 300);
assert.equal(dayBSummary.hasRecords, true);

// 4. Empty date shows hasRecords = false
const emptySummary = getHydrationSummary(
  useHydrationStore.getState().entries,
  store.dailyGoalMl,
  '2026-11-19',
);
assert.equal(emptySummary.hasRecords, false);
assert.equal(emptySummary.currentMl, 0);

// 5. Validation rejects empty input without mutating state
const invalidRes = logValidatedWater('   ', DAY_A);
assert.equal(invalidRes.ok, false);


// 6. Values below the store's 10 ml floor are rejected before persistence.
assert.equal(waterAmountSchema.safeParse(9).success, false);
assert.equal(waterAmountSchema.safeParse(10).success, true);
const countBeforeInvalid = useHydrationStore.getState().entries.length;
assert.equal(logValidatedWater(9, DAY_A).ok, false);
assert.equal(useHydrationStore.getState().entries.length, countBeforeInvalid);

// 7. Visual progress is capped while the factual percentage may exceed the goal.
const overGoal = getHydrationSummary(
  [{ id: 'over', dateKey: DAY_A, amountMl: 3000, timeLabel: '12:00' }],
  2500,
  DAY_A,
);
assert.equal(overGoal.percent, 120);
assert.equal(overGoal.barPercent, 100);
