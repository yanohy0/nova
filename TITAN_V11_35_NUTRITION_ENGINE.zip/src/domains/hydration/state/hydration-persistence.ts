import { isValidLocalDateKey } from '../../../shared/utils/local-date.ts';
import type { HydrationLogEntry } from '../domain/entities/hydration-entry';

export interface HydrationPersistedState {
  dailyGoalMl: number;
  entries: HydrationLogEntry[];
  lastEventSeq: number;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isValidEntry(value: unknown): value is HydrationLogEntry {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === 'string' && value.id.trim().length > 0 &&
    typeof value.dateKey === 'string' && isValidLocalDateKey(value.dateKey) &&
    typeof value.amountMl === 'number' && Number.isFinite(value.amountMl) &&
    value.amountMl >= 10 && value.amountMl <= 5000 &&
    typeof value.timeLabel === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value.timeLabel)
  );
}

export function mergeHydrationPersistedState(
  persisted: unknown,
  current: HydrationPersistedState,
): HydrationPersistedState {
  if (!isRecord(persisted)) return current;
  const dailyGoalMl = typeof persisted.dailyGoalMl === 'number' &&
    Number.isFinite(persisted.dailyGoalMl) && persisted.dailyGoalMl >= 500 && persisted.dailyGoalMl <= 8000
    ? Math.round(persisted.dailyGoalMl)
    : current.dailyGoalMl;
  const legacyDemoIds = new Set(['hyd-prev-1', 'hyd-1', 'hyd-2', 'hyd-3', 'hyd-4']);
  const entries = Array.isArray(persisted.entries)
    ? persisted.entries.filter(isValidEntry).filter((entry) => !legacyDemoIds.has(entry.id))
    : current.entries;
  const ids = new Set<string>();
  const uniqueEntries = entries.filter((entry) => {
    if (ids.has(entry.id)) return false;
    ids.add(entry.id);
    return true;
  });
  const lastEventSeq = typeof persisted.lastEventSeq === 'number' &&
    Number.isSafeInteger(persisted.lastEventSeq) && persisted.lastEventSeq >= 0
    ? persisted.lastEventSeq
    : current.lastEventSeq;
  return { dailyGoalMl, entries: uniqueEntries, lastEventSeq };
}
