import assert from 'node:assert/strict';
import { estimateCompletedWorkoutActivityEnergy } from '../workout-activity-energy.ts';
import { reconcileActivityEnergyRecords } from '../../../activity/domain/rules/activity-reconciliation.ts';

const session = {
  id: 'session-1', planId: 'plan-1', planTitle: 'Upper', dateKey: '2026-11-26',
  startedAtMs: Date.parse('2026-11-26T10:00:00.000Z'), completedAtMs: Date.parse('2026-11-26T11:00:00.000Z'),
  completedSets: 12, totalSets: 12, sets: [],
};
const met = {
  code: 'resistance-moderate', category: 'strength', label: 'Resistance training, moderate effort', met: 3.5,
  ageMin: 18, ageMax: 65, sourceName: 'Exercise Compendium', sourceVersion: '2024',
  sourceUrl: 'https://example.org/compendium', sourceLicense: 'CC-BY-4.0', measurementStatus: 'estimated',
};
const result = estimateCompletedWorkoutActivityEnergy(session, { weightKg: 80, age: 30, activityEntry: met });
assert.equal(result.record.source, 'training_app');
assert.equal(result.record.energyKind, 'active');
assert.equal(result.record.quality, 'estimated');
assert.equal(result.record.kind, 'workout_session');
assert.ok(result.record.energyKcal > 0);
const reconciled = reconcileActivityEnergyRecords([result.record]);
assert.equal(reconciled.accepted.length, 1);
assert.throws(() => estimateCompletedWorkoutActivityEnergy({ ...session, startedAtMs: null }, { weightKg: 80, activityEntry: met }));
assert.throws(() => estimateCompletedWorkoutActivityEnergy(session, { weightKg: 80 }));
console.log('Workout activity energy bridge tests passed.');
assert.equal(result.record.parentWorkoutId, session.id,
  'sample parent link must identify the completed session, not the reusable workout plan');
