import type { ActivityMetEntry, ActivityEnergyEstimate } from '../../activity/domain/rules/activity-energy.ts';
import { estimateActivityEnergy } from '../../activity/domain/rules/activity-energy.ts';
import type { ImportedActivityEnergyRecord } from '../../activity/domain/rules/activity-reconciliation.ts';
import type { CompletedWorkoutSession } from '../domain/entities/workout.ts';
import type { RestingMetabolicRateEstimate } from '../../profile/domain/rules/resting-metabolic-rate.ts';
import type { BiologicalSex } from '../../profile/domain/contracts/user-profile.ts';

export interface CompletedWorkoutEnergyInput {
  weightKg: number;
  activityEntry: ActivityMetEntry;
  age?: number;
  sex?: BiologicalSex;
  heightCm?: number;
  restingMetabolicRate?: RestingMetabolicRateEstimate;
}

export interface CompletedWorkoutActivityEnergy {
  estimate: ActivityEnergyEstimate;
  record: ImportedActivityEnergyRecord;
  limitations: string[];
}

/**
 * Produces a conservative active-energy estimate for a completed session.
 * Requires a source-versioned, licensed MET entry and real session timestamps.
 * Sets/reps/load are deliberately not used as a kcal model. This is opt-in and
 * is not persisted or injected into TDEE until the caller explicitly reconciles it.
 */
export function estimateCompletedWorkoutActivityEnergy(
  session: CompletedWorkoutSession,
  input: CompletedWorkoutEnergyInput,
): CompletedWorkoutActivityEnergy {
  if (!session.id || !Number.isFinite(session.startedAtMs) || !Number.isFinite(session.completedAtMs) ||
      session.startedAtMs === null || session.completedAtMs <= session.startedAtMs) {
    throw new RangeError('A sessão precisa ter horários de início e conclusão válidos.');
  }
  const durationMinutes = (session.completedAtMs - session.startedAtMs) / 60_000;
  if (!Number.isFinite(durationMinutes) || durationMinutes < 1 || durationMinutes > 720) {
    throw new RangeError('A duração da sessão precisa estar entre 1 e 720 minutos.');
  }
  const estimate = estimateActivityEnergy({
    activityEntry: input.activityEntry,
    weightKg: input.weightKg,
    durationMinutes,
    ...(input.age !== undefined ? { age: input.age } : {}),
    ...(input.sex !== undefined ? { sex: input.sex } : {}),
    ...(input.heightCm !== undefined ? { heightCm: input.heightCm } : {}),
    ...(input.restingMetabolicRate !== undefined ? { restingMetabolicRate: input.restingMetabolicRate } : {}),
  });
  const record: ImportedActivityEnergyRecord = {
    id: `training-session:${session.id}:${input.activityEntry.code}`,
    source: 'training_app',
    sourceRecordId: session.id,
    kind: 'workout_session',
    energyKind: 'active',
    startTime: new Date(session.startedAtMs).toISOString(),
    endTime: new Date(session.completedAtMs).toISOString(),
    energyKcal: estimate.netKcal,
    quality: 'estimated',
    parentWorkoutId: session.id,
    activityCode: input.activityEntry.code,
    updatedAt: new Date(session.completedAtMs).toISOString(),
  };
  return {
    estimate,
    record,
    limitations: [
      'MET médio não captura precisamente variações de exercício, intervalos, falha muscular ou contribuição anaeróbica.',
      'A duração inclui descansos e transições entre séries; não é uma medida contínua de trabalho metabólico.',
      'O registro é estimado e exige reconciliação com HealthKit/Health Connect para evitar duplicidade.',
      'Não usar simultaneamente com gasto bruto/total já incorporado ao TDEE basal.',
    ],
  };
}
