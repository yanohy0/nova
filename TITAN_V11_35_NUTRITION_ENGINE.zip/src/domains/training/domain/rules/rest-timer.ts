import type { WorkoutPlan } from '../entities/workout';

export interface RestProgressSnapshot {
  elapsedSeconds: number;
  targetSeconds: number;
  overtimeSeconds: number;
  isOvertime: boolean;
}

export function computeRestSnapshot(
  startedAtMs: number,
  nowMs: number,
  targetSeconds: number,
): RestProgressSnapshot {
  const elapsedSeconds = Math.max(0, Math.floor((nowMs - startedAtMs) / 1000));
  const isOvertime = elapsedSeconds > targetSeconds;
  const overtimeSeconds = isOvertime ? elapsedSeconds - targetSeconds : 0;

  return {
    elapsedSeconds,
    targetSeconds,
    overtimeSeconds,
    isOvertime,
  };
}

export function computeWorkoutCompletion(plan: WorkoutPlan): {
  completedSets: number;
  totalSets: number;
  percent: number;
  nextExerciseName: string | null;
} {
  let completedSets = 0;
  let totalSets = 0;
  let nextExerciseName: string | null = null;

  for (const ex of plan.exercises) {
    let hasPending = false;
    for (const s of ex.sets) {
      totalSets += 1;
      if (s.completed) completedSets += 1;
      else hasPending = true;
    }
    if (hasPending && nextExerciseName === null) {
      nextExerciseName = ex.name;
    }
  }

  const percent = totalSets === 0 ? 0 : Math.round((completedSets / totalSets) * 100);
  return { completedSets, totalSets, percent, nextExerciseName };
}
