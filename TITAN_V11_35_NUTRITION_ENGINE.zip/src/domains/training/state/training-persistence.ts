import type { CompletedWorkoutSession, WorkoutPlan } from '../domain/entities/workout';
import { isValidLocalDateKey } from '../../../shared/utils/local-date.ts';
import { getExerciseBySlug } from '../../exercise-library/data/repositories/exercise-catalog.ts';

export interface PersistedRestTimer {
  active: boolean;
  startedAtMs: number;
  targetSeconds: number;
  exerciseName: string;
}

export interface PersistedTrainingState {
  plans: WorkoutPlan[];
  activePlanId: string;
  focusedExerciseId: string;
  restTimer: PersistedRestTimer | null;
  sessionStartedAtMs: number | null;
  completedSessions: CompletedWorkoutSession[];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function finiteRange(value: unknown, min: number, max: number): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
}

function mergePlanProgress(defaultPlan: WorkoutPlan, savedPlan: unknown): WorkoutPlan {
  if (!isRecord(savedPlan) || savedPlan.id !== defaultPlan.id) return defaultPlan;
  const rawExercises = Array.isArray(savedPlan.exercises) ? savedPlan.exercises : [];
  const hasLegacySeedCompletion = rawExercises.some((exercise) => isRecord(exercise) && Array.isArray(exercise.sets) &&
    exercise.sets.some((set) => isRecord(set) && set.completed === true && finiteRange(set.completedAtMs, 0, 10)));
  const status = hasLegacySeedCompletion
    ? defaultPlan.status
    : savedPlan.status === 'pending' || savedPlan.status === 'in_progress' || savedPlan.status === 'completed'
      ? savedPlan.status
      : defaultPlan.status;
  const savedExercises = Array.isArray(savedPlan.exercises) ? savedPlan.exercises : [];
  return {
    ...defaultPlan,
    status,
    exercises: defaultPlan.exercises.map((defaultExercise) => {
      const savedExercise = savedExercises.find((candidate) => isRecord(candidate) && candidate.id === defaultExercise.id);
      if (!isRecord(savedExercise) || !Array.isArray(savedExercise.sets)) return defaultExercise;
      const recoveredSets: unknown[] = savedExercise.sets;
      return {
        ...defaultExercise,
        sets: defaultExercise.sets.map((defaultSet) => {
          const savedSet = recoveredSets.find((candidate: unknown) => isRecord(candidate) && candidate.id === defaultSet.id);
          if (!isRecord(savedSet)) return defaultSet;
          const weightKg = finiteRange(savedSet.weightKg, 0, 500) ? savedSet.weightKg : defaultSet.weightKg;
          const reps = finiteRange(savedSet.reps, 1, 100) && Number.isInteger(savedSet.reps)
            ? savedSet.reps
            : defaultSet.reps;
          const completedAtMs = finiteRange(savedSet.completedAtMs, 0, Number.MAX_SAFE_INTEGER)
            ? savedSet.completedAtMs
            : undefined;
          const repsInReserve = savedSet.repsInReserve === null ? null
            : finiteRange(savedSet.repsInReserve, 0, 5) && Number.isInteger(savedSet.repsInReserve)
              ? savedSet.repsInReserve : undefined;
          const isLegacySeedCompletion = savedSet.completed === true && completedAtMs !== undefined && completedAtMs <= 10;
          const completed = isLegacySeedCompletion ? defaultSet.completed : typeof savedSet.completed === 'boolean' ? savedSet.completed : defaultSet.completed;
          return {
            ...defaultSet,
            weightKg,
            reps,
            repsInReserve,
            completed,
            ...(completed && completedAtMs !== undefined ? { completedAtMs } : {}),
          };
        }),
      };
    }),
  };
}


function parseCustomPlans(value: unknown, defaultIds: Set<string>): WorkoutPlan[] {
  if (!Array.isArray(value)) return [];
  const plans: WorkoutPlan[] = [];
  const seen = new Set<string>(defaultIds);
  for (const raw of value.slice(0, 30)) {
    if (!isRecord(raw) || typeof raw.id !== 'string' || !/^custom-[a-z0-9-]{3,80}$/i.test(raw.id) || seen.has(raw.id)) continue;
    if (typeof raw.title !== 'string' || !raw.title.trim() || raw.title.length > 80) continue;
    const exercises: WorkoutPlan['exercises'] = [];
    const exerciseIds = new Set<string>();
    const exerciseSlugs = new Set<string>();
    if (!Array.isArray(raw.exercises) || raw.exercises.length > 30) continue;
    for (const item of raw.exercises) {
      if (!isRecord(item) || typeof item.id !== 'string' || !/^[-a-z0-9_]{1,100}$/i.test(item.id) ||
        exerciseIds.has(item.id) || typeof item.exerciseSlug !== 'string' || exerciseSlugs.has(item.exerciseSlug) ||
        !finiteRange(item.targetRestSeconds, 15, 600) || !Array.isArray(item.sets) || item.sets.length < 1 || item.sets.length > 20) continue;
      // Persisted labels and muscle mappings are untrusted. Rebuild them from the canonical exercise registry.
      const definition = getExerciseBySlug(item.exerciseSlug);
      if (!definition) continue;
      const setIds = new Set<string>();
      const sets = item.sets.flatMap((set: unknown, index: number) => {
        if (!isRecord(set) || typeof set.id !== 'string' || !/^[-a-z0-9_]{1,120}$/i.test(set.id) || setIds.has(set.id) ||
          !finiteRange(set.weightKg, 0, 500) || !finiteRange(set.reps, 1, 100) || !Number.isInteger(set.reps) ||
          typeof set.targetReps !== 'string' || !set.targetReps.trim()) return [];
        setIds.add(set.id);
        const repsInReserve = set.repsInReserve === null ? null
          : finiteRange(set.repsInReserve, 0, 5) && Number.isInteger(set.repsInReserve)
            ? set.repsInReserve : undefined;
        return [{ id: set.id, setNumber: index + 1, targetReps: set.targetReps.trim().slice(0, 20), weightKg: set.weightKg,
          reps: set.reps, repsInReserve, completed: false }];
      });
      if (sets.length !== item.sets.length) continue;
      exerciseIds.add(item.id);
      exerciseSlugs.add(item.exerciseSlug);
      exercises.push({ id: item.id, exerciseSlug: definition.slug, name: definition.name, equipment: definition.equipment,
        targetRestSeconds: Math.round(item.targetRestSeconds), muscles: {
          primary: [...definition.muscles.primary], secondary: [...definition.muscles.secondary],
        }, sets });
    }
    seen.add(raw.id);
    plans.push({ id: raw.id, title: raw.title.trim(), splitLabel: typeof raw.splitLabel === 'string' ? raw.splitLabel.slice(0, 100) : 'Personalizado',
      status: raw.status === 'in_progress' ? 'in_progress' : 'pending', exercises });
  }
  return plans;
}

function parseCompletedSessions(value: unknown, nowMs: number): CompletedWorkoutSession[] {
  if (!Array.isArray(value)) return [];
  const sessions: CompletedWorkoutSession[] = [];
  const seenIds = new Set<string>();

  for (const item of value) {
    if (!isRecord(item)) continue;
    if (typeof item.id !== 'string' || !item.id.trim() || seenIds.has(item.id)) continue;
    if (typeof item.planId !== 'string' || typeof item.planTitle !== 'string') continue;
    if (typeof item.dateKey !== 'string' || !isValidLocalDateKey(item.dateKey)) continue;
    if (!finiteRange(item.completedAtMs, 0, nowMs + 60_000)) continue;
    if (item.startedAtMs !== null && !finiteRange(item.startedAtMs, 0, item.completedAtMs)) continue;
    if (!finiteRange(item.completedSets, 0, 500) || !finiteRange(item.totalSets, 0, 500)) continue;
    if (item.completedSets > item.totalSets || !Array.isArray(item.sets)) continue;

    const sets = item.sets.flatMap((set: unknown) => {
      if (!isRecord(set)) return [];
      if (typeof set.exerciseId !== 'string' || typeof set.exerciseName !== 'string') return [];
      if (!finiteRange(set.setNumber, 1, 100) || !Number.isInteger(set.setNumber)) return [];
      if (!finiteRange(set.weightKg, 0, 500) || !finiteRange(set.reps, 1, 100) || !Number.isInteger(set.reps)) return [];
      const repsInReserve = set.repsInReserve === null ? null
        : finiteRange(set.repsInReserve, 0, 5) && Number.isInteger(set.repsInReserve)
          ? set.repsInReserve : undefined;
      return [{
        exerciseId: set.exerciseId,
        exerciseName: set.exerciseName,
        setNumber: set.setNumber,
        weightKg: set.weightKg,
        reps: set.reps,
        repsInReserve,
      }];
    });
    if (sets.length !== item.sets.length || sets.length !== item.completedSets) continue;

    seenIds.add(item.id);
    sessions.push({
      id: item.id,
      planId: item.planId,
      planTitle: item.planTitle,
      dateKey: item.dateKey,
      startedAtMs: item.startedAtMs === null ? null : item.startedAtMs as number,
      completedAtMs: item.completedAtMs,
      completedSets: item.completedSets,
      totalSets: item.totalSets,
      sets,
    });
  }

  return sessions.sort((a, b) => b.completedAtMs - a.completedAtMs).slice(0, 100);
}

function parseRestTimer(value: unknown, nowMs: number): PersistedRestTimer | null {
  if (!isRecord(value) || value.active !== true || typeof value.exerciseName !== 'string' || !value.exerciseName.trim()) {
    return null;
  }
  const startedAtMs = value.startedAtMs;
  const targetSeconds = value.targetSeconds;
  if (!finiteRange(startedAtMs, 0, nowMs + 60_000)) return null;
  if (nowMs - startedAtMs > 8 * 60 * 60 * 1000) return null;
  if (!finiteRange(targetSeconds, 15, 600)) return null;
  return {
    active: true,
    startedAtMs,
    targetSeconds: Math.round(targetSeconds),
    exerciseName: value.exerciseName,
  };
}

export function mergeTrainingPersistedState(
  persisted: unknown,
  defaults: WorkoutPlan[],
  nowMs = Date.now(),
): PersistedTrainingState {
  const record = isRecord(persisted) ? persisted : {};
  const savedPlans = Array.isArray(record.plans) ? record.plans : [];
  const plans = [
    ...defaults.map((plan) => mergePlanProgress(
      plan,
      savedPlans.find((candidate) => isRecord(candidate) && candidate.id === plan.id),
    )),
    ...parseCustomPlans(savedPlans, new Set(defaults.map((plan) => plan.id))),
  ];
  const activePlan = plans.find((plan) => plan.id === record.activePlanId) ?? plans[0];
  const focusedExerciseId = typeof record.focusedExerciseId === 'string' &&
    activePlan?.exercises.some((exercise) => exercise.id === record.focusedExerciseId)
    ? record.focusedExerciseId
    : activePlan?.exercises.find((exercise) => exercise.sets.some((set) => !set.completed))?.id ?? activePlan?.exercises[0]?.id ?? '';
  return {
    plans,
    activePlanId: activePlan?.id ?? '',
    focusedExerciseId,
    restTimer: parseRestTimer(record.restTimer, nowMs),
    sessionStartedAtMs: finiteRange(record.sessionStartedAtMs, 0, nowMs + 60_000) &&
      nowMs - record.sessionStartedAtMs <= 7 * 24 * 60 * 60 * 1000
      ? record.sessionStartedAtMs
      : null,
    completedSessions: parseCompletedSessions(record.completedSessions, nowMs),
  };
}
