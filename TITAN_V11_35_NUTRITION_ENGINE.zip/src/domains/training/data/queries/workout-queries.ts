import type { WorkoutPlan } from '../../domain/entities/workout';

export function findWorkoutPlanById(
  plans: readonly WorkoutPlan[],
  planId: string,
): WorkoutPlan | undefined {
  return plans.find((plan) => plan.id === planId);
}
