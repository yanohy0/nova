import type { WorkoutPlan } from '../../domain/entities/workout';

export function cloneWorkoutPlan(plan: WorkoutPlan): WorkoutPlan {
  return {
    ...plan,
    exercises: plan.exercises.map((ex) => ({
      ...ex,
      muscles: {
        primary: [...ex.muscles.primary],
        secondary: [...ex.muscles.secondary],
      },
      sets: ex.sets.map((s) => ({ ...s })),
    })),
  };
}
