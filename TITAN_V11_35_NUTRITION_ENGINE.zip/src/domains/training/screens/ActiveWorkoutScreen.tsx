import { Button } from '@/src/shared/ui/Button';
import { Surface } from '@/src/shared/ui/Surface';
import { getMuscleLabels } from '@/src/domains/anatomy/application/anatomy-public';
import { completeActiveWorkout } from '../application/complete-workout';
import { focusWorkoutExercise } from '../application/start-workout';
import { useActiveWorkoutProgress } from '../state/selectors';
import { useTrainingSessionStore } from '../state/training-session.store';
import { ExerciseRow } from '../components/ExerciseRow';
import { RestTimer } from '../components/RestTimer';
import { SetEditor } from '../components/SetEditor';
import { WorkoutHeader } from '../components/WorkoutHeader';

interface ActiveWorkoutScreenProps {
  onBack: () => void;
}

export function ActiveWorkoutScreen({ onBack }: ActiveWorkoutScreenProps) {
  const { plan, completedSets, totalSets, percent, calculations } = useActiveWorkoutProgress();
  const focusedExerciseId = useTrainingSessionStore((s) => s.focusedExerciseId);
  const summary = useTrainingSessionStore((s) => s.sessionCompletedSummary);
  const dismissSummary = useTrainingSessionStore((s) => s.dismissSummary);

  const focusedExercise =
    plan.exercises.find((e) => e.id === focusedExerciseId) ?? plan.exercises[0];

  return (
    <div className="space-y-5">
      <WorkoutHeader
        title={plan.title}
        subtitle={`${completedSets} de ${totalSets} séries`}
        percent={percent}
        onBack={onBack}
        onFinish={completeActiveWorkout}
      />

      <Surface elevation={0} className="p-3 sm:p-4">
        <div className="grid grid-cols-3 gap-3">
          <div>
            <p className="text-[10px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)]">Volume com carga externa</p>
            <p className="mt-1 text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)]">
              {calculations.totalVolumeLoadKg.toLocaleString('pt-BR', { maximumFractionDigits: 1 })} kg
            </p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)]">Repetições</p>
            <p className="mt-1 text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)]">{calculations.totalReps}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)]">1RM estimado</p>
            <p className="mt-1 text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)]">
              {focusedExercise && calculations.estimatedOneRepMaxByExercise[focusedExercise.exerciseSlug] !== undefined
                ? `${calculations.estimatedOneRepMaxByExercise[focusedExercise.exerciseSlug]!.toLocaleString('pt-BR', { maximumFractionDigits: 1 })} kg`
                : '—'}
            </p>
            <p className="text-[10px] text-[var(--titan-text-muted)]">{focusedExercise ? focusedExercise.name : 'Registre uma série'}</p>
            {focusedExercise && calculations.oneRepMaxEffortBasisByExercise[focusedExercise.exerciseSlug] && (
              <p className="text-[10px] text-[var(--titan-text-muted)]">
                {calculations.oneRepMaxEffortBasisByExercise[focusedExercise.exerciseSlug] === 'reported_rir'
                  ? 'RIR informado na série de referência'
                  : 'RIR não informado · presume falha'}
              </p>
            )}
          </div>
        </div>
        <p className="mt-2 text-[10px] text-[var(--titan-text-muted)]">1RM é estimado por fórmulas em séries de até 10 repetições. Registre o RIR para melhorar o ajuste; sem ele, o cálculo presume falha e reduz a confiança. Para uma repetição, a carga observada não é necessariamente um máximo real.</p>
      </Surface>

      {summary && (
        <Surface className="p-4 border-[var(--titan-status-success)]/50 bg-[var(--titan-accent-deep)]/25">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">
                Treino concluído · {summary.planTitle}
              </h2>
              <p className="text-xs text-[var(--titan-text-secondary)] mt-1">
                {summary.completedSets} séries registradas · Finalizado às {summary.finishedAtLabel}
              </p>
            </div>
            <Button
              variant="secondary"
              onClick={() => {
                dismissSummary();
                onBack();
              }}
            >
              Fechar
            </Button>
          </div>
        </Surface>
      )}

      <RestTimer />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {focusedExercise && (
          <Surface elevation={2} className="p-4 lg:col-span-7 space-y-4 titan-focus-card">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <div>
                <h2 className="text-lg font-semibold text-[var(--titan-text-primary)]">
                  {focusedExercise.name}
                </h2>
                <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
                  {focusedExercise.equipment} · Primário:{' '}
                  {getMuscleLabels(focusedExercise.muscles.primary).join(', ')}
                </p>
              </div>
              <span className="text-xs text-[var(--titan-text-muted)] font-mono-metric">
                Alvo descanso: {focusedExercise.targetRestSeconds}s
              </span>
            </div>

            <div className="space-y-2.5">
              {focusedExercise.sets.map((s) => (
                <SetEditor key={s.id} exerciseId={focusedExercise.id} setRecord={s} />
              ))}
            </div>
          </Surface>
        )}

        <div className="lg:col-span-5 space-y-2.5">
          <h3 className="titan-card-eyebrow">Sequência do treino</h3>
          {plan.exercises.map((ex) => (
            <ExerciseRow
              key={ex.id}
              exercise={ex}
              isFocused={ex.id === focusedExercise?.id}
              onSelect={focusWorkoutExercise}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
