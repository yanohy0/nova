import { useEffect, useState } from 'react';
import { calculateRestSnapshot } from '../application/calculate-rest';
import { useTrainingSessionStore } from '../state/training-session.store';

export function useRestTimerSnapshot() {
  const restTimer = useTrainingSessionStore((s) => s.restTimer);
  const extendRestTarget = useTrainingSessionStore((s) => s.extendRestTarget);
  const stopRestTimer = useTrainingSessionStore((s) => s.stopRestTimer);
  const [, setTick] = useState(0);

  useEffect(() => {
    if (!restTimer?.active) return;
    const id = window.setInterval(() => {
      setTick((n) => n + 1);
    }, 500);
    return () => window.clearInterval(id);
  }, [restTimer?.active, restTimer?.startedAtMs]);

  const snapshot = restTimer?.active
    ? calculateRestSnapshot(restTimer.startedAtMs, restTimer.targetSeconds)
    : null;

  return {
    restTimer,
    snapshot,
    extendRestTarget,
    stopRestTimer,
  };
}
