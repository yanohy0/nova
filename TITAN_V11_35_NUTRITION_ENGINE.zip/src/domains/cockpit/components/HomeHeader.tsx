import { memo, startTransition, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Calendar,
  CalendarClock,
  Check,
  ChevronDown,
  Flame,
  Layers,
  ShieldCheck,
  SlidersHorizontal,
  Target,
  TrendingUp,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  formatNumericDateBR,
  getFirstRecordDateKey,
  MonthlyCalendar,
  resolveCalendarDay,
} from '@/src/domains/calendar/application/calendar-days';
import { useHydrationStore } from '@/src/domains/hydration/application/hydration-actions';
import { getDailyEnergyIntakeHistory, useNutritionStore } from '@/src/domains/nutrition/application/nutrition-public';
import { sortMeasurementsChronologically, useEvolutionStore } from '@/src/domains/evolution/application/evolution-public';
import {
  ACTIVITY_LEVEL_OPTIONS,
  calculatePhysiologicalGoalTargets,
  estimateAdaptiveTdee,
  GOAL_OPTIONS,
  resolveAutomaticRmrMethod,
  type BiologicalSex,
  type DailyActivityLevel,
  type FitnessGoalType,
  type FatFreeMassSource,
  useProfileStore,
  validateProfileGoals,
} from '@/src/domains/profile/application/profile-public';
import { AnimatePresence, motion, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import { getLocalDateKey } from '@/src/shared/utils/local-date';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { formatKcal, formatMilliliters, parseLocaleNumber } from '@/src/shared/utils/formatters';

function addDaysToDateKey(dateKey: string, days: number): string {
  const [y, m, d] = dateKey.split('-').map(Number);
  const base = new Date(Date.UTC(y!, m! - 1, d!));
  base.setUTCDate(base.getUTCDate() + days);
  return base.toISOString().slice(0, 10);
}

const EMPTY_MARKED_DATE_KEYS = new Set<string>();

const GOAL_META: Record<FitnessGoalType, { icon: typeof Flame; hint: string }> = {
  lose_weight: { icon: Flame, hint: 'Déficit controlado' },
  recomposition: { icon: Layers, hint: 'Troca de composição' },
  maintain: { icon: ShieldCheck, hint: 'Estabilidade calórica' },
  gain_muscle: { icon: TrendingUp, hint: 'Hipertrofia limpa' },
};

const FFM_SOURCE_OPTIONS: Array<{ id: FatFreeMassSource | ''; label: string }> = [
  { id: '', label: 'Não informada' },
  { id: 'dexa', label: 'DXA' },
  { id: 'bod_pod', label: 'Bod Pod' },
  { id: 'isotope_dilution', label: 'Diluição' },
  { id: 'validated_bioimpedance', label: 'Bioimpedância' },
  { id: 'other', label: 'Outra' },
];

interface HomeHeaderProps {
  openGoalsRequestKey?: number;
}

export const HomeHeader = memo(function HomeHeader({ openGoalsRequestKey = 0 }: HomeHeaderProps) {
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [goalsOpen, setGoalsOpen] = useState(false);
  const [deadlinePickerOpen, setDeadlinePickerOpen] = useState(false);
  const [precisionOpen, setPrecisionOpen] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const setActiveDateKey = useNutritionStore((s) => s.setActiveDateKey);
  const meals = useNutritionStore((s) => s.meals);
  const intakeDayConfirmations = useNutritionStore((s) => s.intakeDayConfirmations);
  const evolutionRecords = useEvolutionStore((s) => s.records);
  const latestObservedWeight = useMemo(() => {
    if (evolutionRecords.length === 0) return undefined;
    const sorted = sortMeasurementsChronologically(evolutionRecords);
    return sorted[sorted.length - 1]?.weightKg;
  }, [evolutionRecords]);
  const profile = useProfileStore((s) => s.profile);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const updateProfile = useProfileStore((s) => s.updateProfile);
  const adaptiveTdee = useMemo(
    () => {
      return estimateAdaptiveTdee(getDailyEnergyIntakeHistory(), evolutionRecords, 28, {
        sex: profile.sex, age: profile.age, heightCm: profile.heightCm,
        weightKg: latestObservedWeight ?? profile.currentWeightKg,
        ...(profile.bodyFatPercent !== undefined ? { bodyFatPercent: profile.bodyFatPercent } : {}),
      });
    },
    [meals, intakeDayConfirmations, evolutionRecords, profile.sex, profile.age, profile.heightCm, profile.currentWeightKg, profile.bodyFatPercent, latestObservedWeight],
  );
  const updateDailyGoals = useNutritionStore((s) => s.updateDailyGoals);
  const setReferenceProfileId = useNutritionStore((s) => s.setReferenceProfileId);

  const hydrationEntries = useHydrationStore((s) => s.entries);
  const setDailyGoalMl = useHydrationStore((s) => s.setDailyGoalMl);

  const firstRecordDateKey = useMemo(
    () => getFirstRecordDateKey([
      ...evolutionRecords.map((record) => record.dateKey),
      ...meals.map((meal) => meal.dateKey),
      ...hydrationEntries.map((entry) => entry.dateKey),
    ]),
    [evolutionRecords, meals, hydrationEntries],
  );
  const [draftSex, setDraftSex] = useState<BiologicalSex>(profile.sex);
  const [draftGoal, setDraftGoal] = useState<FitnessGoalType>(profile.goal);
  const [draftCurrentWeight, setDraftCurrentWeight] = useState(
    profileConfigured ? String(profile.currentWeightKg) : '',
  );
  const [draftTargetWeight, setDraftTargetWeight] = useState(
    profileConfigured ? String(profile.targetWeightKg) : '',
  );
  const [draftActivity, setDraftActivity] = useState<DailyActivityLevel>(
    profile.activityLevel,
  );
  const [draftDeadline, setDraftDeadline] = useState(profile.deadlineDateKey);
  const [draftHeight, setDraftHeight] = useState(profileConfigured ? String(profile.heightCm) : '');
  const [draftAge, setDraftAge] = useState(profileConfigured ? String(profile.age) : '');
  const [draftMeasuredRmr, setDraftMeasuredRmr] = useState(profile.measuredRmrKcal === undefined ? '' : String(profile.measuredRmrKcal));
  const [draftBodyFat, setDraftBodyFat] = useState(profile.bodyFatPercent === undefined ? '' : String(profile.bodyFatPercent));
  const [draftFatFreeMassSource, setDraftFatFreeMassSource] = useState<FatFreeMassSource | ''>(profile.fatFreeMassSource ?? '');

  const [todayGreeting, setTodayGreeting] = useState('Visão diária');
  useEffect(() => {
    const hour = new Date().getHours();
    setTodayGreeting(hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite');
  }, []);

  useEffect(() => {
    if (goalsOpen) return;
    setDraftSex(profile.sex);
    setDraftGoal(profile.goal);
    setDraftCurrentWeight(profileConfigured ? String(profile.currentWeightKg) : '');
    setDraftTargetWeight(profileConfigured ? String(profile.targetWeightKg) : '');
    setDraftActivity(profile.activityLevel);
    setDraftDeadline(profile.deadlineDateKey);
    setDraftHeight(profileConfigured ? String(profile.heightCm) : '');
    setDraftAge(profileConfigured ? String(profile.age) : '');
    setDraftMeasuredRmr(profile.measuredRmrKcal === undefined ? '' : String(profile.measuredRmrKcal));
    setDraftBodyFat(profile.bodyFatPercent === undefined ? '' : String(profile.bodyFatPercent));
    setDraftFatFreeMassSource(profile.fatFreeMassSource ?? '');
  }, [profile, profileConfigured, goalsOpen]);

  const activeDay = resolveCalendarDay(activeDateKey);
  const todayKey = getLocalDateKey();
  const contextLabel =
    activeDateKey === todayKey
      ? todayGreeting
      : activeDateKey < todayKey
        ? 'Histórico observado'
        : 'Planejamento futuro';

  const markedDateKeys = useMemo(() => {
    if (!calendarOpen) return EMPTY_MARKED_DATE_KEYS;
    const set = new Set<string>();
    for (const m of meals) {
      if (m.status !== 'planned') set.add(m.dateKey);
    }
    for (const h of hydrationEntries) {
      set.add(h.dateKey);
    }
    for (const record of evolutionRecords) {
      set.add(record.dateKey);
    }
    return set;
  }, [calendarOpen, calendarOpen ? meals : null, calendarOpen ? hydrationEntries : null, calendarOpen ? evolutionRecords : null]);

  const autoRmrSelection = useMemo(
    () =>
      resolveAutomaticRmrMethod({
        age: draftAge.trim() ? parseLocaleNumber(draftAge) : undefined,
        activityLevel: draftActivity,
        bodyFatPercent: draftBodyFat.trim() ? parseLocaleNumber(draftBodyFat) : undefined,
        fatFreeMassSource: draftFatFreeMassSource || undefined,
        measuredRmrKcal: draftMeasuredRmr.trim() ? parseLocaleNumber(draftMeasuredRmr) : undefined,
      }),
    [draftAge, draftActivity, draftBodyFat, draftFatFreeMassSource, draftMeasuredRmr],
  );

  const previewValidation = useMemo(() => {
    if (!goalsOpen) return null;
    return validateProfileGoals({
      sex: draftSex,
      goal: draftGoal,
      currentWeightKg: draftCurrentWeight,
      targetWeightKg: draftTargetWeight,
      activityLevel: draftActivity,
      deadlineDateKey: draftDeadline,
      heightCm: draftHeight,
      age: draftAge,
      measuredRmrKcal: draftMeasuredRmr,
      bodyFatPercent: draftBodyFat,
      fatFreeMassSource: draftFatFreeMassSource || undefined,
    });
  }, [
    goalsOpen,
    draftSex,
    draftGoal,
    draftCurrentWeight,
    draftTargetWeight,
    draftActivity,
    draftDeadline,
    draftHeight,
    draftAge,
    draftMeasuredRmr,
    draftBodyFat,
    draftFatFreeMassSource,
  ]);

  const previewTargets = useMemo(
    () =>
      previewValidation?.ok
        ? calculatePhysiologicalGoalTargets(previewValidation.data, activeDateKey, adaptiveTdee)
        : null,
    [previewValidation, activeDateKey, adaptiveTdee],
  );

  const lastGoalsRequestRef = useRef(openGoalsRequestKey);

  const openGoalsModal = useCallback(() => {
    setDraftSex(profile.sex);
    setDraftGoal(profile.goal);
    setDraftCurrentWeight(latestObservedWeight !== undefined
      ? String(latestObservedWeight)
      : profileConfigured ? String(profile.currentWeightKg) : '');
    setDraftTargetWeight(profileConfigured ? String(profile.targetWeightKg) : '');
    setDraftActivity(profile.activityLevel);
    setDraftDeadline(profile.deadlineDateKey);
    setDraftHeight(profileConfigured ? String(profile.heightCm) : '');
    setDraftAge(profileConfigured ? String(profile.age) : '');
    const nextMeasuredRmr = profile.measuredRmrKcal === undefined ? '' : String(profile.measuredRmrKcal);
    const nextBodyFat = profile.bodyFatPercent === undefined ? '' : String(profile.bodyFatPercent);
    setDraftMeasuredRmr(nextMeasuredRmr);
    setDraftBodyFat(nextBodyFat);
    setDraftFatFreeMassSource(profile.fatFreeMassSource ?? '');
    setDeadlinePickerOpen(false);
    setPrecisionOpen(Boolean(nextBodyFat.trim() || nextMeasuredRmr.trim()));
    setFormError(null);
    setGoalsOpen(true);
  }, [profile, profileConfigured, latestObservedWeight]);

  useEffect(() => {
    if (openGoalsRequestKey > lastGoalsRequestRef.current) {
      lastGoalsRequestRef.current = openGoalsRequestKey;
      openGoalsModal();
    }
  }, [openGoalsRequestKey, openGoalsModal]);

  const saveGoals = () => {
    if (!previewValidation) return;
    if (!previewValidation.ok) {
      setFormError(previewValidation.error);
      return;
    }

    const targets = calculatePhysiologicalGoalTargets(
      previewValidation.data,
      activeDateKey,
      adaptiveTdee,
    );

    updateProfile(previewValidation.data);
    updateDailyGoals({
      kcal: targets.kcal,
      proteinG: targets.proteinG,
      carbsG: targets.carbsG,
      fatG: targets.fatG,
    });
    setDailyGoalMl(targets.waterMl);
    setReferenceProfileId(targets.driProfileId);
    setFormError(null);
    setGoalsOpen(false);
    toast.success('Metas fisiológicas calibradas');
  };

  const activeActivityOption = ACTIVITY_LEVEL_OPTIONS.find((item) => item.id === draftActivity);

  return (
    <>
      <header className="titan-home-header">
        <div className="min-w-0">
          <div className="flex items-center gap-3">
            <span className="titan-brand-wordmark md:hidden">TITAN</span>
            <span className="titan-eyebrow">{contextLabel}</span>
          </div>
          <AnimatePresence mode="wait" initial={false}>
            <motion.p
              key={activeDateKey}
              initial={{ opacity: 0, y: 3 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -3 }}
              transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
              className="titan-home-header-date mt-1 truncate"
            >
              {activeDay.fullLabel}
            </motion.p>
          </AnimatePresence>
        </div>

        <div className="titan-home-header-actions shrink-0">
          <button
            type="button"
            onClick={() => setCalendarOpen(true)}
            aria-label="Selecionar data no calendário"
            aria-expanded={calendarOpen}
            className="min-h-[44px] min-w-[44px] px-3 rounded-2xl bg-[linear-gradient(180deg,rgba(24,33,30,0.92),rgba(13,18,16,0.96))] border border-[var(--titan-border)]/80 shadow-[inset_0_1px_0_rgba(241,240,232,0.06)] text-[var(--titan-text-secondary)] flex items-center justify-center gap-1.5 text-xs font-medium transition-colors hover:border-[var(--titan-champagne)]/45 hover:text-[var(--titan-text-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]/70"
          >
            <Calendar className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">Calendário</span>
          </button>

          <button
            type="button"
            onClick={openGoalsModal}
            aria-label="Configurar metas e variáveis do objetivo"
            aria-expanded={goalsOpen}
            className="min-h-[44px] min-w-[44px] px-3.5 rounded-2xl bg-[linear-gradient(180deg,rgba(28,37,33,0.96),rgba(15,21,18,0.98))] border border-[var(--titan-champagne)]/40 shadow-[inset_0_1px_0_rgba(200,173,122,0.16)] text-[var(--titan-text-primary)] flex items-center justify-center gap-1.5 text-xs font-semibold whitespace-nowrap transition-all hover:border-[var(--titan-champagne)]/70 active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]/70"
          >
            <Target className="w-4 h-4 text-[var(--titan-champagne)] shrink-0" />
            <span>{profileConfigured ? 'Metas' : 'Configurar'}</span>
          </button>
        </div>
      </header>

      {/* Calendário mensal real ancorado no primeiro registro */}
      <BottomSheet
        open={calendarOpen}
        onClose={() => setCalendarOpen(false)}
        eyebrow="Linha temporal"
        title="Calendário"
      >
        <MonthlyCalendar
          selectedDateKey={activeDateKey}
          minDateKey={firstRecordDateKey}
          markedDateKeys={markedDateKeys}
          anchorLabel="Data do primeiro registro"
          onSelectDate={(dateKey) => {
            startTransition(() => setActiveDateKey(dateKey));
            setCalendarOpen(false);
          }}
        />
      </BottomSheet>

      {/* Configurações ultra luxo obsidian + champagne */}
      <BottomSheet
        open={goalsOpen}
        onClose={() => setGoalsOpen(false)}
        animateOpen
        eyebrow="Calibração fisiológica"
        title={profileConfigured ? 'Metas & Perfil' : 'Configurar perfil'}
        subtitle="Parâmetros biométricos e ritmo diário"
        footer={(
          <div className="space-y-2">
            {formError && (
              <p className="text-xs text-[var(--titan-status-error)] px-1" role="alert">
                {formError}
              </p>
            )}
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setGoalsOpen(false)}
                className="min-h-[46px] px-4 rounded-2xl border border-[var(--titan-border)]/80 bg-[var(--titan-bg-canvas)]/70 text-xs font-medium text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)] transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={saveGoals}
                className="titan-button flex-1 !min-h-[46px] !px-5 !rounded-2xl bg-[linear-gradient(180deg,#DFC89B_0%,#C29F5E_52%,#AC894B_100%)] border border-[rgba(255,244,218,0.45)] text-[#090C0B] text-sm font-semibold tracking-tight shadow-[inset_0_1px_0_rgba(255,255,255,0.38),0_8px_24px_rgba(200,173,122,0.26)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-champagne)]"
              >
                Salvar metas
              </button>
            </div>
          </div>
        )}
      >
        <div className="space-y-5">
          {!profileConfigured && (
            <p className="rounded-2xl border border-[var(--titan-champagne)]/35 bg-[rgba(200,173,122,0.06)] px-3.5 py-2.5 text-xs leading-relaxed text-[var(--titan-text-secondary)]" role="note">
              Informe peso, altura e idade reais e confirme sexo, objetivo, movimento e prazo para calibrar as metas.
            </p>
          )}

          {/* Hero Live Telemetry Preview */}
          {previewTargets && (
            <div className="titan-luxury-group p-4 space-y-3 border-[rgba(200,173,122,0.22)]">
              <div className="flex items-baseline justify-between gap-2">
                <div>
                  <span className="titan-eyebrow text-[var(--titan-champagne)]">
                    Meta diária · {autoRmrSelection.label}
                  </span>
                  <div className="mt-1 flex items-baseline gap-1.5">
                    <span className="font-display text-3xl font-semibold tracking-tight text-[var(--titan-text-primary)] font-mono-metric">
                      {formatKcal(previewTargets.kcal)}
                    </span>
                    <span className="text-xs font-medium text-[var(--titan-text-muted)]">kcal</span>
                  </div>
                </div>
                <div className="text-right font-mono-metric text-[11px] text-[var(--titan-text-secondary)]">
                  <div>RMR {formatKcal(previewTargets.restingMetabolicRateKcal)}</div>
                  <div className="text-[var(--titan-text-muted)]">Demais componentes {formatKcal(previewTargets.energyBudget.nonRestingResidualKcal)}</div>
                  <div className="text-[var(--titan-text-muted)]">TDEE {formatKcal(previewTargets.energyBudget.totalDailyExpenditureKcal)}</div>
                  <div className={previewTargets.calorieAdjustmentKcal < 0 ? 'text-[var(--titan-info)]' : 'text-[var(--titan-accent)]'}>
                    Ajuste {previewTargets.calorieAdjustmentKcal > 0 ? '+' : ''}{formatKcal(previewTargets.calorieAdjustmentKcal)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 pt-2.5 border-t border-[rgba(193,204,196,0.10)] text-center font-mono-metric">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Carb</div>
                  <div className="text-xs font-semibold text-[var(--titan-info)] mt-0.5">{previewTargets.carbsG} g</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Prot</div>
                  <div className="text-xs font-semibold text-[var(--titan-accent)] mt-0.5">{previewTargets.proteinG} g</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Gord</div>
                  <div className="text-xs font-semibold text-[var(--titan-champagne)] mt-0.5">{previewTargets.fatG} g</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Água</div>
                  <div className="text-xs font-semibold text-[#38D9D2] mt-0.5">{formatMilliliters(previewTargets.waterMl)}</div>
                </div>
              </div>

              <p className="text-[11px] leading-relaxed text-[var(--titan-text-muted)] pt-0.5">
                O TDEE já considera atividade e treino pela categoria de atividade ou pelo histórico observado. Não some as calorias do treino novamente. “Demais componentes” é o residual estimado (atividade, efeito térmico e incerteza do modelo), não uma medição isolada.
              </p>
              {previewTargets.tdeeSource === 'observed_adaptive' && (
                <p className="text-[11px] text-[var(--titan-text-muted)] pt-0.5">
                  TDEE adaptativo pelo histórico · faixa modelada {formatKcal(previewTargets.tdeeRangeKcal?.lower ?? previewTargets.tdee)}–{formatKcal(previewTargets.tdeeRangeKcal?.upper ?? previewTargets.tdee)} kcal; ainda sem calibração externa.
                </p>
              )}
            </div>
          )}

          {/* Sexo Biológico */}
          <div className="space-y-2">
            <span className="titan-eyebrow block px-0.5">Perfil biológico</span>
            <div className="grid grid-cols-2 gap-2.5" role="group" aria-label="Sexo biológico">
              {(
                [
                  { id: 'male', label: 'Masculino' },
                  { id: 'female', label: 'Feminino' },
                ] as const
              ).map((sexOption) => {
                const active = draftSex === sexOption.id;
                return (
                  <button
                    key={sexOption.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setDraftSex(sexOption.id)}
                    className="titan-luxury-tile min-h-[48px] px-3.5 py-2.5 flex items-center justify-between text-left"
                  >
                    <span className={`text-sm font-medium ${active ? 'text-[var(--titan-text-primary)]' : 'text-[var(--titan-text-secondary)]'}`}>
                      {sexOption.label}
                    </span>
                    <span
                      className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                        active
                          ? 'border-[var(--titan-champagne)] bg-[var(--titan-champagne)] text-[#0A0E0C]'
                          : 'border-[var(--titan-border)] bg-transparent text-transparent'
                      }`}
                      aria-hidden="true"
                    >
                      <Check className="w-3 h-3 stroke-[2.5]" />
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Objetivo Principal */}
          <div className="space-y-2">
            <span className="titan-eyebrow block px-0.5">Direção estratégica</span>
            <div className="grid grid-cols-2 gap-2.5" role="group" aria-label="Objetivo principal">
              {GOAL_OPTIONS.map((opt) => {
                const active = draftGoal === opt.id;
                const meta = GOAL_META[opt.id];
                const Icon = meta.icon;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setDraftGoal(opt.id)}
                    className="titan-luxury-tile min-h-[64px] p-3 flex flex-col justify-between text-left"
                  >
                    <div className="flex items-center justify-between gap-2 w-full">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          active ? 'text-[var(--titan-champagne)]' : 'text-[var(--titan-text-muted)]'
                        }`}
                        aria-hidden="true"
                      />
                      {active && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[var(--titan-champagne)]" aria-hidden="true" />
                      )}
                    </div>
                    <div className="mt-2">
                      <div className={`text-xs font-semibold leading-tight ${active ? 'text-[var(--titan-text-primary)]' : 'text-[var(--titan-text-secondary)]'}`}>
                        {opt.label}
                      </div>
                      <div className="text-[11px] text-[var(--titan-text-muted)] mt-0.5 leading-tight">
                        {meta.hint}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Biometria de Precisão em bloco inset hairline */}
          <div className="space-y-2">
            <span className="titan-eyebrow block px-0.5">Biometria</span>
            <div className="titan-luxury-group grid grid-cols-2 divide-x divide-y divide-[rgba(193,204,196,0.10)]">
              <label className="block px-3.5 py-2.5 focus-within:bg-[rgba(200,173,122,0.04)] transition-colors">
                <span className="block text-[11px] text-[var(--titan-text-muted)]">Peso atual</span>
                <div className="mt-1 flex items-baseline gap-1">
                  <input
                    type="number"
                    step="0.1"
                    inputMode="decimal"
                    placeholder="75.0"
                    value={draftCurrentWeight}
                    onChange={(e) => setDraftCurrentWeight(e.target.value)}
                    className="w-full min-h-[34px] bg-transparent text-base font-mono-metric font-semibold text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)]/50 focus:outline-none"
                  />
                  <span className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] shrink-0">kg</span>
                </div>
              </label>

              <label className="block px-3.5 py-2.5 focus-within:bg-[rgba(200,173,122,0.04)] transition-colors">
                <span className="block text-[11px] text-[var(--titan-text-muted)]">Peso meta</span>
                <div className="mt-1 flex items-baseline gap-1">
                  <input
                    type="number"
                    step="0.1"
                    inputMode="decimal"
                    placeholder="72.0"
                    value={draftTargetWeight}
                    onChange={(e) => setDraftTargetWeight(e.target.value)}
                    className="w-full min-h-[34px] bg-transparent text-base font-mono-metric font-semibold text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)]/50 focus:outline-none"
                  />
                  <span className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] shrink-0">kg</span>
                </div>
              </label>

              <label className="block px-3.5 py-2.5 focus-within:bg-[rgba(200,173,122,0.04)] transition-colors">
                <span className="block text-[11px] text-[var(--titan-text-muted)]">Altura</span>
                <div className="mt-1 flex items-baseline gap-1">
                  <input
                    type="number"
                    inputMode="numeric"
                    placeholder="178"
                    value={draftHeight}
                    onChange={(e) => setDraftHeight(e.target.value)}
                    className="w-full min-h-[34px] bg-transparent text-base font-mono-metric font-semibold text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)]/50 focus:outline-none"
                  />
                  <span className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] shrink-0">cm</span>
                </div>
              </label>

              <label className="block px-3.5 py-2.5 focus-within:bg-[rgba(200,173,122,0.04)] transition-colors">
                <span className="block text-[11px] text-[var(--titan-text-muted)]">Idade</span>
                <div className="mt-1 flex items-baseline gap-1">
                  <input
                    type="number"
                    inputMode="numeric"
                    placeholder="28"
                    value={draftAge}
                    onChange={(e) => setDraftAge(e.target.value)}
                    className="w-full min-h-[34px] bg-transparent text-base font-mono-metric font-semibold text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)]/50 focus:outline-none"
                  />
                  <span className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] shrink-0">anos</span>
                </div>
              </label>
            </div>
          </div>

          {/* Movimento Diário com barras de intensidade */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2 px-0.5">
              <span className="titan-eyebrow">Movimento diário</span>
              {activeActivityOption && (
                <span className="text-[11px] font-medium text-[var(--titan-champagne)]">
                  {activeActivityOption.label}
                </span>
              )}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
              {ACTIVITY_LEVEL_OPTIONS.map((option, index) => {
                const active = draftActivity === option.id;
                const levelBars = index + 1;
                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setDraftActivity(option.id)}
                    aria-pressed={active}
                    className="titan-luxury-tile min-h-[52px] px-2.5 py-2 flex flex-col items-center justify-center gap-1.5 text-center"
                  >
                    <div className="flex items-end gap-[2.5px] h-3" aria-hidden="true">
                      {[1, 2, 3, 4, 5].map((bar) => (
                        <span
                          key={bar}
                          className={`w-[3px] rounded-full transition-colors ${
                            bar <= levelBars
                              ? active
                                ? 'bg-[var(--titan-champagne)]'
                                : 'bg-[var(--titan-text-secondary)]/55'
                              : 'bg-[var(--titan-border)]/45'
                          }`}
                          style={{ height: `${bar * 2 + 2}px` }}
                        />
                      ))}
                    </div>
                    <span className={`text-[11px] leading-none ${active ? 'text-[var(--titan-text-primary)] font-semibold' : 'text-[var(--titan-text-secondary)]'}`}>
                      {option.label}
                    </span>
                  </button>
                );
              })}
            </div>
            {activeActivityOption && (
              <p className="text-[11px] text-[var(--titan-text-muted)] leading-snug px-0.5">
                {activeActivityOption.description}
              </p>
            )}
          </div>

          {/* Horizonte / Prazo */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2 px-0.5">
              <span className="titan-eyebrow">Horizonte da meta</span>
              <div className="flex items-center gap-1.5">
                {[30, 90, 180].map((days) => {
                  const presetKey = addDaysToDateKey(getLocalDateKey(), days);
                  const active = draftDeadline === presetKey;
                  return (
                    <button
                      key={days}
                      type="button"
                      onClick={() => {
                        setDraftDeadline(presetKey);
                        setDeadlinePickerOpen(false);
                      }}
                      className={`min-h-[32px] rounded-xl px-2.5 text-[11px] font-mono-metric border transition-colors ${
                        active
                          ? 'border-[var(--titan-champagne)]/75 bg-[rgba(200,173,122,0.14)] text-[var(--titan-champagne)] font-semibold'
                          : 'border-[var(--titan-border-subtle)] bg-[var(--titan-bg-canvas)]/70 text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]'
                      }`}
                    >
                      +{days}d
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="titan-luxury-group overflow-hidden">
              <button
                type="button"
                onClick={() => setDeadlinePickerOpen((v) => !v)}
                aria-expanded={deadlinePickerOpen}
                className="w-full min-h-[48px] px-3.5 text-sm text-[var(--titan-text-primary)] flex items-center justify-between gap-2 hover:bg-[rgba(241,240,232,0.02)] transition-colors"
              >
                <span className="flex items-center gap-2.5 font-mono-metric">
                  <CalendarClock className="w-4 h-4 text-[var(--titan-champagne)]" />
                  <span>{formatNumericDateBR(draftDeadline)}</span>
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-[var(--titan-text-muted)] transition-transform ${
                    deadlinePickerOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              <AnimatePresence initial={false}>
                {deadlinePickerOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
                    className="overflow-hidden"
                  >
                    <div className="p-3 border-t border-[rgba(193,204,196,0.10)] bg-[#0A0E0C]/80">
                      <MonthlyCalendar
                        selectedDateKey={draftDeadline}
                        minDateKey={getLocalDateKey()}
                        anchorLabel="Início"
                        onSelectDate={(dateKey) => {
                          setDraftDeadline(dateKey);
                          setDeadlinePickerOpen(false);
                        }}
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Refinar Precisão (Composição / Calorimetria) */}
          <div className="titan-luxury-group overflow-hidden">
            <button
              type="button"
              onClick={() => setPrecisionOpen((v) => !v)}
              aria-expanded={precisionOpen}
              className="w-full min-h-[48px] px-3.5 flex items-center justify-between gap-2 text-left hover:bg-[rgba(241,240,232,0.02)] transition-colors"
            >
              <span className="flex items-center gap-2 text-xs font-semibold text-[var(--titan-text-primary)]">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[var(--titan-champagne)]" />
                <span>Refinar precisão</span>
              </span>
              <span className="flex items-center gap-2">
                <span className="font-mono-metric text-[11px] font-medium text-[var(--titan-accent)]">
                  Auto: {autoRmrSelection.label}
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-[var(--titan-text-muted)] transition-transform ${
                    precisionOpen ? 'rotate-180' : ''
                  }`}
                />
              </span>
            </button>

            <AnimatePresence initial={false}>
              {precisionOpen && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
                  className="overflow-hidden"
                >
                  <div className="px-3.5 pb-3.5 pt-2.5 border-t border-[rgba(193,204,196,0.10)] space-y-3.5">
                    <p className="text-[11px] text-[var(--titan-text-muted)] leading-relaxed">
                      {autoRmrSelection.reason}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <label className="block rounded-xl border border-[var(--titan-border)]/75 bg-[#0A0E0C]/80 px-3 py-2">
                        <span className="block text-[11px] text-[var(--titan-text-muted)]">Gordura corporal (%)</span>
                        <input
                          type="number"
                          min="2"
                          max="70"
                          step="0.1"
                          inputMode="decimal"
                          value={draftBodyFat}
                          onChange={(e) => setDraftBodyFat(e.target.value)}
                          placeholder="Opcional"
                          className="mt-1 w-full min-h-[32px] bg-transparent text-sm font-mono-metric text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)]/55 focus:outline-none"
                        />
                      </label>

                      <label className="block rounded-xl border border-[var(--titan-border)]/75 bg-[#0A0E0C]/80 px-3 py-2">
                        <span className="block text-[11px] text-[var(--titan-text-muted)]">RMR medido (kcal/dia)</span>
                        <input
                          type="number"
                          min="300"
                          max="5000"
                          step="1"
                          inputMode="numeric"
                          value={draftMeasuredRmr}
                          onChange={(e) => setDraftMeasuredRmr(e.target.value)}
                          placeholder="Calorimetria"
                          className="mt-1 w-full min-h-[32px] bg-transparent text-sm font-mono-metric text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)]/55 focus:outline-none"
                        />
                      </label>
                    </div>

                    <div className="space-y-1.5">
                      <span className="block text-[11px] text-[var(--titan-text-muted)]">Origem da medição corporal</span>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                        {FFM_SOURCE_OPTIONS.map((src) => {
                          const active = draftFatFreeMassSource === src.id;
                          return (
                            <button
                              key={src.id || 'none'}
                              type="button"
                              aria-pressed={active}
                              onClick={() => setDraftFatFreeMassSource(src.id)}
                              className="titan-luxury-tile min-h-[38px] px-2.5 text-[11px] font-medium text-center truncate"
                            >
                              <span className={active ? 'text-[var(--titan-text-primary)]' : 'text-[var(--titan-text-secondary)]'}>
                                {src.label}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </BottomSheet>
    </>
  );
});
