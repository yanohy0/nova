import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import {
  computeDailyMacroAndEnergyBreakdown,
  type MealConsumptionStatus,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import {
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '@/src/shared/graphics/fluid-shader-engine';
import { motion, stepRK4Spring, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { formatKcal } from '@/src/shared/utils/formatters';

type MacroKey = 'carbs' | 'protein' | 'fat';

interface MetallicTheme {
  metalPreset: 'silver' | 'chromium' | 'gold';
  metalRgb: [number, number, number];
  highlightRgb: [number, number, number];
  fallbackColor: string;
}

const MACRO_METALS: Record<MacroKey, MetallicTheme> = {
  carbs: {
    metalPreset: 'silver',
    metalRgb: [0.22, 0.58, 0.98],
    highlightRgb: [0.84, 0.95, 1.00],
    fallbackColor: '#76B0F0',
  },
  protein: {
    metalPreset: 'chromium',
    metalRgb: [0.18, 0.72, 0.48],
    highlightRgb: [0.80, 1.00, 0.90],
    fallbackColor: '#66C898',
  },
  fat: {
    metalPreset: 'gold',
    metalRgb: [0.88, 0.70, 0.36],
    highlightRgb: [1.00, 0.96, 0.80],
    fallbackColor: '#D8BA7E',
  },
};

const MACRO_META: Record<MacroKey, { label: string; field: 'carbsG' | 'proteinG' | 'fatG'; color: string }> = {
  carbs: { label: 'Carboidratos', field: 'carbsG', color: MACRO_METALS.carbs.fallbackColor },
  protein: { label: 'Proteínas', field: 'proteinG', color: MACRO_METALS.protein.fallbackColor },
  fat: { label: 'Gorduras', field: 'fatG', color: MACRO_METALS.fat.fallbackColor },
};

const MACRO_TABS: MacroKey[] = ['carbs', 'protein', 'fat'];

const MEAL_STATUS_LABELS: Record<MealConsumptionStatus, string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

const GAUGE_W = 116;
const GAUGE_H = 68;
const INTERPOLATION_TIME_CONSTANT_SECONDS = 0.14;
const MACRO_GRAMS_FORMATTER = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 0 });
const MACRO_FINE_GRAMS_FORMATTER = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 });

function formatMacroGrams(amount: number): string {
  if (amount > 0 && amount < 0.05) return '<0,1 g';
  const formatter = amount > 0 && amount < 10
    ? MACRO_FINE_GRAMS_FORMATTER
    : MACRO_GRAMS_FORMATTER;
  return `${formatter.format(amount)} g`;
}

function useSpringRounded(targetValue: number): number {
  const safeTarget = Number.isFinite(targetValue) ? Math.max(0, targetValue) : 0;
  const [displayValue, setDisplayValue] = useState(() => Math.round(safeTarget));
  const springRef = useRef({ value: safeTarget, velocity: 0 });
  const lastRoundedRef = useRef(Math.round(safeTarget));

  useEffect(() => {
    if (typeof window === 'undefined' || prefersReducedMotion()) {
      springRef.current.value = safeTarget;
      springRef.current.velocity = 0;
      const rounded = Math.round(safeTarget);
      if (lastRoundedRef.current !== rounded) {
        lastRoundedRef.current = rounded;
        setDisplayValue(rounded);
      }
      return;
    }

    if (
      Math.abs(safeTarget - springRef.current.value) < 0.35 &&
      Math.abs(springRef.current.velocity) < 0.5
    ) {
      springRef.current.value = safeTarget;
      springRef.current.velocity = 0;
      const rounded = Math.round(safeTarget);
      if (lastRoundedRef.current !== rounded) {
        lastRoundedRef.current = rounded;
        setDisplayValue(rounded);
      }
      return;
    }

    let rafId = 0;
    let lastAt = performance.now();

    const tick = (now: number) => {
      const dt = Math.min(0.033, Math.max(0.002, (now - lastAt) / 1000));
      lastAt = now;
      stepRK4Spring(springRef.current, safeTarget, 220, 24, dt);

      const settled =
        Math.abs(safeTarget - springRef.current.value) < 0.35 &&
        Math.abs(springRef.current.velocity) < 0.5;
      if (settled) {
        springRef.current.value = safeTarget;
        springRef.current.velocity = 0;
      }

      const rounded = Math.round(springRef.current.value);
      if (rounded !== lastRoundedRef.current) {
        lastRoundedRef.current = rounded;
        setDisplayValue(rounded);
      }
      if (!settled) {
        rafId = window.requestAnimationFrame(tick);
      }
    };

    rafId = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(rafId);
  }, [safeTarget]);

  return displayValue;
}

interface MacroGaugeProps {
  label: string;
  consumedG: number;
  goalG: number;
  plannedRemainingG?: number;
  metal: MetallicTheme;
  isSelected: boolean;
  onSelect: () => void;
}

function drawMacroFallback(
  canvas: HTMLCanvasElement,
  ratio: number,
  color: string,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const pixelWidth = Math.round(GAUGE_W * dpr);
  const pixelHeight = Math.round(GAUGE_H * dpr);
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, GAUGE_W, GAUGE_H);

  const cx = GAUGE_W * 0.5;
  const cy = 59;
  const radius = 45;
  ctx.lineCap = 'round';
  ctx.lineWidth = 10.5;
  ctx.strokeStyle = 'rgba(220, 236, 228, 0.14)';
  ctx.beginPath();
  ctx.arc(cx, cy, radius, Math.PI, 0, false);
  ctx.stroke();

  ctx.lineWidth = 8.5;
  ctx.strokeStyle = 'rgba(8, 15, 13, 0.85)';
  ctx.beginPath();
  ctx.arc(cx, cy, radius, Math.PI, 0, false);
  ctx.stroke();

  if (ratio > 0) {
    const gradient = ctx.createLinearGradient(0, 10, 0, 56);
    gradient.addColorStop(0, '#FFFFFF');
    gradient.addColorStop(0.24, color);
    gradient.addColorStop(0.58, `${color}88`);
    gradient.addColorStop(0.84, color);
    gradient.addColorStop(1, '#F8FBF9');
    ctx.lineWidth = 9;
    ctx.strokeStyle = gradient;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, Math.PI, Math.PI * (1 + ratio), false);
    ctx.stroke();

    // Flowing metallic core sheen matching the macro color
    ctx.lineWidth = 3.2;
    ctx.strokeStyle = `${color}cc`;
    ctx.beginPath();
    ctx.arc(cx, cy, radius - 0.8, Math.PI, Math.PI * (1 + ratio), false);
    ctx.stroke();
  }

  // Dark-field crystal borosilicate bevel without cyan wash
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.44)';
  ctx.beginPath();
  ctx.arc(cx, cy, radius + 3.4, Math.PI * 1.08, Math.PI * 1.92, false);
  ctx.stroke();

  ctx.lineWidth = 1.0;
  ctx.strokeStyle = 'rgba(230, 234, 238, 0.24)';
  ctx.beginPath();
  ctx.arc(cx, cy, radius - 3.6, Math.PI * 1.12, Math.PI * 1.88, false);
  ctx.stroke();
}

const MacroSemicircle = memo(function MacroSemicircle({
  label,
  consumedG,
  goalG,
  metal,
  isSelected,
  onSelect,
}: MacroGaugeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const safeConsumed = Number.isFinite(consumedG) ? Math.max(0, consumedG) : 0;
  const hasValidGoal = Number.isFinite(goalG) && goalG > 0;
  const safeGoal = hasValidGoal ? goalG : 1;
  const ratio = hasValidGoal
    ? Math.min(1, Math.max(0, safeConsumed / safeGoal))
    : 0;
  const percent = hasValidGoal ? Math.round((safeConsumed / safeGoal) * 100) : 0;
  const progressValue = Math.min(100, Math.max(0, percent));
  const remaining = hasValidGoal ? Math.max(0, safeGoal - safeConsumed) : 0;
  const excess = hasValidGoal ? Math.max(0, safeConsumed - safeGoal) : 0;
  const statusAriaDetail = !hasValidGoal
    ? 'meta não definida'
    : excess > 0.0001
      ? `${formatMacroGrams(excess)} acima da meta`
      : remaining > 0.0001
        ? `${formatMacroGrams(remaining)} restantes`
        : 'meta atingida';

  const targetRatioRef = useRef(ratio);
  const currentRatioRef = useRef(ratio);
  const lastFrameAtRef = useRef(0);
  const metalRef = useRef(metal);
  const tiltRef = useRef<[number, number]>([0, 0]);
  const tiltTargetRef = useRef<[number, number]>([0, 0]);
  const isVisibleRef = useRef(true);
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);
  const animatedGrams = useSpringRounded(safeConsumed);

  useEffect(() => {
    targetRatioRef.current = ratio;
    metalRef.current = metal;
    const engine = getSharedFluidEngine();

    if (
      typeof window !== 'undefined' &&
      prefersReducedMotion()
    ) {
      currentRatioRef.current = ratio;
      lastFrameAtRef.current = 0;
      if (providerRef.current) {
        const rendered = engine.renderSinglePass(providerRef.current);
        if (!rendered && canvasRef.current) {
          drawMacroFallback(canvasRef.current, ratio, metal.fallbackColor);
        }
      }
      return;
    }

    lastFrameAtRef.current = 0;
    if (providerRef.current) {
      const rendered = engine.renderSinglePass(providerRef.current);
      if (!rendered && canvasRef.current) {
        drawMacroFallback(canvasRef.current, ratio, metal.fallbackColor);
      }
      if (!prefersReducedMotion() && Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005) {
        engine.wake();
      }
    }
  }, [ratio, metal]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = getSharedFluidEngine();

    const provider = (): FluidDrawJob | null => {
      const now = performance.now();
      const elapsed = lastFrameAtRef.current
        ? Math.min(0.05, Math.max(0, (now - lastFrameAtRef.current) / 1000))
        : 1 / 60;
      lastFrameAtRef.current = now;

      const motionAllowed = typeof window === 'undefined' ? false : !prefersReducedMotion();
      currentRatioRef.current = motionAllowed
        ? interpolateRatio(
            currentRatioRef.current,
            targetRatioRef.current,
            elapsed,
            INTERPOLATION_TIME_CONSTANT_SECONDS,
          )
        : targetRatioRef.current;
      const isInterpolating =
        Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005;
      if (motionAllowed) {
        // The pointer only changes the target. A short exponential spring preserves
        // the glass parallax while allowing the shared renderer to sleep when settled.
        const tiltAlpha = 1 - Math.exp(-elapsed / 0.085);
        tiltRef.current[0] += (tiltTargetRef.current[0] - tiltRef.current[0]) * tiltAlpha;
        tiltRef.current[1] += (tiltTargetRef.current[1] - tiltRef.current[1]) * tiltAlpha;
        if (Math.abs(tiltTargetRef.current[0] - tiltRef.current[0]) < 0.0005) {
          tiltRef.current[0] = tiltTargetRef.current[0];
        }
        if (Math.abs(tiltTargetRef.current[1] - tiltRef.current[1]) < 0.0005) {
          tiltRef.current[1] = tiltTargetRef.current[1];
        }
      } else {
        tiltRef.current = [0, 0];
        tiltTargetRef.current = [0, 0];
      }
      const isTiltSettling =
        Math.abs(tiltTargetRef.current[0] - tiltRef.current[0]) > 0.0005 ||
        Math.abs(tiltTargetRef.current[1] - tiltRef.current[1]) > 0.0005;
      return {
        kind: 'metal',
        targetCanvas: canvas,
        width: GAUGE_W,
        height: GAUGE_H,
        fill: currentRatioRef.current,
        tilt: motionAllowed ? tiltRef.current : [0, 0],
        // Static metal is drawn once; only a value transition or pointer parallax runs RAF.
        isAnimating: isInterpolating || isTiltSettling,
        metalColor: metalRef.current.metalRgb,
        metalHighlight: metalRef.current.highlightRgb,
        metalPreset: metalRef.current.metalPreset,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const renderCurrent = () => {
      const rendered = engine.renderSinglePass(provider);
      if (!rendered) {
        drawMacroFallback(canvas, currentRatioRef.current, metalRef.current.fallbackColor);
      }
    };

    const intersectionObserver =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                renderCurrent();
                if (
                  !prefersReducedMotion() &&
                  (Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005 ||
                    Math.abs(tiltTargetRef.current[0] - tiltRef.current[0]) > 0.0005 ||
                    Math.abs(tiltTargetRef.current[1] - tiltRef.current[1]) > 0.0005)
                ) {
                  engine.wake();
                }
              }
            },
            { threshold: 0.05 },
          )
        : null;
    intersectionObserver?.observe(canvas);

    renderCurrent();
    const unsubscribe = engine.subscribe(provider, true);
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handleMotionPreference = (event: MediaQueryListEvent) => {
      if (event.matches) {
        currentRatioRef.current = targetRatioRef.current;
        lastFrameAtRef.current = 0;
        renderCurrent();
      } else if (
        isVisibleRef.current &&
        (Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005 ||
          Math.abs(tiltTargetRef.current[0] - tiltRef.current[0]) > 0.0005 ||
          Math.abs(tiltTargetRef.current[1] - tiltRef.current[1]) > 0.0005)
      ) {
        lastFrameAtRef.current = 0;
        engine.wake();
      }
    };
    motionQuery.addEventListener('change', handleMotionPreference);

    return () => {
      providerRef.current = null;
      unsubscribe();
      intersectionObserver?.disconnect();
      motionQuery.removeEventListener('change', handleMotionPreference);
    };
  }, []);

  const valueText = hasValidGoal
    ? `${formatMacroGrams(safeConsumed)} de ${formatMacroGrams(safeGoal)}; ${percent}% da meta; ${statusAriaDetail}`
    : `${formatMacroGrams(safeConsumed)} consumidos; meta não definida`;

  return (
    <div
      data-selected={isSelected ? 'true' : 'false'}
      className="titan-macro-glass-tile px-1.5 py-2.5"
    >
      <button
        type="button"
        onClick={onSelect}
        onPointerMove={(e) => {
          if (prefersReducedMotion()) return;
          const r = e.currentTarget.getBoundingClientRect();
          if (r.width <= 0 || r.height <= 0) return;
          const nx = ((e.clientX - r.left) / r.width - 0.5) * 0.5;
          const ny = ((e.clientY - r.top) / r.height - 0.5) * 0.5;
          tiltTargetRef.current = [nx, -ny];
          getSharedFluidEngine().wake();
        }}
        onPointerLeave={() => {
          tiltTargetRef.current = [0, 0];
          if (!prefersReducedMotion()) getSharedFluidEngine().wake();
        }}
        aria-label={`Detalhar ${label}: ${valueText}`}
        className="absolute inset-0 z-[1] rounded-[18px] cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
      />
      <div
        className="pointer-events-none relative flex flex-col items-center text-center"
        role={hasValidGoal ? 'progressbar' : 'group'}
        aria-label={
          hasValidGoal
            ? label
            : `${label}: ${formatMacroGrams(safeConsumed)} consumidos; meta não definida`
        }
        aria-valuemin={hasValidGoal ? 0 : undefined}
        aria-valuemax={hasValidGoal ? 100 : undefined}
        aria-valuenow={hasValidGoal ? progressValue : undefined}
        aria-valuetext={hasValidGoal ? valueText : undefined}
      >
        <div className="relative w-[100px] sm:w-[112px] h-[58px] sm:h-[65px] flex items-end justify-center">
          <canvas
            ref={canvasRef}
            width={GAUGE_W}
            height={GAUGE_H}
            className="w-[100px] sm:w-[112px] h-[58px] sm:h-[65px] block drop-shadow-[0_6px_14px_rgba(0,0,0,0.48)]"
            aria-hidden="true"
          />

          <span
            aria-hidden="true"
            className={`absolute bottom-0.5 text-base sm:text-xl font-semibold font-mono-metric leading-none tabular-nums ${
              safeConsumed <= 0 ? 'text-[var(--titan-text-muted)]' : 'text-[var(--titan-text-primary)]'
            }`}
          >
            {animatedGrams} g
          </span>
        </div>

        <span
          aria-hidden="true"
          className="mt-1.5 text-xs font-semibold tracking-tight"
          style={{ color: metal.fallbackColor }}
        >
          {label}
        </span>

        <span aria-hidden="true" className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] mt-0.5 tabular-nums">
          {hasValidGoal ? formatMacroGrams(safeGoal) : '—'}
        </span>
      </div>
    </div>
  );
});

interface MacroDetailSheetProps {
  selectedMacro: MacroKey;
  onSelectMacro: (macro: MacroKey) => void;
  onClose: () => void;
  values: Record<MacroKey, { consumedG: number; goalG: number; plannedRemainingG: number }>;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

function MacroDetailSheet({
  selectedMacro,
  onSelectMacro,
  onClose,
  values,
  onOpenNutrition,
}: MacroDetailSheetProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);

  const breakdown = useMemo(
    () => computeDailyMacroAndEnergyBreakdown(meals, activeDateKey),
    [meals, activeDateKey],
  );

  const meta = MACRO_META[selectedMacro];
  const activeStats = values[selectedMacro];
  const hasValidGoal = Number.isFinite(activeStats.goalG) && activeStats.goalG > 0;
  const safeConsumed = Number.isFinite(activeStats.consumedG) ? Math.max(0, activeStats.consumedG) : 0;
  const ratio = hasValidGoal ? Math.min(1, Math.max(0, safeConsumed / activeStats.goalG)) : 0;
  const percent = hasValidGoal ? Math.round((safeConsumed / activeStats.goalG) * 100) : 0;
  const remaining = hasValidGoal ? Math.max(0, activeStats.goalG - safeConsumed) : 0;
  const excess = hasValidGoal ? Math.max(0, safeConsumed - activeStats.goalG) : 0;
  const plannedTotalG = breakdown.plannedTotals[meta.field];

  const topFoods = useMemo(
    () =>
      [...breakdown.consumedFoods]
        .filter((f) => f.macros[meta.field] > 0)
        .sort((a, b) => b.macros[meta.field] - a.macros[meta.field]),
    [breakdown.consumedFoods, meta.field],
  );

  return (
    <BottomSheet
      open
      onClose={onClose}
      animateOpen
      title={meta.label}
      subtitle="Consumido vs meta e distribuição pelas refeições do dia"
    >
      <div className="space-y-4">
        <div className="titan-segmented w-full grid grid-cols-3" role="tablist" aria-label="Selecionar macronutriente">
          {MACRO_TABS.map((key) => {
            const tabMeta = MACRO_META[key];
            const active = key === selectedMacro;
            return (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={active}
                aria-pressed={active}
                onClick={() => onSelectMacro(key)}
                className="titan-segment text-xs"
              >
                {tabMeta.label}
              </button>
            );
          })}
        </div>

        <div className="titan-luxury-group p-3.5 space-y-3">
          <div className="flex items-baseline justify-between gap-2">
            <div>
              <div className="text-[11px] uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
                Consumido
              </div>
              <div className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)]">
                {formatMacroGrams(safeConsumed)}
              </div>
            </div>
            <div className="text-right font-mono-metric">
              <div className="text-xs font-semibold" style={{ color: meta.color }}>
                {hasValidGoal ? `${percent}% da meta` : 'Meta não definida'}
              </div>
              <div className="text-xs text-[var(--titan-text-muted)]">
                {hasValidGoal ? `Meta: ${formatMacroGrams(activeStats.goalG)}` : 'Configure em Metas'}
              </div>
            </div>
          </div>

          <div className="h-2 w-full rounded-full bg-[var(--titan-track)] overflow-hidden">
            <motion.div
              className="h-full w-full rounded-full origin-left"
              style={{ backgroundColor: meta.color }}
              initial={false}
              animate={{ scaleX: ratio }}
              transition={{ duration: TITAN_DURATIONS.progress, ease: TITAN_EASE }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1 text-center font-mono-metric text-xs">
            <div>
              <div className="text-[11px] text-[var(--titan-text-muted)]">
                {excess > 0.0001 ? 'Excedente' : 'Restante'}
              </div>
              <div className="font-semibold text-[var(--titan-text-primary)] mt-0.5">
                {!hasValidGoal ? '—' : excess > 0.0001 ? `+${formatMacroGrams(excess)}` : formatMacroGrams(remaining)}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-[var(--titan-text-muted)]">Planejado</div>
              <div className="font-semibold text-[var(--titan-text-secondary)] mt-0.5">
                {formatMacroGrams(plannedTotalG)}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-[var(--titan-text-muted)]">A consumir</div>
              <div className="font-semibold text-[var(--titan-accent)] mt-0.5">
                {activeStats.plannedRemainingG > 0 ? `+${formatMacroGrams(activeStats.plannedRemainingG)}` : '0 g'}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Por refeição
          </h3>
          {breakdown.meals.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">Nenhuma refeição programada nesta data.</p>
          ) : (
            <div className="titan-luxury-group divide-y divide-[rgba(193,204,196,0.08)] px-3">
              {breakdown.meals.map((meal) => (
                <div key={meal.mealId} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {meal.time} · {meal.title}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)]">
                      {MEAL_STATUS_LABELS[meal.status]} · planejado {formatMacroGrams(meal.planned[meta.field])}
                    </div>
                  </div>
                  <span
                    className={`font-mono-metric font-semibold shrink-0 ${
                      meal.isRecorded ? 'text-[var(--titan-text-primary)]' : 'text-[var(--titan-text-muted)]'
                    }`}
                  >
                    {meal.isRecorded ? formatMacroGrams(meal.consumed[meta.field]) : '0 g reg.'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Alimentos que mais contribuíram
          </h3>
          {topFoods.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhum alimento registrado ainda para este macronutriente.
            </p>
          ) : (
            <div className="titan-luxury-group max-h-48 overflow-y-auto divide-y divide-[rgba(193,204,196,0.08)] px-3">
              {topFoods.map((food, idx) => (
                <div key={`${food.mealId}-${food.foodId}-${idx}`} className="py-2 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {food.foodName}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)] truncate">
                      {food.mealTitle} · {food.quantityG} g · {formatKcal(Math.round(food.macros.kcal))} kcal
                    </div>
                  </div>
                  <span className="font-mono-metric font-semibold shrink-0" style={{ color: meta.color }}>
                    {formatMacroGrams(food.macros[meta.field])}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {onOpenNutrition && (
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenNutrition('cardapio');
            }}
            className="titan-button titan-button--mineral w-full !min-h-[44px] !text-xs"
          >
            <span>Ajustar refeições no Cardápio</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        )}
      </div>
    </BottomSheet>
  );
}

interface MacroOverviewProps {
  carbsG: number;
  proteinG: number;
  fatG: number;
  goals: {
    carbsG: number;
    proteinG: number;
    fatG: number;
  };
  plannedRemaining?: {
    carbsG: number;
    proteinG: number;
    fatG: number;
  };
  isEstimatedGoal?: boolean;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

export const MacroOverview = memo(function MacroOverview({
  carbsG,
  proteinG,
  fatG,
  goals,
  plannedRemaining,
  onOpenNutrition,
}: MacroOverviewProps) {
  const [selectedMacro, setSelectedMacro] = useState<MacroKey | null>(null);
  const handleSelectCarbs = useCallback(() => setSelectedMacro('carbs'), []);
  const handleSelectProtein = useCallback(() => setSelectedMacro('protein'), []);
  const handleSelectFat = useCallback(() => setSelectedMacro('fat'), []);

  const macroValues = useMemo(
    () => ({
      carbs: {
        consumedG: carbsG,
        goalG: goals.carbsG,
        plannedRemainingG: plannedRemaining?.carbsG ?? 0,
      },
      protein: {
        consumedG: proteinG,
        goalG: goals.proteinG,
        plannedRemainingG: plannedRemaining?.proteinG ?? 0,
      },
      fat: {
        consumedG: fatG,
        goalG: goals.fatG,
        plannedRemainingG: plannedRemaining?.fatG ?? 0,
      },
    }),
    [carbsG, proteinG, fatG, goals.carbsG, goals.proteinG, goals.fatG, plannedRemaining],
  );

  return (
    <section aria-label="Macronutrientes" className="px-0.5 py-1">
      <div className="mb-2.5 flex items-center justify-between gap-2">
        <h2 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
          Macronutrientes
        </h2>
      </div>

      <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
        <MacroSemicircle
          label="Carboidratos"
          consumedG={carbsG}
          goalG={goals.carbsG}
          plannedRemainingG={plannedRemaining?.carbsG}
          metal={MACRO_METALS.carbs}
          isSelected={selectedMacro === 'carbs'}
          onSelect={handleSelectCarbs}
        />
        <MacroSemicircle
          label="Proteínas"
          consumedG={proteinG}
          goalG={goals.proteinG}
          plannedRemainingG={plannedRemaining?.proteinG}
          metal={MACRO_METALS.protein}
          isSelected={selectedMacro === 'protein'}
          onSelect={handleSelectProtein}
        />
        <MacroSemicircle
          label="Gorduras"
          consumedG={fatG}
          goalG={goals.fatG}
          plannedRemainingG={plannedRemaining?.fatG}
          metal={MACRO_METALS.fat}
          isSelected={selectedMacro === 'fat'}
          onSelect={handleSelectFat}
        />
      </div>

      {selectedMacro && (
        <MacroDetailSheet
          selectedMacro={selectedMacro}
          onSelectMacro={setSelectedMacro}
          onClose={() => setSelectedMacro(null)}
          values={macroValues}
          onOpenNutrition={onOpenNutrition}
        />
      )}
    </section>
  );
});
