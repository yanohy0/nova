# TITAN V.MAX — V11.20

## Implementado nesta evolução

### Plasma volumétrico: integração adaptativa limitada

- Substituído o raymarch de 12 amostras fixas por uma política determinística dependente do comprimento do segmento.
- Segmentos curtos usam 8 amostras; segmentos típicos preservam aproximadamente 12; segmentos longos refinam até 16.
- O loop GLSL mantém limite estático de 16 iterações e encerra quando alcança a contagem selecionada, preservando compatibilidade com drivers GLSL ES 3.00 conservadores.
- `ds = segmentLength / volumeSteps` mantém a integração distribuída por todo o segmento; o jitter interleaved-gradient continua estável por pixel.
- Nenhum shader de física foi substituído; nenhum pacote runtime foi adicionado.

## Limites que permanecem

- O campo de plasma ainda é procedural/curl-noise e não resolve MHD, equações de Navier–Stokes compressíveis, ionização ou transporte radiativo.
- Os canais de descarga ainda são VFX procedural com envelopes temporais; não são um solver completo de dielectric breakdown/streamer.
- A água interna ainda usa grade Euleriana 48×24 e óptica SDF/2.5D. As gotas de interface têm massa/área aproximadas, mas há fontes, sumidouros, reciclagem e perdas visuais que impedem afirmar conservação global de massa.
- O menisco ainda é perfil linearizado planar de Young–Laplace, não uma solução não linear 3D com histerese de contato acoplada.
- O vidro/metais ainda usam aproximações RGB de dispersão/constantes ópticas, não transporte espectral contínuo de ligas caracterizadas.
- A pele ainda combina pré-filtragem UV de refletância/albedo com difusão screen-space aproximada; não é BSSRDF completo nem convolução UV da irradiância.
- A topologia muscular ainda é limitada pela malha MakeHuman ativa e pelos IDs canônicos existentes. Não foram inventados músculos independentes onde não há geometria correspondente.
- Build completo, compilação real de shaders e benchmarks GPU continuam dependendo de ambiente com dependências instaladas e contexto WebGL2 funcional.

## Verificação

- `npm run test:adaptive-plasma`: contrato estático do raymarch adaptativo.
- `npm run test:rendering-realism`: inclui o novo contrato além das regressões anteriores.
- A execução de build/GPU não é declarada como aprovada sem ambiente e execução reais.
