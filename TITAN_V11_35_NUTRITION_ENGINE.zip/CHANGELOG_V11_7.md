# TITAN HYDRATION V.MAX V11.7 — React/runtime hardening

## Correções aplicadas

- O dia corrente agora é derivado da data local do dispositivo; os seletores de calendário geram os últimos cinco dias dinamicamente.
- A conversão de chave de data não substitui mais datas ausentes/inválidas por 21/11/2026. Datas inválidas são rejeitadas, incluindo dias impossíveis e anos bissextos incorretos.
- Registros de hidratação agora são persistidos localmente com Zustand, chave versionada e normalização defensiva dos dados restaurados.
- Progresso de treino, séries concluídas, carga/repetições, plano ativo e descanso são persistidos localmente. Na restauração, os dados são reconciliados com os IDs/estrutura do seed atual; séries desconhecidas e campos inválidos não entram no estado.
- Perfil, evolução e nutrição reutilizam o adaptador seguro de armazenamento, em vez de acessar `localStorage` diretamente. Perfil, evolução e nutrição também validam o estado restaurado em `merge`, inclusive quando o número de versão já é o atual; registros de evolução inválidos e IDs duplicados são descartados.
- Corrigido o fallback em memória do adaptador: quando o navegador bloqueia `setItem`, `getItem` prioriza o valor mais recente em memória sobre um valor local obsoleto. Exclusões que falham deixam tombstone em memória para não ressuscitar registros antigos.
- A gravação de série valida também se o `setId` pertence ao exercício selecionado e se a série ainda não foi concluída; uma requisição inválida não inicia descanso.
- O limite mínimo do calendário e os dias marcados agora derivam de registros reais de evolução, refeições e hidratação; o calendário consegue navegar até medições históricas anteriores ao seed inicial de refeições.
- `BottomSheet` agora associa título/descrição com ARIA, move o foco para o painel, mantém Tab/Shift+Tab dentro do diálogo, restaura o foco anterior e bloqueia/restaura o scroll do body.
- `React.StrictMode` habilitado na raiz para expor efeitos sem cleanup durante desenvolvimento.
- O código do renderer Three.js é importado dinamicamente; import tardio após unmount é cancelado e erro de carregamento ou falha síncrona após a criação do controller aciona o fallback 2D e descarta listeners, canvas e recursos do controller.
- `npm start` agora inicia `server.js` compilado; `npm run build` compila o backend com esbuild após o bundle Vite. Isso evita executar TypeScript cru diretamente no Node.

## Compatibilidade preservada

- React 19, Vite 8, Zustand 5, Zod 4 e Three.js mantidos.
- Nenhuma dependência runtime nova.
- IDs dos exercícios, planos de treino, TBCA 5.830 registros, contratos nutricionais e os 14 grupos musculares canônicos preservados.
- Nenhuma sincronização em nuvem foi adicionada: persistência é local ao navegador/dispositivo.

## Validação nesta sessão

- Novos testes puros de data local, armazenamento com quota/permissão negada, normalização de hidratação, normalização de treino, perfil/evolução, limite mínimo do calendário e validação de série: PASS.
- Regressões existentes de anatomia, shaders, musculatura, catálogo de exercícios, perfil, cálculos de força, nutrição e evolução: executadas novamente quando disponíveis.
- Sintaxe TypeScript/TSX: verificada por transpilation em lote.
- Build Vite, typecheck estrito e E2E real de navegador: não executados porque `node_modules` não está instalado e a instalação de dependências não está disponível neste ambiente. O novo comando de build do servidor foi configurado, mas precisa ser verificado em um ambiente com esbuild instalado.
- Persistência real em navegador e comportamento de foco de modal precisam de um passe E2E com Playwright em Chrome/Firefox/WebKit; os testes unitários validam normalizadores e contratos, não substituem essa execução.
