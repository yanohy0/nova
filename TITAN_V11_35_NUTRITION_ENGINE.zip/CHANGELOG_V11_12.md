# TITAN HYDRATION V.MAX — V11.12

## Implementado

- Hidratação de fichas personalizadas passa a reconstruir nome, equipamento e músculos a partir do catálogo canônico de exercícios; o conteúdo salvo não pode injetar grupos musculares nem rótulos de exercício falsos.
- Slugs de exercício desconhecidos, IDs de exercício/série duplicados e identificadores fora do formato esperado são rejeitados durante a recuperação do estado.
- Testes de regressão cobrem adulteração de nome/equipamento/músculos, slugs inexistentes e colisões de IDs.
- Persistência nutricional rejeita nomes acima de 80 caracteres, descrições acima de 500, notas acima de 300, URLs `javascript:`/protocol-relative e imagens excessivamente longas. Caminhos locais relativos à raiz e URLs HTTP(S) são aceitos.
- Testes de regressão cobrem URLs inseguras, rótulos fora do limite e imagem local legítima.
- Nenhuma dependência de runtime ou desenvolvimento foi adicionada; `bun.lock` permanece intacto.

## Pesquisa e seleção de repositórios

A V11.12 mantém Playwright como alvo E2E, Vitest como runner coerente com Vite, React Testing Library para testes orientados ao usuário, MSW para contratos de rede simulados e axe-core para acessibilidade. O ranking geral de testes consultado em 22/11/2026 registra Playwright (~100,8k), Puppeteer (~95,9k), Storybook (~91,7k), Jest (~45,5k) e React Testing Library (~19,7k). Maior número de estrelas não substitui adequação ao Vite/React, licença, manutenção ou custo de integração. Fontes: https://maal.top/charts/github-testing/ e https://github.com/microsoft/playwright.

## Validação

- `npm run test:review`: PASS.
- Testes focados de persistência de treino e nutrição: PASS.
- Checks estáticos de limites de domínio, semântica visual, design system, contrato anatômico e catálogo TBCA: PASS.
- `npm ping`: BLOCKED por falha DNS `EAI_AGAIN registry.npmjs.org`; Bun e `node_modules` ausentes.
- Build oficial, typecheck semântico completo, Playwright E2E e auditoria Lighthouse: não executados por indisponibilidade de dependências/ambiente.

## Não alegado como concluído

React Router, autenticação, sincronização multi-dispositivo, testes E2E reais, auditoria Lighthouse e build de produção continuam sem validação. Não foram simulados.
