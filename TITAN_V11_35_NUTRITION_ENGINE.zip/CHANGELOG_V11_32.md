# V11.32 — Nutrition integrity reconstruction

> Release reconstruction based on the recoverable V11.28 archive. The V11.29–V11.31 ZIPs were not available in the active workspace; only the prior-session engineering handoff was available for the HiGHS V11.30 guard and supplement-ledger design. This release does not claim byte-for-byte continuity with those missing archives.

## Implemented

- **HiGHS primal hardening:** validate every continuous `xN` primal, finite numeric value, variable bounds, binary `b_slot_option` completeness, integrality and one-hot selection. Invalid QP vectors use the deterministic TypeScript fallback; invalid MIP vectors return no joint proposal rather than inventing zero/default values.
- **UL scope correction:** the food-only micronutrient view suppresses ULs scoped only to supplements, preformed compounds or synthetic forms. Only total-intake ULs and compatible CDRR guidance appear in that view.
- **Supplement micronutrient ledger:** date/time, product, nutrient, quantity, unit, chemical form, source label/version/record ID and timestamp; validator; mass-only g/mg/µg conversion; scope-aware supplemental exposure aggregation; removal action; Zustand persistence v3 migration; interface panel.
- **No false completeness:** absent supplement records remain `not_logged`; unresolved chemical form or unit mismatch yields an unresolved result. Supplement micronutrients do not create calories/macros and do not mark a food-intake day complete. UI form choices are filtered by the selected nutrient and subtotal is labeled supplement-only.
- **USDA FDC import boundary:** strict parser for explicit Foundation, SR Legacy, FNDDS and Experimental metadata; exact permanent FDC nutrient ID + legacy nutrient number + nutrient name + unit map; 100 g composition basis; specific-Atwater energy preferred; unknown IDs and changed units quarantined; source version and record lineage preserved; explicit registration into food lookup and source-specific coverage. Conflicting duplicate nutrient observations are quarantined rather than resolved by JSON order.
- **Import audit sidecar:** the CLI writes a content-addressed JSON audit file containing every rejected food and quarantined nutrient observation. The generated catalog manifest pins the audit path and SHA-256; catalog promotion happens after the audit artifact is materialized. The integration test proves unknown nutrients and rejected food rows remain inspectable, and that a failed empty import leaves the previous catalog untouched.
- **Training-energy bridge:** completed workout sessions can produce a source-versioned MET estimate only with a valid start/end interval, body mass and an explicit licensed MET entry. Result is marked `estimated` and `active`; it is opt-in and not automatically injected into TDEE.
- **Public API and tests:** new import/ledger/bridge contracts exported; test suite expanded as `npm run test:nutrition-hardening` and included in `npm run test:review`.

## Not implemented / evidence still required

- No actual USDA archive was imported. Tests use synthetic records, but the adapter crosswalk was corrected against the current official FDC permanent nutrient list and field definitions: `nutrient.id` is the permanent nutrient ID, while `nutrient.number` is the separate legacy code. A full dataset-wide regression against a pinned archive is still required.
- The runtime registration API is in-memory. The importer can publish a static generated TypeScript catalog and immutable audit JSON, but the checked-in catalog is empty; a real Foundation/SR Legacy/FNDDS file still needs to be imported and tested. Large future Branded imports may need IndexedDB/SQLite-backed storage and measured memory/atomic-swap validation.
- No Branded FDC importer, no audited TBCA↔FDC crosswalk and no dataset-wide duplicates/coverage delta were produced. Duplicate IDs and nutrient conflicts are rejected in individual import files, but this has not yet been measured against a real release.
- The new supplement ledger is a micronutrient-only manual entry route. It does not yet implement serving/product database resolution, labels/barcodes, medications, complete supplement macro/energy contributions, or combined food+supplement total-intake assessments where the food chemical form is unresolved.
- The workout MET bridge is not wired to a user-facing MET picker or persistent activity history. Resistance-training energy remains uncertain; MET is only an estimate.
- DIAAS and cooking-retention engines still lack per-food, per-preparation, per-amino-acid verified datasets.
- Multi-day meal optimization, clinical validation, dietitian review, and full browser/device validation remain open.

## Verification

See `docs/quality/NUTRITION_ENGINE_V11_32_VERIFICATION.md` for exact PASS/BLOCKED commands. A passing review suite does not imply a production-ready or clinically validated nutrition engine.
