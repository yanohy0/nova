# TITAN V11.22 — Rendering & Physics Closure

Date: 2026-11-25

## Implemented

### Hydration / pressure projection
- Replaced the V11.21 Jacobi pressure relaxation with incomplete-Cholesky zero-fill preconditioned conjugate gradient (IC(0)-PCG/ICCG) for the current 48×24 five-point negative-Laplacian grid.
- Preconditioner factor is cached in the caller-owned instance workspace by grid dimensions; no per-step array allocation.
- Uses the same fixed preconditioner for the initial and subsequent residuals (fixed-M PCG invariant).
- Pressure gradient now corrects every velocity face participating in interior divergence, including right and bottom boundary faces.
- Recomputes the true Poisson residual `b - A p` after solving.
- Measured deterministic field: divergence RMS 0.30164297 → 0.01301 in 8 iterations (~95.7% reduction). Four additional deterministic fields satisfy ≥90% reduction in ≤12 iterations.

### Plasma / lightning
- Branch IDs and local coordinates remain spatially anchored (`pos3D.x` only); animation time no longer moves the branch grid.
- Each spatial node has a stable seed and individually seeded discharge-cycle rate (0.72–1.20); the Heidler pulse changes branch activity, not branch identity.
- Added source-contract regression test for stable spatial topology and independent temporal cadence.

### Body skin compositor
- Replaced two-radius sampling with bounded three-radius screen-space diffusion (0.9, 2.6, 5.8 pixels in 4 cardinal directions).
- Preserved channel-dependent red/green/blue scattering widths, depth discontinuity rejection, skin hue/material gate, normalized weights and alpha behavior.
- This remains a screen-space approximation; it does not claim a full irradiance-space BSSRDF.

### Research / quality gates
- Added five high-relevance GitHub references for each domain: water/pressure, glass/metals, volumetric plasma, electrical arcs, anatomy, skin SSS and studio lighting.
- Inspected relevant code, README and licenses where possible; documented engine mismatch and licensing caveats.
- No external executable code or 3D model assets were copied into TITAN.
- Preserved existing optics, mass ledger, Heidler waveform, adaptive plasma raymarch, dual-body topology map and the single diffuse backdrop halo/no-floor-light contract.

## Tests

Expected to pass in the available local Node toolchain:
- `npm run test:rendering-v11-22`
- `npm run test:rendering-realism`
- `npm run test:review`
- `npm run typecheck:calculations`
- plus the existing anatomy, shader, hydration and domain-boundary checks attempted in the full suite.

Full dependency-backed test/build/lint and hardware GPU compilation remain separate release gates; exact outputs are recorded with the release artifact and ledger.

## Remaining structural work

1. Calibrated 3D water/meniscus only if UI fidelity requires it; connect mass ledger to visible volume.
2. Continuous spectral/CIE pipeline and measured reference scenes for glass/metals.
3. License-cleared Laplace/DBM leader and MTLE channel model, with dielectric parameters, if physical arcs are required.
4. Compatible male/female segmented anatomy assets, origins/insertions, tendons/fascia and true independent geometry for currently shared muscle groups.
5. Irradiance-space separable BSSRDF and regional thickness maps.
6. Calibrated HDRI/exposure and real-device 360° GPU QA.
