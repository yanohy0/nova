import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  const rootDir = import.meta.dirname;
  return {
    plugins: [
      react(),
      tailwindcss(),
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build' as const,
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(rootDir, 'dist');
          const srcAssets = path.resolve(rootDir, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, { recursive: true, force: true });
          }
        },
      },
    ],
    worker: {
      format: 'es' as const,
    },
    resolve: {
      alias: [
        {
          find: /^.*tbca-catalog-source\.node(\.ts)?$/,
          replacement: path.resolve(
            rootDir,
            'src/domains/nutrition/data/sources/tbca-catalog-source.browser.ts',
          ),
        },
        {
          find: '@',
          replacement: path.resolve(rootDir, '.'),
        },
      ],
    },
    build: {
      modulePreload: {
        resolveDependencies(_filename, deps) {
          return deps.filter(
            (dep) =>
              !/(tbca-catalog|highs|smiles-drawer|three-vendor|composer-optimizer|anatomy-renderer)/i.test(
                dep,
              ),
          );
        },
      },
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('tbca-catalog.compact.json')) {
              return 'tbca-catalog';
            }
            if (id.includes('/node_modules/three/')) {
              return 'three-vendor';
            }
            if (id.includes('/node_modules/highs/')) {
              return 'highs';
            }
            if (id.includes('/node_modules/smiles-drawer/')) {
              return 'smiles-drawer';
            }
            if (
              id.includes('/node_modules/react/') ||
              id.includes('/node_modules/react-dom/') ||
              id.includes('/node_modules/scheduler/')
            ) {
              return 'react-vendor';
            }
            if (id.includes('/node_modules/motion/') || id.includes('/node_modules/framer-motion/')) {
              return 'motion-vendor';
            }
            return undefined;
          },
        },
      },
    },
    preview: {
      host: '0.0.0.0',
      port: Number(process.env.PORT ?? 4173),
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
