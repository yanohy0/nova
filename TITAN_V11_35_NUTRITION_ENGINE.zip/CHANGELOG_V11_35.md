# V11.35 — Niacina equivalente rastreável e cobertura TBCA por tipo

## Corrigido e ampliado

- O adaptador USDA FDC agora calcula vitamina B3 em `mg NE/100 g` sem tratar niacina pré-formada (FDC 406, mg) como equivalente total.
- Prioridade estrita da fonte: FDC 409 (total NE) direto; depois FDC 406 + 407 (niacina e fração derivada do triptofano já expressa em mg); por fim FDC 406 + 501 (niacina mg + triptofano g convertido por `g × 1000 / 60`).
- FDC 407 e FDC 501 são caminhos alternativos para a fração proveniente de triptofano. Nunca são somados entre si.
- O resultado derivado preserva fórmula, URL metodológica, base de 100 g e os IDs, números, nomes, valores e unidades dos componentes que o originaram.
- O registro USDA revalida a evidência da derivação e recalcula o resultado ao registrar o catálogo. O FDC 409 direto preserva também a identidade exata de origem e é revalidado no mesmo limite runtime. Evidência incompleta, inconsistente, com unidade/ID divergentes ou duplicatas conflitantes é recusada/quarentenada.
- Niacina isolada, triptofano isolado ou qualquer componente ausente nunca são tratados como zero nem produzem B3 quantificada. Nenhuma estimativa de triptofano com percentual de proteína foi introduzida.
- Overflow no caminho prioritário 406+407 falha fechado e não cai para o caminho 406+501; a evidência preferencial inválida não pode ser ocultada por um segundo método.
- O relatório de cobertura nutricional agora detalha todos os micronutrientes separadamente para TBCA `ALIMENTO`, `PREPARACAO_COMPOSTA` e `UNKNOWN`, mantendo totais globais e por fonte.
- Os auditores TBCA foram versionados em V11.35 sem reescrever os dados compactos da TBCA 7.2.

## Preservado

- Gate V11.34 de ingrediente TBCA: `ALIMENTO` permitido; `PREPARACAO_COMPOSTA` e tipo desconhecido bloqueados; busca geral/diário preserva preparações compostas.
- Os seis modelos de receita legados inelegíveis continuam fora de novas seleções/substituições; os dois modelos com ingredientes elegíveis continuam disponíveis.
- Aliases/proveniência legados e dados TBCA 7.2 não foram reescritos nesta versão.
- Nenhuma dependência de runtime foi adicionada.

## Dados e limites

- TBCA local: 7.2; 5.830 registros — 2.717 `ALIMENTO`, 3.113 `PREPARACAO_COMPOSTA`, 0 tipo desconhecido.
- Catálogo consolidado: 5.835 registros — TBCA 5.830, Open Food Facts 2, USDA FDC 0, TITAN_LEGACY 3.
- A derivação B3 foi validada com fixtures sintéticas; o corpus USDA real não foi baixado/importado nesta sessão. Cobertura USDA continua 0.
- TBCA 7.3 não foi importada/reempacotada: os termos públicos vigentes exigem confirmar permissão para reprodução/uso pretendido com a coordenação.
- O motor não é declarado clinicamente validado.
