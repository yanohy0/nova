# V11.25 — Orçamento energético e meta de ingestão

## Implementado

- Novo resolver puro de orçamento energético com distinção explícita entre base TDEE total (atividade/treino já incluídos) e uma futura base que exclua exercício.
- A meta de ingestão é derivada do TDEE total mais o ajuste assinado do objetivo: negativo para emagrecimento, zero para manutenção/recomposição nesta versão e positivo para ganho.
- RMR permanece exposto como componente; o residual TDEE−RMR é identificado como agregado estimado, sem alegar que seja NEAT ou TEF medido.
- Exercício NET informado é apenas rastreado quando o TDEE já inclui atividade. Só uma base explicitamente não aditiva ao exercício pode somá-lo uma vez.
- O cálculo agora separa ajuste solicitado, ajuste limitado e ajuste efetivo final, evitando mostrar déficit/superávit que foi alterado pelo piso de viabilidade dos macros.
- O preview de metas apresenta RMR, residual, TDEE e ajuste do objetivo, com explicação contra dupla contagem.
- Regressões cobrem NASEM, TDEE adaptativo, treino já incluído, ausência de dados de exercício, base não-exercício, validações e coerência da meta final.
- Varredura exaustiva de 1.071.840 combinações adultas válidas para sexo, idade, altura, peso e categoria de atividade: o EER NASEM ficou acima do RMR em todos os casos, com margem mínima de 167 kcal.
- Validador estrutural de composição alimentar aplicado à agregação, impacto de ingrediente, QP, escala proporcional e busca: rejeita campos macro não finitos/negativos, massa >105 g/100 g e gordura saturada acima da gordura total; Atwater divergente é aviso, não correção.
- Anomalia TBCA 7.2 `BRC1144B` (219 g de carboidrato/100 g) identificada e colocada em quarentena, sem adivinhar o decimal correto. A busca e novas entradas bloqueiam esse registro; receitas persistidas com ele ficam com cobertura incompleta e não recebem cálculo otimizado certificado.
- Pesquisa GitHub Top por finalidade e inspeção de código documentadas em `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_25.md`; nenhuma dependência ou código de terceiros foi incorporado.

## Limites que permanecem

- A aplicação ainda não persiste e integra um total diário de calorias líquidas de treino ao cálculo do perfil; por segurança, não soma dados isolados.
- Não há validação clínica externa nova do NASEM, Hall ou TDEE adaptativo. O intervalo adaptativo continua model-based e não calibrado externamente.
- A meta de recomposição mantém energia neutra e proteína específica; não há ainda modelo individual validado de recomposição.
- Se a meta de kcal não comporta a proteína desejada e a gordura mínima, o alvo de proteína é reduzido primeiro até o mínimo configurado; a ingestão só é elevada quando nem esse mínimo cabe, e o ajuste efetivo é recalculado para não mascarar o déficit.
- Otimização multi-período completa com restrições de micronutrientes ainda não foi implementada; o protótipo pesquisado não tem licença detectada nem validação suficiente para adoção.
- O inventário TBCA 7.2 ainda contém pelo menos um registro macro inconsistente que foi colocado em quarentena; corrigir a fonte exige conferir o registro oficial, não inferir um decimal.
- Otimização simultânea completa dos 23 micronutrientes e DIAAS/PDCAAS continua dependendo de dados completos e métodos específicos de digestibilidade/aminoácidos.
- A atualização da TBCA 7.3 permanece bloqueada até liberação formal dos direitos para o uso pretendido.

## Verificação

- Baseline V11.24 `npm run test:review`: PASS após as mudanças; também passaram `npm run test:nutrition-data-quality`, `npm run typecheck:calculations`, typecheck focado dos módulos nutricionais e transpilação de sintaxe dos 10 arquivos alterados.
- Novos testes do orçamento energético e regressões do cálculo de metas: executados na etapa final; resultados registrados no ledger Superpowers.
- Build, lint semântico completo, WASM HiGHS e UI browser dependem de instalação de dependências; só serão declarados aprovados se executados.
