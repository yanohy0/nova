# TITAN HYDRATION V.MAX — V11.10

## Implementado

- Editor inicial de fichas de treino: criar, duplicar, renomear e excluir fichas personalizadas.
- Adicionar exercícios do catálogo canônico a uma ficha personalizada e remover exercícios.
- Novas fichas e duplicatas são persistidas no store de treino.
- Hidratação do estado agora preserva fichas personalizadas, com limites de tamanho e validação dos valores de séries, carga, repetições e descanso.
- Bloqueio da execução de fichas vazias.
- Controles de edição exibidos apenas para fichas personalizadas, evitando ações sem efeito nas fichas base.
- Testes de regressão para persistência de fichas personalizadas e rejeição de dados inválidos.

## Compatibilidade

- Fichas padrão existentes continuam sendo reconstruídas a partir do catálogo oficial do app.
- O histórico de sessões concluídas permanece como snapshot independente das alterações posteriores nas fichas.
- Não foram adicionadas dependências de runtime nem alterações no lockfile.

## Limites conhecidos

- A edição de séries (adicionar/remover séries, metas de repetições e descanso por exercício) ainda é uma próxima etapa do editor.
- Testes de navegador e build completo precisam ser executados no ambiente de CI com Bun e dependências instaladas.
