import assert from 'node:assert/strict';
import { createMuscleFiberNormalPixels } from '../src/domains/anatomy/engine/materials/muscle-fiber-normal.ts';

const size = 256;
const pixels = createMuscleFiberNormalPixels(size);
assert.equal(pixels.length, size * size * 4);
let minR = 255, maxR = 0, minG = 255, maxG = 0, minB = 255, maxB = 0;
for (let offset = 0; offset < pixels.length; offset += 4) {
  const r = pixels[offset], g = pixels[offset + 1], b = pixels[offset + 2], a = pixels[offset + 3];
  assert.equal(a, 255, 'normal-map alpha must be opaque');
  assert.ok(b >= 235, 'tangent-space normal must remain predominantly +Z');
  minR = Math.min(minR, r); maxR = Math.max(maxR, r);
  minG = Math.min(minG, g); maxG = Math.max(maxG, g);
  minB = Math.min(minB, b); maxB = Math.max(maxB, b);
}
assert.ok(maxR - minR > 8, 'normal map must contain directional fiber variation in U');
assert.ok(maxG - minG > 2, 'normal map must contain low-amplitude irregularity in V');
assert.ok(maxB - minB < 20, 'normal map must avoid extreme normal perturbations');

// The normal map repeats in both UV axes. Opposite borders should be nearly
// continuous; a non-periodic frequency in V creates a visible horizontal seam.
let maxVEdgeDelta = 0;
let maxUEdgeDelta = 0;
for (let coordinate = 0; coordinate < size; coordinate += 1) {
  const top = coordinate * 4;
  const bottom = ((size - 1) * size + coordinate) * 4;
  const left = (coordinate * size) * 4;
  const right = (coordinate * size + size - 1) * 4;
  for (let channel = 0; channel < 3; channel += 1) {
    maxVEdgeDelta = Math.max(maxVEdgeDelta, Math.abs(pixels[top + channel] - pixels[bottom + channel]));
    maxUEdgeDelta = Math.max(maxUEdgeDelta, Math.abs(pixels[left + channel] - pixels[right + channel]));
  }
}
assert.ok(maxVEdgeDelta <= 2, `normal map V repeat seam too large (${maxVEdgeDelta} byte levels)`);
assert.ok(maxUEdgeDelta <= 12, `normal map U repeat seam too large (${maxUEdgeDelta} byte levels)`);
assert.throws(() => createMuscleFiberNormalPixels(255), RangeError);
assert.throws(() => createMuscleFiberNormalPixels(8), RangeError);
assert.equal(createMuscleFiberNormalPixels(16).length, 16 * 16 * 4);
console.log('Muscle normal-map tests passed (dimensions, variation, bounded normals, and validation).');
