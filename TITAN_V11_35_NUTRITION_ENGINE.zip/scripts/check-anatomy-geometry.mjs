import assert from 'node:assert/strict';
import { averageClosedLoftSeamNormals, createLoftTopology, writeLoftCapPositions } from '../src/domains/anatomy/engine/scene/loft-topology.ts';

const closed = createLoftTopology(5, 12, true, true);
assert.equal(closed.columns, 13);
assert.equal(closed.vertexCount, 67);
assert.equal(closed.uvs.length, closed.vertexCount * 2);
assert.equal(closed.indices.length, 360);
assert.ok(closed.indices instanceof Uint16Array);
for (let row = 0; row < 5; row += 1) {
  const first = row * closed.columns;
  const last = first + 12;
  assert.equal(closed.uvs[first * 2], 0, `row ${row} U seam start`);
  assert.equal(closed.uvs[last * 2], 1, `row ${row} U seam end`);
  assert.equal(closed.uvs[first * 2 + 1], row / 4);
  assert.equal(closed.uvs[last * 2 + 1], row / 4);
}
assert.equal(closed.uvs[(65) * 2], 0.5, 'bottom cap center U');
assert.equal(closed.uvs[(65) * 2 + 1], 0, 'bottom cap center V');
assert.equal(closed.uvs[(66) * 2], 0.5, 'top cap center U');
assert.equal(closed.uvs[(66) * 2 + 1], 1, 'top cap center V');
assert.ok([...closed.indices].every((index) => index < closed.vertexCount), 'closed topology must not index outside vertex buffer');
const capPositions = new Float32Array(closed.vertexCount * 3);
const capEnd = writeLoftCapPositions(capPositions, 5 * closed.columns * 3, [1, 2, 3], [4, 5, 6], true);
assert.equal(capEnd, capPositions.length);
assert.deepEqual([...capPositions.slice(5 * closed.columns * 3)], [1, 2, 3, 4, 5, 6]);
assert.equal(writeLoftCapPositions(new Float32Array(3), 0, [1, 2, 3], [4, 5, 6], false), 0);
assert.throws(() => writeLoftCapPositions(new Float32Array(3), 0, [1, 2, 3], [4, 5, 6], true), RangeError);

const open = createLoftTopology(7, 20, false, false);
assert.equal(open.vertexCount, 147);
assert.equal(open.indices.length, 6 * 20 * 6);
assert.ok(open.indices instanceof Uint16Array);
assert.ok([...open.indices].every((index) => index < open.vertexCount));

const large = createLoftTopology(6000, 20, false, false);
assert.ok(large.indices instanceof Uint32Array, 'large geometry must switch to 32-bit indices safely');
assert.ok([...large.indices].every((index) => index < large.vertexCount));

const seamNormals = new Float32Array(3 * 9 * 3);
for (let row = 0; row < 3; row += 1) {
  const start = row * 9 * 3;
  const end = (row * 9 + 8) * 3;
  seamNormals.set([1, 0, 0], start);
  seamNormals.set([0, 0, 1], end);
}
averageClosedLoftSeamNormals(seamNormals, 3, 8);
for (let row = 0; row < 3; row += 1) {
  const start = row * 9 * 3;
  const end = (row * 9 + 8) * 3;
  assert.deepEqual(Array.from(seamNormals.slice(start, start + 3)), Array.from(seamNormals.slice(end, end + 3)));
  assert.ok(Math.abs(Math.hypot(...seamNormals.slice(start, start + 3)) - 1) < 1e-6, 'seam normals remain normalized');
}
assert.throws(() => averageClosedLoftSeamNormals(new Float32Array(2), 3, 8), /normal buffer is too small/);

assert.throws(() => createLoftTopology(1, 12, true, true), RangeError);
assert.throws(() => createLoftTopology(4, 2, true, true), RangeError);
console.log('Anatomy geometry tests passed (closed seam UVs/normals, caps, open patches, bounds, and index-width selection).');
