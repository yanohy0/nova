import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/domains/anatomy/engine/assets/human-mesh-binary.ts', import.meta.url), 'utf8');
const b64 = source.match(/export const HUMAN_MESH_BASE64 = "([^"]+)";/)?.[1];
assert.ok(b64, 'embedded anatomy mesh payload missing');
const names = source.match(/HUMAN_MESH_MORPH_NAMES = \[([\s\S]*?)\] as const/)?.[1];
assert.ok(names);
const morphNames = [...names.matchAll(/'([^']+)'/g)].map(x => x[1]);
const bytes = Buffer.from(b64, 'base64');
let off = 0;
const u32 = () => { const v = bytes.readUInt32LE(off); off += 4; return v; };
const u16 = () => { const v = bytes.readUInt16LE(off); off += 2; return v; };
const nCanon = u32(), nRender = u32(), nTriangles = u32(), nMorphs = u32();
off += nCanon * 3 * 2; // base positions
  off += nCanon * 3 * 2; // female delta
const renderToCanonical = new Uint16Array(nRender);
for (let i=0;i<nRender;i++) renderToCanonical[i] = u16();
off += nRender * 2 * 2; // UVs
const renderMuscleIds = bytes.subarray(off, off+nRender); off += nRender;
off += nRender; // muscle side
const canonicalIds = new Int16Array(nCanon); canonicalIds.fill(-1);
const ambiguous = new Uint8Array(nCanon);
for (let i=0;i<nRender;i++) {
  const c = renderToCanonical[i], id = renderMuscleIds[i];
  if (id === 255) continue;
  if (canonicalIds[c] === -1) canonicalIds[c] = id;
  else if (canonicalIds[c] !== id) ambiguous[c] = 1;
}
for (let i=0;i<nCanon;i++) if (ambiguous[i]) canonicalIds[i] = -1;
off += nTriangles * 3 * 2;
const counts = new Map();
for (let morph=0;morph<nMorphs;morph++) {
  const count = u32();
  const hist = new Map();
  for (let i=0;i<count;i++) {
    const vertex = u16();
    off += 3 * 2;
    const id = canonicalIds[vertex];
    if (id >= 0) hist.set(id, (hist.get(id) ?? 0) + 1);
  }
  counts.set(morphNames[morph], Object.fromEntries([...hist.entries()].sort((a,b)=>a[0]-b[0])));
}
assert.equal(nCanon, 13524);
assert.equal(nRender, 14677);
assert.ok(counts.get('biceps_triceps')?.[5] > 0, 'biceps sparse morph has no canonical biceps region');
assert.ok(counts.get('biceps_triceps')?.[6] > 0, 'triceps sparse morph has no canonical triceps region');
assert.ok(counts.get('deltoids')?.[2] > 0, 'deltoid sparse morph has no anterior-head canonical region');
assert.ok(counts.get('deltoids')?.[3] > 0, 'deltoid sparse morph has no lateral-head canonical region');
assert.ok(counts.get('deltoids')?.[4] > 0, 'deltoid sparse morph has no posterior-head canonical region');
assert.ok(counts.get('quadriceps_hamstrings')?.[12] > 0, 'quadriceps sparse morph has no canonical quadriceps region');
assert.ok(counts.get('quadriceps_hamstrings')?.[13] > 0, 'hamstrings sparse morph has no canonical hamstrings region');
console.log('V11.19 anatomy sparse morph mapping passed:', JSON.stringify({canonicalVertices:nCanon,renderVertices:nRender,bicepsTriceps:counts.get('biceps_triceps'),deltoidHeads:counts.get('deltoids'),quadricepsHamstrings:counts.get('quadriceps_hamstrings')}));
