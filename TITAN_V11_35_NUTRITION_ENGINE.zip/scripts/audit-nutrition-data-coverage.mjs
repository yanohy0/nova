import fs from 'node:fs/promises';
import { TBCA_FOODS } from '../src/domains/nutrition/data/sources/tbca-adapter.ts';
import { OPEN_FOOD_FACTS_PRODUCTS } from '../src/domains/nutrition/data/sources/open-food-facts-adapter.ts';
import { USDA_FDC_GENERATED_CATALOG, USDA_FDC_GENERATED_MANIFEST } from '../src/domains/nutrition/data/sources/usda-fdc-catalog.generated.ts';
import { collectNutritionCoverageFoods } from './lib/nutrition-coverage-catalog.mjs';
import { MICRONUTRIENT_CHEMISTRY } from '../src/domains/nutrition/data/chemistry/micronutrient-chemistry.ts';
import { MICRONUTRIENT_ORDER } from '../src/domains/nutrition/domain/entities/nutrient.ts';
import { buildNutritionDataCoverage } from '../src/domains/nutrition/domain/rules/nutrition-data-coverage.ts';

const allTbcaEntries = Object.entries(TBCA_FOODS);
const canonicalTbcaFoods = Object.fromEntries(allTbcaEntries.filter(([key, food]) => food.source_id === 'TBCA' && key === `tbca:${food.source_record_id}`));
const titanLegacyFoods = allTbcaEntries.map(([, food]) => food).filter((food) => food.source_id === 'TITAN_LEGACY');
const foods = collectNutritionCoverageFoods({
  tbcaFoods: canonicalTbcaFoods,
  openFoodFactsProducts: OPEN_FOOD_FACTS_PRODUCTS,
  usdaFoods: USDA_FDC_GENERATED_CATALOG,
  titanLegacyFoods,
});
const targets = MICRONUTRIENT_ORDER.map((nutrientId) => ({
  nutrientId,
  unit: MICRONUTRIENT_CHEMISTRY[nutrientId].canonicalUnit,
}));
const report = {
  generatedAt: new Date().toISOString(),
  catalogRecordCount: foods.length,
  sourceRecordCounts: {
    TBCA: Object.keys(canonicalTbcaFoods).length,
    OPEN_FOOD_FACTS: Object.keys(OPEN_FOOD_FACTS_PRODUCTS).length,
    USDA_FDC: USDA_FDC_GENERATED_CATALOG.length,
    TITAN_LEGACY: titanLegacyFoods.length,
  },
  usdaManifest: USDA_FDC_GENERATED_MANIFEST,
  methodology: 'Count as quantified only when data_status=quantified, normalized value is finite and >=0, basis_quantity is finite and >0, and normalized_unit exactly matches canonical chemistry unit. Missing/trace/invalid/unit-mismatch never become zero.',
  nutrients: buildNutritionDataCoverage(foods, targets),
};

if (process.argv.includes('--write')) {
  const destination = 'docs/research/NUTRIENT_COVERAGE_ALL_SOURCES_V11_35.json';
  await fs.writeFile(destination, `${JSON.stringify(report, null, 2)}\n`);
  process.stdout.write(`Wrote ${destination}\n`);
}

for (const item of report.nutrients) {
  const tbca = item.bySource.TBCA ?? { quantifiedFoodRecords: 0, totalFoodRecords: 0 };
  const off = item.bySource.OPEN_FOOD_FACTS ?? { quantifiedFoodRecords: 0, totalFoodRecords: 0 };
  const usda = item.bySource.USDA_FDC ?? { quantifiedFoodRecords: 0, totalFoodRecords: 0 };
  const eligible = item.byTbcaFoodType.ALIMENTO;
  const composite = item.byTbcaFoodType.PREPARACAO_COMPOSTA;
  const unknown = item.byTbcaFoodType.UNKNOWN;
  process.stdout.write(
    `${item.nutrientId}\t${item.unit}\t${item.quantifiedFoodRecords}/${item.totalFoodRecords} (${item.coveragePercent}%)\t` +
    `TBCA ${tbca.quantifiedFoodRecords}/${tbca.totalFoodRecords} [ALIMENTO ${eligible.quantifiedFoodRecords}/${eligible.totalFoodRecords}; ` +
    `PREPARACAO_COMPOSTA ${composite.quantifiedFoodRecords}/${composite.totalFoodRecords}; UNKNOWN ${unknown.quantifiedFoodRecords}/${unknown.totalFoodRecords}]\t` +
    `OFF ${off.quantifiedFoodRecords}/${off.totalFoodRecords}\tUSDA ${usda.quantifiedFoodRecords}/${usda.totalFoodRecords}\t` +
    `missing ${item.statusCounts.missing}; trace ${item.statusCounts.trace}; not analyzed ${item.statusCounts.not_analyzed}; unit mismatch ${item.statusCounts.unit_mismatch}; invalid ${item.statusCounts.invalid_value}\n`,
  );
}
