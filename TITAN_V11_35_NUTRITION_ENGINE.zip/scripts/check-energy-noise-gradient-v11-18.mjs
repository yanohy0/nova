import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../src/shared/graphics/fluid-shader-engine.ts', import.meta.url), 'utf8');
assert.match(source, /vec4 energyNoise3DGradient\(vec3 x\)/);
assert.match(source, /vec3 grad = energyNoise3DGradient\(p\)\.yzw;/);
assert.doesNotMatch(source, /energyNoise3D\(p\s*[+-]\s*vec3\(0\.0,\s*e,/);
const fract = x => x - Math.floor(x);
const hash31 = ([x,y,z]) => {
  let p = [fract(x*0.1031), fract(y*0.1030), fract(z*0.0973)];
  const dot = p[0]*(p[1]+33.33)+p[1]*(p[0]+33.33)+p[2]*(p[2]+33.33);
  p = p.map(v=>v+dot);
  return fract((p[0]+p[1])*p[2]);
};
const smooth = x => x*x*(3-2*x);
const dsmooth = x => 6*x*(1-x);
function valueNoise(p) {
  const i=p.map(Math.floor), f=p.map(fract), u=f.map(smooth);
  const h=(x,y,z)=>hash31([i[0]+x,i[1]+y,i[2]+z]);
  const n000=h(0,0,0),n100=h(1,0,0),n010=h(0,1,0),n110=h(1,1,0);
  const n001=h(0,0,1),n101=h(1,0,1),n011=h(0,1,1),n111=h(1,1,1);
  const nx00=n000+(n100-n000)*u[0], nx10=n010+(n110-n010)*u[0];
  const nx01=n001+(n101-n001)*u[0], nx11=n011+(n111-n011)*u[0];
  const nxy0=nx00+(nx10-nx00)*u[1], nxy1=nx01+(nx11-nx01)*u[1];
  return nxy0+(nxy1-nxy0)*u[2];
}
function analyticGradient(p) {
  const i=p.map(Math.floor), f=p.map(fract), u=f.map(smooth), du=f.map(dsmooth);
  const h=(x,y,z)=>hash31([i[0]+x,i[1]+y,i[2]+z]);
  const n000=h(0,0,0),n100=h(1,0,0),n010=h(0,1,0),n110=h(1,1,0);
  const n001=h(0,0,1),n101=h(1,0,1),n011=h(0,1,1),n111=h(1,1,1);
  const nx00=n000+(n100-n000)*u[0], nx10=n010+(n110-n010)*u[0];
  const nx01=n001+(n101-n001)*u[0], nx11=n011+(n111-n011)*u[0];
  const nxy0=nx00+(nx10-nx00)*u[1], nxy1=nx01+(nx11-nx01)*u[1];
  const value=nxy0+(nxy1-nxy0)*u[2];
  const dx0=(n100-n000)+((n110-n010)-(n100-n000))*u[1];
  const dx1=(n101-n001)+((n111-n011)-(n101-n001))*u[1];
  const dx=(dx0+(dx1-dx0)*u[2])*du[0];
  const dy=((nx10-nx00)+((nx11-nx01)-(nx10-nx00))*u[2])*du[1];
  const dz=(nxy1-nxy0)*du[2];
  return {value,gradient:[dx,dy,dz]};
}
const points=[[0.23,1.41,2.67],[3.17,0.42,1.89],[8.11,4.37,0.63],[11.28,3.52,6.74],[0.71,7.22,2.39],[9.63,1.77,5.18]];
const eps=1e-4;
for(const p of points){
  const {value,gradient}=analyticGradient(p);
  assert.ok(Number.isFinite(value));
  for(let axis=0;axis<3;axis++){
    const a=[...p],b=[...p]; a[axis]+=eps; b[axis]-=eps;
    const numeric=(valueNoise(a)-valueNoise(b))/(2*eps);
    assert.ok(Math.abs(numeric-gradient[axis])<0.002,`gradient mismatch @ ${p.join(',')} axis ${axis}: ${numeric} != ${gradient[axis]}`);
  }
}
console.log(`V11.18 analytic noise gradient passed (${points.length*3} central-difference comparisons).`);
