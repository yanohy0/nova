import assert from 'node:assert/strict';
import { collectNutritionCoverageFoods } from '../lib/nutrition-coverage-catalog.mjs';

const tbca = { 'tbca:1': { food_id: 'tbca:1', source_id: 'TBCA' } };
const off = { 'off:2': { food_id: 'off:2', source_id: 'OPEN_FOOD_FACTS' } };
const usda = [{ food_id: 'usda-fdc:3', source_id: 'USDA_FDC' }];
const legacy = [{ food_id: 'titan-legacy:meal', source_id: 'TITAN_LEGACY' }];
const result = collectNutritionCoverageFoods({ tbcaFoods: tbca, openFoodFactsProducts: off, usdaFoods: usda, titanLegacyFoods: legacy });
assert.deepEqual(result.map((food) => food.food_id), ['tbca:1', 'off:2', 'usda-fdc:3', 'titan-legacy:meal']);
assert.equal(result.filter((food) => food.source_id === 'USDA_FDC').length, 1);
assert.throws(() => collectNutritionCoverageFoods({ usdaFoods: {} }), /array/);
assert.throws(() => collectNutritionCoverageFoods({ tbcaFoods: [] }), /objeto/);
assert.throws(() => collectNutritionCoverageFoods({ titanLegacyFoods: {} }), /array/);
console.log('Nutrition coverage source aggregation tests passed.');
