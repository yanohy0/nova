#!/usr/bin/env node
import { mkdir, realpath } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fetchUsdaFdcArchive, persistUsdaArchiveImmutable, USDA_FDC_DOWNLOADS } from './lib/usda-fdc-download.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUTPUT_DIRECTORY = path.join(ROOT, 'data', 'external', 'usda-fdc');

function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (token === '--help' || token === '-h') return { help: true };
    if (!token.startsWith('--')) throw new Error(`Argumento inesperado: ${token}`);
    const key = token.slice(2);
    if (key !== 'type') throw new Error(`Argumento desconhecido: --${key}`);
    if (args[key] !== undefined) throw new Error(`Argumento duplicado: --${key}`);
    const value = argv[index + 1];
    if (!value || value.startsWith('--')) throw new Error(`Valor ausente para --${key}`);
    args[key] = value;
    index += 1;
  }
  return args;
}

function usage() {
  return `Uso:\n  bun run download:usda-fdc -- --type <Foundation|SR Legacy|Survey (FNDDS)>\n\nSomente releases JSON fixadas e servidas diretamente por fdc.nal.usda.gov são aceitas.\n`;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { process.stdout.write(usage()); return; }
  if (!args.type || !Object.hasOwn(USDA_FDC_DOWNLOADS, args.type)) {
    process.stderr.write(usage());
    process.exitCode = 2;
    return;
  }

  const archive = await fetchUsdaFdcArchive(args.type);
  await mkdir(OUTPUT_DIRECTORY, { recursive: true });
  const resolvedOutputDirectory = await realpath(OUTPUT_DIRECTORY);
  if (!resolvedOutputDirectory.startsWith(ROOT + path.sep)) throw new Error('Diretório de download USDA aponta para fora do projeto.');
  const output = path.join(resolvedOutputDirectory, archive.fileName);
  const persisted = await persistUsdaArchiveImmutable({ destination: output, bytes: archive.bytes, sha256: archive.sha256 });
  process.stdout.write(`${persisted.created ? 'Arquivo USDA salvo' : 'Arquivo USDA já existe, hash idêntico'}: ${path.relative(ROOT, output)}\n`);
  process.stdout.write(`Tipo: ${archive.dataType}; release: ${archive.releaseVersion}\n`);
  process.stdout.write(`Bytes: ${archive.byteLength}; SHA-256 ZIP: ${archive.sha256}\n`);
  process.stdout.write(`Origem: ${archive.sourceUrl}\n`);
  process.stdout.write(`Próximo passo:\n  bun run import:usda-fdc -- --input "${path.relative(ROOT, output)}" --type "${archive.dataType}" --release "${archive.releaseVersion}" --source-url "${archive.sourceUrl}"\n`);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n${usage()}`);
  process.exitCode = 1;
});
