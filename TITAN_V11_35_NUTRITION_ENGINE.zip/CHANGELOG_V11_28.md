# V11.28 — Proteção de limites superiores e evidência DIAAS

## Adicionado/corrigido

- Propostas contínuas com UL alimentar aplicável excedido são bloqueadas em três camadas: regra de domínio (`getOptimizationProposalBlockReason`), ação Zustand `applyOptimizationProposal` e interface (botão Aplicar e Salvar variante desabilitados com razão explícita). Conflitos em alimentos/quantidades travados não podem ser aplicados como uma aproximação comum.
- Os limites que estão apenas sem dados continuam reportados como insuficientes; o motor não inventa consumo nem declara conformidade com UL quando o catálogo não tem cobertura.
- DIAAS não aceita dados de digestibilidade de rato como base para pontuação. As espécies aceitas são humano ou suíno, com método true/standardized ileal, e cada fator é específico do aminoácido.
- Perfil de aminoácidos exige proveniência vinculada ao alimento e estado exatos, fonte/versão/referência/URL e base `mg_per_g_protein`.
- Cada evidência de digestibilidade exige o mesmo ID do alimento, estado correspondente, fonte, versão, referência, URL, espécie e método. Evidências de outro alimento ou estado não são combinadas.
- Testes adversariais RED→GREEN adicionados à suíte de revisão.

## Verificação V11.28

- `npm run test:review`: PASS (suite de revisão, não a suíte integral `npm test`).
- `tsc -p tsconfig.calc-review.json --pretty false`: PASS.
- Transpilation syntax TypeScript/TSX: 18/18 módulos passaram após V11.28.
- `npm run audit:nutrition-coverage`: PASS; snapshot de 5.838 registros regenerado.
- `git diff --check`: PASS.
- ZIP final `TITAN_V11_28_NUTRITION_ENGINE.zip`: `unzip -t` PASS; extração limpa confirmou versão 11.28.0 e executou `npm run test:review` com exit 0.
- Build e `npm test` integral continuam não executáveis neste ambiente enquanto faltarem `vite` e `tsx`; HiGHS WASM não executado.

## Limites científicos/dados que permanecem

- Catálogo ainda sem perfis de aminoácidos e digestibilidade ileal medidos por alimento/preparo; nenhum DIAAS real calculável no catálogo atual.
- Ainda não existe crosswalk validado TBCA→USDA por alimento, corte e método para yield/retention; não há conversão cru/cozido automática ativa.
- Seis novos micronutrientes continuam sem dados quantificados; niacina equivalente e vitaminas K/B5/B7 têm cobertura praticamente nula. Ver snapshot V11.27.
- Exposição total a suplementos, água/bebidas e fontes externas não está no UL do plano alimentar.
- TBCA 7.3 depende de liberação/licenciamento; modelos energéticos ainda sem validação clínica externa.
