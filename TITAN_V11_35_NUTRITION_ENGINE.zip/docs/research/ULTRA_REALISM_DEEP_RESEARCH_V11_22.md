# TITAN V11.22 — Deep Search técnico por subsistema

Data: 2026-11-25  
Base real: `TITAN_V11_21_REALISM_CLOSURE.zip` (recuperado da Biblioteca; checksum e origem registrados no ledger desta execução).  
Pesquisa: GitHub Search + leitura direta de README, código e LICENSE pelos conectores GitHub. **Firecrawl não foi utilizado.**  
Critério: Top 5 por relevância técnica e capacidade de informar a implementação; não é ranking global por estrelas. Uma referência não é uma dependência. Código/ativos só seriam copiados após licença, proveniência e compatibilidade confirmadas.

## Resumo executivo

V11.22 fecha três deficiências que podiam ser corrigidas dentro da arquitetura atual:

1. A projeção de pressão 2D passa de Jacobi para **IC(0)-PCG/ICCG**, com fator incompleto de Cholesky pré-computado e armazenado no workspace da instância. O teste em campos determinísticos confirma convergência em até 8 iterações no caso principal e até 12 nos quatro campos adicionais.
2. A identidade dos nós de ramificação do plasma deixa de depender da coordenada temporal. Cada nó também recebe uma cadência de descarga própria, derivada de um seed espacial estável.
3. A difusão cutânea screen-space passa a usar três raios (0,9 / 2,6 / 5,8 px), pesos RGB normalizados no acumulador, rejeição por profundidade, seletor de tonalidade de pele e alpha preservado.

Não há substituição do renderer, migração WebGPU, importação de malhas sem adaptação, MHD, path tracing ou BSSRDF completo. Esses limites são intencionais e estão descritos abaixo.

---

## 1. Água, pressão e superfície livre

### Top 5 — repositórios de referência

| Repositório | Técnicas que importam | Licença/compatibilidade | Decisão para TITAN |
|---|---|---|---|
| [doyubkim/fluid-engine-dev](https://github.com/doyubkim/fluid-engine-dev) | PCG, ICCG, MGPCG, stencil 5 pontos, precondicionador incomplete-Cholesky zero-fill e sistemas FDM | MIT; C++/CPU | Referência principal para derivação do IC(0)-PCG da grade 48×24. Nenhum código C++ foi copiado. |
| [PavelDoGreat/WebGL-Fluid-Simulation](https://github.com/PavelDoGreat/WebGL-Fluid-Simulation) | Stable Fluids em WebGL, advecção semi-Lagrangiana, projeção de pressão, vorticity confinement | MIT; WebGL | Referência direta para a família de técnicas compatível com WebGL2. |
| [InteractiveComputerGraphics/SPlisHSPlasH](https://github.com/InteractiveComputerGraphics/SPlisHSPlasH) | SPH, PBF, PCISPH, DFSPH, viscosidade implícita e busca de vizinhos | MIT; C++ | Referência para futuro fluido de partículas 3D, não para a pequena barra de hidratação atual. |
| [google/FluidNet](https://github.com/google/FluidNet) | Aceleração de solver Euleriano por CNN, projeção e estimativa de pressão | Repositório arquivado; README documenta limitações; runtime antigo | Pesquisa acadêmica, não adotar modelo aprendido no renderer. |
| [RealAbdurRehman/fluid-simulation](https://github.com/RealAbdurRehman/fluid-simulation) | Simulação/visualização por compute shader, espuma, espessura, absorção e cáusticas | MIT; WebGPU | Referência visual e de pipeline, mas API/backend não é drop-in WebGL2. |

### Técnica avançada adotada

- Operador de Poisson simétrico positivo definido: `A = -∇²`, stencil cinco pontos, fronteira de pressão Dirichlet zero.
- Pré-condicionador **IC(0)**: fatorização incompleta sem fill-in fora do stencil original; fator triangular é montado uma vez por dimensão de grid e guardado no workspace.
- **PCG/ICCG**: `r=b-Ax`, `z=M⁻¹r`, `p=z+βp`, `α=(r·z)/(p·Ap)`. A aplicação inicial e as aplicações subsequentes usam o mesmo precondicionador fixo; misturar Jacobi no primeiro passo e IC(0) nos passos seguintes violaria a recorrência PCG.
- Projeção consistente com os operadores discretos usados: gradiente de pressão corrige todas as faces de contorno adjacentes às células interiores, inclusive borda direita e inferior.
- Resíduo verdadeiro é recalculado como `b-Ap` depois da iteração, para não depender apenas do resíduo recursivo armazenado em Float32.

### Medição desta versão

- Campo 48×24 de referência: RMS de divergência `0,30164297 → 0,01301` em 8 iterações (≈95,7% de redução).
- Quatro campos determinísticos adicionais também passaram o critério de redução ≥90% em até 12 iterações.
- O pré-condicionador é guardado nos typed arrays pertencentes à instância; sem alocação por passo.

### Ainda falta

- O solver continua sendo um modelo Euleriano 2D, com unidades normalizadas. Cox–Voinov não deve ser acoplado antes de definir conversão de pixel/unidade de cena para metros e segundos.
- Para uma gota realmente livre em 3D, a rota candidata é **PBF/DFSPH** (incompressibilidade), spatial hashing/compact neighbor search, reconstrução de superfície por marching cubes ou screen-space thickness, seguida de Beer–Lambert/Fresnel/Snell. Só justificar essa rota com medição real de cena e GPU.
- Menisco final precisa de solução não linear de Young–Laplace em geometria do recipiente, ângulo de contato e histerese medidos; o perfil atual continua uma aproximação simplificada para o componente.
- Caústicas físicas 3D dependem de normal/refração estáveis e rastreamento de luz; não basta elevar a frequência de ruído.

---

## 2. Vidro, metais, dispersão e óptica espectral

### Top 5 — repositórios/datasets

| Repositório | Técnicas que importam | Licença/compatibilidade | Decisão para TITAN |
|---|---|---|---|
| [refractiveindex.info-database](https://github.com/polyanskiy/refractiveindex.info-database) | Dados `n(λ), k(λ)`, Sellmeier, Cauchy, Drude/Lorentz, fonte DOI e faixa espectral | CC0; dados tabulados | Fonte de dados medida; V11.21 já inclui amostras Au/Ag/Cr e quadratura espectral RGB em GLSL. |
| [mmp/pbrt-v4](https://github.com/mmp/pbrt-v4) | `SampledSpectrum`, amostragem espectral, CIE XYZ, Fresnel de condutor, dispersão | Apache-2.0 no código; path tracer CPU/GPU | Referência algorítmica para expansão futura de RGB multi-banda a espectro/CIE. |
| [google/filament](https://github.com/google/filament) | PBR, GGX, compensação multiscattering, clearcoat, transmissão, espessura, anisotropia, IBL | Apache-2.0; engine independente | Referência de consistência energética/material, não migrar engine. |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Materiais físicos, IOR, transmissão, espessura, dispersão, LUTs LTC e PMREM | MIT; runtime atual | Referência direta para manter alinhamento com WebGLRenderer e os materiais físicos. |
| [lightsmith-photonics/lightsmith-materials](https://github.com/lightsmith-photonics/lightsmith-materials) | Camada de consulta/importação de dados ópticos e material | Código MIT; dados mantêm a licença da fonte original | Referência de organização/proveniência, não adicionar dependência. |

### Stack técnica

- Dados medidos por material, DOI e condição: `n(λ), k(λ)`, temperatura, fase, rugosidade e preparação da amostra. Não tratar filme fino, liga comercial e metal puro como o mesmo material.
- Interpolação limitada ao domínio medido (linear, spline monotônica ou modelo de dispersão quando houver parâmetros publicados); extrapolação deve falhar/ser explicitamente marcada.
- Fresnel complexo para condutores, Fresnel dielétrico exato para vidro, Snell/TIR, Beer–Lambert por espessura, rough microfacet GGX e multiscattering energy compensation.
- Para renderização espectral real: amostras de comprimento de onda, distribuição de amostragem, `SampledSpectrum`, integração com funções de correspondência CIE 1931 XYZ e transformação XYZ→linear sRGB. A quadratura espectral atual do shader é uma aproximação multi-banda, não um path tracer espectral.
- Revestimentos/vidro com interferência exigiriam transferência de matrizes por camada (thin-film), índices complexos por camada e ângulo dependente; não adicionar sem necessidade visual demonstrada.

### Situação no TITAN

A V11.21 já usa nove bandas de `n,k` para Au/Ag/Cr e GLSL `measuredMetalFresnelSpectral`. V11.22 preserva essa implementação. Não houve necessidade de reescrever o shader de materiais nesta versão.

### Ainda falta

- Dados de liga/temperatura/camada específicos para ouro, prata, cromo, borossilicato e superfícies reais do produto.
- Validação contra esfera de material, HDRI de estúdio e referências fotométricas multiângulo.
- Camadas de película fina e múltiplas interfaces internas para vidros com revestimento, apenas se requeridos.
- Testes reais de aliasing/highlights em diferentes resoluções e GPUs.

---

## 3. Plasma volumétrico

### Top 5 — bibliotecas/refs

| Repositório | Técnicas que importam | Licença/compatibilidade | Decisão para TITAN |
|---|---|---|---|
| [Auburn/FastNoiseLite](https://github.com/Auburn/FastNoiseLite) | OpenSimplex2/S, Perlin, Cellular, fractais, domain warp 2D/3D e ports GLSL | MIT | Alternativa de ruído determinístico a avaliar em benchmark; não substituir a função atual sem ganho. |
| [stegu/webgl-noise](https://github.com/stegu/webgl-noise) | Simplex/Perlin/Worley 2D–4D sem lookup de textura, GLSL | MIT | Referência de ruído procedimental auto-contido e uso de ALU. |
| [shader-park/shader-park-core](https://github.com/shader-park/shader-park-core) | Abstração para gráficos 2D/3D procedurais e animação | MIT; framework/authoring | Referência de autoria procedural, não motor volumétrico pronto. |
| [keijiro/NoiseShader](https://github.com/keijiro/NoiseShader) | Perlin/simplex 3D e derivadas analíticas HLSL | Código derivado do webgl-noise; licença MIT do código de ruído identificado, pacote tem integração Unity | Referência de derivadas analíticas e custo do campo; não copiar wrapper Unity. |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Raymarching/volume examples, GLSL, buffers e integração com renderer | MIT; runtime atual | Referência de integração e compatibilidade WebGL. |

### Stack avançada recomendada

- Densidade volumétrica: multi-octave 3D noise + domain warping + curl/noise advection + density remapping por raio/temperatura.
- Integração: Beer–Lambert transmittance, optical depth acumulado, early termination, amostragem jittered blue-noise e passo limitado por curvatura/gradiente da densidade.
- Espalhamento: Henyey–Greenstein anisotrópico e iluminação de volume com orçamento controlado; emissividade e extinção devem ser grandezas separadas.
- Temporal: seed por voxel/célula estável, advecção coerente, filtragem de variação de alta frequência e sem flicker temporal por reconstrução aleatória.
- Desempenho: adaptive step count, early-out, ruído ALU versus 3D texture cache medido, resolução adaptativa e perfil de qualidade por GPU.

### Situação no TITAN

V11.21 já usa `curl noise`, FBM 3D, densidade radial, raymarch adaptativo de 8–16 amostras, jitter espacial estável e parada por transmittance. V11.22 não adiciona amostras cegamente; as otimizações devem ser medidas em GPU real antes de aumentar a fidelidade.

### Ainda falta

- Validar optical-depth error por segmento e comparar integração de volume com referência offline.
- Calibrar o halo local dentro do vidro para que emissão interna ilumine parede e borda sem usar bloom como substituto de luz.
- Registrar orçamento de energia do plasma: núcleo, corona, filamentos, emissão e absorção.
- MHD/eletromagnetismo real não está implementado e não é requisito para uma VFX realista convincente.

---

## 4. Arcos elétricos, ramificações e microanimações

### Top 5 — repositórios/refs

| Repositório | Técnicas que importam | Licença/compatibilidade | Decisão para TITAN |
|---|---|---|---|
| [the-worst-student/dielectric-breakdown-model](https://github.com/the-worst-student/dielectric-breakdown-model) | SOR para resolver Laplace, campo elétrico local, limiar de ruptura e crescimento estocástico de árvore | Não foi encontrado LICENSE público | Pesquisa física somente; não copiar código. |
| [eXoddiS/lightning-arc](https://github.com/eXoddiS/lightning-arc) | Net de arcos multi-hop, bolt pool, cadeia de segmentos, gradiente hot-core/edge e atualização temporal | MIT; Three.js | Referência de VFX/estrutura de linhas, não solver elétrico. |
| [SahilK-027/Lightning-VFX](https://github.com/SahilK-027/Lightning-VFX) | Arcos procedurais, crackle, sparks e impacto | MIT | Referência artística para camadas de descarga. |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | LightningStrike geometry, ruído e atualização no renderer | MIT; runtime atual | Preferir primitives nativas caso uma geometria de arco seja necessária. |
| [keijiro/NoiseShader](https://github.com/keijiro/NoiseShader) | Derivadas analíticas de ruído 2D/3D e variações temporais | Código de ruído MIT; port Unity | Referência para deformar canal sem reamostrar topologia. |

### Stack avançada

- Caminho do líder elétrico: crescimento em grid/volume guiado por `∇²V = 0`, campo máximo na ponta, stochastic dielectric-breakdown probability `P ∝ |E|^η`, branching seed e inibição de canal.
- Descarga: Heidler current waveform, canal com MTLE (Modified Transmission Line with Exponential decay), envelope por nó/segmento e heat/emissivity deposition.
- Microanimações: nascimento/morte individual, branch IDs persistentes, leader advance, return-stroke propagation, restrike com memória, corona, micro-sparks com culling e tempo de vida.
- Render: tubo/line distance field, hot core + broad halo, anisotropic bloom localizado, spill óptico no plasma/vidro.

### V11.22

Corrigiu deriva de topologia: `nodeId` e `nodeLocalX` dependem somente de `pos3D.x`; `nodeSeed` e `nodeCycleRate` definem um pulso próprio para cada nó. O tempo não muda o endereço espacial do nó. O canal continua procedimental; não é simulação de campo elétrico.

### Ainda falta

- Solução Laplace/DBM licencia­da ou implementada originalmente e calibrada para o dielétrico do componente.
- MTLE físico, tensão/condutividade e tempo em unidades calibradas.
- Sequências visuais de 10–20 s para revisar repetição, popping e restrikes.

---

## 5. Corpo 3D, anatomia e deformação

### Top 5 — repositórios/refs

| Repositório | Cobertura/técnica | Licença/compatibilidade | Decisão para TITAN |
|---|---|---|---|
| [MervinR07/open-anatomy-3d](https://github.com/MervinR07/open-anatomy-3d) | GLB masculino/feminino, meshes nomeadas por sistema e catálogo | Modelos/catalog CC BY 4.0; código MIT; mulher é ajustada por thin-plate-spline a partir da anatomia masculina para estruturas sem referência feminina | Melhor candidato para atlas de referência separado; não substitui a malha ativa/morphs. |
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | 2.234 meshes BodyParts3D separáveis, 15 sistemas e 3.432 conceitos | App MIT; dataset de referência masculina mantém licença/proveniência própria | Bom para navegação e picking; não resolve dual-body nem morfos atuais. |
| [makehumancommunity/makehuman](https://github.com/makehumancommunity/makehuman) | Base corporal paramétrica, morph targets e rig humano | Licenças variam entre base e ativos contributivos; TITAN já usa hm08 | Preservar a base atual e melhorar sua topologia/targets com rastreabilidade. |
| [LluisV/Z-Anatomy](https://github.com/LluisV/Z-Anatomy) | Atlas muscular/esquelético detalhado e nomenclatura anatômica | CC BY-SA 4.0 (ShareAlike) | Referência de terminologia/anatomia; requer compatibilidade de licença antes de incorporar. |
| [vchoutas/smplx](https://github.com/vchoutas/smplx) | Modelo humano paramétrico, corpo/rosto/mãos, blend shapes e pose | Licença restrita a pesquisa científica não comercial para modelos/softwares | Referência acadêmica, não usar em distribuição comercial do TITAN. |

### Situação real do TITAN

O mapa de estruturas diferencia `geometryStatus` e `deformationStatus`. As três cabeças do deltoide têm geometria/deformação independentes na base atual. Pectoral, bíceps/tríceps, antebraço, dorsais/trapézio, abdômen, glúteos, quadríceps, posteriores e panturrilha continuam com grupos compartilhados em graus diferentes. O construtor de volumes procedurais pode acentuar regiões, mas isso não transforma cabeças musculares em meshes individuais com origem/inserção próprias.

### Melhorias estruturais necessárias

- Um adaptador de atlas separado deve carregar nós/catálogos por estrutura, preservar `sourceId`, espécie/sexo, coordinate frame, unidade, pose e checksum; não alterar IDs de vértice do corpo atual/objetivo.
- Segmentação independente só é válida quando há faces/vértices próprios ou uma máscara anatômica verificável; não criar cabeça por rótulo ou peso inventado.
- Deformação de treino precisa de origem/inserção, eixo de ação, volume preservation, limites articulares, fáscia/tendão e validação para modelos masculinos e femininos.
- Melhorar as mãos/pés, transições de clavícula/axila/joelho/tornozelo e anatomia superficial; testar silhouette 360°.
- Ativos CC BY 4.0 devem trazer crédito completo aos upstream (BodyParts3D/HRA/MakeHuman) e indicar modificações; atlas educativo não é diagnóstico.

### Ainda falta

- Implementar loader opt-in de atlas masculino/feminino somente depois de pinning/inspeção de GLBs e compatibilidade de pose/escala/topologia.
- Meshes de músculo individualizados para os grupos compartilhados, tendões/fáscias, landmarks de origem/inserção e deformações independentes.
- Medidas corporais e incerteza para o corpo objetivo; morph paramétrico não deve ser apresentado como previsão fisiológica precisa.

---

## 6. Pele, subsurface scattering e microtextura

### Top 5 — repositórios/refs

| Repositório | Técnicas | Licença/compatibilidade | Decisão para TITAN |
|---|---|---|---|
| [iryoku/separable-sss](https://github.com/iryoku/separable-sss) | Diffusion profile multi-Gaussian, separable horizontal/vertical filtering e transmittance para regiões finas | Licença BSD customizada com aviso específico em redistribuição binária | Principal referência para etapa UV/irradiance-space futura; nenhum código foi copiado. |
| [google/filament](https://github.com/google/filament) | Material subsurface/translucency, thickness e PBR físico | Apache-2.0 | Referência de modelo de material e integração PBR. |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Exemplo de SSS com thickness map e shader de difusão | MIT; exemplo legado baseado em Blinn–Phong | Referência de integração, não representa SSS de produção moderna. |
| [playcanvas/engine](https://github.com/playcanvas/engine) | PBR material pipeline, diffuse transmission e LTC area lights | MIT | Referência de integração de luz/material e testes de shader. |
| [mmp/pbrt-v4](https://github.com/mmp/pbrt-v4) | BSSRDF e transporte de luz espectral/offline | Apache-2.0; custo offline | Referência teórica para comparar aproximações, não migrar renderer. |

### Stack avançada

- BSSRDF/separable SSS no espaço de irradiância antes de tone mapping, perfil multi-Gaussian por canal e convolução horizontal/vertical.
- Espessura regional: orelha/nariz/lábio/dedo/abdômen/braço/perna; perfil diferente para pele, tecido e estruturas internas.
- Albedo/normal/roughness escaneados, poros e micro-rugas; separar detalhe de alta frequência de scattering de baixa frequência.
- Screen-space: depth, normal, material ID, thickness e alpha gates para evitar bleed por silhueta e sobreposição de membros.

### V11.22

O compositor atual mantém três escalas espaciais com rejeição por profundidade, gate por hue/material e preservação de alpha. Esse filtro é uma aproximação screen-space; não é um BSSRDF. O perfil UV pré-existente continua como reflectance/albedo prefilter.

### Ainda falta

- Passe separável que filtre irradiância, não apenas cor do albedo, com normal/depth-aware taps e material mask.
- Mapas de espessura regional medidos e referências de pele escaneada.
- Comparações sob luz frontal, lateral e contraluz em múltiplos tons de pele.

---

## 7. Iluminação de estúdio e halo traseiro

### Top 5 — repositórios/refs

| Repositório | Técnicas | Licença/compatibilidade | Decisão para TITAN |
|---|---|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | RectAreaLight, LUTs LTC, PMREM e PBR | MIT; renderer atual | Manter como base. |
| [google/filament](https://github.com/google/filament) | IBL, GGX, exposição/câmera, área de luz e material | Apache-2.0 | Referência de calibração material/luz. |
| [playcanvas/engine](https://github.com/playcanvas/engine) | Clustered lighting, area lights e LTC LUTs | MIT | Referência para custo de lights e energia. |
| [LiamSwarbrick/LTCClustered-ManyAreaLights](https://github.com/LiamSwarbrick/LTCClustered-ManyAreaLights) | LTC poligonal + clustered forward shading | LICENSE não encontrada nesta inspeção; pesquisa somente | Referência para escalabilidade, sem importar código. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | Environment presets, transmission helpers e integração React Three Fiber | MIT; camada R3F | Referência auxiliar; não necessária ao Three.js direto usado pelo TITAN. |

### Situação atual

O palco anatômico já tem uma direção key compartilhada entre shader e luzes, softboxes/RectAreaLight com fallback, RoomEnvironment→PMREM e **um único halo difuso atrás do corpo**. O chão/plinto/projetor, círculo luminoso inferior e luz de contato já foram retirados. V11.22 preserva esse contrato; não se deve reintroduzir luz no piso.

### Ainda falta

- HDRI/EXR de estúdio com licença, exposição e white balance conhecidos.
- Calibrar intensidades, tamanho aparente das fontes, temperatura de cor, tone mapping e resposta da pele.
- Capturas 360° para corpo masculino/feminino e qualidade em desktop/mobile.
- Validar fallback de luz retangular em software renderer e hardware low-end.

---

## Integração, desempenho e decisões

- Não adicionar mais luzes para esconder defeitos de material; calibrar uma composição coerente.
- Não transformar o plasma em MHD nem a gota em CFD 3D sem necessidade visual e orçamento GPU demonstrados.
- Não usar um modelo masculino de atlas como base feminina; nem tratar deformação por TPS como anatomia feminina independente.
- Não reutilizar modelos SMPL-X comercialmente sob licença não comercial.
- O PCG/IC(0) é adequado à pequena grade atual; uma grade grande/3D precisaria reavaliar multigrid, MIC(0), AMG ou solver GPU.
- V11.22 continua com Three.js r187 + WebGL2/GLSL ES 3.00 e sem dependências runtime novas.
