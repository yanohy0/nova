# TITAN V.MAX V11.20 — Deep Research, seleção de repositórios e plano de fechamento

**Base auditada:** `TITAN_V11_19_ULTRA_REALISM.zip` (CRC íntegro).  
**Estratégia:** manter React + Three.js/WebGL2 e os subsistemas existentes; usar repositórios como referência de algoritmos, não como dependências automáticas.  
**Critério de seleção:** aderência técnica ao problema, maturidade, documentação, possibilidade de portar um algoritmo isolado e licença. “Top 5” abaixo significa shortlist técnica por funcionalidade, não ranking universal de estrelas.

## 1. Água, gota e menisco — Top 5

| Repositório | Técnica útil | Decisão para TITAN |
|---|---|---|
| [jeantimex/webgpu-water](https://github.com/jeantimex/webgpu-water) | Heightfield GPU 256², refração por Snell, caustics e Fresnel | Referência para avaliar aumento de resolução em hardware capaz; não portar WebGPU como requisito |
| [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) | WebGL2, FFT, ripples, caustics, resolução adaptativa | Referência de orçamento adaptativo e óptica compacta; licença MIT visível |
| [ScottieFox/caustic-volume](https://github.com/ScottieFox/caustic-volume) | Caustics com versão Lite e sandbox de maior custo | Referência para separar perfil de qualidade e caustics |
| [HowdyKeith/swek-webgl2-water](https://github.com/HowdyKeith/swek-webgl2-water) | Heightfield ping-pong, differential-area caustics | Referência de implementação simples WebGL2; MIT declarado |
| [urcraft/ship-in-a-bottle](https://github.com/urcraft/ship-in-a-bottle) | SDF compartilhado, solver GPU/CPU, menisco e caustics | Referência de coerência entre geometria/solver/shader; validar licenças de assets separadamente |

**Técnicas avançadas a fechar:** volume integral analítico da cavidade (já existe); solver shallow-water conservativo de volumes finitos/HLL só se o caso de uso exigir escoamento de superfície; advecção semi-Lagrangiana com MacCormack/BFECC para reduzir difusão; projeção incompressível com pressão iterativa e fronteiras ghost-cell; CFL adaptativo; conservação por ledger de massa com fontes/sumidouros explícitos; menisco Young–Laplace não linear axisimétrico com ângulo de contato dinâmico e histerese advancing/receding; curvatura por heightfield e caustics por Jacobiano diferencial da refração.

**Não fazer:** trocar a gota de interface por SPH/FLIP ou solver oceanográfico. O custo não se justifica para o componente compacto.

## 2. Vidro e metais — Top 5

| Repositório | Técnica útil | Decisão |
|---|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Fresnel, transmissão, chunks PBR e render targets | Manter como runtime e referência |
| [google/filament](https://github.com/google/filament) | BRDF/BSDF, energia conservada, materiais transmissivos | Usar como referência matemática |
| [KhronosGroup/glTF-Sample-Viewer](https://github.com/KhronosGroup/glTF-Sample-Viewer) | Implementação de materiais glTF e validação de render | Referência de comportamento e testes |
| [pmndrs/drei](https://github.com/pmndrs/drei) | MeshTransmissionMaterial, thickness e backside | Referência de custo e composição, não dependência |
| [polyanskiy/refractiveindex.info-database](https://github.com/polyanskiy/refractiveindex.info-database) | Dados espectrais de n,k por material | Fonte de dados com atribuição/licença por dataset; auditar antes de incorporar |

**Técnicas avançadas:** interpolação espectral de n(λ), k(λ) em tabela compacta; amostragem espectral hero-wavelength em 6–12 bandas apenas em modo high; Fresnel complexo condutor exato; Beer–Lambert por comprimento óptico; Sellmeier para dielétricos; múltiplos ressaltos internos com limite energético; microfacet GGX com VNDF; roughness filtering por footprint; thin-film interference somente em camadas fisicamente justificadas; IBL/PMREM calibrado. A implementação atual já tem Fresnel exato, Snell/TIR, Sellmeier e Beer–Lambert; o gap é a tabela RGB de n,k e validação multi-bounce.

## 3. Plasma volumétrico — Top 5

| Repositório | Técnica útil | Decisão |
|---|---|---|
| [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) | Perfil adaptativo de resolução em WebGL2 | Referência de orçamento GPU, não de plasma |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Pipeline WebGL, render targets e integração | Runtime atual |
| [Auburn/FastNoiseLite](https://github.com/Auburn/FastNoiseLite) | Ruído coerente e configurações multi-octave | Referência; ruído analítico próprio já existe |
| [shader-park/shader-park-core](https://github.com/shader-park/shader-park-core) | Composição procedural de campos/shaders | Referência de prototipagem; não copiar DSL inteira |
| [bilgili/skinny](https://github.com/bilgili/skinny) | Path tracing, volume transport, delta tracking e materiais em camadas | Referência offline para validar direção física; não adequado ao runtime mobile |

**Técnicas avançadas:** raymarch adaptativo por comprimento do segmento (implementado em V11.20: 8–16 passos); extinction/emission integradas com Beer–Lambert e front-to-back compositing; jitter blue-noise temporal com reprojeção quando houver histórico; density majorant e delta tracking para validação offline; multi-scale curl noise; separação explícita de emissividade do núcleo, corona e densidade do meio; iluminação local na parede do vidro; LOD de ruído e step count por footprint. Para simulação física real seria necessário MHD/transportes acoplados, fora do orçamento e do objetivo visual atual.

## 4. Arcos e descargas — Top 5

| Repositório | Técnica útil | Decisão |
|---|---|---|
| [diluuuu10/triggered-discharge](https://github.com/diluuuu10/triggered-discharge) | Laplace field, dielectric-breakdown growth, Heidler/MTLE, volume GPU | Referência técnica de maior aderência; licença não declarada no metadata consultado, não copiar código |
| [keijiro/spektrlightning](https://github.com/keijiro/spektrlightning) | VFX de raios no Unity | Referência visual; verificar licença e engine antes de qualquer uso |
| [patch-gg/pixelfx](https://github.com/patch-gg/pixelfx) | Estados temporais de efeitos lightning | Referência para charge/strike/decay, não física |
| [Remotion](https://github.com/remotion-dev/remotion) | Sequenciamento temporal de animação | Não é solver; útil apenas para testes/captura determinística se licença/escopo permitir |
| [SummerEngine](https://github.com/SummerEngine) | Referência de VFX em tempo real | Identidade/licença precisa de confirmação antes de uso |

**Técnicas avançadas:** campo potencial Laplaciano ∇²V=0; crescimento de streamer por dielectric-breakdown model com probabilidade proporcional a |E|^η; branching com memória espacial e anisotropia; líder stepped com velocidade finita; retorno Heidler; decaimento MTLE; canal condutor com raio e condutividade finitos; corona e glow volumétrico; persistência/restrike e extinção independentes. TITAN continua VFX procedural; só migrar para solver físico se houver requisito científico explícito.

## 5. Anatomia e deformação muscular — Top 5

| Repositório/dataset | Técnica útil | Decisão |
|---|---|---|
| [MakeHuman](https://github.com/makehumancommunity) | Base paramétrica humana e morph targets | Base atual; não confundir morph de grupo com cabeça muscular independente |
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | Referência BodyParts3D e mapeamento anatômico | Dados CC BY 4.0, atlas masculino adulto; não é substituto universal/topológico |
| [facebookresearch/SMPL](https://github.com/facebookresearch/SMPL) | Modelo paramétrico e deformação corporal | Verificar licença/modelo de pesquisa antes de integração comercial |
| [NVIDIA/SOMA](https://github.com/NVIDIA/SOMA) | Dados e rigging musculoesquelético | Referência avançada; auditar asset license e formato |
| [Naver/Anny](https://github.com/naver/anny) | Referência de corpo/pose | Validar licença e cobertura anatômica antes de adoção |

**Técnicas avançadas:** rig musculoesquelético com origem/inserção; bones + tendons + fascia; deformação muscle bulge condicionada a pose e volume; corrective blendshapes; pose-space deformation; dual-quaternion skinning; volume preservation; atlas UV por região; correspondência topológica validada; malhas masculinas/femininas e diversidade morfológica. O gap principal é asset/topologia, não um shader. Não fabricar subdivisões musculares sem geometria ou evidência anatômica.

## 6. Pele e SSS — Top 5

| Repositório | Técnica útil | Decisão |
|---|---|---|
| [google/filament](https://github.com/google/filament) | Subsurface material e pipeline PBR | Referência para perfil e energia |
| [nff747/subsurface-scattering-wgsl](https://github.com/nff747/subsurface-scattering-wgsl) | SSSS separável, soma de Gaussianas Jimenez e translucência | Prova de conceito WebGPU; validar qualidade/licença antes de portar |
| [bilgili/skinny](https://github.com/bilgili/skinny) | BSSRDF/volume layered skin e delta tracking | Referência de ground truth offline |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Thickness, render targets e shaders | Compatibilidade runtime |
| [playcanvas/engine](https://github.com/playcanvas/engine) | Pipeline PBR e SSS/lighting patterns | Referência de implementação |

**Técnicas avançadas:** perfil de difusão normalized multi-Gaussian (Jimenez 6-term); convolution separável horizontal/vertical com bilateral depth/normal gates; thickness map anatômico por UV; irradiance bake UV com chart/seam dilation; diffusion por canal em linear light; backface transmission; albedo/specular separation; calibrar por espectro/tons de pele; validação multi-light e multi-view. Atual V11.19: pré-filtragem UV de refletância e screen-space diffusion 8 taps cardinais. Não declarar BSSRDF completo.

## 7. Iluminação — Top 5

| Repositório | Técnica útil | Decisão |
|---|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | PMREM, RectAreaLight, WebGL renderer | Manter |
| [google/filament](https://github.com/google/filament) | IBL/PBR e energia consistente | Referência matemática |
| [playcanvas/engine](https://github.com/playcanvas/engine) | LTC area lights e softboxes | Referência para luz retangular |
| [pmndrs/drei](https://github.com/pmndrs/drei) | Environment/lighting helpers | Referência de integração, sem adicionar dependência |
| [pmndrs/react-three-fiber](https://github.com/pmndrs/react-three-fiber) | Integração React/Three | Não altera física da luz; sem necessidade de adoção |

**Técnicas avançadas:** HDRI calibrado; PMREM prefiltered; LTC para area lights; exposição ACES/AgX única; key/fill/rim com medição; IBL consistente entre shader custom e materiais nativos; teste de rotação 360°. Restrição imutável: corpo não recebe luz projetada no chão; manter um único halo difuso atrás do corpo, sem plinto, chão emissivo ou feixe inferior.

## 8. Implementação V11.20

O shader de plasma agora escolhe 8–16 amostras por comprimento de segmento, com 12 amostras aproximadas para segmento típico. O loop tem máximo estático 16 para GLSL ES 3.00. É uma otimização/qualidade adaptativa de integração, não uma simulação física nem prova de ganho em GPU. O contrato estático foi adicionado ao teste de realismo.

## 9. Trabalho ainda necessário para o nível final

1. **GPU real:** compilar todos os shaders WebGL2 em Chromium/ANGLE funcional; medir GPU ms, VRAM, draw calls e custo do compositor em desktop e mobile.
2. **Água:** construir balanço de massa observável com fontes/sumidouros nomeados; substituir reciclagem visual por transferência explícita de massa; resolver menisco não linear axisimétrico e ângulo de contato dinâmico; validar caustics com referência offline.
3. **Óptica:** aumentar amostras n,k por faixa espectral; validar espessura e múltiplos ressaltos internos; adicionar micro-scratch anisotrópico e ambiente HDR calibrado.
4. **Plasma/arcos:** medir custo do raymarch adaptativo; avaliar reprojeção temporal e blue-noise; criar state machine por ramo; só então avaliar solver de Laplace/DBM/Heidler/MTLE como modo de demonstração física separado.
5. **Anatomia:** escolher/obter assets licenciados com topologia humana adequada; construir correspondência topológica e morphs por cabeça muscular; validar sexo, proporção, mãos/pés e articulações.
6. **Pele:** irradiance UV bake com dilation de chart; perfil multi-Gaussian completo por canal; thickness map por região; dataset de referência com direitos claros.
7. **Iluminação:** HDRI de estúdio, calibração de exposição e teste 360°, mantendo halo único e ausência absoluta de luz no chão.
8. **Entrega:** instalar dependências quando registry estiver acessível; executar npm test, lint, build e WebGL shader compile; screenshots golden e benchmark; testes E2E.

## 10. Licenciamento e adoção

Nenhum código ou asset de terceiros foi copiado nesta evolução. Os links são referências de estudo. Antes de importar geometria, textura, dataset ou shader, verificar a licença do código **e** a licença do asset/dado separadamente, atribuição exigida, uso comercial, redistribuição e restrições de pesquisa. Repositórios sem licença identificável ficam apenas como referência conceitual.
