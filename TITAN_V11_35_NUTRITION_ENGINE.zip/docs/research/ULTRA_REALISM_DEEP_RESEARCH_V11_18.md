# TITAN V.MAX V11.18 — Pesquisa profunda e engenharia de realismo

**Data da pesquisa:** 25 de novembro de 2026  
**Base:** V11.17 reconstruída com os arquivos omitidos no ZIP recebido preservados da versão completa anterior.  
**Stack de runtime mantida:** React + TypeScript + Three.js 0.187 + WebGL2 + GLSL ES 3.00; o compositor anatômico continua GLSL ES 1.00 no pipeline WebGL1/Three.js correspondente.  
**Regra de integração:** referências GitHub servem para comparar algoritmos e fundamentar escolhas. Nenhum projeto foi copiado como runtime ou adicionado como dependência apenas por popularidade.

> Estrelas são snapshots aproximados observados no levantamento anterior e em 25/11/2026. A seleção é por relevância técnica para cada especialidade, não por ranking global cego. Licença de código e licença de datasets/ativos são verificações separadas.

## 1. Síntese das decisões

1. Preservar o ray marcher e a geometria SDF já existentes para água, vidro, plasma e metal; os componentes são pequenos e não justificam ocean solver, path tracer ou uma segunda engine.
2. Usar Fresnel dielétrico exato (s/p) com Snell e reflexão interna total nas interfaces água/vidro relevantes. Usar Fresnel exato de condutor complexo com `n(λ)+i k(λ)` e GGX anisotrópico para os macros.
3. Os valores de metais não devem ser inferidos da cor de UI. A V11.18 usa amostras tabuladas R/G/B aproximadas de Johnson & Christy para prata, cromo e ouro; a cor visual do macro atua somente como acabamento/tint leve.
4. O plasma continua sendo volume emissivo procedural. A dispersão, filamentos e arcos devem ter coerência temporal; os caminhos dos arcos são persistentes durante a descarga e o ruído os deforma em vez de reconstruir a topologia em todo frame.
5. Para pele, combinar espessura óptica regional, um perfil RGB de espalhamento aproximado no material e uma difusão screen-space curta, com rejeição por profundidade e proteção de cores holográficas. Isto melhora a aparência, mas não equivale a UV-space multi-Gaussian SSS nem a path tracing.
6. Melhorar a independência muscular com os IDs anatômicos já incorporados no mesh CC0; evitar importar malhas de terceiros sem correspondência topológica/licença comprovadas.
7. Iluminação permanece sem luz projetada no chão: key, fill e rim discretos revelam o corpo; um único halo difuso, no plano de fundo atrás da silhueta, cria separação e profundidade.

## 2. Pesquisa por especialidade — Top 5

### 2.1 Água: gota e barra de hidratação

| Repositório | Estrelas aprox. | Licença/estado verificado | Aplicação no TITAN |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Base de renderer, shaders, precisão, refração e ambiente. |
| [evanw/webgl-water](https://github.com/evanw/webgl-water) | 1.3k | Sem licença identificada nos metadados consultados | Referência de height-field, refração, Fresnel e cáusticas; código não copiado. |
| [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) | 0.5k | MIT | Referência WebGL de Beer–Lambert, ondas e caústicas; escala de piscina não deve ser portada. |
| [jeantimex/threejs-water](https://github.com/jeantimex/threejs-water) | 0.24k | Metadados sem SPDX confirmado nesta coleta | GPU height-field e integrações Three.js; considerar compatibilidade de runtime antes de portar. |
| [ScottieFox/caustic-volume](https://github.com/ScottieFox/caustic-volume) | 0.19k | MIT | Caústicas, reflexão/refração e volume como referência de fenômeno. |

**Deep-search de implementação:** nos exemplos oficiais do Three.js, `WaterRefractionShader` usa distorção DuDv em uma textura projetada; é útil para água de cena, mas não substitui as interseções de dupla parede já usadas pelo medidor. `clearwater` e `caustic-volume` demonstram solver de superfície e cáusticas de escopo muito maior; portar esse solver para uma cápsula de hidratação teria custo desproporcional.

**Técnicas escolhidas:** Fresnel dielétrico exato s/p, Snell/TIR, Beer–Lambert em espaço linear, Sellmeier para água/vidro, menisco Young–Laplace, filtro analítico por footprint, caústicas por derivadas diferenciais e render sob demanda com dither estável por pixel.

**Limite:** a gota e a barra são aproximações SDF/2.5D otimizadas para UI. Não são fluidos SPH/FLIP nem path-traced; não se adicionou solver FFT, bolhas GPU ou partículas em massa.

### 2.2 Vidro de energia e de macros

| Repositório | Estrelas aprox. | Licença | Contribuição relevante |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | `MeshPhysicalMaterial`, iluminação e shaders-base. |
| [google/filament](https://github.com/google/filament) | 20.8k | Apache-2.0 | PBR, unidades físicas, transmissão, roughness e SSS. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10.2k | MIT | `MeshTransmissionMaterial`, thickness/backside, IOR, aberração e custo de buffers. |
| [google/model-viewer](https://github.com/google/model-viewer) | 8.3k | Apache-2.0 | Validação de materiais glTF em cena de referência. |
| [KhronosGroup/glTF-Sample-Viewer](https://github.com/KhronosGroup/glTF-Sample-Viewer) | 1.5k | Apache-2.0 | Implementação de referência de extensões de transmissão/volume/IOR/dispersion. |

**Achado importante do deep-search:** o código do Drei e suas histórias documentam explicitamente o custo de resolução de transmissão, backside e thickness. A melhor decisão para este projeto é estudar o modelo e manter o ray marching local do TITAN, não adicionar um passe de transmissão da cena inteira.

**Técnicas escolhidas:** IOR e dupla interface, Fresnel exato, Snell/TIR, espessura de parede, absorção Beer–Lambert, dispersão Sellmeier do borossilicato e GGX para micro-highlights. A parede externa não deve receber dispersão RGB uniforme; o efeito é atenuado em regiões quase planas e cresce em bordas/ângulos rasantes.

#### Metais: dados ópticos

Fonte primária de dados: [polyanskiy/refractiveindex.info-database](https://github.com/polyanskiy/refractiveindex.info-database), que declara CC0 para a base. As amostras usadas são tabulações room-temperature de Johnson & Christy:

- Au: *Optical constants of the noble metals*, Physical Review B 6 (1972), 4370–4379.
- Ag: mesma publicação e tabela.
- Cr: *Optical constants of transition metals*, Physical Review B 9 (1974), 5056–5070.

A V11.18 amostra `n,k` em 659.5, 520.9 e 450.9 nm (R/G/B). Não é uma curva espectral contínua nem uma certificação de liga comercial; é uma aproximação RGB rastreável, muito melhor que derivar `n,k` da cor do widget. A equação usa Fresnel de condutor exato e termo correto `n²-k²-sin²θ`, com GGX anisotrópico. O teste numérico em incidência normal usa F0 aproximado: Ag 0.9906/0.9835/0.9803, Cr 0.5567/0.5581/0.5551, Au 0.9626/0.6434/0.4082 (R/G/B).

### 2.3 Plasma volumétrico

| Repositório | Estrelas aprox. | Licença | Contribuição e limite |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Contexto de runtime e WebGL. |
| [Auburn/FastNoiseLite](https://github.com/Auburn/FastNoiseLite) | 3.5k | MIT | Família de ruídos e GLSL; biblioteca de ruído, não plasma. |
| [pmndrs/postprocessing](https://github.com/pmndrs/postprocessing) | 3k | Zlib | Passes e bloom; não substitui a integração volumétrica. |
| [shader-park/shader-park-core](https://github.com/shader-park/shader-park-core) | 0.83k | MIT | Campos procedurais/SDF como referência de organização. |
| [Donitzo/three.js-volume-renderer](https://github.com/Donitzo/three.js-volume-renderer) | 22 | MIT | Raymarching de volume, clipping e extinção. |

**Técnicas:** ruído 3D multifrequência, curl noise, domain warp moderado, remapeamento de densidade, volume integration, Beer–Lambert, jitter estável, término antecipado, emissão HDR e bloom limitado ao núcleo. Não se deve aumentar o número de passos sem um benchmark de GPU; o shader atual tem um custo de ruído 3D significativo.

**Limite:** plasma de widget é uma representação emissiva estilizada. Henyey–Greenstein pode descrever scattering de volume, mas não transforma plasma emissivo em um meio atmosférico real. A luz interna/reflexo verde na parede deve continuar local e discreta.

### 2.4 Raios e microanimações

| Repositório | Estrelas aprox. | Licença/limite | Uso adequado |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Buffers, geometria e shader runtime. |
| [remotion-dev/remotion](https://github.com/remotion-dev/remotion) | 75k | Não assumir licença de reutilização pelo número de estrelas | Estudar efeito de lightning e envelopes temporais. |
| [patch-gg/pixelfx](https://github.com/patch-gg/pixelfx) | 9.2k | MIT | Catálogo e timing de arcos, corrente elétrica, sparks e bursts; linguagem visual VFX, não modelo 3D físico. |
| [keijiro/spektrlightning](https://github.com/keijiro/spektrlightning) | 210 | MIT; Unity/C# | Referência de ramificação procedural, não integração direta no Three.js. |
| [SummerEngine/summer](https://github.com/SummerEngine/summer) | 113 | MIT | Pipeline de efeitos/skills VFX; não um motor autônomo de plasma 3D. |

**Técnicas:** topologia de arcos persistente por seed, pontos de ramificação estáveis, jitter espacial limitado, envelope de ataque/decay contínuo, pulsos que percorrem canal, ramificações com vida independente, reacendimento parcial, núcleo e corona separados, distância/cobertura volumétrica e flicker não quantizado. As fontes consultadas são referências de arte e de VFX, não simulação de descarga elétrica de laboratório.

**Limite:** o componente do TITAN não calcula campo elétrico, breakdown dielétrico, streamer eletro-hidrodinâmico ou propagação de elétrons. Não se deve apresentar a animação como uma simulação física de descarga atmosférica.

### 2.5 Corpo, anatomia e deformação muscular

| Repositório | Estrelas aprox. | Licença | Aplicação/limite |
|---|---:|---|---|
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | 4.6k | Código MIT; dado BodyParts3D CC BY 4.0 | Estruturas anatômicas e taxonomia; referência masculina adulta e dataset com atribuição. |
| [makehumancommunity/makehuman](https://github.com/makehumancommunity/makehuman) | 1.7k | Metadados devem ser verificados por componente/asset | Parametrização de corpo e base morfológica. |
| [facebookresearch/MHR](https://github.com/facebookresearch/MHR) | 0.9k | Apache-2.0 | Human model reconstruction e forma paramétrica. |
| [NVlabs/SOMA-X](https://github.com/NVlabs/SOMA-X) | 0.9k | Apache-2.0 | Parametrização de forma e morphs; backend científico, não renderer de app. |
| [naver/anny](https://github.com/naver/anny) | 0.66k | Licença/uso de dados precisa de avaliação específica | Representação e reconstrução humana. |

**Técnicas:** mapa semântico por vértice canônico, máscara muscular, morph targets esparsos, deformação por região e lado, volume preservation, smooth transitions, normal recomputation/tangent correctness e LOD real. A V11.18 separa os grupos já codificados nos dados da malha: bíceps (ID 5) e tríceps (ID 6), quadríceps (ID 12) e posteriores/isquiotibiais (ID 13). Os lofts complementares também recebem lóbulos anteriores e posteriores independentes.

**Limite importante:** isso aprimora a independência de deformação da malha existente. Não cria origem/inserção anatômica validada para todos os músculos, não aumenta automaticamente a resolução do asset-base, nem substitui um atlas anatômico completo. A malha MakeHuman hm08 continua como ativo-base CC0.

### 2.6 Pele e subsurface scattering

| Repositório | Estrelas aprox. | Licença | Contribuição |
|---|---:|---|---|
| [google/filament](https://github.com/google/filament) | 20.8k | Apache-2.0 | Modelo material subsurface e parâmetros, integração PBR. |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Thickness e pipeline de materiais/iluminação. |
| [playcanvas/engine](https://github.com/playcanvas/engine) | 17.3k | MIT | Renderer e iluminação; referência de implementação de luz/arte. |
| [pmndrs/postprocessing](https://github.com/pmndrs/postprocessing) | 3k | Zlib | Pós-processamento e infraestrutura de filtros, não skin SSS pronto. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10.2k | MIT | Materiais e integração R3F; referência de pipeline, não dependência necessária. |

**Fonte técnica adicional:** NVIDIA GPU Gems 3, capítulo “Advanced Techniques for Realistic Real-Time Skin Rendering” descreve difusão de luz por perfis multi-Gaussian em espaço de textura. O estudo ensina que a luz se espalha lateralmente em escalas diferentes e que um único blur é insuficiente.

**V11.18:** estimativa de espessura óptica por região (tronco, membros, cabeça), atenuação RGB e perfis próximo/largo no shader da pele; o compositor aplica 5 amostras screen-space, com rejeição por profundidade e filtro cromático para não borrar holograma/contorno. Isso é uma aproximação realtime, não substitui o método multi-Gaussian UV-space. A resolução e os RTs atuais devem ser medidos em GPU para decidir se o próximo salto justifica outro pass.

### 2.7 Iluminação do corpo

| Repositório | Estrelas aprox. | Licença | Contribuição |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Renderer, PMREM, RectAreaLight. |
| [google/filament](https://github.com/google/filament) | 20.8k | Apache-2.0 | PBR e consistência de luz/material. |
| [playcanvas/engine](https://github.com/playcanvas/engine) | 17.3k | MIT | Área de luz e softboxes retangulares via LTC. |
| [pmndrs/react-three-fiber](https://github.com/pmndrs/react-three-fiber) | 33.9k | MIT | Integração Three.js/React, não melhora física por si só. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10.2k | MIT | Environment/lighting utilities. |

**Decisão:** key de área para desenhar volume, fill fraco para abrir sombra, rim suave para separar contorno e um único halo difuso atrás do corpo. Sem floor mesh emissivo, ground projector, círculo nos pés ou feixe vertical. O halo é cenário, não uma fonte de luz local falsa no chão.

## 3. Implementação V11.18

### 3.1 Óptica dielétrica

- Adicionada equação exata de Fresnel não polarizado, média de polarizações s/p, com lei de Snell e TIR.
- Substituídos os Fresnel aproximados de interfaces dielétricas críticas água/vidro e microfacetas de água/borossilicato.
- Mantidos modelos de dispersão Sellmeier e Beer–Lambert já existentes.

### 3.2 Óptica metálica

- Corrigida e implementada Fresnel exata de condutor com `n,k` complexos.
- Adicionados três perfis de material: silver, chromium e gold, com amostras RGB tabuladas de `refractiveindex.info`/Johnson–Christy.
- O preset material vem do tipo do macro (carboidrato/prata, proteína/cromo, gordura/ouro); cor da UI apenas tinge o resultado levemente.
- Mantido GGX anisotrópico e anti-aliasing de highlight.

### 3.3 Plasma e microanimação de descarga

- O curl do campo escalar foi refeito com derivada analítica do ruído trilinear (`energyNoise3DGradient`): oito cantos do lattice são avaliados uma vez e o gradiente é obtido pela regra da cadeia, em vez de seis reamostragens por diferenças finitas.
- O caminho ridged do canal principal/secundário deixou de avaliar quatro extremidades por coordenada e interpolá-las a cada passo do raymarch; agora consulta diretamente duas coordenadas contínuas do campo, reduzindo o trabalho do caminho em cada amostra.
- O ruído ridged usa remapeamento com `smoothstep` para suavizar a inversão em torno do meio do sinal. A identidade da ramificação continua presa ao `nodeId`, com envelope temporal contínuo.
- Essa otimização reduz amostras de ruído, mas não é um benchmark de tempo de GPU. Os 12 passos fixos de volume e custo total continuam exigindo medição em hardware.

### 3.4 Anatomia e pele

- Verificada a separação de IDs canônicos para bíceps/tríceps e quadríceps/isquiotibiais no asset binário.
- Morfologia da malha usa os IDs distintos em cada morph esparso.
- Loft procedural recebe lóbulos anteriores/posteriores independentes e transições suavizadas.
- Material de pele recebe espessura óptica regional e perfis RGB multi-lobe aproximados.
- Compositor dual-body recebe difusão screen-space de cinco amostras com proteção por profundidade e tonalidade.

### 3.5 Iluminação

- Rig refinado para soft key retangular, fill baixo e rim suave; fallback de software possui intensidades próprias.
- Preservado apenas o halo difuso no fundo. Nenhum projetor/plinto de chão é criado.

### 3.6 Dependências

Nenhuma nova dependência runtime foi adicionada. Evita-se adicionar um segundo renderer, transmissão de cena inteira, solver oceanográfico ou pacote de partículas ao app.

## 4. Testes acrescentados

- `scripts/check-rendering-realism-v11-18.mjs`: contratos de ótica exata, constantes `n,k`, presets de metal, morphs regionais, SSS e halo.
- `scripts/check-anatomy-independent-morphs-v11-18.mjs`: decodifica a geometria binária e valida que os morphs esparsos realmente alcançam IDs distintos das quatro regiões musculares.
- `scripts/check-energy-noise-gradient-v11-18.mjs`: compara a derivada analítica do ruído com diferenças centrais em seis pontos e três eixos (18 comparações).
- O contrato de realismo também confirma a derivada analítica do ruído de plasma e a retirada da interpolação segmentada redundante dos caminhos de arco.
- `scripts/check-gpu-shaders-v11-18.mjs`: cria contexto headless Chromium/WebGL2 e compila os sete fragment shaders de fluidos e o fragment shader do compositor, se o host oferecer Chromium com SwiftShader/WebGL.

## 5. Limitações remanescentes que exigem dados ou hardware externo

- A simulação de água continua um shader SDF/2.5D; não é SPH/FLIP nem path tracing.
- O metal usa três amostras visíveis de `n,k` por material; não é uma curva espectral contínua nem identifica composição de uma liga real.
- O plasma e os arcos são representações visuais, não simulações de eletrodinâmica/plasma físico.
- A pele usa espessura estimada e difusão screen-space local; falta a implementação de SSS multi-Gaussian UV-space completa, que exigiria UVs/RTs/blur e benchmark específico.
- A anatomia foi refinada dentro da malha/IDs existentes. Para todas as origens, inserções, tendões e músculos profundos será necessário adquirir/validar ativo anatômico com licença e correspondência topológica, ou construir um novo asset.
- A calibração final de tom, roughness, bloom, exposição, subpixel aliasing e FPS precisa ser executada em browsers/GPU reais (desktop e mobile). Compilação headless confirma sintaxe/link do shader, não aprovação perceptual nem desempenho.

## 6. Arquivos de referência consultados (deep-search em código e documentação)

- [Three.js WaterRefractionShader](https://github.com/mrdoob/three.js/blob/dev/examples/jsm/shaders/WaterRefractionShader.js) e [exemplo de refração](https://github.com/mrdoob/three.js/blob/dev/examples/webgl_refraction.html): distorção screen-space DuDv; útil como referência complementar, não para substituir os limites internos SDF do medidor.
- [Drei MeshTransmissionMaterial source](https://github.com/pmndrs/drei/blob/master/src/core/MeshTransmissionMaterial.tsx) e [documentação do material](https://github.com/pmndrs/drei/blob/master/docs/shaders/mesh-transmission-material.mdx): contrato de `transmission`, `thickness`, backside, roughness e resolução. Reforça o custo de transmissão por buffer.
- [FastNoiseLite GLSL README](https://github.com/Auburn/FastNoiseLite/blob/master/GLSL/README.md): configurações e uso GLSL; avaliado como referência, sem substituir a função noise local por uma biblioteca extra.
- [Filament Materials guide](https://github.com/google/filament/blob/main/docs/Materials.md.html): material Subsurface, propriedades e integração PBR.
- [Three.js TSL thickness docs](https://github.com/mrdoob/three.js/blob/dev/tsl/content/Guide.md): thickness como espessura de volume para transmissão/SSS; referência para coerência de parâmetro.
- [PixelFX catalog — lightning effects](https://github.com/patch-gg/pixelfx/blob/main/docs/CATALOG.md): timing de charge-up/electrified/strike e camadas de descarga. É catálogo VFX e não modelo eletrofísico.
- [Human Atlas attribution and data scope](https://github.com/ashemag/human-atlas/blob/main/public/ATTRIBUTION.md): confirma licença CC BY 4.0 do conjunto BodyParts3D e a limitação de referência masculina adulta; por isso nenhum dado foi importado silenciosamente.
- [PlayCanvas area-light example](https://github.com/playcanvas/engine/blob/main/examples/src/examples/lights-and-shadows/area-lights/example.mjs): fonte retangular / softbox como referência de iluminação; o renderer do TITAN permanece Three.js.
- [RefractiveIndex database — Ag](https://github.com/polyanskiy/refractiveindex.info-database/blob/main/database/data/main/Ag/nk/Johnson.yml), [Au](https://github.com/polyanskiy/refractiveindex.info-database/blob/main/database/data/main/Au/nk/Johnson.yml) e [Cr](https://github.com/polyanskiy/refractiveindex.info-database/blob/main/database/data/main/Cr/nk/Johnson.yml): arquivos consultados para as três amostras RGB usadas no shader.
- [NVIDIA GPU Gems 3 — Advanced Techniques for Realistic Real-Time Skin Rendering](https://developer.nvidia.com/gpugems/gpugems3/part-iii-rendering/chapter-14-advanced-techniques-realistic-real-time-skin): referência de perfil de difusão multi-Gaussian e blur em espaço de textura; não foi portada como algoritmo completo nesta iteração.
