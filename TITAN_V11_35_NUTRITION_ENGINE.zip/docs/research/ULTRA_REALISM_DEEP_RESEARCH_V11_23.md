# TITAN V11.23 — Deep Research técnico e decisões por subsistema

Data: 25/11/2026  
Base: `TITAN_V11_22_ULTRA_REALISM.zip`, recuperado da Biblioteca e extraído em workspace isolado.  
Pesquisa: GitHub Search e leitura direta de README/código/licenças via integração GitHub. **Firecrawl não foi usado.**  
Método: top 5 por aderência técnica ao problema (não ranking de estrelas). Repositórios são referências de engenharia, não dependências automáticas. Nenhum código ou ativo de terceiros foi incorporado.

## Decisões de arquitetura desta revisão

- Manter Three.js r187 + WebGL2 + GLSL ES 3.00. Não migrar para outro renderer nem introduzir WebGPU para componentes pequenos.
- Não adicionar endpoints, SDKs de IA, clientes HTTP genéricos, sincronização remota ou analytics genérico sem caso de uso ativo.
- Não construir ossos, esqueleto ou tendões. O corpo 3D é uma representação visual da superfície corporal e dos grupos musculares relevantes ao treino; as camadas existentes de tecido mole são preservadas.
- Melhorar o menisco existente com um perfil Young–Laplace 2D não linear limitado, testado contra uma referência RK4; não alegar solução 3D exata.
- Preservar o halo único difuso atrás do corpo e a ausência de luz projetada no chão.
- Preservar dados locais e proveniência de alimentos/exercícios; remover somente chamadas/SDKs/URL builders sem consumidor.

## 1. Água, gotas, menisco e cáusticas

### Top 5 — referências GitHub

| Repositório | Contribuição técnica | Decisão |
|---|---|---|
| [doyubkim/fluid-engine-dev](https://github.com/doyubkim/fluid-engine-dev) | SPH/PCISPH, PIC/FLIP/APIC, level sets, IC/ICCG, MGPCG e solvers 2D/3D; MIT | Referência numérica para solver e discretização, sem adicionar runtime C++ |
| [PavelDoGreat/WebGL-Fluid-Simulation](https://github.com/PavelDoGreat/WebGL-Fluid-Simulation) | Stable Fluids GPU, advecção semi-Lagrangiana, projeção, vorticity confinement; MIT | Referência mais próxima do backend WebGL atual |
| [InteractiveComputerGraphics/SPlisHSPlasH](https://github.com/InteractiveComputerGraphics/SPlisHSPlasH) | SPH, PBF, PCISPH, DFSPH, viscosidade implícita e vizinhança | Referência para eventual gota livre em 3D, não necessária para o copo atual |
| [google/FluidNet](https://github.com/google/FluidNet) | Estimativa de pressão por CNN e projeção de fluido | Pesquisa acadêmica; não adicionar modelo aprendido ao app |
| [RealAbdurRehman/fluid-simulation](https://github.com/RealAbdurRehman/fluid-simulation) | Superfície, espuma, absorção e cáusticas em GPU/WebGPU | Referência visual; API não é drop-in para WebGL2 |

### Stack apropriada

- Grade Euleriana 2D: advecção semi-Lagrangiana/MacCormack, projeção de pressão `A p = -∇·u`, precondicionador IC(0)-PCG e resíduo verdadeiro.
- Gota 3D somente quando houver necessidade medida: PBF/DFSPH, spatial hashing, compact neighbor lists, superfície reconstruída e culling por tile.
- Óptica: SDF da cavidade, Fresnel dielétrico, Snell/TIR, Beer–Lambert, espessura óptica e foco de cáusticas limitado.
- Menisco: Young–Laplace não linear `h'' = h(1+h'^2)^(3/2)`, ângulo de contato, parâmetro capilar e histerese avanço/recuo. Cox–Voinov só é válido depois de calibrar velocidade/escala em unidades SI.

### Resultado V11.23

- A referência CPU usa uma aproximação fechada limitada, com altura de parede da primeira integral não linear e transição exponencial corrigida pela inclinação na linha de contato.
- O shader GLSL repete a mesma fórmula e as duas cavidades existentes (vidro e reservatório) chamam a função comum.
- Teste numérico compara ângulos de 22,5° a 157,5° e distâncias de 0 a 4 comprimentos capilares contra integração RK4; limite de erro relativo declarado no teste: 8%.
- Isto não é uma solução 3D de menisco curvo nem um solver de Navier–Stokes completo.

## 2. Vidros, metais e óptica espectral

### Top 5 — referências GitHub

| Repositório | Contribuição técnica | Decisão |
|---|---|---|
| [polyanskiy/refractiveindex.info-database](https://github.com/polyanskiy/refractiveindex.info-database) | Tabelas `n(λ), k(λ)`, Sellmeier, Cauchy, Drude/Lorentz com fontes/DOIs; CC0 para dados | Fonte de dados medidos já usada na V11.21 |
| [mmp/pbrt-v4](https://github.com/mmp/pbrt-v4) | `SampledSpectrum`, transporte espectral pontual, Fresnel de condutores, dispersão e volumetria | Referência algorítmica; path tracer não é renderer de UI |
| [google/filament](https://github.com/google/filament) | PBR realtime, GGX, transmissão, clearcoat, espessura, IBL | Referência de consistência; não migrar engine |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | IOR, transmissão, PMREM, materiais e shader hooks | Runtime atual, manter compatibilidade |
| [lightsmith-photonics/lightsmith-materials](https://github.com/lightsmith-photonics/lightsmith-materials) | Organização de dados ópticos medidos e proveniência | Referência de catalogação, sem nova dependência |

### Stack apropriada

- Condutores: Fresnel complexo usando `n(λ)+i k(λ)`, interpolação monotônica limitada à faixa medida e rugosidade microfacet GGX.
- Dielétricos: Fresnel exato, Snell/TIR, Beer–Lambert por espessura e Sellmeier onde o vidro tem coeficientes publicados.
- Espectro completo exigiria amostragem de comprimentos de onda, integração CIE 1931 XYZ e conversão XYZ→linear sRGB; 9 bandas no shader são uma aproximação multi-banda, não um path tracer espectral.
- Filmes finos somente quando a espessura/coating for conhecida: transferência matricial para camadas complexas e interferência.

### Situação e limite

A base já preserva dados medidos de Au/Ag/Cr, interpolação e aproximação espectral no shader. Esta revisão não amplia para CIE contínuo porque isso exige teste de referência espectral, novos dados de coating e custo GPU mensurado. Não se altera o caminho óptico sem cenas de calibração e comparação multiajuste.

## 3. Plasma volumétrico

### Top 5 — referências GitHub

| Repositório | Contribuição técnica | Decisão |
|---|---|---|
| [Auburn/FastNoiseLite](https://github.com/Auburn/FastNoiseLite) | OpenSimplex2/S, Perlin, Cellular, fractais e domain warp em GLSL/JS; MIT | Referência para campo de densidade, sem instalar biblioteca |
| [stegu/webgl-noise](https://github.com/stegu/webgl-noise) | Simplex/Perlin/Worley 2D–4D sem lookup de textura; MIT | Referência de custo ALU/ruído GLSL |
| [shader-park/shader-park-core](https://github.com/shader-park/shader-park-core) | Autoria procedural e mapeamento de campos | Não substitui o raymarch do produto |
| [keijiro/NoiseShader](https://github.com/keijiro/NoiseShader) | Ruído 3D e derivadas analíticas HLSL | Referência para derivadas/gradientes; wrapper Unity não é compatível |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | GLSL, raymarching, render targets e integração | Referência de integração no renderer atual |

### Stack apropriada

- Campo volumétrico: multi-octave 3D noise, domain warp, curl-noise e densidade remapeada por raio/temperatura.
- Integração: Beer–Lambert por optical depth acumulado, early termination, majorant/step adaptativo e amostragem blue-noise para reduzir banding.
- Luz: Henyey–Greenstein, separação core/envelope/filamentos/corona e contribuição local de emissão; controlar bloom sem saturar o objeto vizinho.
- Perf: 8/12/16 amostras adaptativas, limite de iteração estático GLSL e resolução dinâmica de acordo com cobertura.

### Situação

A V11.20 já trocou passos fixos por raymarch adaptativo (8/12/16); V11.22 estabilizou identidade espacial e cadência independente dos ramos. Continua um campo procedural visual, não plasma MHD. A validação de qualidade/tempo em GPU física continua pendente.

## 4. Arcos e descargas elétricas

### Top 5 — referências GitHub

| Repositório | Contribuição técnica | Decisão |
|---|---|---|
| [the-worst-student/dielectric-breakdown-model](https://github.com/the-worst-student/dielectric-breakdown-model) | DBM e crescimento estocástico guiado por campo | Referência para pesquisa de líder; auditar licença antes de reutilizar |
| [eXoddiS/lightning-arc](https://github.com/eXoddiS/lightning-arc) | Redes de arcos multi-hop, core quente e gradiente de brilho; Three.js | Referência visual procedural; não é modelo eletrofísico |
| [SahilK-027/Lightning-VFX](https://github.com/SahilK-027/Lightning-VFX) | Construção de VFX de raios e ramificações | Inspiração visual; verificar licença/qualidade antes de qualquer adoção |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Geometrias LightningStrike e integração no render | Preferir primitivos nativos |
| [keijiro/NoiseShader](https://github.com/keijiro/NoiseShader) | Deformação temporal e derivadas de ruído | Referência matemática; não importar wrapper Unity |

### Stack apropriada

- Física do líder, quando realmente necessária: potencial `∇²V=0`, campo na ponta `E=-∇V`, DBM com probabilidade `P∝|E|^η`, seed determinístico e inibição de canal.
- Descarga: corrente de Heidler, propagação MTLE, parâmetros calibrados de condutividade/permissividade/tensão.
- Animação: branch IDs espaciais persistentes, pulse envelope por segmento, leader advance, return stroke, restrike e extinção por TTL.
- Render: core emissivo fino, glow multiescala local, corona curta e spill no plasma/vidro; não exigir bloom global para que o raio seja visível.

### Situação

A V11.21 introduziu forma de onda normalizada de Heidler; a V11.22 separou seed/clock por nó e manteve a topologia espacial. DBM/MTLE físico não está presente e não deve ser afirmado.

## 5. Corpo 3D e musculatura visível (sem ossos/tendões)

### Top 5 — referências GitHub

| Repositório | Contribuição técnica | Decisão |
|---|---|---|
| [MervinR07/open-anatomy-3d](https://github.com/MervinR07/open-anatomy-3d) | GLB masculino/feminino com meshes nomeadas e catálogo de 147 estruturas; modelos CC BY 4.0, código MIT | Referência anatômica; não substituir a malha atual porque a malha feminina tem estruturas transformadas por TPS |
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | Atlas de estruturas BodyParts3D e navegação/picking | Referência de nomenclatura; não carregar assets no viewer |
| [makehumancommunity/makehuman](https://github.com/makehumancommunity/makehuman) | Corpo paramétrico, targets e topologia humana | Preservar hm08 atual e seus IDs de vértices |
| [LluisV/Z-Anatomy](https://github.com/LluisV/Z-Anatomy) | Atlas de anatomia e terminologia | Pesquisa textual/visual somente; licença ShareAlike/NC conforme ativo |
| [vchoutas/smplx](https://github.com/vchoutas/smplx) | Modelo paramétrico humano e pose blend shapes | Restrição não comercial torna a adoção inadequada ao produto |

### Stack apropriada ao escopo

- Surface/body base + músculo superficial + plano profundo: manter batches separados para seleção, morph e sombreado.
- Deformação: morph targets esparsos, máscaras suaves por grupo e lateralidade; manter volume aproximado e transições suaves sem inventar topologia de cabeças musculares ausentes.
- Aparência: fibers orientadas à superfície/UV, normal microdetail, roughness regional e PBR; validação por silhueta e rotação.
- Não criar `skeletonGroup`, malhas ósseas, tendões ou tubos anatômicos ocultos. A estrutura permanece focada na superfície e nas camadas musculares existentes.

### V11.23

Foram removidos os batches escondidos de coluna, costelas, crânio, membros e dedos, o material esquelético sem uso e o toggle de visibilidade correspondente. Corpo-base, músculos superficiais/profundos, 14 IDs canônicos, morphs, seleção, picking e oclusão permanecem. O alias persistido `layerMode: 'skeleton'` continua sendo normalizado para a vista completa apenas para compatibilidade com estado antigo; não volta a criar geometria.

## 6. Pele e subsurface scattering

### Top 5 — referências GitHub

| Repositório | Contribuição técnica | Decisão |
|---|---|---|
| [iryoku/separable-sss](https://github.com/iryoku/separable-sss) | Perfil multi-Gaussian e filtro separável em duas passagens | Referência algorítmica; não copiar a demo antiga DirectX |
| [google/filament](https://github.com/google/filament) | Material subsurface/translucency, thickness e PBR; Apache-2.0 | Referência de comportamento/material |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Exemplos de SSS/thickness e integração WebGL | Referência de integração, não de qualidade final |
| [playcanvas/engine](https://github.com/playcanvas/engine) | PBR, diffuse transmission, area lights e LUTs LTC | Referência de pipeline de iluminação |
| [mmp/pbrt-v4](https://github.com/mmp/pbrt-v4) | BSSRDF e transporte de luz offline/espectral | Referência para comparar o limite das aproximações realtime |

### Stack apropriada

- BSSRDF/separable SSS de alta qualidade deve filtrar irradiância linear pré-tone mapping, não apenas albedo.
- Perfil de difusão multi-Gaussian por canal, taps separáveis com normal/depth/material/thickness gate e transmittance para regiões finas.
- Thickness regional medido; poros/micro-rugas em albedo/normal de alta frequência, scattering com frequência baixa.

### Situação

A V11.22 mantém três escalas de difusão screen-space, rejeição por profundidade, seletor de pele e alpha estável. Não há buffer de irradiância UV nem BSSRDF completo. Uma implementação disso exigiria novo render target e passe específico; não adicionar até medir custo e provar resultado em dispositivos alvo.

## 7. Iluminação de estúdio e halo de fundo

### Top 5 — referências GitHub

| Repositório | Contribuição técnica | Decisão |
|---|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | RectAreaLight, LTC, PMREM e PBR | Runtime atual e referência principal |
| [google/filament](https://github.com/google/filament) | IBL, GGX, exposure/camera e resposta de materiais | Referência de calibração, sem migração |
| [playcanvas/engine](https://github.com/playcanvas/engine) | Clustered lighting, area lights e LUT LTC | Referência de escalabilidade |
| [LiamSwarbrick/LTCClustered-ManyAreaLights](https://github.com/LiamSwarbrick/LTCClustered-ManyAreaLights) | LTC poligonal e clustered forward shading | Pesquisa somente enquanto licença não estiver confirmada |
| [pmndrs/drei](https://github.com/pmndrs/drei) | HDRI/Environment helpers na integração R3F | Não necessário ao Three.js direto usado pelo app |

### Stack apropriada

- HDRI/EXR calibrado com licença e metadados, PMREM, exposição/white balance explícitos.
- Softboxes de área retangular com fallback coerente, direção key única para luz real e shader, tone mapping controlado.
- Testes 360° com fundo neutro e pele em key/fill/rim. Um único halo difuso atrás do corpo; nenhum chão, plinto, círculo luminoso inferior ou luz de contato no piso.

### Situação

A direção key sincronizada, softboxes/RectAreaLight com fallback, RoomEnvironment→PMREM e halo único já estão presentes. Falta calibração visual com HDRI autorizado e execução no navegador/GPU de destino; não há evidência para declarar o look aprovado em hardware.

## Auditoria de APIs e dependências

- `server.ts`: cinco handlers em quatro famílias de rota não tinham consumidores no frontend; a aplicação Express inteira foi removida. Vite atende desenvolvimento/preview e `dist/` é publicado como estático.
- Excluir `http-client.ts`, `sync-queue.ts`, `event-tracker.ts` sem consumidores, `server.ts`, o bundle obsoleto `server.js` e as dependências diretas Express/compression.
- Remover SDK `@google/genai`, variável `GEMINI_API_KEY` e metadata `MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API`: não havia import nem chamada. Não adicionar AI API ou endpoint.
- Remover `buildOpenFoodFactsV3Url` sem consumidor. Preservar registros locais de produtos, marcação `label_partial` e identificação do dataset Open Food Facts; não alegar consulta remota ativa.
- Remover painel de candidatos de repositórios da tela de exercícios; manter registro estático e proveniência/licença por exercício.
- Preservar bridge de atividade nativa e os catálogos de domínio efetivamente usados; eles não são chamadas HTTP genéricas.

## Validação e limites que não podem ser mascarados

- Perfil não linear de menisco: teste CPU vs RK4 e contrato estático CPU/GLSL.
- Escopo e pruning: teste verifica rotas, dependência Gemini, URL builder OFF, lote de esqueleto ausente e dados locais preservados.
- Testes herdados V11.22 continuam sendo parte da regressão.
- Build completo, lint com tipos do Vite, compilação GLSL em WebGL2 e profiling GPU real dependem de dependências e host GPU/browser disponíveis. Sem isso não existe certificação V.MAX nem medição FPS/VRAM.
