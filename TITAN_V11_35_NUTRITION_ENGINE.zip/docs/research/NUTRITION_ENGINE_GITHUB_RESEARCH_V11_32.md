# TITAN Nutrition Engine — Deep research and repository decisions (V11.32)

Research snapshot: 2026-11-26. Star counts fluctuate; values below are approximate repository-page snapshots, not quality scores. Popularity is a discovery signal only.

## 1. Repositories compared by capability

| Capability | Repository | Approx. stars | License | Decision for TITAN |
|---|---|---:|---|---|
| TypeScript compiler/type system | [microsoft/TypeScript](https://github.com/microsoft/TypeScript) | 111.9k | Apache-2.0 | Adopt practices: strict compiler options, explicit nullability, no unchecked indexing. Do not fork/compiler-swap. |
| Runtime data contracts | [colinhacks/zod](https://github.com/colinhacks/zod) | ~44k | MIT | Already a project dependency. Reuse at UI/API boundaries; keep narrow domain guards for serialized nutrition records where semantic checks are more important than generic schemas. |
| Type-aware static analysis | [typescript-eslint/typescript-eslint](https://github.com/typescript-eslint/typescript-eslint) | 16.5k | MIT | Preferred next static-analysis expansion: `recommendedTypeChecked`, `no-floating-promises`, unsafe assignment/member access, consistent type imports, exhaustive switches. Not installed/changed in this iteration. |
| Test runner | [vitest-dev/vitest](https://github.com/vitest-dev/vitest) | 17.4k | MIT | Strong future runner for this Vite project; not introduced because the existing Node-based review suite can run without dependency installation. |
| Property-based testing | [dubzzz/fast-check](https://github.com/dubzzz/fast-check) | 5.2k | MIT | Candidate for generated nutrient-unit, meal aggregation, solver-bound and persistence round-trip invariants; not added as a dependency. Existing new tests use deterministic adversarial cases. |
| Structural AST search/lint/codemods | [ast-grep/ast-grep](https://github.com/ast-grep/ast-grep) | 16.7k | MIT | Best targeted option for structural checks across TS/TSX (unsafe casts, raw storage, direct cross-domain imports) and repeatable codemods; not installed. |
| Static code-quality platform | [SonarSource/sonarqube](https://github.com/SonarSource/sonarqube) | 11.2k | LGPL-3.0 | Use as an optional CI quality gate for complexity, duplication, bugs and coverage once build/test CI is reproducible; not added locally. |
| SAST / custom rule engine | [semgrep/semgrep](https://github.com/semgrep/semgrep) | ~17.8k | LGPL-2.1 | Candidate for custom rules: missing provenance, `Number()`/zero coercion on nutrient data, unsafe external JSON and solver fallback paths. Community Edition has analysis-scope limitations; do not describe it as a complete cross-file SAST solution. |
| Review annotations | [reviewdog/reviewdog](https://github.com/reviewdog/reviewdog) | 9.8k | MIT | Good integration layer to annotate changed lines from ESLint, Semgrep and Sonar on PRs; not an analyzer by itself. |
| Operations research | [google/or-tools](https://github.com/google/or-tools) | 14.4k | Apache-2.0 | Reference for CP-SAT and multi-period constraints. Not adopted: current HiGHS solves the existing LP/QP/MIP problem and a solver rewrite is not justified yet. |
| Current solver | [ERGO-Code/HiGHS](https://github.com/ERGO-Code/HiGHS) | ~1.9k | MIT | Retained. The immediate defect was primal-vector acceptance, not solver selection. Requires live WASM validation in a dependency-installed environment. |
| Nutrition diary / sources | [simonoppowa/OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker) | 3k | GPL-3.0 | Architecture and citation UX reference only. No code copied; copyleft makes direct code reuse inappropriate without a deliberate licensing decision. |
| Food stock / recipe workflows | [grocy/grocy](https://github.com/grocy/grocy) | 9.7k | MIT | Reference for inventory and consumption workflows, not nutrient-science authority. No dependency/code added. |
| USDA FDC parsing | [nodef/usda-fdc](https://github.com/nodef/usda-fdc) | modest | Check repository LICENSE before reuse | Compared as an FDC corpus loader/search reference. TITAN parser is independently written and retains source nutrient IDs, names, units and data statuses. |
| USDA API client | [john-hix/usda-food-data-central-client](https://github.com/john-hix/usda-food-data-central-client) | modest | Check repository LICENSE before reuse | Generated OpenAPI client pattern; not the right tool for offline bulk-data ingestion. |

Sources for the snapshot: repository pages are linked in each row. Counts are approximate snapshots captured on 2026-11-26; license and star count should be rechecked before introducing any dependency. See also [ast-grep](https://github.com/ast-grep/ast-grep), [SonarQube](https://github.com/SonarSource/sonarqube), [Semgrep](https://github.com/semgrep/semgrep) and [reviewdog](https://github.com/reviewdog/reviewdog).

## 2. Advanced stack and terminology by problem domain

### A. Senior TypeScript / code quality

- `strict`, `noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`, `noImplicitOverride`, `noPropertyAccessFromIndexSignature`.
- Type-aware ESLint (`typescript-eslint` `recommendedTypeChecked`), promise-safety lint, exhaustiveness checking, import-boundary checks and `git diff --check`.
- Keep domain contracts typed at the boundary; use runtime parsing for persisted state and imported datasets. `satisfies` and discriminated unions for scientific data states.
- Add `fast-check` only when reproducible generated invariants provide measurable coverage; avoid adding a test framework just for reputation.

### B. USDA FoodData Central and food-source integrity

- Release pinning by `dataType + publication/release version + dataset SHA-256 + source URL + license + retrieval timestamp`.
- Schema-aware parsing; exact tuple `nutrient.id + nutrient.number + nutrient.name + unitName`; no fuzzy matching; quarantine unknown IDs, legacy-number mismatches, duplicate conflicts and changed units. In official FDC JSON, `nutrient.id` is the permanent ID while `nutrient.number` is a separate legacy code; e.g. Protein = `(1003, "203")`, Fiber = `(1079, "291")`, Calcium = `(1087, "301")`, and Atwater Specific Energy = `(2048, "958")`.
- Idempotent source identity `(source_id, fdcId, release_version)`; staging table/catalog; duplicate-ID detection; source-preserving raw value; explicit normalization method; import report by food/nutrient/status.
- Bulk archive ingestion is distinct from the FDC REST API. Foundation, SR Legacy, FNDDS and Branded datasets have different semantics and release cadences; do not flatten them into one source-quality class. The USDA publishes JSON and CSV separately; current downloads include Foundation Oct-2026, SR Legacy Apr-2018 and FNDDS 2021–2023 (Oct-2024). [USDA downloads](https://fdc.nal.usda.gov/download-datasets/)
- The importer now stores an immutable, content-addressed audit JSON with rejected food identities and nutrient quarantine rows; the generated catalog manifest points to its SHA-256. The generated catalog is the publication pointer and is promoted after the audit is present. The exact FDC crosswalk additionally maps chromium (1096/310), fluoride (1099/313), iodine (1100/314) and molybdenum (1102/316), alongside the original set, when the FDC ID, nutrient number, name and unit all match. The canonical chloride field is intentionally not mapped from `Chlorine, Cl` without a reviewed semantic equivalence; niacin mg is not treated as mg NE and phylloquinone is not treated as total vitamin K.
- Production pipeline still needs a pinned archive, real-data regression, content-hash verification, durable large catalog and deployment-level atomic version promotion.

### C. DRI / UL / supplement exposures

- Model exposure as provenance-bearing events with `dateKey`, local time, nutrient ID, amount, unit, chemical form and label/source identity.
- Keep `not_logged`, `quantified`, `unit_mismatch` and `form_unresolved` as separate states; don't zero-fill missing intake.
- Treat `UL scope` as a type-level constraint: `total_intake`, `supplements_only`, `supplements_and_medications`, `supplements_and_fortified_foods`, `preformed_only`, `synthetic_forms_only`.
- Preserve each UL's own numerical unit and chemical basis: preformed vitamin A in µg RAE, folic acid UL in µg folic acid (not µg DFE), niacin UL in mg niacin (not mg NE), vitamin E as alpha-tocopherol, and magnesium from supplements/medications only. NIH ODS explicitly distinguishes these source scopes; see [Vitamin A](https://ods.od.nih.gov/factsheets/VitaminA-HealthProfessional/), [Folate](https://ods.od.nih.gov/factsheets/Folate-HealthProfessional/), [Niacin](https://ods.od.nih.gov/factsheets/Niacin-HealthProfessional/), [Vitamin E](https://ods.od.nih.gov/factsheets/VitaminE-HealthProfessional/), and [Magnesium](https://ods.od.nih.gov/factsheets/Magnesium-HealthProfessional/).
- Mass conversion may scale g↔mg↔µg. It must not derive IU↔mass, RAE, DFE or niacin equivalents without nutrient/form-specific conversion rules and source evidence.
- Food-only and supplement-only subtotals remain separate unless form-resolved data prove the total is comparable.

### D. Meal/recipe optimization and solver correctness

- Distinguish LP/QP/MIP variables and preserve their primal values, bounds, integrality and one-hot semantics.
- Validate the complete primal vector and variable domain before constructing the proposal. Never fill missing continuous values with current grams or missing binaries with zero.
- Next solver hardening: evaluate original-constraint residuals (max absolute and scaled residual), primal/dual feasibility tolerances, solver-reported objective vs recomputed objective, infeasibility diagnostics and model/data fingerprints. Add perturbation/property tests to prove fallback and feasibility under missing/degenerate columns.
- Multi-day optimization (not yet implemented) should use multi-period MIP/CP-SAT with frequency/variety, repeat penalties, availability, budget, cooking-batch and cross-day nutrient constraints. Use lexicographic objective tiers and explicit slack/infeasibility explanations; do not bury hard safety limits inside weighted penalties.

### E. Cooking transformations / yield and retention

- Retain exact food identity and state; use preparation method, cut/edible portion, raw mass, cooked mass, yield factor, water gain/loss, nutrient-specific true-retention factor and source.
- True retention is based on nutrient amount before vs after preparation, not concentration alone; concentration can change merely because water mass changes. Keep `yield_factor = cooked_mass/raw_mass` separate from `true_retention = nutrient_after_total/nutrient_before_total`; if either input is absent, don't synthesize a value. The correct concentration after cooking is derived from both separately.
- Keep macro yield factors separate from micronutrient retention tables. USDA Table of Nutrient Retention Factors is not a general macro-retention table.
- No automatic TBCA↔FDC cooking crosswalk until identity, cultivar/cut, preparation and retention-code mapping have been reviewed.

### F. Protein quality / DIAAS

- DIAAS uses the limiting digestible indispensable amino acid ratio; needs amino-acid composition in mg/g protein and true ileal digestibility per indispensable amino acid for the same food and preparation.
- Evidence metadata must include species, method, study, sample, food identity, processing state, indispensable amino-acid composition, reference pattern and uncertainty. Do not use faecal crude-protein digestibility as a substitute. Score by limiting amino-acid ratio and report the limiting amino acid / data coverage; never call a protein-total heuristic DIAAS.
- Data pipeline still lacks verified per-food amino-acid and ileal-digestibility records; the calculator is a contract/engine, not populated DIAAS truth.

### G. Training energy / adaptive TDEE

- Distinguish gross, net/active and total calories. Do not add gross/total exercise calories to a TDEE baseline that already contains activity.
- Session estimates require start/end time, source-versioned activity/MET code and body mass. Strength-session MET is a population proxy; sets/reps/load are not a validated energy equation.
- Reconcile HealthKit, Health Connect, wearables and manual/estimated sessions by source identity, interval overlap and measurement quality. Keep estimated records lower-priority than measured records. Deduplicate overlap before daily aggregation; don't add GROSS calories to a TDEE baseline containing activity, and don't count NET exercise twice.
- Do not feed estimates into adaptive TDEE without explicit model policy, duplicate resolution and uncertainty calibration.

### H. Scientific and clinical validation

- Separate software correctness from nutrient-reference correctness and clinical validity.
- Maintain provenance, population scope, age/sex/pregnancy/lactation limits, confidence, unit basis and source edition on every DRI/evidence row.
- Validate with independent food analyses, reference meal calculations, dietitian review, edge populations, and longitudinal calibration. Current synthetic energy simulation is not clinical validation.

## 3. Senior review / security-analysis toolchain recommendation

Recommended incremental CI path once install and CI runners are available: (1) `tsc` strict project checks and `typescript-eslint` type-aware rules; (2) `ast-grep` structural rules on unsafe nutrition boundaries and import layering; (3) Semgrep rules for tainted imported JSON, missing provenance and dangerous fallbacks; (4) SonarQube quality gate for maintainability/coverage; (5) `reviewdog` to put findings on the actual changed lines. These tools overlap partly, so do not enable all rulesets at once. Start with high-signal rules and baseline existing warnings to avoid noise.

The project has no independent agent reviewer available in this environment. The release received a local adversarial self-review and executable regression suite, not a second-party review sign-off.

## 4. Why no new dependency was added

The repository already contains TypeScript, Zod, HiGHS and a large deterministic Node review suite. The critical fixes were data-contract and domain-logic work. Adding OR-Tools, Vitest, fast-check or a nutrition application dependency would add lockfile, bundle and deployment surface without solving the immediate failure mode. The release uses existing tooling; future adoption should start with measured gaps and CI installation.

## 2.1 Official FDC nutrient identity crosswalk (V11.32 correction)

The importer was adversarially checked against the USDA FoodData Central current `fullNutrientList` and its download field dictionary. FDC documents the permanent ID field separately from the `food_nutrient.nutrient_id` relation; API nutrient objects additionally contain a legacy `number`. These fields are not interchangeable. The source parser therefore requires the permanent ID, legacy number, canonical nutrient name and unit to match as one reviewed tuple. See the official [FDC download field descriptions](https://fdc.nal.usda.gov/portal-data/external/dataDictionary) and [current downloadable datasets/API documentation](https://fdc.nal.usda.gov/download-datasets/).

| Canonical field | Permanent `nutrient.id` | Legacy `nutrient.number` | Exact FDC nutrient name | Source unit |
|---|---:|---:|---|---|
| Energy (general Atwater) | 2047 | 957 | Energy (Atwater General Factors) | kcal |
| Energy (specific Atwater) | 2048 | 958 | Energy (Atwater Specific Factors) | kcal |
| Energy (generic) | 1008 | 208 | Energy | kcal |
| Protein | 1003 | 203 | Protein | g |
| Total fat | 1004 | 204 | Total lipid (fat) | g |
| Carbohydrate by difference | 1005 | 205 | Carbohydrate, by difference | g |
| Dietary fiber | 1079 | 291 | Fiber, total dietary | g |
| Calcium | 1087 | 301 | Calcium, Ca | mg |
| Iron | 1089 | 303 | Iron, Fe | mg |
| Magnesium | 1090 | 304 | Magnesium, Mg | mg |
| Phosphorus | 1091 | 305 | Phosphorus, P | mg |
| Potassium | 1092 | 306 | Potassium, K | mg |
| Sodium | 1093 | 307 | Sodium, Na | mg |
| Zinc | 1095 | 309 | Zinc, Zn | mg |
| Chromium | 1096 | 310 | Chromium, Cr | µg |
| Copper | 1098 | 312 | Copper, Cu | mg |
| Fluoride | 1099 | 313 | Fluoride, F | µg |
| Iodine | 1100 | 314 | Iodine, I | µg |
| Manganese | 1101 | 315 | Manganese, Mn | mg |
| Molybdenum | 1102 | 316 | Molybdenum, Mo | µg |
| Selenium | 1103 | 317 | Selenium, Se | µg |
| Vitamin A RAE | 1106 | 320 | Vitamin A, RAE | µg |
| Vitamin E (alpha-tocopherol) | 1109 | 323 | Vitamin E (alpha-tocopherol) | mg |
| Vitamin D2 + D3 | 1114 | 328 | Vitamin D (D2 + D3) | µg |
| Vitamin C | 1162 | 401 | Vitamin C, total ascorbic acid | mg |
| Thiamin (B1) | 1165 | 404 | Thiamin | mg |
| Riboflavin (B2) | 1166 | 405 | Riboflavin | mg |
| Pantothenic acid (B5) | 1170 | 410 | Pantothenic acid | mg |
| Vitamin B6 | 1175 | 415 | Vitamin B-6 | mg |
| Biotin (B7) | 1176 | 416 | Biotin | µg |
| Vitamin B12 | 1178 | 418 | Vitamin B-12 | µg |
| Choline | 1180 | 421 | Choline, total | mg |
| Folate DFE | 1190 | 435 | Folate, DFE | µg |
| Saturated fatty acids | 1258 | 606 | Fatty acids, total saturated | g |
| Cholesterol | 1253 | 601 | Cholesterol | mg |

Niacin (`number=406`) and phylloquinone (`number=430`) remain deliberately unmapped to total niacin equivalents and total vitamin K, respectively. Chloride is not mapped from a `Chlorine, Cl` analyte without reviewed semantic equivalence. The importer never converts niacin mg into mg NE, folate into DFE or preformed vitamin A from total vitamin A on a generic path.

Energy selection order is specific Atwater `(2048, 958)`, general Atwater `(2047, 957)`, then generic Energy `(1008, 208)`. A food without an actual supported energy row is rejected; zero kcal is never synthesized.
