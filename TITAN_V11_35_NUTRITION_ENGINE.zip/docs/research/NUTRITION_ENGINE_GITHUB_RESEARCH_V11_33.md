# Deep research — TITAN Nutrition Engine V11.33

Data da consulta: 2026-11-26. Estrelas são snapshots observados nas páginas públicas do GitHub nesta consulta; não medem qualidade científica nem adequação funcional.

## 1. Repositórios por capacidade

| Capacidade | Repositório | Estrelas observadas | Licença | Decisão para TITAN |
|---|---|---:|---|---|
| Linguagem e compilador TS | [microsoft/TypeScript](https://github.com/microsoft/TypeScript) | 111.9k | Apache-2.0 | Usar o próprio compilador como gate; habilitar strictness incremental nas fronteiras de domínio. |
| Validação runtime | [colinhacks/zod](https://github.com/colinhacks/zod) | 44.4k | MIT | Referência para validar payloads externos. Zod já faz parte da stack; não introduzir outro validador. |
| Testes unitários/integrados | [vitest-dev/vitest](https://github.com/vitest-dev/vitest) | 17.5k | MIT | Referência de ergonomia e integração Vite; manter os testes existentes até a suíte e o ambiente estarem prontos para a migração. |
| Lint tipado TS | [typescript-eslint/typescript-eslint](https://github.com/typescript-eslint/typescript-eslint) | 16.5k | MIT | Fonte de regras `recommendedTypeChecked`, `no-floating-promises`, `no-misused-promises` e `consistent-type-imports`; ampliar quando o lint global estiver executável. |
| Busca/rewrite estrutural | [ast-grep/ast-grep](https://github.com/ast-grep/ast-grep) | 16.7k | MIT | Útil para migrações controladas e regras AST em TS/TSX; não é dependência runtime. |
| Property-based testing | [dubzzz/fast-check](https://github.com/dubzzz/fast-check) | 5.3k | MIT | Boa opção futura para invariantes de unidades, solver, limites e conversão; nesta revisão não foi adicionado, pois os testes determinísticos e os geradores atuais cobrem o patch sem expandir dependências. |
| Otimização combinatória | [google/or-tools](https://github.com/google/or-tools) | 14.5k | Apache-2.0 | Referência para CP-SAT/MIP, diagnósticos de inviabilidade e restrições multi-período; não substitui o solver QP/MIP HiGHS atual sem benchmark comparativo. |
| Solver LP/QP/MIP | [ERGO-Code/HiGHS](https://github.com/ERGO-Code/HiGHS) | 2.0k | MIT | Manter como solver existente; prioridade é validar o vetor primal, testar WASM real e documentar limites de precisão. |
| Diário nutricional | [simonoppowa/OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker) | 2.9k | GPL-3.0 | Referência de UX, fontes e proveniência multi-dataset; não copiar código para evitar herança de copyleft no produto. |
| Receitas/planejamento | [mealie-recipes/mealie](https://github.com/mealie-recipes/mealie) | 14.0k | AGPL-3.0 | Referência de organização de receitas/planejamento doméstico; não incorporar código AGPL. |
| Estoque/itens/alimentos | [grocy/grocy](https://github.com/grocy/grocy) | 9.7k | MIT | Referência para rastreamento de itens, lotes, validade e unidades; não usar a aplicação inteira como dependência do motor. |

Links de referência e snapshots: [TypeScript](https://github.com/microsoft/TypeScript), [Zod](https://github.com/colinhacks/zod), [Vitest](https://github.com/vitest-dev/vitest), [typescript-eslint](https://github.com/typescript-eslint/typescript-eslint), [ast-grep](https://github.com/ast-grep/ast-grep), [fast-check](https://github.com/dubzzz/fast-check), [OR-Tools](https://github.com/google/or-tools), [HiGHS](https://github.com/ERGO-Code/HiGHS), [OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker), [Mealie](https://github.com/mealie-recipes/mealie), [Grocy](https://github.com/grocy/grocy).

**Escolha de arquitetura:** nenhum repositório foi selecionado apenas por ter mais estrelas. Não foi copiado código de terceiros, não foram adicionadas dependências nesta revisão e os repositórios GPL/AGPL foram tratados apenas como referência conceitual.

## 2. Ingestão FDC e contratos de dados

### Pipeline agora implementado

`pinned release URL → bounded fetch → ZIP central-directory validation → one JSON payload → source adapter → quarantine/audit → atomic generated catalog → source-aware coverage`

Técnicas: *allowlisted release manifest*, *redirect denial*, host/path exact match, `Content-Length` + streamed-byte bounds (stream obrigatório; sem fallback `arrayBuffer()` ilimitado), `AbortSignal.timeout`, SHA-256 do ZIP original, *ZIP slip/path traversal rejection*, *ZIP bomb ratio cap*, central-directory consistency, validação de data descriptor ZIP com e sem assinatura opcional, CRC32, duplicate/ambiguous JSON rejection, *content-addressed audit sidecar*, immutable raw archive storage, atomic no-overwrite promotion e *source namespace isolation*.

Releases fixadas na lista atual:
- Foundation Foods `2026-10-29` / FDC 16.0, JSON ZIP ~681 KB compactado / ~9 MB expandido.
- SR Legacy `2018-04`, JSON ZIP ~12.3 MB / ~205 MB.
- FNDDS 2021–2023 `2024-10-31`, JSON ZIP ~3.7 MB / ~64 MB.

O download completo Branded Foods (JSON) é aproximadamente 187 MB compactado / 3 GB descompactado e fica fora do fluxo padrão. Branded tem origem em declarações de rótulos/fornecedores e precisa de política específica de produto, GTIN/UPC, `publication_date`, atualização e duplicatas; não deve ser tratado como Foundation/SR/FNDDS equivalentes. Fonte primária: [USDA Downloadable Data](https://fdc.nal.usda.gov/download-datasets/) e [FDC Data Type Documentation](https://fdc.nal.usda.gov/data-documentation/).

O catálogo gerado continua vazio até importar um arquivo real. As fixtures sintéticas demonstram contratos e segurança do parser, mas não comprovam a completude dos registros do USDA, o desempenho de `JSON.parse` em SR Legacy ou a cobertura por nutriente no corpus real.

## 3. Cobertura nutricional e proveniência

A auditoria agora reúne TBCA, Open Food Facts e USDA mantendo `food_id` e `source_id` separados. O resultado deve continuar segmentado por nutriente × fonte × estado do dado, e nunca transformar `missing`, `trace`, `not_analyzed`, `unit_mismatch` ou conflito em zero. A unidade canônica deve coincidir com a química declarada; a base (por 100 g, por porção, por 100 mL etc.) também faz parte do significado do valor.

Fases seguintes: *identity resolution/crosswalk review* TBCA↔FDC com candidatos, score e evidência; nunca juntar alimentos só por nome aproximado; comparar estado cru/cozido, cultivar, parte comestível, fortificação e método analítico. Persistir `sourceId`, `sourceRecordId`, `dataType`, `releaseVersion`, `datasetSha256`, `derivation`, `unit` e base de medição.

## 4. Escopo químico dos ULs

UL não é apenas `nutrientId + value`. Precisa de população/estágio de vida, forma química, fonte abrangida, unidade/base e referência. O sistema deve distinguir: ingestão total; apenas suplementos/medicamentos; apenas suplementos + fortificados; e formas moleculares específicas (ex. vitamina A pré-formada vs provitamina A). Se o ledger não contém todas as fontes requeridas pelo escopo, resultado do UL deve ser `indeterminate/coverage-incomplete`, não `safe` nem `exceeded`.

## 5. Preparo culinário e retenção

A [USDA Table of Nutrient Retention Factors, Release 6](https://catalog.data.gov/dataset/usda-table-of-nutrient-retention-factors-release-6-2007) fornece fatores para vitaminas, minerais e álcool no preparo. Implementação futura precisa separar:
- *cooking yield*: massa cozida / massa crua (alteração de água, descarte, rendimento);
- *true nutrient retention*: (concentração cozida × massa cozida) / (concentração crua × massa crua) × 100;
- *apparent retention*: concentração cozida / concentração crua × 100, que pode confundir perda/ganho de água com retenção real.

O FDC também expõe códigos de retenção no contexto dos alimentos Survey/FNDDS; ainda é necessário mapear alimento/ingrediente, etapa de preparo e código para regras específicas. Não aplicar um fator genérico a macros ou a nutrientes sem linha de evidência apropriada. O Release 6 contém fatores para 26 vitaminas/minerais/álcool e acrescentou colina; não é uma tabela universal de retenção de proteína, carboidrato e lipídios.

## 6. Qualidade proteica (DIAAS)

A [FAO 2013](https://www.fao.org/4/i3124e/i3124e.pdf) define DIAAS pela menor razão digestível entre os aminoácidos indispensáveis do alimento e o padrão de referência, multiplicada por 100. O contrato precisa de perfil de cada aminoácido indispensável, quantidade por grama de proteína, digestibilidade ileal verdadeira específica de cada aminoácido e identidade exata de espécie, alimento e estado/preparo. Não estimar DIAAS com proteína bruta, digestibilidade fecal total ou aminoácido ausente. Para misturas, calcular pela contribuição digestível de cada ingrediente antes de escolher o aminoácido limitante.

## 7. Energia de atividade e treino

A revisão sistemática de 2024 sobre gasto energético de treino resistido inclui 166 estudos; a maioria usou calorimetria indireta, poucos usaram MET, e os valores/definições de período variam bastante. Calorimetria indireta por si só pode não capturar todo o componente glicolítico; combinar medições de recuperação e lactato seria mais robusto, mas impraticável fora do laboratório. MET serve como estimativa de campo e precisa de intervalo/baixa confiança; não usar uma estimativa por sessão para somar novamente em TDEE/EER que já incorporam atividade.

O [2024 Adult Compendium](https://pmc.ncbi.nlm.nih.gov/articles/PMC10818145/) lista 1.114 atividades, mas o artigo é CC BY-NC-ND. O projeto não deve empacotar uma cópia derivada da tabela sem revisão de direitos; o adaptador pode aceitar entradas de MET licenciadas e rastreadas separadamente.

## 8. Otimização e arquitetura do plano alimentar

Técnicas apropriadas, ainda não concluídas: *multi-period MILP/CP-SAT*, frequências por alimento/grupo, restrições de repetição, orçamento, disponibilidade e preparo em lote; objetivo lexicográfico (primeiro segurança/viabilidade, depois adequação nutricional, depois custo/variedade/preferências); penalidade explícita por incerteza e cobertura; *infeasibility explanation* com conjunto mínimo de restrições conflitantes; *robust optimization* com intervalos só quando a fonte realmente fornece variância/erro.

OR-Tools é uma referência de alto volume para CP-SAT e modelagem combinatória; HiGHS é mantido para o problema atual. Trocar solver sem benchmark de viabilidade, qualidade da solução, latência, memória e determinismo não se justifica.

## 9. Gaps que exigem dados ou avaliação externos

- Importar e benchmarkar releases reais FDC; executar hashes e distribuição de quarentena por tipo e release.
- Validar crosswalk TBCA↔USDA alimento por alimento, com revisão humana.
- Retenção/yield por combinação de alimento, método e nutrientes.
- Conjunto de aminoácidos e digestibilidade ileal com referências publicadas/licença.
- Persistência e calibração individual do ledger de energia com verificação contra dupla contagem.
- Cardápio multidiário, explicação de inviabilidade e teste com dados alimentares reais.
- Revisão por nutricionistas/cientistas, análise de risco e testes de uso fora de ambiente de desenvolvimento.
