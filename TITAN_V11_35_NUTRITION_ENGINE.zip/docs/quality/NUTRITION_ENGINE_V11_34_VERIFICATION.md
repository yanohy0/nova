# V11.34 — relatório de verificação

Data: 26 nov 2026
Base: V11.33 commit `34841b675245a74b832eb5092ce1b2fd598863d2`
Release: `11.34.0`

## Regressões específicas da mudança

| Verificação | Resultado |
|---|---|
| `npm run test:nutrition-data-quality` | PASS |
| `npm run test:nutrition-hardening` | PASS |
| `npm run test:review` | PASS |
| `npm run test:usda-import-cli` | PASS — fixtures sintéticas; sem importar corpus real |
| `npm run typecheck:calculations` | PASS |
| `npm run test:energy-budget-boundaries` | PASS — 1.071.840 combinações; margem mínima TDEE-RMR 167 kcal |
| `npm run test:adaptive-simulation` | PASS — simulação sintética; RMSE 91,6 kcal estável e 74,6 após adaptação |
| `npm run audit:nutrition-coverage` | PASS — 5.835 registros catalogados |
| `npm run audit:tbca-ingredients` | PASS — 5.830 TBCA: 2.717 ALIMENTO e 3.113 PREPARACAO_COMPOSTA |
| `npm run audit:recipe-catalog-eligibility` | PASS — 2/8 modelos elegíveis; seis bloqueados por refeições compostas locais |
| `git diff --check` | PASS |
| Transpilação sintática TS/TSX dos arquivos alterados via TypeScript global | PASS — 7 arquivos |
| ZIP final (`unzip -t`) | PASS |
| Extração limpa do ZIP — `npm run test:review` | PASS |
| Extração limpa do ZIP — `npm run test:nutrition-hardening` | PASS |
| Extração limpa do ZIP — `npm run test:usda-import-cli` | PASS — fixture sintética |
| Extração limpa do ZIP — `npm run typecheck:calculations` | PASS |

## Ambiente indisponível

Não há `node_modules` nesta sessão, e o runtime Bun não está instalado. Por isso:

- `npm run lint` não concluiu: `TS2688 Cannot find type definition file for 'vite/client'`.
- `npm run build` não concluiu: `vite: not found`.
- `npm test` não concluiu: `tsx: not found`.

A busca ampliada com Firecrawl não foi executada porque os créditos da conexão Firecrawl estavam esgotados; a pesquisa de engenharia desta revisão usou metadados, arquivos e READMEs públicos via GitHub. O typecheck dedicado aos cálculos passou; isso não substitui o typecheck global, build e execução com dependências instaladas. A transpilação sintática confirmou que os arquivos TypeScript/TSX alterados podem ser analisados pelo compilador, mas não fornece validação de tipos completa.

## Dados e cobertura

- TBCA embarcada: versão 7.2, 5.830 registros, 0 `food_type` ausente.
- Open Food Facts: 2 registros usados no catálogo atual.
- USDA FDC: 0 registros importados; os adaptadores e o pipeline de arquivo/importação têm testes, mas ainda falta importar os releases reais.
- TITAN_LEGACY: 3 snapshots de refeições compostas, não verificados e fora da contagem TBCA.
- Catálogo total desta auditoria: 5.835 registros.

A cobertura de alguns micronutrientes continua baixa ou nula. Em especial: vitamina K 0,1%; B5 0,1%; B7, niacina (com unidade atual NE incompatível com o campo esperado), colina, iodo, cloreto, molibdênio, cromo e fluoreto 0%; selênio 82,7%. A ausência de dados não foi transformada em zero.

## Limites de validação

A simulação adaptativa e a varredura de limites são testes computacionais/sintéticos, não estudos clínicos. Não houve revisão independente por nutricionista ou agente externo de código nesta sessão. O patch não declara o motor clinicamente validado.

O catálogo TBCA continua na versão local 7.2; não houve importação da 7.3. O uso/reprodução comercial dos dados TBCA requer confirmar e cumprir os termos atuais com os responsáveis pela tabela antes de publicar ou redistribuir um dataset derivado.
