# V11.35 — relatório de verificação

Data: 26 nov 2026
Base: V11.34 commit `a5c5d87c6045f496e70334849ed1be2453ebf783`
Release: `11.35.0`

## Regressões desta mudança

| Verificação | Resultado |
|---|---|
| FDC 409 direto | PASS — valor total priorizado; ID/número/nome/unidade/valor de origem preservados e revalidados no registro runtime |
| FDC 406 + 407 | PASS — soma da niacina pré-formada com fração derivada medida |
| FDC 406 + 501 | PASS — gramas de triptofano convertidas para mg e divididas por 60 |
| Não somar 407 + 501 | PASS — evita duplicar a contribuição de triptofano |
| Ausência de 406 ou fração de triptofano | PASS — sem B3 quantificada e componentes isolados vão para quarentena |
| Unidade/ID/número divergente | PASS — não participa da derivação |
| Duplicata conflitante | PASS — não resolve por ordem do array |
| Registro runtime de evidência | PASS — valida a identidade 409 direto, os IDs/rótulos/unidades dos componentes, fórmula, base e aritmética antes de registrar |
| B3 `mg NE` sem evidência | PASS — método genérico `unit_scale` sem fonte/derivação é recusado no registro runtime (RED → GREEN) |
| Overflow numérico | PASS — soma e conversão de componentes finitos que resultam em infinito são bloqueadas e quarentenadas (RED → GREEN) |
| Overflow no caminho preferencial | PASS — overflow em 406+407 não pode ser contornado por fallback para 406+501 (RED → GREEN) |
| Cobertura TBCA por tipo | PASS — `ALIMENTO`, `PREPARACAO_COMPOSTA`, `UNKNOWN` reconciliam com TBCA; outras fontes não entram em UNKNOWN |

## Suítes e auditorias — execução final V11.35

| Verificação | Resultado final |
|---|---|
| `npm run test:review` | PASS — exit 0; revisão de domínio completa, incluindo nutrition hardening e data quality |
| `npm run test:nutrition-hardening` | PASS — exit 0; USDA FDC adapter/catalog/import, TBCA ingredient integrity/store guard e recipe eligibility |
| `npm run test:nutrition-data-quality` | PASS — exit 0; search, macro quality, eligibility, recipe/store guards |
| `npm run typecheck:calculations` | PASS — exit 0 |
| `npm run audit:tbca-ingredients` | PASS — 5.830 itens; 2.717 `ALIMENTO`, 3.113 `PREPARACAO_COMPOSTA`, 0 `UNKNOWN` |
| `npm run audit:recipe-catalog-eligibility` | PASS — 2/8 templates selecionáveis; 6 bloqueados |
| `npm run audit:nutrition-coverage` | PASS — 5.835 registros, cobertura por micronutriente, fonte e tipo TBCA atualizada |
| `npm run test:usda-import-cli` | PASS — fixtures sintéticas apenas; sem corpus oficial |
| `npm run test:usda-archive` | PASS — ZIP parser/downloader e limites de segurança |
| `npm run test:energy-budget-boundaries` | PASS — 1.071.840 combinações de perfis/atividade; margem mínima TDEE-RMR de 167 kcal |
| `npm run test:adaptive-simulation` | PASS — simulação sintética; steady n=600 RMSE 91,6, viés -5,7; após adaptação n=400 RMSE 74,6, viés 23,1; cobertura intervalar sintética 100% |
| `git diff --check` | PASS — sem whitespace errors |

### Verificações bloqueadas pelo toolchain ausente

| Verificação | Resultado |
|---|---|
| `npm run lint` | BLOCKED — TS2688: `vite/client` não instalado |
| `npm run build` | BLOCKED — `vite: not found` |
| `npm test` | BLOCKED — `tsx: not found` |

O projeto contém `bun.lock`; não há `node_modules` nem Bun instalado. Não foi gerado lockfile npm alternativo nem alterada a stack. O typecheck dedicado e os testes nativos não substituem o build/lint/teste global.

## Dados verificados

- TBCA local 7.2: 5.830 itens; 2.717 `ALIMENTO`, 3.113 `PREPARACAO_COMPOSTA`, zero tipo desconhecido.
- Open Food Facts: 2 registros.
- USDA FDC: zero registros reais importados.
- TITAN_LEGACY: 3 snapshots locais fora da contagem TBCA.
- Total catalogado: 5.835.
- B3 total atual: 0/5.835 `mg NE`; TBCA não publicou os componentes necessários no catálogo atual e USDA ainda não foi importado.

## Limitações de ambiente/dados

- O download do ZIP oficial Foundation Foods 2026-10-29 não concluiu neste ambiente. Nenhum corpus USDA real foi importado; os testes de B3 demonstram as regras de parsing/derivação em fixtures sintéticas, não cobertura real.
- Não há `node_modules` nem Bun instalados nesta sessão. As três verificações globais foram tentadas novamente e ficaram bloqueadas: lint por `vite/client` ausente, build por `vite` ausente e `npm test` por `tsx` ausente. O projeto usa `bun.lock`; instalar por um runner suportado é o próximo gate. `typecheck:calculations` passou, mas não substitui build/lint globais.
- Não houve subagente/revisor independente disponível. Foi feita revisão adversarial manual do diff e testes. Não houve validação clínica por nutricionista.
- TBCA 7.3 não foi importada: o catálogo local continua 7.2 até que acesso e permissões de uso pretendido estejam confirmados.

## Conclusão limitada

A V11.35 fecha a lógica determinística e auditável de B3/NE para registros USDA que tragam componentes compatíveis e torna a cobertura TBCA interpretável por tipo de alimento. Não demonstra a cobertura real que a importação futura do USDA produzirá e não declara o motor completo ou clinicamente validado.

## Verificação do artefato de release

- `git archive` da árvore commitada: PASS.
- `unzip -t`: PASS, sem erros de integridade.
- Extração em diretório vazio: PASS.
- No diretório extraído, passaram `test:review`, `test:nutrition-hardening`, `test:nutrition-data-quality`, `typecheck:calculations`, `test:usda-import-cli`, `test:usda-archive`, `audit:tbca-ingredients`, `audit:recipe-catalog-eligibility` e `audit:nutrition-coverage`.
- As limitações de `lint`, `build` e `npm test` permanecem as mesmas por ausência de dependências e Bun; a extração limpa não instala nem esconde essas dependências.
