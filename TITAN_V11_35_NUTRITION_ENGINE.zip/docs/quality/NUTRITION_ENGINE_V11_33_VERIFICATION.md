# V11.33 — verificação e limites

Data: 2026-11-26
Base: V11.32 ZIP recuperado e validado localmente antes da implementação
Branch: `feature/v11.33-nutrition-engine`

## Alterações verificadas

- Downloader pinado de Foundation/SR Legacy/FNDDS e contrato de resposta testado com `fetch` simulado.
- ZIP reader restrito com validação de diretório central, caminhos, compressão, limites, CRC32, data descriptor (com/sem assinatura) e JSON único.
- Importador JSON/ZIP com SHA-256 do arquivo original e identificação da entrada JSON; leitura limitada em streaming (256 MB JSON/64 MB ZIP), erros preservam catálogo existente.
- Diretório físico de saída validado contra symlink escape; sidecar de auditoria content-addressed, imutável e atômico.
- Auditoria de cobertura agora une TBCA, OFF e USDA mantendo registros e fontes separados.
- CI usa Bun 1.4.5 e adiciona gates específicos de cálculos, hardening, ZIP/download e import CLI.

## Comandos de verificação executados nesta sessão

| Comando | Resultado observado |
|---|---|
| `node scripts/__tests__/usda-fdc-archive.test.mjs` | PASS — stored/deflate, CRC, data descriptor com/sem assinatura, flags, limites, caminhos e headers malformados |
| `node scripts/__tests__/download-usda-fdc.test.mjs` | PASS — allowlist, redirect/URL final, streaming obrigatório, limite por bloco, SHA-256 e promoção atômica/idempotente sob concorrência |
| `node scripts/__tests__/nutrition-coverage-catalog.test.mjs` | PASS — união das fontes sem colapsar namespaces |
| `node --experimental-strip-types --loader ./scripts/ts-extension-loader.mjs scripts/__tests__/usda-catalog-composition.test.mjs` | PASS — agregação multitype e duplicatas entre fontes |
| `node scripts/test-usda-import-cli.mjs` | PASS — JSON/ZIP, hash do arquivo original, auditoria imutável, limite de leitura, symlink escape e preservação em falhas |
| `npm run test:nutrition-hardening` | PASS — inclui ZIP/stream tests |
| `npm run test:review` | PASS — suíte completa de review no worktree e novamente após extrair o ZIP final em diretório limpo |
| `npm run typecheck:calculations` | PASS |
| `npm run test:energy-budget-boundaries` | PASS — 1.071.840 combinações sintéticas de perfil/atividade |
| `npm run test:adaptive-simulation` | PASS — RMSE sintético 91,6 kcal estável; 74,6 kcal após adaptação |
| `npm run audit:nutrition-coverage` | PASS — 5.838 registros: TBCA 5.836, Open Food Facts 2, USDA 0 |
| `node --check` nos scripts modificados | PASS |
| `git diff --check` | PASS |
| `unzip -t TITAN_V11_33_NUTRITION_ENGINE.zip` | PASS — nenhum erro no diretório compactado |
| Testes USDA dedicados + typecheck no ZIP extraído | PASS — `test:usda-import-cli`, `test:usda-archive` e `typecheck:calculations` |

## Verificação global bloqueada

| Comando | Resultado observado |
|---|---|
| `npm run lint` | BLOCKED — `TS2688: Cannot find type definition file for 'vite/client'` (dependências ausentes) |
| `npm run build` | BLOCKED — `vite: not found` |
| `npm test` | BLOCKED — `tsx: not found` |
| `bun install --frozen-lockfile` | Não executado — Bun ausente no ambiente e sem instalação de dependências/rede disponível |
| Build/teste global em runner GitHub Actions | Configurado no workflow, mas não executado nesta sessão |

## Bloqueios/limites desta execução

- A tentativa de baixar o ZIP Foundation 2026-10-29 diretamente do host USDA falhou nesta sessão. Nenhum release oficial foi importado e a contagem USDA continua zero. O parser/downloader foram testados apenas com fixtures sintéticas, não com corpus oficial real.
- Não foi possível fazer `bun install`, build Vite, lint global ou teste integral via `tsx` nesta sandbox sem dependências; o CI está configurado para fazê-lo em runner limpo, mas ainda não foi observado verde.
- Runtime WASM HiGHS e navegador real não foram executados.
- Não houve revisor humano/agente independente disponível; a revisão final foi adversarial e executada no próprio worktree.
- O importador e ZIP parser passaram por fixtures sintéticas; isso não demonstra distribuição de cobertura, memory peak ou rejeições em dataset USDA real. O limite máximo de entrada e a razão de compressão são testados, mas o consumo de memória do release completo depende da execução com os arquivos reais.
