# TITAN HYDRATION — ordem de implementação V11.9 → V12

**Prioridade definida por impacto no produto, risco e dependências, não por estrelas de repositório.**

| Ordem | Prioridade | O que implementar | Base técnica | Critério de pronto |
|---:|---|---|---|---|
| 1 | P0 | Testes E2E críticos: primeiro uso, perfil, hidratação, registro de peso, diário alimentar, série de treino, backup/restore e reload | Playwright | Fluxos passam em Chromium; smoke em Firefox/WebKit; erros de console e persistência verificados |
| 2 | P0 | Testes de componentes e acessibilidade | Vitest + React Testing Library + user-event + axe-core | Componentes críticos testados por comportamento, teclado, foco, labels e aria |
| 3 | P0 | Typecheck/build oficiais no CI da versão exata do Bun/TypeScript e lockfile | Bun lockfile canônico + CI | `bun install --frozen-lockfile`, `bun run lint`, `bun run test`, `bun run build` passam limpos |
| 4 | P1 | Editor de fichas de treino: criar/duplicar/editar plano, exercícios, séries, descanso, ordem e progressão | React Hook Form + Zod; catálogo de exercício existente | Template separado de sessão executada; histórico imutável; validação e testes de domínio |
| 5 | P1 | Construtor de refeições/receitas e diário em quantidades/porções | RHF + Zod; catálogo TBCA/OFF existente | Ingredientes, gramas, porção, fonte, qualidade dos dados, cálculo de macros e registro de consumo coerentes |
| 6 | P1 | Proveniência e nível de confiança nos números | contratos de domínio existentes | Distinguir medido, informado, calculado, meta, referência e desconhecido em todo gráfico/resumo |
| 7 | P1 | Rotas URL, browser back/forward, deep links e proteção de rota | React Router | Refresh e links compartilhados preservam rota, filtros e paginação sem quebrar a navegação atual |
| 8 | P1 | Benchmark de performance desktop/mobile e budgets de bundle | React Profiler/React Scan + Lighthouse + web-vitals | Baseline com LCP/INP/CLS, chunks, heap, tempo de busca e interações; comparar antes/depois |
| 9 | P2 | Server-state e sincronização | TanStack Query + MSW; API tipada | Apenas após API autenticada/real; cache key, invalidation, retry, optimistic rollback e offline policy testados |
| 10 | P2 | Persistência local escalável e migrações | IndexedDB/Dexie (avaliar) | Justificada por volume; versionamento de schema, migração, quota e recuperação testados |
| 11 | P2 | Conta/sessão e backup cloud | Better Auth ou Supabase Auth/Clerk, após arquitetura comparativa | Autorização no servidor, isolamento por usuário, recuperação e política de exclusão; tokens não persistidos em texto claro no browser |
| 12 | P2 | Editor com reatividade atômica | Jotai, somente se profiling mostrar necessidade | Não duplicar estado; derivados cobertos por testes e benchmark mostra ganho frente aos selectors Zustand |
| 13 | P2 | Workflows multiestágio | XState, somente para processos stateful complexos | Grafo de estados/transições documentado, cenários impossíveis bloqueados, pause/resume e recovery testados |
| 14 | P3 | Virtualização de catálogos grandes | react-window / react-virtualized | Só quando resultados renderizados excederem o budget e o profiler demonstrar custo significativo |

## Top 5 ajustes técnicos da próxima rodada

1. **Playwright E2E**: cobrir regressões cross-domain que testes puros não encontram, especialmente reload, navegador, foco e WebGL.
2. **Vitest + Testing Library + axe-core**: adicionar testes de componentes no mesmo ecossistema do Vite, com consultas como o usuário e verificações de acessibilidade.
3. **Editor de treino e editor de nutrição reais**: transformar os catálogos e templates em operações editáveis; RHF + Zod passa a ter ROI real.
4. **React Router**: substituir gradualmente a navegação só por Zustand por rotas persistentes e compartilháveis, sem big-bang migration.
5. **Performance medida**: budgets de bundles e Core Web Vitals, perfil de busca e renderizações; depois decidir se precisa virtualização, Jotai ou React Compiler.

## Guardrails

- Não adicionar duas bibliotecas que resolvam a mesma responsabilidade (Jest + Vitest; Cypress + Playwright; Apollo + TanStack Query para o mesmo endpoint; Zustand + Jotai para o mesmo estado).
- Zustand continua como client state; TanStack Query fica com server state. Não colocar respostas de API remota no store Zustand apenas para evitar uma integração de query.
- Zod permanece como fonte de validação de domínio; React Hook Form gerencia estado de formulário, não regras de negócio.
- React Router armazena estado que deve sobreviver a reload, browser history ou ser compartilhado; Zustand continua para estado transitório de interface.
- Context é aceitável para sessão estável depois que houver um auth provider real, mas autorização e ownership devem ser validados no servidor/banco.
- Jotai e XState não são dependências obrigatórias de um app moderno; só entram com caso de uso mensurável.
- Não declarar performance, cobertura, acessibilidade ou produção validada sem execução real dos testes correspondentes.
