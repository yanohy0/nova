# Motor de cálculos V11.16 — modelo dinâmico, RMR e energia de atividade

## 1. Modelo dinâmico de peso — core Hall 2011

Implementação independente em `src/domains/profile/domain/rules/hall-body-weight.ts`. A referência científica descreve a resposta dinâmica do peso corporal a desequilíbrios energéticos, incluindo compartimentos de gordura/massa magra e adaptações ao longo do tempo; o NIDDK apresenta o Body Weight Planner como aplicação de pesquisa baseada nesse trabalho. Isso não significa que esta implementação seja o executável oficial NIH/NIDDK. Referências: [NIDDK Body Weight Planner research](https://www.niddk.nih.gov/research-funding/at-niddk/labs-branches/laboratory-biological-modeling/integrative-physiology-section/research/body-weight-planner) e Hall et al. (2011), *Quantification of the effect of energy imbalance on bodyweight*, Lancet.

Compartimentos e equações implementadas (energia em kJ, tecido em kg, tempo em dias):

- Densidades energéticas publicadas: gordura 39.500 kJ/kg, massa magra 7.600 kJ/kg, glicogênio 17.600 kJ/kg.
- Partição do desequilíbrio energético: `p = C / (C + F)`, com `C = 10,4 × rho_lean / rho_fat`; `p` é a fração destinada ao tecido magro.
- Energia de gasto: soma do termo basal calibrado, custos metabólicos de gordura e massa magra, atividade proporcional ao peso, TEF, termogênese adaptativa e custo dinâmico do tecido, dividida pelo termo de realimentação metabólica publicado.
- TEF: 10% da mudança na ingestão energética.
- Termogênese adaptativa: resposta de primeira ordem a 14 dias e amplitude de 14% da mudança de ingestão.
- Glicogênio: balanço de carboidrato com reservatório inicial de 0,5 kg; água associada calculada em 2,7 kg/kg de glicogênio.
- Fluido extracelular: estado relativo ao baseline com coeficientes de recuperação de sódio e acoplamento à ingestão de carboidrato.
- Massa gorda e magra são atualizadas diariamente por integração explícita de 1 dia; o solver usa busca binária na ingestão constante para aproximar o peso-alvo no horizonte informado.

Inicialização e limites:

- Se não há % de gordura informado, a massa gorda inicial usa a equação antropométrica associada ao modelo. É uma estimativa, não medição.
- Se não há RMR de calorimetria indireta, usa Mifflin–St Jeor para calibrar o termo de atividade.
- Sem macronutrientes observados, assume 45% da energia como carboidrato. Sem mudança de sódio informada, assume sódio estável.
- Horizonte máximo de simulação: 10 anos. Faixa de busca da ingestão: 700–8.000 kcal/dia. A meta é limitada depois pelas regras conservadoras de velocidade semanal e proporção do TDEE que já existiam no motor.
- Mudanças de glicogênio/água, sódio, ciclo menstrual, inflamação, doença e erros de ingestão podem gerar desvios transitórios. O resultado é uma previsão de modelo, não garantia de resultado nem prescrição.

## 2. Densidade energética adaptativa

O estimador Theil–Sen + Kalman agora aceita sexo, idade, altura, peso e % de gordura opcionais. A partir da massa gorda e da partição de Hall, calcula densidade local implícita:

`rho_eff = 1 / ((1-p)/rho_fat + p/rho_lean) / 4,184`

Essa densidade substitui 7.000 kcal/kg na transformação da tendência de peso em TDEE e na variância de medição. Se a composição não está disponível, o fallback de 7.000 permanece, com aviso explícito. O modelo é local e simplificado: não captura fluxo de água/glicogênio, mudanças temporais de composição dentro da janela ou toda a dinâmica Hall. A faixa de Kalman continua model-based e não calibrada externamente.

## 3. RMR completo no perfil

A interface permite selecionar Mifflin–St Jeor, Pavlidou, Cunningham, Katch–McArdle e Ten Haaf, registrar percentual de gordura e origem da composição e informar RMR medido por calorimetria indireta. A medição informada tem precedência sobre a equação. Perfis antigos preservam compatibilidade por campos opcionais. Qualquer percentual de gordura exige origem declarada; Cunningham/Katch exigem percentual de gordura com origem ou RMR medido. Idade é validada em anos inteiros.

O TDEE inicial continua via NASEM EER 2023 quando não há TDEE adaptativo utilizável; não convertemos RMR em TDEE usando um fator genérico apresentado como precisão individual.

## 4. Reconciliação de atividade e prevenção de dupla contagem

`activity-reconciliation.ts` normaliza Health Connect e HealthKit e:

- deduplica `sourceRecordId` por fonte;
- usa o agregado da sessão quando os samples possuem `parentWorkoutId` correspondente;
- remove sessões amplamente sobrepostas de fontes diferentes, privilegiando evidência medida e a hierarquia de fontes;
- coloca ambos os registros de uma sobreposição parcial em quarentena (`conflicted`) até revisão; eles não entram no agregado ativo enquanto a ambiguidade existir;
- exclui energia `gross` ou `total` da soma de calorias ativas, pois pode conter gasto de repouso já presente no TDEE basal/total.

O serviço `syncNativeActivityEnergy` exige bridge injetada e permissão/fluxo nativo antes da leitura. A bridge Kotlin expõe o Activity Result permission contract para o host lançar e processar explicitamente as permissões. Calorias ativas reconciliadas ficam disponíveis para analytics de atividade, mas **não** são somadas ao TDEE adaptativo: o TDEE derivado de ingestão + tendência de peso já incorpora o gasto total observado. Somar exercício manual ou sensor sobre ele seria dupla contagem.

## 5. Catálogo MET versionado e licenciamento

`activity-met-catalog.ts` importa JSON com versão de schema, identificador/versão do catálogo, URL, licença e fonte idênticos em todas as linhas. O código bloqueia licenças não permitidas para redistribuição/derivação, incluindo NC/ND e licenças desconhecidas. Isso é uma barreira automática, não substitui revisão jurídica.

A tabela Adult Compendium 2024 não está embarcada. O importador não cria nem transforma dados do Compendium; só aceita datasets que possam ser redistribuídos e modificados sob licença compatível.

## 6. Integrações nativas

- Android scaffold: `native/android/titan-healthconnect` usa Health Connect 1.1.0 e lê sessão, energia ativa e total. Requer host com compileSdk 36/AGP adequado, UI e autorização, background permission apenas quando necessário.
- iOS scaffold: `native/ios/TitanHealthKit` lê amostras de energia ativa e metadados de workout. HealthKit não revela se permissão de leitura foi negada; consulta vazia não prova ausência de dados.
- App web/preview não captura sensores contínuos em segundo plano. Os scaffolds nativos não foram compilados nem testados em dispositivo, logo sync nativa não deve ser anunciada como disponível.
- OpenMetabolics continua aguardando port de aquisição/filtros/features/XGBoost, prova de direitos dos pesos/dados e testes de paridade em aparelho físico.

## 7. Repositórios revisados

Ver `docs/REPOSITORY_RESEARCH_V11_16.md`. Principais escolhas: FilterPy (3,9k, MIT) como referência algorítmica; android/health-samples (350, Apache-2.0) como referência oficial Health Connect; HealthKMP (93, Apache-2.0) como referência multiplataforma. wger (7,3k, AGPL) não foi acoplado; o dataset com ~24k estrelas foi rejeitado porque a licença não está declarada; free-exercise-db (2,1k, Unlicense) foi considerado apenas para exercício/taxonomia, não MET. Não houve cópia de código/dados.

## 8. Validação

Testes adicionados:

- Hall: equilíbrio na manutenção, respostas em déficit/superávit, solver, validações de faixa e composição;
- Adaptive: densidade composition-aware e fallback explícito sem perfil;
- Activity: deduplicação por origem/intervalo/sessão, energia total versus ativa, bridge Health Connect/HealthKit;
- MET: validação de versão, metadados e rejeição de CC BY-NC-ND.

Simulação determinística (200 perfis sintéticos, ruído de ingestão 350 kcal, ruído de peso 0,6 kg, mudança simulada de TDEE −200 kcal/dia):

| Período | n | RMSE | Viés | Cobertura da banda model-based | Meia-largura média |
|---|---:|---:|---:|---:|---:|
| Estável | 600 | 91,6 kcal | −5,7 kcal | 100% | 382,4 kcal |
| Após adaptação | 400 | 74,6 kcal | +23,1 kcal | 100% | 316,5 kcal |

Esses números são dados sintéticos gerados com a mesma densidade de referência do cenário; não constituem acurácia clínica nem validação externa.
