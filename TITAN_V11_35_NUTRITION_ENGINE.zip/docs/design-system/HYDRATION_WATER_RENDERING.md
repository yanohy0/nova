# Hydration liquid rendering — V.MAX

## Visual intent

The hydration meter is a small optical object, not a standard progress bar:
- one refractive water droplet at the left;
- one horizontal mineral-glass capsule;
- a clear, pale-cyan water volume that grows from left to right;
- a brief meniscus/ripple after a real hydration value change;
- a static, composed still state when nothing is changing.

The 3D-like visual is rendered in a shared WebGL2 context. The component still owns its value, goal, date scope, quick-entry sheet, correction flow and history. Rendering never writes hydration data.

## Research used

The implementation adapts techniques rather than importing a large water renderer:

1. [evanw/webgl-water](https://github.com/evanw/webgl-water) — reflection/refraction, Fresnel, height-field waves and differential-area caustics. Used as the baseline reference for optical behavior.
2. [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) — modern WebGL2 shallow-water shading, spectral refraction, Fresnel and adaptive rendering. Its full ocean/FFT pipeline is intentionally not imported for a 54px UI capsule.
3. [HowdyKeith/swek-webgl2-water](https://github.com/HowdyKeith/swek-webgl2-water) — compact WebGL2 heightfield, Schlick Fresnel and differential-area caustics. Used to review a lightweight ripple model.
4. [pmndrs/drei MeshTransmissionMaterial](https://github.com/pmndrs/drei/blob/master/src/core/MeshTransmissionMaterial.tsx) — transmission, thickness, IOR, attenuation, chromatic aberration and backside-refraction concepts. No dependency added.
5. [StarKnightt/liquid-glass](https://github.com/StarKnightt/liquid-glass) and [smirki/glasswork](https://github.com/smirki/glasswork) — SDF-based droplet/lens silhouettes, normals from distance gradients, bounded Snell refraction and refined rim response.

The existing engine already had most of the right optical primitives (IOR, Schlick Fresnel, Beer–Lambert attenuation, dispersion, caustics and SDF droplet). The main quality defects were the icon's small rendering size, the low 44px tank, the simplified 2D fallback, decorative bubbles and continuous idle redraw.

## Implemented changes

### Droplet
- Increased the optical canvas from 72×86 to 84×100 CSS pixels while preserving the same aspect ratio.
- Kept one SDF-based droplet with a real liquid fill plane, curved meniscus, internal refraction and glass-edge highlights.
- Reduced chromatic dispersion so water does not look like a rainbow prism.
- Removed animated micro-bubbles.
- Added two restrained studio softbox streaks to communicate thickness and curvature.
- Kept the percentage directly below the droplet.
- The droplet and capsule are read-only indicators; neither advertises a click action.

### Horizontal glass capsule
- Increased the tube from 44px to 54px high.
- Tightened the icon-to-meter grid to an 8px gap while allowing the meter to consume all remaining width.
- Refined the CSS glass bevel with a cool mineral edge and two subtle specular lines.
- Retained the horizontal fill model and its left-to-right meniscus.
- Reduced noisy wave amplitude and chromatic dispersion.
- Removed decorative micro-bubbles.
- Added optical end-cap highlights so the capsule reads as a thick glass part rather than a flat rounded rectangle.

### Motion and performance
- Fill interpolation is frame-rate independent.
- Spring simulation uses a fixed 60Hz-equivalent accumulator, capped to three catch-up steps.
- The shared WebGL animation loop wakes only for a fill transition or its resulting spring ripple.
- The loop stops when all fluid jobs settle; static water is rendered once instead of redrawing at 30fps indefinitely.
- Visibility changes re-render still states and resume only active value transitions.
- Reduced-motion mode applies the new value immediately.

### Fallback
- Replaced the flat Canvas2D droplet with a layered glass/liquid fallback.
- Replaced the rectangular flat tank fill with a rounded glass capsule, translucent liquid, meniscus, reflection strip and beveled shell.
- Fallback values continue to use the same hydration summary and do not change business logic.

## Constraints

- This is a stylized optical UI object, not a full SPH fluid solver or a physically complete ray-traced glass simulation.
- The progress capsule is a compact visual meter, so FFT ocean simulation, particle-based fluid and WebGPU-only materials would add cost without proportional benefit.
- The icon and track stay still after the single value-transition ripple.
- The existing quick add, custom amount, correction and history behaviors remain unchanged.


## Accuracy note

The studio environment is analytically generated in GLSL from a floor, horizon, sky and softbox lobes. It is **not** an imported HDR image/texture and the renderer is not path-traced or a complete 3D fluid solver. Its visual result is a deliberately bounded 2.5D/SDF optical approximation for a small dashboard control.
