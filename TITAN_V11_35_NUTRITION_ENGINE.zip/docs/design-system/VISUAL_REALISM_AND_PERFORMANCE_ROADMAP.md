# Visual Realism & Performance Roadmap — TITAN Cockpit

## Decision rule

For every visual component, work in this order:
1. Correct data semantics and interaction states.
2. Define the material, lighting, shape and motion that best communicate the concept.
3. Reach the strongest visual quality justified by the component's size and role.
4. Reduce shader samples, draw calls, pixel ratio and React work without visible degradation.
5. Validate on real WebGL devices, including a lower-end mobile profile.

Do not add a rendering framework merely because it is popular. Keep the current shared WebGL2 engine for compact shader-driven indicators unless measured requirements justify a scene graph.

## Current component assessment

| Component | Current state | Decision |
|---|---|---|
| Hydration droplet and glass tube | Refined 2.5D/SDF optics with Fresnel, refraction, Beer–Lambert attenuation, GGX highlights and approximate caustics | Preserve its custom renderer. Improve the optical model and environment incrementally; do not replace it with a heavy ocean/fluid simulation. |
| Energy progress | Mineral Sage fluid/gel material with one low-frequency FBM call, a restrained softbox and a static meniscus | Preserve this visual language. Render a dash and expose a labelled group when no valid daily target exists; never present an undefined target as 0% progress. |
| Macro gauges | Three compact semicircular metallic indicators, custom WebGL shader and semantic macro colors | Keep the custom gauge. Use a more controlled GGX reflection, reduce decorative iridescence and preserve distinct carbohydrate/protein/fat hues. |
| Macro data labels | Values, goal/excess copy and clamped progress are present; small residual amounts need exact state handling | Use unrounded values for the state decision, one decimal for small gram differences, and a `group` rather than a `progressbar` when no valid target exists. |
| Anatomy hologram | Separate Three.js scene with visibility-aware, demand-driven rendering and resource disposal | Preserve the scene graph. Profile draw calls, transparency overdraw, geometry density and DPR before changing the renderer. Keep idle rendering stopped. |
| Molecular structures | SMILES-derived SVG with shared drawers and cached SVG payloads | Preserve vector clarity and cache reuse. Audit cache bounds and asynchronous parsing if the nutrient catalog expands substantially. |
| Evolution | KPI comparison and a history table; no analytical time-series chart is currently implemented | When trend analysis is added, use honest axes, units, date ranges and reference lines. Evaluate Recharts rather than hand-writing a chart framework. |
| Cockpit typography | Labels are intentionally restrained and use tabular metric typography | Prefer concise, data-first wording. Do not let shader effects compete with numeric hierarchy. |

## Rendering decisions

### Hydration — highest fidelity path

1. Keep the existing droplet silhouette, glass shell, water volume and meniscus.
2. Move from an analytic-only studio to a compact, authored HDR environment or a calibrated analytic softbox rig. Compare memory and sampling cost before choosing HDR.
3. Model the optical sequence explicitly: air → glass → water → glass → air. Use the correct IOR and Fresnel response at each boundary; handle total internal reflection only where physically possible.
4. Make Beer–Lambert attenuation depend on optical path length, not a screen-space proxy.
5. Replace the mixed procedural caustic detail with a better-defined differential projection. Keep the current approximation if the true solution is not visible at 84×100 / 54px scale.
6. Preserve a single shared WebGL2 context and direct canvas blitting; avoid allocating/transferring a new ImageBitmap for every tiny gauge frame.
6. Add micro-roughness only if it improves the glass at the real component size. Avoid scratches, bubbles or chromatic dispersion as decoration.
7. Keep the still state static. A short ripple is justified only after a volume change or explicit user input.
8. Match the Canvas2D fallback's silhouette, fill, contrast and state; it need not fake expensive refraction.

### Energy — visual metaphor, not a literal biological simulation

1. Use Mineral Sage and graphite, not high-saturation neon green or rainbow plasma.
2. Give the fill a layered translucent mineral/gel body, a broad studio highlight and a restrained boundary meniscus.
3. Keep the track dark and recessed so the value remains legible.
4. Keep the animation event-driven: interpolate only after a real data change; no idle noise animation.
5. Do not imply that the visual fluid is a scientific model of metabolism. The number and target remain the factual information.

### Macros — liquid-metal finish with trustworthy data

1. Keep one consistent arc geometry and three semantic finishes: information blue for carbohydrates, Mineral Sage for protein and muted gold for fat.
2. Use a calibrated studio environment and GGX microfacet highlights; remove rainbow thin-film coloration unless a deliberate product-wide holographic language is adopted.
3. Keep the gauge visually subordinate to grams and target. Do not add decorative particles or continuous idle movement.
4. Display `g restantes`, `Meta atingida` or `+g acima da meta` as appropriate.
5. Expose each gauge as a progressbar only when its target is valid. Without a target, expose a labelled group rather than a false 0% progress value.
6. Derive remaining/excess state from unrounded values. Small gram differences should remain visible to one decimal place rather than being rounded into an incorrect `Meta atingida`.
6. Use custom canvas/WebGL for these three small gauges. Do not add Recharts for a component that is not a time-series chart.

## Performance rules

- One shared WebGL2 context and one shared demand-driven animation loop.
- Wake the loop on target changes; never rely on another component to happen to be animating.
- Use time-based interpolation, not a fixed per-frame lerp factor.
- Pause work when the component is outside the viewport or the document is hidden.
- Respect `prefers-reduced-motion`, including changes to that preference while the page is open.
- Cap DPR for small UI shaders; use 1.5 as the default ceiling until device profiling demonstrates a need for more.
- Reuse programs, VAO, buffers and uniform storage. Avoid per-frame allocation and redundant shader samples.
- Blit the shared WebGL render target directly to its cached 2D target context when supported; do not create/close an ImageBitmap on every gauge frame.
- Use derivatives of an already-computed height field for local normals when this is visually equivalent to extra texture/noise samples.
- Keep Canvas2D fallback responsive to resize and value changes.
- Do not add FFT, SPH, Rapier, a second canvas renderer or a full R3F scene for a 20–100px UI indicator without measured evidence.

## Data visualization and UX

- Use custom shader gauges for the three macro summary values; they are compact visual indicators, not analytical charts.
- For history/trend charts (daily calories, macro distribution over time, hydration over time), prefer a conventional SVG chart with honest axes, units, reference lines and readable tooltips. Evaluate Recharts before writing a chart engine, but do not introduce it until a real trend chart is requested.
- Keep all values available as text; canvas pixels are decorative and must be hidden from the accessibility tree.
- A progressbar's `aria-valuenow` must stay inside its declared min/max. Put the actual over-goal amount in `aria-valuetext` and visible copy.
- Prefer one semantic heading per component and avoid ambiguous shorthand such as “Macro”.

## Research repositories and what to reuse

| Repository | Role in this project | Reuse decision |
|---|---|---|
| `mrdoob/three.js` (~118k★) | Core rendering, color management, PBR and WebGL/WebGPU reference | Reference its anisotropic GGX visibility/distribution for the arc-aligned satin-metal highlight; keep the small UI gauges in the shared shader engine. |
| `pmndrs/react-three-fiber` (~33.8k★) | React renderer for Three.js and scaling-performance guidance | Reuse the demand-rendering, explicit invalidation, and resource-reuse principles; use R3F for complex interactive scene work, not these small gauges. |
| `pmndrs/drei` (~10.2k★) | Environment, Lightformer and transmission material patterns, including thickness, IOR, roughness and sample controls | Borrow studio-lighting and transmission concepts; note the cost of backside rendering and refraction samples; avoid adding the package to this custom engine. |
| `Aureliengmz/clearwater` (~511★) | WebGL2 water, Fresnel, absorption, caustics, adaptive resolution and optical quality controls | Reference water optics and adaptive quality; ocean FFT and seabed are excessive for this dashboard. |
| `evanw/webgl-water` (~1.3k★) | Refraction, reflection, height-field waves, environment cube map and projected caustics | Foundational reference for water optics and the cost of a true height-field simulation; do not copy its perpetual animation loop. |
| `jeantimex/threejs-water` (~235★) | Ray intersections, caustics, water simulation and Fresnel | Study selected techniques; do not import the pool simulation. |
| `drcmda/the-substance` (~430★) | Three.js/R3F refraction and shader composition | Visual reference for glass/liquid materials; do not import its full page effect. |
| `recharts/recharts` (~28k★) | React/SVG analytical charts | Candidate for future time-series analytics only. |
| `radix-ui/primitives` (~19.5k★) | Accessible semantic interaction patterns | Reference for ARIA and keyboard behavior; current components can remain native React/HTML. |
| `motiondivision/motion` (~35.4k★) | Declarative React animation | Already installed; use only for DOM transitions, not as a replacement for the shader loop. |
| `dequelabs/axe-core` (~7.9k★) | Automated accessibility checks | Add to browser QA when the test environment is available. |
| `pmndrs/postprocessing` (~2.9k★) | GPU post-processing | Avoid bloom/post-processing for small progress indicators unless visual testing proves a benefit. |
| `storybookjs/storybook` (~91.7k★) | Component isolation, interaction and visual review | Candidate for component-level visual states; add only when the project adopts a repeatable UI review workflow. |
| `microsoft/playwright` (~100.7k★) | Browser automation and screenshot/regression testing | Preferred browser QA candidate for responsive snapshots, keyboard flow and reduced-motion scenarios. |

## Repository evidence inspected for this iteration

- `mrdoob/three.js`: `src/renderers/shaders/ShaderChunk/lights_physical_pars_fragment.glsl.js` — anisotropic GGX Smith visibility, anisotropic GGX distribution and the BRDF combination used as the macro-metal reference.
- `mrdoob/three.js`: `src/materials/MeshPhysicalMaterial.js` — physical transmission, anisotropy, clearcoat and the additional per-pixel cost of physical materials; environment maps are recommended for best results.
- `pmndrs/react-three-fiber`: `docs/advanced/scaling-performance.mdx` — demand rendering, explicit invalidation after imperative mutation, cached/reused resources and draw-call considerations.
- `pmndrs/drei`: `src/core/MeshTransmissionMaterial.tsx` — IOR/thickness/roughness, transmission buffer, optional backside pass and refraction sample controls.
- `Aureliengmz/clearwater`: `README.md` and `index.html` — WebGL2 float render targets, Fresnel, absorption, refracted caustics, adaptive resolution and a no-dependency rendering path.
- `evanw/webgl-water`: `water.js` and `main.js` — height-field wave update, normal reconstruction, floating-point render targets, environment cube map and projected caustics.
- `recharts/recharts`: `README.md` — declarative SVG chart composition; reserve for true history charts, not small circular progress gauges.
- `radix-ui/primitives` and `dequelabs/axe-core`: accessible component primitives and automated accessibility audit guidance.

Repository links: [three.js](https://github.com/mrdoob/three.js), [React Three Fiber](https://github.com/pmndrs/react-three-fiber), [Drei](https://github.com/pmndrs/drei), [Clearwater](https://github.com/Aureliengmz/clearwater), [WebGL Water](https://github.com/evanw/webgl-water), [Recharts](https://github.com/recharts/recharts), [Radix Primitives](https://github.com/radix-ui/primitives), [axe-core](https://github.com/dequelabs/axe-core), [Playwright](https://github.com/microsoft/playwright), [Storybook](https://github.com/storybookjs/storybook).

## Component-by-component backlog

### Hydration 3D
- [ ] Compare the current analytic studio with one small, authored HDRI under identical camera/material settings.
- [ ] Implement explicit air/glass/water interfaces and optical path length if the improvement survives the actual 84×100 / 54px UI scale.
- [ ] Capture GPU-validated snapshots and compare against the Canvas2D fallback.

### Energy indicator
- [x] Replace the sci-fi plasma appearance with the restrained Mineral Sage fluid treatment.
- [x] Reduce fractal noise work and remove the oversized shared optics block from this shader.
- [x] Fix wake-on-change, frame-rate-independent interpolation, resize fallback and reduced-motion changes.
- [x] Avoid repeated backing-store resets in the droplet/tank Canvas2D fallback and remove unused fallback path construction.
- [ ] Validate the new shader's color/contrast against the live cockpit at phone and desktop sizes.

### Macro gauges
- [x] Keep the three semicircular gauges and semantic colors.
- [x] Move highlights to GGX, then add an arc-aligned anisotropic GGX response based on the Three.js microfacet implementation.
- [x] Reduce macro shader fractal work to one FBM call and replace branch-local screen derivatives with an analytic wave gradient.
- [x] Reduce rainbow coloration and remove the chrome-gradient text treatment.
- [x] Derive remaining/goal/excess from unrounded data, format small residuals to one decimal, and use group semantics when no valid target exists.
- [ ] Validate the actual chrome response under the target GPU color pipeline and ensure the three colors remain distinguishable without relying on color alone.

### Anatomy hologram
- [x] Retain visibility-aware, demand-driven rendering and explicit disposal already present in the controller.
- [ ] Profile draw calls, alpha overdraw, geometry complexity and DPR while the hydration renderer is also active.
- [ ] Reduce only measured bottlenecks; preserve the anatomy silhouette, layer separation and selection response.

### Molecular structures and future charts
- [x] Retain the shared SMILES drawers and cached SVG payloads for repeated molecular icons.
- [ ] Bound/measure the SVG cache if the nutrient catalog expands.
- [ ] When trend charts are added, use Recharts as the first candidate; define data semantics, units, missing-data behavior, date range and accessible text before styling.

## Required validation before calling a component production-ready

1. TypeScript strict check and project build.
2. GLSL compile/link on an actual WebGL2 implementation.
3. Visual snapshots at DPR 1, 1.5 and 2, in desktop and mobile widths.
4. Test 0%, partial, 100%, above-goal, invalid and rapidly changing values.
5. Test initial offscreen mount followed by scroll into view, resize, tab hide/show, context loss and reduced-motion changes.
6. Compare idle CPU/GPU activity against an animation-in-progress trace. Idle components should not keep a requestAnimationFrame loop alive.
7. Run keyboard/screen-reader checks and axe-core; verify that text conveys every value without reading the canvas.
8. Record GPU timings on at least one integrated-GPU laptop and one mid-range mobile device before increasing shader quality.

## Latest implementation status — V.MAX v5

- [x] Arc-oriented anisotropic GGX reflections for the macro liquid-metal gauges.
- [x] One FBM invocation per macro fragment, with analytically differentiated wave detail instead of screen derivatives inside a varying branch.
- [x] Direct shared-render-target blit instead of per-frame ImageBitmap allocation/transfer.
- [x] Correct no-goal semantics for energy, macros and hydration progress: values are announced as groups instead of fabricated 0% progress.
- [x] Exact macro remainder/excess state decisions, with finer display precision below 10 g.
- [x] Canvas2D fallback avoids backing-store reallocation when dimensions do not change.
- [x] Static shader checks now detect duplicate GLSL functions, macro derivative use, noise-budget regressions and ImageBitmap transfer regressions.

### V.MAX v5 validation log

- [x] `scripts/check-fluid-shaders.mjs` — smoothstep bounds, GLSL block/function structure, anisotropic GGX presence, macro noise budget, derivative guard and render-target allocation path.
- [x] `scripts/check-cockpit-visual-semantics.mjs` — no-goal semantics, progress value bounds, macro precision and canvas backing-store reuse.
- [x] Strict TypeScript check of `fluid-shader-engine.ts` with `noUncheckedIndexedAccess`.
- [x] TypeScript/TSX transpilation of EnergySummary, MacroOverview, HydrationSummary and the shared engine.
- [x] Runtime assertions for spring settling, wave symmetry and frame-rate-independent interpolation.
- [ ] Full application build and complete test suite — dependencies are not installed in this workspace; Bun is not available.
- [ ] WebGL2 compile/link and screenshot approval — headless Chromium returned neither a WebGL1 nor WebGL2 context under the available SwiftShader configurations, so the GPU shader result remains unverified here.

## Current limitations

The hydration and macro materials remain shader-based visual approximations. The water environment is not a captured HDRI, the water is not a full volumetric/path-traced simulation, and the macro metal is not a complete measured PBR scene. No claim of photorealism should be made until the WebGL output is visually inspected and GPU shader compilation is verified on target hardware.

## V.MAX V7 — implemented visual-system pass

- [x] Obsidian / Graphite / Ceramic / Mist / Mineral Sage / Mineral Blue / Copper / Champagne semantic token families.
- [x] Distinct resting/raised/elevated/hero/inset surfaces and explicit type-role scale.
- [x] Anatomy stage promoted to cockpit lead; projector cone removed and plinth lighting reduced.
- [x] Low-cost fixed directional/specular shading in the existing procedural anatomy shader; no shadow-map or post-processing pass.
- [x] Direct pointer picking connected to `MusclePicker`, with drag threshold and hidden-ancestor filtering.
- [x] Enlarged meal photography surfaces, deferred image loading/decoding, and role-specific macro category colors.
- [x] Observed-measurement SVG history chart, with no smoothing/projection and labels spaced for longer histories.
- [x] Static contrast gate and design-system checks added to the test script.
- [ ] Actual GPU screenshot review and real-device profiling.
- [ ] Licensed high-fidelity atlas asset audit and integration decision (not bundled; current body remains procedural).

## V7 research decisions

Additional repository evidence and source-level decisions are recorded in `docs/REPOSITORY_RESEARCH.md`. Product intent and component-by-component design rationale are recorded in `docs/PRODUCT_VISUAL_DIRECTION_VMAX_V7.md`.
