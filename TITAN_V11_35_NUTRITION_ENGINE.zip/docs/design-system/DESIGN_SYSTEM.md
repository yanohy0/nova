# Sistema de Design — TITAN V.MAX V7

A especificação vigente está em [`DESIGN.md`](../../DESIGN.md). Este arquivo preserva o acesso rápido à paleta e à tipografia; não deve ser usado como fonte de tokens independente.

## Paleta semântica vigente

| Papel | Cor | Uso |
|---|---|---|
| Canvas Obsidian | `#0E1412` | Fundo da aplicação |
| Surface Graphite | `#171E1B` | Cartões em repouso |
| Raised Graphite | `#202925` | Componentes em destaque |
| Elevated Graphite | `#29332D` | Camada superior de superfície |
| Ceramic | `#F1F0E8` | Texto principal e valores |
| Mist | `#B7C1BA` | Texto secundário |
| Mineral Sage | `#A0B7A8` | Marca e ação primária |
| Champagne | `#C8AD7A` | Foco e detalhe de marca |
| Mineral Blue | `#91AFBE` | Hidratação e informação |
| Copper | `#B89579` | Categoria de gordura |

Estados de sucesso, aviso e erro são separados das cores de marca e de categoria. A paleta de shaders anatômicos e os materiais de água têm tokens próprios.

## Tipografia

- `Plus Jakarta Sans`: display, títulos e números protagonistas.
- `DM Sans`: texto de leitura, labels e ações.
- `JetBrains Mono`: medições, unidades, timer e números que exigem alinhamento tabular.

12 px é a base mínima de texto auxiliar. Eyebrows/status curtos podem ser menores somente quando não carregam instrução ou dado essencial.

## Camadas

- `elevation=0`: inset/flat para grupos compactos de KPIs.
- `elevation=1`: superfície padrão.
- `elevation=2`: foco, sessão atual e protagonista anatômico.
- `titan-surface--hero`: palco visual único; não deve ser usado em todos os cartões.
