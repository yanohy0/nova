# TITAN V.MAX — Catálogo de Texturas, Materiais e Efeitos V10

**Data:** 22 nov 2026  
**Escopo:** somente acabamentos, materiais, texturas procedurais, iluminação, efeitos ópticos e custo de renderização associado. Não altera fluxos de treino, nutrição, dados, navegação funcional ou regras de negócio.

## Direção material

A identidade continua **Anatomical Precision**: grafite mineral fosco, superfícies opacas com níveis de profundidade, água de aparência vítrea, metal acetinado e anatomia legível. O acabamento deve aumentar a percepção de qualidade sem transformar cada área em uma superfície brilhante.

Não foi adotado ruído global, textura de mármore/pedra, madeira, fibra decorativa, partículas, neon, bloom permanente ou glassmorphism generalizado. Essas opções adicionariam ruído visual, custo de composição ou uma linguagem de marca que não pertence ao TITAN.

## Referências GitHub priorizadas por adoção e pertinência

Estrelas consultadas diretamente nos metadados públicos dos repositórios em 22/11/2026. O número de estrelas é um sinal de adoção, não uma prova isolada de qualidade, adequação ou performance.

| Ordem | Repositório | Estrelas | Utilidade aplicada | Decisão |
|---:|---|---:|---|---|
| 1 | [Three.js](https://github.com/mrdoob/three.js) | 119.164 | Materiais PBR, roughness, metalness, anisotropy e ciclo de vida WebGL | Referência principal; manter engine e `MeshStandardMaterial` onde já é suficiente |
| 2 | [Tailwind CSS](https://github.com/tailwindlabs/tailwindcss) | 98.709 | CSS utilitário e integração com os estilos atuais | Manter a fundação existente; não adicionar um segundo sistema de estilos |
| 3 | [React Three Fiber](https://github.com/pmndrs/react-three-fiber) | 33.886 | Renderização sob demanda e prevenção de loops ociosos | Aplicar o princípio no renderer imperativo já existente; não migrar para R3F |
| 4 | [Babylon.js](https://github.com/BabylonJS/Babylon.js) | 26.427 | Segunda referência de rendering/PBR, reflexão e materiais | Referência comparativa; não trocar Three.js |
| 5 | [Drei](https://github.com/pmndrs/drei) | 10.190 | Implementação de transmissão/refração e seus buffers de cena | Consultado; não importar `MeshTransmissionMaterial` para gauges pequenos |
| 6 | [meshoptimizer](https://github.com/zeux/meshoptimizer) | 8.897 | Redução de buffers, cache de vértices, quantização e otimização de malha | Preservar a compactação V9 sem simplificar os grupos musculares |
| 7 | [Google model-viewer](https://github.com/google/model-viewer) | 8.352 | Referência de apresentação de ativos glTF e materiais PBR | Referência; não é necessário no viewer procedural atual |
| 8 | [postprocessing](https://github.com/pmndrs/postprocessing) | 2.989 | Bloom, SSAO e passes de pós-processamento | Não adicionar: os ganhos não justificam passes fullscreen para este layout |
| 9 | [Khronos glTF Sample Viewer](https://github.com/KhronosGroup/glTF-Sample-Viewer) | 1.488 | Comparação de comportamento de materiais glTF/PBR | Referência especializada para futuras malhas com mapas reais |
| 10 | [evanw/webgl-water](https://github.com/evanw/webgl-water) | 1.286 | Refração, Fresnel, ondas e cáusticas de água | Referência especializada para o shader de hidratação |

### Leituras técnicas que orientaram as decisões

- O código de [`MeshPhysicalMaterial`](https://github.com/mrdoob/three.js/blob/dev/src/materials/MeshPhysicalMaterial.js) documenta anisotropia para metais escovados, clearcoat para superfícies com camada refletiva e transmissão física para vidro. Também alerta que os recursos adicionais elevam o custo por pixel. Por isso o corpo anatômico permanece em `MeshStandardMaterial`, sem lobos de clearcoat desnecessários.
- A documentação de [performance do React Three Fiber](https://github.com/pmndrs/react-three-fiber/blob/master/docs/advanced/scaling-performance.mdx) recomenda renderizar sob demanda quando a cena pode ficar parada. O TITAN já implementa esse comportamento no engine compartilhado.
- O [Drei MeshTransmissionMaterial](https://github.com/pmndrs/drei/blob/master/src/core/MeshTransmissionMaterial.tsx) usa buffers de renderização e expõe custo adicional para renderizar o lado posterior. Para um medidor de 116 × 68 px, o shader 2D/2.5D existente é mais simples e apropriado.
- [meshoptimizer](https://github.com/zeux/meshoptimizer) continua sendo a referência de compactação; não foi aplicada decimação destrutiva porque a geometria anatômica precisa manter IDs, lados e superfícies de seleção.

## Inventário: cada superfície, textura, material e efeito

| Elemento | Material / textura / efeito presente | O que melhora visualmente | Ajuste V10 e limite |
|---|---|---|---|
| Fundo geral | Grafite/obsidiana fosco | Faz o conteúdo, números e anatomia emergirem sem competir com eles | Mantido opaco e sem ruído global |
| Superfície base | Plano grafite com borda discreta e sombra interna | Separa conteúdo do fundo e define uma camada de leitura | Mantida como plano opaco |
| Superfície elevada | Tom mais claro, borda mais presente e sombra de elevação | Dá hierarquia física a painéis realmente elevados | Mantida; não adicionar brilho em todos os cartões |
| Superfície inset | Grafite profundo e borda interna | Faz campos, trilhos e áreas de edição parecerem rebaixados | Mantida sem textura decorativa |
| Superfície hero | Gradiente mineral, luz radial superior e micro-linhas acetinadas | Acrescenta direção de luz e uma sensação tátil de acabamento usinado | **Novo acabamento V10:** micro-satin com opacidade muito baixa, aplicado somente no hero |
| CTA primário | Base Mineral Sage, linha de borda e brilho linear superior | Torna o botão tangível, separa a face da borda e sugere uma luz de softbox | **Refinado V10:** highlight superior mais suave; sem glow forte |
| Barra superior | Vidro escuro translúcido com blur/saturação | Mantém contexto ao rolar e separa a navegação do conteúdo | **Otimizado V10:** blur 18→12 px, fundo mais opaco e suporte `-webkit-backdrop-filter` |
| Navegação inferior | Vidro grafite, borda superior e sombra | Faz a navegação parecer uma camada fixa, mantendo o conteúdo visível por baixo | **Otimizado V10:** blur 20→14 px e opacidade maior para reduzir dependência do backdrop |
| Gota de água | Casca de vidro mineral com gradientes de borda e reflexos alongados | Dá espessura, transparência, curvatura e leitura do volume | Mantida; não substituída por PNG ou blur CSS |
| Coluna/tanque de água | Vidro cilíndrico simulado, paredes internas e reflexo de borda | Faz o volume parecer contido em um recipiente, não apenas uma barra azul | Mantida com a mesma via de renderização compartilhada |
| Líquido de hidratação | Gradiente volumétrico, absorção Beer–Lambert e Fresnel | Dá profundidade, densidade e mudança de cor conforme o caminho óptico | Mantido; o modelo continua sendo uma aproximação 2.5D para UI |
| Menisco | Curvatura da superfície e highlight fino | Comunica tensão superficial e posição exata do nível | Mantido sem ondulação permanente |
| Ondas de água | Ondas Gerstner analíticas e impulso amortecido | Evita aparência de preenchimento rígido e comunica uma alteração recente | Mantidas somente durante interação/alteração de volume |
| Cáusticas | Concentração por área diferencial projetada | Acrescenta focos luminosos que fazem sentido com a refração | Mantidas; substituem busca Voronoi decorativa mais cara |
| Reflexo de vidro | Fresnel frontal/traseiro e reflexão total interna | Explica a borda e a espessura do material | Mantido; não é ray tracing completo |
| Luz de estúdio | Softboxes procedurais retangulares | Gera faixas de reflexão coerentes, evitando pontos artificiais | Mantida como ambiente analítico procedural, não HDRI |
| Indicador de energia | Fluido Mineral Sage com ruído de três oitavas e softbox | Tira o aspecto de barra plana sem parecer plasma ou efeito sci-fi | Mantido; sem novo filtro de pós-processamento |
| Medidores de macros | Metal acetinado, anisotropia GGX, duas luzes e microvariação | Faz o arco parecer metal usinado e arredondado, com reflexos alongados | **Refinado V10:** rugosidade 0,24–0,32, anisotropia principal 0,28, secundária 0,21, movimento mais lento e highlight final reduzido |
| Corpo anatômico externo | Material PBR fosco em tom de pele neutro | Preserva anatomia e volume sem aparência metálica/plástica | **Refinado V10:** roughness 0,74 (antes 0,78); sem clearcoat para evitar custo e aspecto envernizado |
| Grupos musculares | Material PBR compartilhado + cor resolvida no shader | Diferencia repouso, primário, secundário e seleção sem pintar buffers no CPU | **Refinado V10:** roughness 0,68 (antes 0,72); mantém uma malha/batch e uniforms |
| Plano anatômico profundo | Material translúcido de alta rugosidade | Sugere profundidade e separa os planos internos | Mantido; transparência limitada para não encobrir a superfície |
| Referência óssea | Cerâmica óssea clara, fosca | Diferencia o esqueleto dos tecidos sem recorrer a branco brilhante | Mantida com rugosidade alta |
| Reflexão anatômica PMREM | Ambiente de sala procedural convertido em PMREM | Cria highlights ambientais e volume mais convincente no modelo | Mantido apenas em hardware; omitido em renderer de software |
| Sombra de contato | Elipse procedural suave | Assenta visualmente a figura no palco e ajuda a ler sua posição | Mantida no lugar de um shadow-map pass |
| Sweep de seleção | Faixa de luz de curta duração no músculo selecionado | Confirma a seleção e dá resposta espacial ao toque | Mantida em uma única passagem; respeita movimento reduzido |
| Anéis/contornos do palco | Linhas discretas e bordas de contraste baixo | Delimitam o espaço 3D e criam escala sem roubar foco | Mantidos discretos; sem brilho contínuo |
| Sombras de superfície | Sombras em níveis de elevação | Aumentam separação entre planos e legibilidade da hierarquia | Mantidas sem `will-change` global nem filtros extras |

## Melhorias efetivamente aplicadas no código V10

1. Hero recebe microtextura mineral acetinada com baixa opacidade e linhas espaçadas. A textura não é aplicada globalmente e não fica atrás de texto corrido.
2. CTA primário ganha um reflexo linear superior mais controlado, coerente com a linguagem mineral.
3. Material dos músculos e do corpo recebe pequena redução de roughness: a forma anatômica ganha leitura especular sem ativar `MeshPhysicalMaterial`, clearcoat, sheen ou mapas de textura adicionais.
4. Metal dos macros passa a refletir como metal acetinado, não cromado: rugosidade mais ampla, anisotropia um pouco mais evidente, movimento mais lento e hotspot menos intenso.
5. Blur de navegação superior/inferior reduzido, com superfícies mais opacas e prefixo WebKit para compatibilidade.
6. O engine compartilhado limita submissões de desenho a no máximo 60 fps durante transições; ocioso continua sem loop e sem redesenhar valores estáticos.
7. Adicionado `scripts/check-materials-v10.mjs` ao `npm test` para impedir regressões nas decisões materiais e nos limites de performance.

## O que poderia ser adicionado depois — mas não foi aplicado

| Recurso | Benefício visual possível | Motivo para não aplicar agora |
|---|---|---|
| Normal map de poros da pele | Microtextura orgânica muito próxima da pele real | A anatomia é procedural e não possui UV/atlas de pele pronto; inventar um mapa agora pode criar padrões repetidos e artefatos |
| Textura de tecido | Diferenciaria roupas ou acessórios no modelo | O ativo atual não tem um sistema de tecido/UV que justifique uma textura adicional |
| HDRI fotográfico calibrado | Reflexos mais ricos e ambientes consistentes no PBR | Nenhum HDRI licenciado e calibrado veio com o pacote; o ambiente atual é explicitamente procedural |
| Clearcoat/anatomia molhada | Highlights mais intensos em superfícies úmidas | Não combina com a pele neutra atual e eleva custo por pixel; Three.js documenta esse custo em `MeshPhysicalMaterial` |
| Transmissão 3D completa | Refração de objetos atrás de vidro com espessura real | Exige buffers e passes adicionais; desproporcional aos pequenos medidores do cockpit |
| Bloom global | Halos em highlights intensos | Diminui legibilidade, pode contaminar cores semânticas e exige pós-processamento fullscreen |
| SSAO de tela | Sombra de contato adicional entre partes da geometria | O benefício esperado não justifica outro passe no viewer atual; já existe sombra procedural leve |
| Poeira, partículas e glitter | Movimento e brilho decorativo | Desvia atenção dos dados e da anatomia; aumenta trabalho gráfico sem melhorar a tarefa |
| Iridescência | Variação cromática angular em filmes finos | Não corresponde a materiais reais do sistema e introduz uma linguagem chamativa |
| Textura global de grão | Pode unificar superfícies e disfarçar banding | Em telas pequenas degrada clareza; não é coerente com precisão clínica/técnica |

## Performance e critérios de revisão

- Nenhuma dependência nova.
- Nenhuma mudança de motor 3D.
- Nenhuma textura bitmap nova ou aumento de payload de imagem.
- O corpo continua em material PBR padrão; os grupos musculares continuam batched e com IDs preservados.
- A água e os medidores usam o engine compartilhado, programas cacheados e superfícies desenhadas sob demanda.
- O frame budget do engine é no máximo 60 submissões/s durante animação; não há loop quando o valor e as ondas assentam.
- O viewer anatômico mantém o orçamento de pixels, inicialização lazy, PMREM ignorado em software GL, compile assíncrono e descarte de recursos.
- `prefers-reduced-motion` permanece ativo.

### Limitações de validação

O container de edição não tem `node_modules`, Bun nem um caminho WebGL2 funcional. Foram executados os cinco verificadores estáticos do projeto e o novo verificador V10. Não foi possível fazer build Vite, captura visual real ou benchmark GPU em dispositivo. Portanto, não são declarados FPS medidos nem aprovação visual por screenshot. A inspeção final em GPU continua sendo gate antes de produção.
