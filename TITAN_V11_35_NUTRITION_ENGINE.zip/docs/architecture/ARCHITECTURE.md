# Arquitetura Modular por Domínios — TITAN

## Direção de Dependência
`Interface (screens / components)` -> `Application (casos de uso)` -> `Domain (entidades, regras, contratos)` <- `Infrastructure (storage, api, sync, monitoring)`

## Regras Obrigatórias
1. Um domínio não importa arquivos internos de outro domínio; integrações ocorrem por contratos públicos (`application/` ou `shared/types/`).
2. O subsistema `anatomy` recebe destaques do domínio `training`, mas a seleção manual exploratória nunca altera o plano de treino.
3. Regras críticas (cálculo de descanso, validação de séries, progresso) residem em `domain/rules/` e `schemas/` sem dependência de React.
4. Estados separados por responsabilidade:
   - Navegação (`app-core/navigation`)
   - Sessão de treino (`training/state`)
   - Estado 3D e câmera (`anatomy/state`)
   - Nutrição e hidratação (`nutrition/state`, `hydration/state`)
   - Evolução observada (`evolution/state`)
