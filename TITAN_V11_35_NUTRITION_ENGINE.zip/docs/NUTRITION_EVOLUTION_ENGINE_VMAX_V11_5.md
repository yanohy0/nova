# TITAN V.MAX V11.5 — Nutrition & Evolution calculation engine

Research and implementation snapshot: 23 November 2026.

## Scope delivered

- Nutrition is presented through one `NutritionWorkspace` component with Cardápios, Receitas and Alimentos sections. The existing lazy route remains compatible through the `CardapioScreen` export.
- Imported 5,830 TBCA 7.2 food records from the user's `Planejamento_Nutricional_Final.xlsx` sheet `TBCA`. These are exactly the rows marked `Elegivel_Calculo = SIM` and `Status_Dados = OK`. The 47 blocked/incomplete rows are intentionally excluded. `scripts/build-tbca-catalog.py` reproduces the compact catalog and provenance manifest; the manifest stores both source-workbook and generated-catalog SHA-256 hashes.
- Retained legacy food IDs used by existing recipes and workout/nutrition fixtures. The new TBCA IDs are namespaced as `tbca:<source-code>`.
- The catalog retains source code, URL, group, state/preparation, source version, energy/macros, and 20 source nutrients. Vitamin K, B5 and B7 are explicitly `not_analyzed` because this workbook's TBCA sheet does not provide them. Blank values remain `null`/`not_analyzed`; numeric zero remains a measured zero.
- Food list renders at most 60 matches rather than mounting all 5,800+ rows at once.
- Recipe calculations preserve fractional ingredient grams and full precision until the presentation layer.
- Macro calculations now expose quantified-mass coverage, unresolved food IDs and lower-confidence records. An unknown ingredient is not silently treated as a known zero.
- Partial meal calculations use the exact `consumed_foods` masses before any rounded display quantity.
- Nutrition, profile and evolution stores persist locally with Zustand `persist` and versioned keys. Existing seeded records and data structures are retained. This is browser-local persistence, not cloud backup or cross-device sync.
- Weight can be recorded independently every day; waist, arm and thigh are optional primary measurements. Chest, hips, neck, forearm and calf are captured in a collapsed advanced section and stored only when supplied.
- Weight trend uses same-day median aggregation plus Theil–Sen pairwise median slope to reduce outlier sensitivity. Goal pacing reports distance, required kg/week, required kg/day, observed trend and an explicitly labelled projection.
- DRI profile selection now distinguishes male/female 19–50, 51–70 and 71+ adult reference bands; it does not infer menopause or clinical conditions.
- Daily energy intake becomes eligible for adaptive TDEE only after the user explicitly confirms a fully logged day; changing a meal invalidates that day's confirmation.

## Calculation methods and limits

### Initial energy target

The existing Mifflin–St Jeor resting-energy equation and declared-activity multiplier remain the cold-start estimate. Predictive equations estimate population averages; they are not individual metabolic measurements. Indirect calorimetry remains the reference for measured resting energy expenditure.

### Adaptive TDEE calibration

`estimateAdaptiveTdee()` uses confirmed daily calorie intake and aligned weight history. It requires at least 14 complete intake days, at least 60% coverage of the requested 21–90 day window, and at least three weight observations spanning 14 days. It uses median daily intake and a robust Theil–Sen weight trend.

The model returns a range using a 4,500–9,500 kcal/kg sensitivity interval and a 7,000 kcal/kg central planning assumption. It is an observational calibration aid, not the full Hall/NIDDK dynamic body-weight model, not a measured TDEE, and not a clinical prescription. Low-confidence estimates are not used to replace the cold-start equation. No automatic calorie change is applied without sufficient confirmed data.

### Weight trend and projections

- Multiple weights on one date are reduced to that date's median.
- Theil–Sen slope is the median of pairwise daily slopes, expressed as kg/week.
- Trend confidence is labelled low, moderate or higher according to observation count and span; no confidence interval is fabricated.
- Target-date projection extrapolates the observed slope and is explicitly an estimate, not a promise.
- Daily pace is a mathematical conversion of the weekly required pace, not a recommended daily weight-loss target.
- Circumference deltas use the first and last actual measurement for each circumference; missing measurements stay unavailable.

### Food composition and recipe math

- Energy comes from the source energy field; it is not recalculated from rounded macros.
- Protein, total carbohydrate and lipid quantities scale linearly from the 100 g source basis.
- Fiber, saturated fat, cholesterol and sodium are retained where available.
- Copper is normalized from mg to µg while preserving the original value/unit and conversion method.
- RE is not substituted for RAE; vitamin A uses the workbook's RAE column. Missing nutrient values are not coerced to zero.
- The current app recipe catalog contains its existing curated examples. The workbook's recipe sheet has four records, but two are incomplete and two are explicitly technical fixtures rather than real user recipes; they were not imported as production recipes.

## Architecture decisions

- Keep React + TypeScript + Vite and the existing Zustand + Zod stack. No additional runtime dependency was justified by this scope.
- Keep the hand-built SVG weight chart: it already covers the small set of series needed and avoids adding a charting runtime.
- Keep the current simple controlled forms. React Hook Form is a credible option for a future complex recipe editor, but adding it now would not improve these short forms enough to justify another dependency.
- Keep Zustand persistence for local profile, nutrition and evolution state. TanStack Query is a strong MIT option for future remote API caching/synchronization, but this release has no remote nutrition backend to query.
- Do not import code from SparkyFitness: it has approximately 6.8k stars and useful end-to-end feature patterns, but its repository license is explicitly non-commercial/source-available. Its code is not compatible with a commercial product without written permission.

## Repository comparison (GitHub star snapshots around 23 Nov 2026)

| Repository | Approx. stars | License | Decision |
|---|---:|---|---|
| [pmndrs/zustand](https://github.com/pmndrs/zustand) | 58.8k–59k | MIT | Already used. Apply official `persist` middleware; no state-library migration. |
| [TanStack/query](https://github.com/TanStack/query) | 50.5k–50.6k | MIT | Do not add until remote API/server-state caching exists. |
| [react-hook-form/react-hook-form](https://github.com/react-hook-form/react-hook-form) | 44.9k | MIT | Do not add for the current short forms; consider when recipe/food editing becomes a multi-step form. |
| [colinhacks/zod](https://github.com/colinhacks/zod) | 44.1k | MIT | Already used for runtime validation; retain. |
| [TanStack/table](https://github.com/TanStack/table) | 28.6k | MIT | Defer until the app needs sorting, filtering, column visibility and pagination in a real data grid. |
| [recharts/recharts](https://github.com/recharts/recharts) | 28k–28.6k | MIT | Defer; current SVG chart is intentionally small and dependency-free. |
| [CodeWithCJ/SparkyFitness](https://github.com/CodeWithCJ/SparkyFitness) | ~6.8k | Non-commercial only | Reference architecture/feature patterns only; no code copied or bundled. |

Stars are adoption signals, not quality, safety or license approval. Licenses were checked separately. No new repository code or dependency was copied into the runtime in this release.

## Research references

- Mifflin MD et al. *A new predictive equation for resting energy expenditure in healthy individuals.* Am J Clin Nutr. 1990. DOI: https://doi.org/10.1093/ajcn/51.2.241
- Hall KD et al. *Quantification of the effect of energy imbalance on bodyweight.* Lancet. 2011. DOI: https://doi.org/10.1016/S0140-6736(11)60812-X
- NIDDK Body Weight Planner (dynamic model resource): https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner
- 2026 review on healthy weight loss and target weight, which discusses dynamic vs static modelling and body-composition trade-offs: https://doi.org/10.1002/jcsm.70334
- 2026 study comparing predictive equations with indirect calorimetry in older adults with sarcopenia: https://doi.org/10.1002/ncp.70131
- 2025 pragmatic randomized trial of a mobile self-regulation intervention incorporating daily self-weighing and weekly reflection: https://doi.org/10.1186/s12916-025-04519-8
- TBCA source: user-provided `Planejamento_Nutricional_Final.xlsx`, sheet `TBCA`, version identified in the workbook as TBCA 7.2. Review the source database's terms before distributing the extracted food database outside the user's project.

## Validation record

Executed successfully in the editing environment:

- Evolution trend tests: chronological sorting, same-day median, Theil–Sen trend, target pace and weight-only records.
- Profile calculation tests: date validation, goal limits, anthropometry, adaptive TDEE coverage/range and fallback for low-confidence estimates.
- TBCA catalog validation: 5,830 unique eligible foods, 100 g basis, zero/null semantics.
- Domain-boundary checks.
- Anatomy group contract, lifecycle, V9 and V.MAX V11.3 checks (regression guard for untouched functionality).
- TypeScript/TSX syntax transpilation: 128 source files, zero syntax diagnostics.
- Nutrition engine and recipe/goal assertions executed with Node TypeScript strip mode and an extension-resolution loader. The recipe/goal test used a minimal Zustand create stub only to load a calendar constant; it did not validate Zustand persistence behavior.

Not completed in this environment:

- Full `tsc --noEmit`, Vite production build, full test suite and browser E2E, because dependencies were not installed. `npm install` timed out and `node_modules` was absent. Do not interpret syntax transpilation as a full typecheck/build.
- Browser-level validation of Zustand persistence/rehydration, storage quota, offline backup/restore and mobile browser performance.
- Clinical validation of individual TDEE, body-composition estimates or safety of a particular target.

## Next engineering gates

1. Complete typecheck/build and all test suites in CI with the frozen Bun lockfile.
2. Add export/import backup for local records before relying on browser storage as the only persistence layer.
3. Add date-level intake editing and an explicit missing-food resolution workflow before using adaptive TDEE in production decisions.
4. Add recipe yield/final cooked weight, preparation-state and edible-portion handling before claiming per-serving precision for cooked recipes.
5. Add independent measurement types for additional circumferences only when the UI and calculation use-cases are defined.
6. Validate all DRI values against the current NASEM/NIH reference tables and add pregnancy/lactation and clinical population handling only with explicit user inputs.
