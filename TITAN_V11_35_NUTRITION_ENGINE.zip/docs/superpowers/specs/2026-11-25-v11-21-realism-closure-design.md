# TITAN V11.21 — Realism Closure: design

**Status:** implementado parcialmente na base V11.21.0; ainda não é certificação V.MAX física.

## Intenção

Fechar lacunas corrigíveis sem substituir a arquitetura visual existente. Melhorar contabilidade de água, estabilidade do campo de velocidade, histerese de contato, resposta espectral dos metais e forma temporal dos arcos. Preservar o corpo anatômico, os materiais e a iluminação atuais enquanto adiciona evidência e explicita o que ainda depende de ativos, GPU ou modelos físicos maiores.

## Público e resultado esperado

Os componentes de hidratação, energia/macros e anatomia devem manter a experiência responsiva no navegador. A meta desta revisão é elevar consistência física aparente e correção numérica, não transformar pequenos componentes de interface em laboratórios de CFD, eletromagnetismo ou path tracing espectral.

## Objetivos

- Toda alteração de massa de gotas deve ser classificada como fonte, sumidouro, transferência ou redistribuição interna e fechar o balanço do conjunto representado.
- A projeção 2D deve reduzir a divergência com uma discretização coerente entre divergência, gradiente e Laplaciano, com número de iterações limitado e diagnóstico de resíduo.
- A linha de contato deve distinguir avanço e recuo e alimentar a resistência de pinning.
- Os metais devem usar n/k medidos em várias amostras do visível e Fresnel complexo, com dados interpoláveis.
- A animação de descarga deve ter envelope temporal suave e normalizado também na CPU para teste.
- As decisões, referências, licenças, limites e evidências devem ser reproduzíveis no pacote.

## Não objetivos

- Implementar SPH/MLS-MPM, solver CFD 3D ou mudança para WebGPU.
- Afirmar solução não linear 3D Young–Laplace, BSSRDF de irradiância completa, solver MHD/streamer ou espectro CIE hero-wavelength completo.
- Trocar o modelo MakeHuman e seu rig por um GLB externo sem comprovar retargeting, pesos, morfologia e licença de cada ativo.
- Adicionar dependências de runtime ou reescrever a engine de renderização.
- Mudar o conceito aprovado de iluminação: sem chão, plinto ou projetor; preservar somente um halo difuso atrás do corpo.

## Abordagens consideradas

1. **Substituir subsistemas por engines/repositórios completos.** Rejeitada: SPH/MLS-MPM, WebGPU e anatomia GLB sem rig aumentam custo, integração e risco sem garantia de benefício proporcional para componentes pequenos.
2. **Manter apenas os efeitos procedurais existentes.** Rejeitada: continuaria escondendo perda de massa, aproximações espectrais grosseiras e normalização temporal imperfeita.
3. **Evolução incremental, testável e compatível com a stack atual.** Escolhida como decisão técnica: implementar ledger e transferências explícitas, operadores diferenciais compatíveis, contato advancing/receding, n/k medidos multi-amostra e envelope Heidler normalizado; manter explícitos os limites de física e integração.

## Arquitetura e stack

- React 19 + TypeScript + Vite; Three.js r187 para anatomia.
- WebGL2 e GLSL ES 3.00 para medidores e efeitos compartilhados.
- Solver de gota/fluxo 2D compacto, com projeção discreta de pressão e ledger CPU.
- Fresnel complexo exato para condutores, dados tabulados n/k em CC0 e interpolação linear por comprimento de onda.
- Manter materiais, PMREM/RoomEnvironment, RectAreaLight, iluminação de fallback e controle de animação sob demanda.
- Sem nova dependência de runtime.

## Regras de integração

- A massa total das gotas é `initial + sources - sinks`; o que entra em outro recipiente é sink/transferência do conjunto atual e fica explicitado no evento.
- Coalescência é transferência interna conservativa; a massa doadora não pode desaparecer.
- A projeção usa divergência forward e gradiente backward, cuja composição produz o Laplaciano de cinco pontos; não é uma grade MAC face-centered.
- A histerese é uma aproximação fenomenológica com ângulos de avanço/recuo limitados.
- A quadratura espectral usa nove âncoras medidas (três por banda RGB), não uma integração espectral CIE.
- Heidler é um envelope visual escalado em segundos de animação; não modela corrente de retorno em escala física nem streamer.
- Dados n/k foram copiados apenas da base CC0 refractiveindex.info; o código de referência de terceiros não foi copiado.

## Critérios de aceite

- Testes unitários independentes para ledger, projeção, histerese, amostragem espectral e Heidler.
- Teste determinístico mostra redução de divergência e fechamento do ledger em sequência com fontes/sumidouros.
- Teste confirma equação Fresnel complexa em incidência normal e rasante.
- Teste estático confirma integração shader/CPU e quantidade de amostras.
- Suítes existentes de realismo e revisão são executadas; build, lint e GPU são reportados separadamente quando o ambiente os bloqueia.

## Limitações aceitas nesta revisão

A projeção collocated 2D ainda tem erros de contorno e não substitui MAC + multigrid/PCG. O menisco continua linearizado e 2D. O modelo de descarga é visual. A anatomia não recebe nova geometria independente nesta revisão. O SSS atual não é um BSSRDF UV-space completo. A luz de estúdio continua baseada no ambiente analítico atual, sem calibração fotométrica real.
