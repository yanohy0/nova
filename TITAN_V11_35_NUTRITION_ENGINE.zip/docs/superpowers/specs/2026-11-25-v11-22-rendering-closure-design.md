# TITAN V11.22 — Rendering and Physics Closure Design

## Intent

Continue from the actual V11.21 archive and close incremental, evidence-backed gaps in the existing Three.js/WebGL2 renderer. Preserve the user's visual direction: realistic water/materials/plasma/body, with only one diffuse background halo behind the body and no lit floor, plinth, projector or contact light.

## Goals

1. Improve pressure projection convergence on the existing compact 2D fluid grid without replacing the renderer or introducing runtime dependencies.
2. Fix temporal topology drift in plasma side branches so branch identities stay anchored in space while independent pulse envelopes control their life.
3. Improve screen-space skin diffusion's radial/isotropic coverage and edge rejection without pretending the result is a full BSSRDF.
4. Add tests, integration contracts and research evidence for each change.
5. Audit anatomy and lighting claims against the actual model/renderer and add only honest diagnostics or compatibility gates where asset/physical calibration is absent.
6. Run all available project tests and report unavailable full build/GPU checks explicitly.

## Non-goals

- No switch to WebGPU, Unity, Filament or a different renderer.
- No SPH/FLIP/MLS-MPM replacement for the small hydration UI.
- No MHD or full dielectric-breakdown solver.
- No invented independent muscle heads or fabricated anatomy meshes.
- No full irradiance-space BSSRDF or path-traced skin in this incremental release.
- No extra floor illumination, ground plane, light ring or second halo.

## Approaches

1. **Replace whole subsystems with high-fidelity external engines.** Rejected: incompatible with WebGL2/runtime, costly, and unproven value for the small UI components.
2. **Only add documentation.** Rejected: several specific defects are fixable inside the current systems and can be tested deterministically.
3. **Incremental solver/temporal/shading improvements plus explicit unresolved gates.** Selected: keep existing APIs and renderer, use PCG for pressure, stable spatial branch IDs with temporal Heidler pulse, and a bounded three-radius screen-space diffusion kernel with depth gating. This provides measurable improvements without architectural migration.

## Constraints

- React 19, TypeScript strict, Three.js r187, WebGL2, GLSL ES 3.00.
- No new runtime dependencies.
- No more than one new pressure-solver workspace allocation per grid instance; no per-step allocation.
- Pressure Poisson operator must remain symmetric positive definite with explicit zero-Dirichlet border, IC(0) factorization from the five-point stencil, and compatible correction on boundary faces.
- Default pressure solve bounded to at most 12 IC(0)-PCG iterations and residual-relative tolerance 0.05 on the 48×24 visual grid.
- Lightning branch spatial identity must be independent of animation time; temporal gating remains continuous and deterministic.
- Skin diffusion remains RGB, depth-aware, bounded to three spatial radii and four directions; alpha and non-skin/holographic contours remain protected.
- Keep dual-body draw-call/buffer budget and current lighting composition.

## Acceptance criteria

- Pressure test demonstrates at least 90% reduction in divergence RMS on the deterministic 48×24 field and four additional deterministic fields, with finite pressure/residual and residual threshold met within 12 IC(0)-PCG iterations. Zero-flow, invalid-grid and preconditioner-cache cases are covered.
- Lightning test/source contract proves `nodeId` is derived from spatial coordinate only, branch-local coordinate remains spatial, and branch pulse uses stable per-node seed with continuous Heidler envelope.
- Skin shader contract proves three radii, bounded four-direction taps, per-channel red-dominant scatter, normalized accumulation, depth rejection, hue gate, and unchanged alpha behavior.
- Existing rendering-realism, review, V11.21 physics and calculation typecheck commands are rerun.
- `npm test`, lint, build, and GPU shader checks are attempted; unavailable tooling is documented, never counted as passed.

## Explicit unresolved gates

- Real 3D free-surface fluid and nonlinear 3D Young–Laplace meniscus require a separate GPU-backed validation and physical scale calibration.
- Continuous spectral/CIE materials still require wavelength quadrature in the GPU path and measured reference scenes.
- Physical electrical breakdown requires a license-cleared Laplace/DBM/MTLE implementation and calibrated electrical parameters.
- Full anatomy requires compatible male/female segmented assets, rig/pose mapping and independent origins/insertions; no label-only mesh split is acceptable.
- Full skin BSSRDF requires irradiance-space separable diffusion, thickness maps and measured skin references.
- Studio HDRI/exposure and 360° body QA require real device/browser visual captures.
