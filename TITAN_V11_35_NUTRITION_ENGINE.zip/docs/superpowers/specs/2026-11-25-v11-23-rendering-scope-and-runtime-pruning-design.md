# TITAN V11.23 — Rendering Scope and Runtime Pruning Design

## Intent

Continue from the actual V11.22 archive. Improve the visible hydration glass/water meniscus, remove runtime infrastructure that has no product consumer, and stop building hidden skeletal geometry. Keep the product focused on the body surface, muscle presentation, hydration, glass, plasma and lightning visuals.

## Goals

1. Replace the linearized exponential meniscus in the existing glass/water shader with a bounded closed-form approximation calibrated against the nonlinear 2D Young–Laplace boundary-value solution.
2. Keep the CPU reference model and GLSL implementation mathematically aligned, with numerical regression tests.
3. Remove the unused Express application entirely; use Vite for development/preview and publish `dist/` to a static host in production.
4. Remove dead in-memory analytics and synchronization queues that have no consumers.
5. Remove the unused hidden skeleton geometry/material pipeline. Retain body base geometry, muscle surfaces, deep soft-tissue planes, muscle IDs, selection, morphs, and dual-body rendering.
6. Preserve genuine data provenance and active food-domain integrations. Do not delete Open Food Facts data adapter or exercise-record source/licensing metadata.
7. Remove the unused `@google/genai` SDK, Gemini key metadata, and the unconsumed Open Food Facts URL builder; retain local Open Food Facts records and existing provenance.
8. Keep the existing Three.js/WebGL2 architecture; add no runtime dependency and no external API integration.

## Non-goals

- No skeleton/bone meshes or tendon meshes; no new fascia subsystem or external anatomy asset is introduced.
- No full SPH/FLIP/MLS-MPM rewrite, full 3D CFD, MHD solver, or dielectric-breakdown solver in this release.
- No migration to WebGPU, Filament, Unity, or a different renderer.
- No full spectral/CIE path tracer or full irradiance-space BSSRDF; the existing nine-sample measured metal approximation and screen-space skin diffusion remain bounded realtime approximations.
- No new network APIs, account/sync backend, remote analytics, or generic API framework.
- No visual approval or GPU-build claim without a working hardware/browser validation environment.

## Approaches

1. Import full external engines and anatomy assets. Rejected: they are incompatible with the current compact WebGL2 UI, carry license/runtime costs, and are not required to improve visible output.
2. Documentation-only cleanup. Rejected: dead API routes and hidden geometry have concrete runtime/build cost, and the meniscus shader has an identified visible approximation to improve.
3. Local, tested improvements within the existing engine and removal of unconsumed code. Selected: preserve Three.js/WebGL2, implement a CPU-verified nonlinear meniscus approximation mirrored in GLSL, and delete the dead runtime surfaces.

## Technical design

### Nonlinear meniscus approximation

Use the first-integral wall-height constraint of the static 2D Young–Laplace equation:
`h0 / lambda = sign(cos(theta)) * sqrt(2 * (1 - sin(theta)))`.
Use a bounded exponential transition that also matches the contact-line slope and asymptotic decay:
`h/lambda = sign(cos(theta))*q*exp(-x - (a-1)*(1-exp(-4*x))/4)`, where `x=d/lambda`, `q=sqrt(2*(1-sin(theta)))`, and `a=abs(cot(theta))/q`.
This is explicitly an approximation to the nonlinear boundary-value profile, not an exact arbitrary-curvature 3D meniscus solver. Validate it against an RK4 reference integration of `y'' = y*(1+y'^2)^(3/2)` over the contact-angle range used by the shader.

### Runtime/API reduction

The product is a client-side static application; there is no justified product API consumer in this release. Delete `server.ts`, the stale generated `server.js`, and Express/compression packages rather than preserving a server whose only behavior was unconsumed routes and Vite middleware. Use `vite --host 0.0.0.0` for development, `vite preview --host 0.0.0.0` for local preview, and publish `dist/` to a static host/CDN in production. Delete `src/infrastructure/api/http-client.ts`, `sync-queue.ts`, and `event-tracker.ts` after confirming zero imports/consumers. Remove `@google/genai`, `GEMINI_API_KEY`, the false Gemini capability flag, and the unconsumed Open Food Facts live URL builder; preserve the curated local food records and their provenance. Keep `zod` because domain validation still uses it.

### Anatomy scope reduction

Remove the hidden `skeletonGroup`, generated skeleton tubes/ellipsoids, skeletal-reference material, and renderer visibility switch. Preserve shell, superficial muscle batch, deep layer batch, pickable meshes, morphology and canonical muscle registry. Keep legacy persisted `layerMode: 'skeleton'` mapped to `complete` for state compatibility.

### Provenance

The exercise source registry remains a static research/provenance contract used to check selected imported records; it does not make requests. Remove the end-user candidate-repository panel from the exercise screen. Keep item-level source URL, data license and blob SHA. Keep the active Open Food Facts catalog adapter.

## Constraints

- React 19, TypeScript strict, Three.js r187, WebGL2 and GLSL ES 3.00.
- Node runtime minimum 22.12.0, matching the Vite toolchain requirement declared by the package.
- No new runtime or development dependency.
- No product backend, API routes, Express/compression dependency, Gemini SDK/credential, or generic `fetch`-based product integration.
- Preserve the single diffuse halo behind the body and never introduce floor illumination.
- No skeletal/tendon assets or geometry in the active anatomy build.

## Acceptance criteria

- Numerical meniscus tests compare the nonlinear approximation against an RK4 reference for wetting, neutral and non-wetting angles; bounded relative error is <= 8% on tested points from 0.25 to 4 capillary lengths over 22.5–157.5 degrees excluding the exact neutral zero-height case.
- The GLSL function uses the same dimensionless formula and both tank/glass call sites use it.
- `server.ts` and generated `server.js` are absent; Express/compression are absent from package dependencies.
- `dev` and `start` invoke Vite directly; production output is static `dist/`; there is no custom server bundle command.
- No import consumers remain for generic HTTP client, in-memory analytics or in-memory sync queue; the files are removed.
- No skeleton mesh construction/material exists in active anatomy path; muscle surface and deep layer remain.
- Exercise catalog provenance and Open Food Facts source tests continue to pass.
- Existing rendering/physics/review tests are rerun. Build/lint/WebGL checks are reported exactly as run and are not inferred.

## External validation gates

A physical GPU/browser runner is still required for shader compile, 360-degree screenshots and GPU timing. This environment's inability to create WebGL2 context cannot be converted into an approval. Continuous spectrum/CIE weighting and full irradiance-space BSSRDF remain future measured improvements, not acceptance criteria for this focused V11.23 closure.

## API surface audit discovered during implementation

The `@google/genai` SDK and `GEMINI_API_KEY` template were inert: no code imports the SDK or makes Gemini requests. The Open Food Facts URL builder was also unconsumed; keep only the local catalog records with their source provenance/`label_partial` status. This product release has no live Open Food Facts network client.
