# TITAN V11.7 — React and Runtime Hardening Design

## Intent
Harden the existing React 19 + Vite application after a senior review, without replacing its architecture or removing V11.6 features. Priorities are correct local-date behavior, durable local session data, lazy loading the heavy 3D renderer, modal accessibility, reliable workout logging, and a deployable Node server entrypoint.

## Goals
- Derive the current day from the user's local clock; reject malformed calendar dates instead of silently converting them to a hardcoded day. Derive the calendar lower bound and marked days from actual evolution, meal and hydration records.
- Persist hydration records and training progress locally, using the existing safe storage abstraction and validating restored snapshots against current seed contracts. Validate same-version restored profile, nutrition and evolution state as untrusted input.
- Ensure a modal has an accessible name, initial focus, focus containment, Escape close, focus restoration, and scroll lock.
- Keep Three.js renderer code out of the initial module graph and safely handle asynchronous loading/unmount.
- Reject a set submission when the requested set ID does not belong to the selected exercise.
- Make production `start` execute compiled JavaScript rather than a raw TypeScript file.
- Keep all existing nutrition/TBCA, exercise catalog, anatomy IDs and workout slugs compatible.

## Non-goals
- No new runtime framework or state-management dependency.
- No cloud synchronization or claim of cross-device backup.
- No redesign or large-scale domain reorganization.
- No change to medical/nutrition calculations or the 14 canonical muscle groups.

## Approaches considered
1. Replace Zustand with Redux Toolkit / XState: rejected; the current stores are adequate and migration risk is not justified.
2. Add a server-backed persistence layer: rejected for this release; the app's current deployment has no configured database or account model.
3. Harden current Zustand/React architecture: selected. Use existing Zustand persist middleware, the safe local storage adapter, focused validation/normalization, dynamic import and native DOM focus handling. This preserves the project's low-dependency design.

## Constraints and assumptions
- Local persistence remains browser/device-local and can still be cleared by the browser or user.
- The app must remain usable if browser storage is disabled; in-memory fallback is best-effort for the current session.
- Persisted training plans are reconciled against current canonical seed IDs; unknown exercises/sets are ignored rather than injected.
- Heavy external research credits are unavailable in this session; use GitHub's repository/API sources and official React documentation, and disclose the search limitation.

## Acceptance
- Date helpers pass deterministic tests including leap years, month/year rollover, malformed dates and invalid leap days.
- Persisted hydration/training/profile/nutrition/evolution snapshots discard malformed data and retain valid user progress.
- The monthly calendar permits navigation to the earliest actual record and marks evolution measurements.
- A set ID not found under the submitted exercise returns a clear failure without mutating state or starting rest.
- Three.js renderer is imported asynchronously; late import cannot mount after unmount and failures select 2D fallback.
- BottomSheet focus and scroll handling are cleaned up on close/unmount.
- `npm start` points to compiled `server.js`; build script produces it after the Vite build.
- All available static/domain tests pass; missing dependency/browser-based checks are explicitly reported.
