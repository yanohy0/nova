# V11.33 — USDA Ingestion and Coverage Integrity

## Intent

Make official FoodData Central releases reproducibly retrievable and safely importable, and ensure nutrition coverage audits include all three active source catalogs (TBCA, Open Food Facts and USDA FDC).

## Why

V11.32 has a strict offline JSON importer, but the real official archives were not downloaded or imported. It requires the user to unzip data manually. The coverage audit also currently aggregates TBCA and Open Food Facts only, so it would omit USDA even after a real import. CI uses a floating `bun-version: latest` and does not expose nutrition/import gates as distinct steps.

## Goals

- Pin the exact official FDC releases for Foundation Foods (2026-10-29), SR Legacy (2018-04) and FNDDS 2021–2023 (2024-10-31).
- Add a bounded official-download command with redirect/host verification, maximum bytes, SHA-256 output and atomic file promotion.
- Accept either raw JSON or an official ZIP in the existing offline importer.
- Extract one unambiguous JSON entry in memory; reject path traversal, encryption, multi-disk/ZIP64/unsupported compression, malformed central directory, excessive entry/size/ratio and CRC mismatch.
- Keep the ZIP hash as the source dataset hash so archive provenance remains stable.
- Include the generated USDA catalog in nutrition coverage audit output and retain per-source counts/coverage.
- Pin Bun 1.4.5 in CI and add explicit calculation typecheck, nutrition hardening and USDA importer steps.
- No new runtime dependencies and no synthetic source nutrient values.

## Non-goals

- Import a proprietary or non-redistributable activity MET table.
- Claim the USDA archive was imported unless a real download and full-corpus run succeeds.
- Implement TBCA↔FDC fuzzy matching, DIAAS datasets, retention tables, multiday optimizer or browser tests in this patch.
- Bundle Branded Foods (3 GB uncompressed) or exceed bounded archive/JSON limits.

## Approaches

1. Keep manual unzip and only document a command — rejected because it leaves an error-prone manual step and does not guard archive extraction.
2. Add a third-party ZIP library — rejected because it adds a dependency to a simple, single-file ingestion path.
3. Use a narrow Node built-in ZIP reader for one JSON payload plus an allowlisted downloader — selected because the currently supported FDC releases are single-source archives and the ZIP contract can be validated with deterministic tests.

## Architecture decisions

- The downloader exposes only the three exact official FDC archive URLs and redirects must remain on the official FDC host.
- Archive extraction is in-memory and never writes ZIP paths to disk, eliminating ZIP-slip filesystem extraction.
- The importer remains the only catalog promotion path; audit sidecar is written before generated catalog replacement.
- Existing `parseUsdaFdcFoods` exact nutrient mapping and quarantine behavior remain authoritative.
- The coverage audit includes all source catalog arrays without object-key overwrites.
- CI uses a pinned Bun version and reports key nutrition gates separately while preserving full test/build steps.

## Acceptance

- Unit tests cover valid stored/deflated ZIPs, CRC failures, path traversal, duplicate JSON candidates, encrypted flags, ZIP64/multi-disk, truncated records and decompression limits.
- Downloader tests cover successful pinned source, HTTP failure, host/redirect mismatch, content-length and streaming-size limits, and atomic output behavior.
- Import CLI tests prove the ZIP source SHA-256 is recorded and invalid archives do not replace the old generated catalog.
- Coverage tests prove USDA counts and values appear in the same audit report, without converting missing values to zero.
- `npm run test:review`, `npm run test:nutrition-hardening`, `npm run typecheck:calculations`, ZIP-specific tests, CLI tests and `git diff --check` pass.
- Full install/build/browser/runtime WASM and real dataset import are reported separately if not executable in the current environment.
