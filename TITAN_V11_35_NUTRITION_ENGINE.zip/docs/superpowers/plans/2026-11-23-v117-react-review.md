# TITAN V11.7 React Review and Hardening Implementation Plan

> **For agentic workers:** Execute inline. Keep the existing architecture and verify each change with focused tests before implementation.

**Goal:** Fix the concrete runtime, persistence, accessibility, performance and validation defects found in V11.6 without regressions.

**Architecture:** Keep React 19, Vite, Zustand and existing domain contracts. Add narrow pure helpers for local dates and persisted-state normalization, reuse the safe storage adapter, load Three.js lazily, and compile the Node server entrypoint for production.

**Tech Stack:** React 19, TypeScript, Zustand 5, Zod 4, Vite 8, esbuild, Node 22.

**Spec:** `docs/superpowers/specs/2026-11-23-react-architecture-hardening.md`

## Global Constraints
- Preserve all existing domain boundaries and public contracts.
- Preserve V11.6 nutrition/TBCA data, exercise slugs and 14 canonical muscle groups.
- Add no new runtime dependencies.
- Keep persisted data local-only and validate untrusted stored payloads.

## Review Focus
- Date changes across midnight, daylight-saving boundaries, leap days and year rollover.
- Corrupt, partial or stale localStorage state and browser storage denial.
- Persisted training progress after workout seeds evolve.
- Modal opened while focus is inside another control and modal unmounted while open.
- 3D renderer import resolves after viewport unmount or fails on unsupported browsers.

---

### Task 1: Local date correctness
- Add deterministic tests for local date parsing/formatting and current-day descriptors.
- Replace fixed app date literals with local-date helpers; reject invalid calendar values in calendar and nutrition state.

### Task 2: Reliable local persistence
- Fix memory fallback reads and deletion tombstones in `safeStorageAdapter`.
- Persist hydration and training state with versioned keys, safe storage and strict normalization against current seed contracts.
- Validate same-version profile, nutrition and evolution snapshots during `merge`, not only migrations.
- Test malformed and partially valid snapshots.

### Task 3: Workout action integrity
- Add a test for a nonexistent set ID under a valid exercise.
- Reject unknown or already completed sets before changing training state or starting a rest timer.

### Task 4: React accessibility and startup performance
- Derive the calendar earliest selectable day and marked dates from real history.
- Add modal focus containment, return focus, accessible labelling and body-scroll cleanup.
- Enable StrictMode after validating cleanup behavior.
- Move the Three.js renderer to an asynchronous import with cancellation and fallback handling.

### Task 5: Production server entrypoint
- Build `server.ts` to root `server.js` with esbuild after Vite build.
- Point `start` to compiled JavaScript and preserve `dist` resolution.

### Task 6: Verification and review
- Run all available scripts and syntax/type transpilation checks.
- Perform a separate self-review because no independent reviewer agent is available in this execution environment.
- Package a new version and verify the ZIP archive.
