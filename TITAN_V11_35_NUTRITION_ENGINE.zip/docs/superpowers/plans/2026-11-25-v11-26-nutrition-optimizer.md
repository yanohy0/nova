# V11.26 Nutrition Optimizer Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans task-by-task. Each task uses TDD and the whole branch receives a final review.

**Goal:** Make the daily meal optimizer consider all DRI micronutrient targets when complete data exists, while preserving correct unknown-data semantics and hard upper limits.

**Architecture:** Resolve DRI targets in the nutrition domain, prepare per-nutrient coefficients and data-coverage diagnostics in the composer QP model, then consume the same model in HiGHS and the TypeScript fallback. Display applied/skipped constraint status in the optimization result.

**Tech Stack:** Existing TypeScript, Node 22, React, Zustand, HiGHS WASM. No new runtime dependency.

**Spec:** `docs/superpowers/specs/2026-11-25-nutrition-optimizer-completeness-design.md`

## Global Constraints

- Never map missing, trace, or not-analyzed micronutrient values to zero.
- Apply full-day DRI constraints only for day-scope optimization.
- RDA/AI are soft lower targets; CDRR is a soft preferred ceiling; UL alone is a hard upper constraint.
- Only apply a nutrient if all positive-quantity ingredients are quantified for that nutrient.
- Preserve locked ingredients and proportional recipe rules.
- Keep existing public APIs and stored nutrition plans backward compatible.

## Review Focus

- One or more items have a missing/trace/not-analyzed nutrient record.
- Locked/fixed ingredients already exceed an UL.
- The nutrient has a CDRR but no UL.
- The user requests a single-slot optimization with a daily DRI target.
- The HiGHS model is infeasible or the fallback projection does not converge.

---

### Task 1: DRI-derived targets and complete-coverage QP model

**Files:**
- Modify: `src/domains/nutrition/domain/entities/nutrient.ts`
- Modify: `src/domains/nutrition/domain/rules/nutrition-calculator.ts`
- Modify: `src/domains/nutrition/domain/rules/cardapio-composer-engine.ts`
- Create: `src/domains/nutrition/domain/rules/__tests__/micronutrient-optimizer.test.mjs`

**Interfaces:**
- `buildDailyMicronutrientTargets(profileId)` returns normalized daily targets with min, CDRR, UL and units.
- `OptimizeBalanceOptions.micronutrientTargets` accepts those targets.
- `PreparedQPModel.micronutrientConstraints` reports nutrient coefficients, fixed totals, target bounds, and coverage status.

- [ ] Write tests for DRI mapping, complete vs incomplete nutrient coverage, and single-slot scope.
- [ ] Run new tests and verify expected RED.
- [ ] Implement DRI mapping and per-nutrient coverage-aware coefficients.
- [ ] Verify missing/trace/not-analyzed values exclude that nutrient without zero-filling.

### Task 2: HiGHS and TypeScript solver integration

**Files:**
- Modify: `src/domains/nutrition/application/highs-nutrition-solver.ts`
- Modify: `src/domains/nutrition/domain/rules/cardapio-composer-engine.ts`
- Modify: `src/domains/nutrition/components/cardapio-composer/__tests__/highs-solver.test.ts`
- Modify: `src/domains/nutrition/components/cardapio-composer/__tests__/composition-preview.test.ts`

- [ ] Test that HiGHS LP contains soft DRI slacks and actual UL inequalities.
- [ ] Test that fallback uses one-sided nutrient penalties and respects feasible UL projections.
- [ ] Implement solver integration; downgrade results when the UL projection is infeasible or not converged.
- [ ] Verify lock preservation and macro regression tests.

### Task 3: Wire active DRI profile and display diagnostics

**Files:**
- Modify: `src/domains/nutrition/components/cardapio-composer/CardapioComposer.tsx`
- Modify: `src/domains/nutrition/domain/entities/nutrient.ts`
- Modify: `src/domains/nutrition/components/cardapio-composer/variants/OptimizationPreview.tsx`

- [ ] Read `referenceProfileId` and pass DRI targets to day-scope optimization.
- [ ] Do not apply daily DRI targets in slot-scope optimization.
- [ ] Display applied/skipped counts and nutrient before/after vs RDA/AI, CDRR and UL.
- [ ] Keep insufficient-data states explicit and avoid false 0%/100% claims.

### Task 4: Research ledger, regression, verification and package

**Files:**
- Modify: `package.json`
- Modify: `README.md`
- Create: `CHANGELOG_V11_26.md`
- Create: `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_26.md`
- Modify: `.superpowers/sdd/2026-11-25-v11-26-nutrition-closure/progress.md`

- [ ] Run focused new tests and full `npm run test:review`.
- [ ] Run strict calculation typecheck and available build/lint checks.
- [ ] Review all diffs for false nutrient zeros, double-counting, hard-limit bypass and persistence compatibility.
- [ ] Record any unavailable validation gates honestly.
- [ ] Package ZIP, run `unzip -t`, list contents and compute SHA-256.
