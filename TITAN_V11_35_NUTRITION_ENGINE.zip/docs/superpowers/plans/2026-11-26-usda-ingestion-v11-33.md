# V11.33 USDA Ingestion Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans. Steps use checkbox (`- [x]`) syntax for completed tracking.

**Goal:** Make official USDA FDC releases safe to download/import directly from ZIP and make source coverage reports include the USDA catalog.

**Architecture:** A small Node ESM downloader and ZIP reader use built-in APIs only. The existing parser remains responsible for nutrient identity and source promotion. The coverage audit combines all canonical catalogs and CI exposes the nutrition gates explicitly.

**Tech Stack:** Node.js 22 built-ins (`fetch`, `node:crypto`, `node:zlib`, `node:fs`), TypeScript nutrition domain, Bun 1.4.5 CI.

**Spec:** `docs/superpowers/specs/2026-11-26-usda-ingestion-pipeline-v11-33.md`

## Global Constraints
- No new runtime dependency.
- Only exact official FDC URLs for Foundation 2026-10-29, SR Legacy 2018-04, and FNDDS 2024-10-31 are downloadable.
- ZIP data never writes archive paths to disk.
- No ZIP64, encryption, multidisk, unsupported compression, traversal, oversized archive, oversized JSON or CRC mismatch.
- Catalog activation only after validation and audit sidecar creation.
- Do not mark USDA coverage as populated until a real release is imported.

## Review Focus
- EOCD/central directory offsets, ZIP comments, duplicate or ambiguous JSON entries, flags, sizes and CRC.
- ZIP bomb/ratio and decompression output limits.
- Download redirects, hostname suffix spoofing, content-length lies, stream limits and partial files.
- Existing catalog preservation on failure and archive hash provenance.
- Coverage union: same food IDs from distinct source namespaces must not overwrite each other.

---

### Task 1: Safe ZIP extraction (TDD)

**Files:**
- Create `scripts/lib/usda-fdc-archive.mjs`
- Create `scripts/__tests__/usda-fdc-archive.test.mjs`

- [x] Test valid stored and deflated JSON archive.
- [x] Test path traversal, encrypted flags, ambiguous JSON entries, ZIP64/multi-disk, corrupt CRC, truncated entries, unsupported method and output limits.
- [x] Run ZIP tests and observe expected failure.
- [x] Implement central-directory reader, bounded inflate and CRC32 verification.
- [x] Run ZIP tests and verify pass.

### Task 2: Pinned USDA downloader + importer ZIP support (TDD)

**Files:**
- Create `scripts/lib/usda-fdc-download.mjs`
- Create `scripts/download-usda-fdc.mjs`
- Create `scripts/__tests__/download-usda-fdc.test.mjs`
- Modify `scripts/import-usda-fdc.mjs`
- Modify `scripts/__tests__/import-usda-fdc.test.mjs`
- Modify `package.json`, `.gitignore`

- [x] Test pinned type/release URL, redirects/host spoofing, HTTP errors, content-length and streaming limits, deterministic hash.
- [x] Test bounded streaming JSON/ZIP input, immutable audit sidecars and rejection of real-path escape through symlinks.
- [x] Run tests and observe expected failure.
- [x] Implement bounded streaming download and atomic archive save.
- [x] Accept `.zip` as importer input via the safe ZIP reader; retain archive SHA-256 in manifest.
- [x] Prove bad ZIP/JSON does not overwrite current generated catalog.
- [x] Run downloader and importer tests.

### Task 3: USDA-aware coverage audit (TDD)

**Files:**
- Create `scripts/lib/nutrition-coverage-catalog.mjs`
- Create `scripts/__tests__/nutrition-coverage-catalog.test.mjs`
- Modify `scripts/audit-nutrition-data-coverage.mjs`

- [x] Test catalog merge keeps TBCA, OFF and USDA as separate source records.
- [x] Run test and observe expected failure.
- [x] Add generated USDA catalog and source manifest to coverage audit.
- [x] Keep missing/trace/incompatible values as non-quantified; write a new V11.33 coverage artifact path.
- [x] Run audit test and coverage CLI; record current USDA count honestly.

### Task 4: Release CI gates + research/docs

**Files:**
- Modify `.github/workflows/quality.yml`
- Modify `README.md`, `package.json`, `CHANGELOG_V11_33.md`
- Create `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_33.md`
- Modify `docs/quality/NUTRITION_ENGINE_V11_32_REMAINING_GAPS.md`

- [x] Pin Bun 1.4.5 and add explicit calculation typecheck, nutrition hardening and USDA CLI gate steps.
- [x] Add ZIP/downloader tests to nutrition hardening.
- [x] Record repository choices, licensing and why Compendium 2024 is not copied/bundled.
- [x] Run full review suite, dedicated tests, calculation typecheck, energy boundaries, adaptive simulation and syntax checks.
- [x] Attempt build/lint only where dependencies are available; report actual blockers.
- [x] Commit implementation; release archive verification is recorded in V11.33 verification report after packaging.
