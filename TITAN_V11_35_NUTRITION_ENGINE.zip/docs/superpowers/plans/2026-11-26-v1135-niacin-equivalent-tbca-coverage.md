# V11.35 Niacin Equivalent & TBCA Coverage Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Compute USDA niacin equivalents only from exact, complete source components and report TBCA micronutrient coverage separately for recipe-eligible foods and composite preparations.

**Architecture:** Keep the USDA FDC adapter as the strict source boundary. Add typed source/derivation evidence to nutrient records; use exact nutrient-ID/number/name/unit contracts and deterministic priority rules, revalidated at runtime. Extend the existing pure coverage rule with a TBCA-only food-type breakdown, leaving the global/source totals intact.

**Tech Stack:** TypeScript strict, Node native TypeScript stripping for tests, existing adapter and domain rule tests, JSON report generation. No new runtime dependencies.

**Spec:** `docs/superpowers/specs/2026-11-26-usda-niacin-equivalent-and-tbca-coverage-design.md`

## Global Constraints

- No nutrient missingness may be converted into zero.
- No fuzzy ID/name/unit matching is permitted in the import adapter.
- B3 unit remains `mg NE` per 100 g.
- The 406/407/409/501 paths are mutually exclusive in the tryptophan contribution.
- No estimated tryptophan from protein is introduced.
- TBCA `PREPARACAO_COMPOSTA` remains excluded from ingredient matching.
- No TBCA 7.3 dataset is imported or redistributed without explicit permission.
- No new runtime dependencies.

## Review Focus

- FDC has N406 alone and no tryptophan-derived component: B3 must remain unquantified.
- FDC contains N407 and N501 simultaneously: never add both tryptophan contributions.
- Direct N409 coexists with component rows: direct total wins and remains labeled as direct source data.
- Any mismatched unit, permanent ID, number, name, duplicate or negative/non-finite amount: no invalid component can enter B3.
- TBCA data with missing/unrecognized `food_type`: counted only in TBCA `UNKNOWN`, never promoted to recipe-eligible.

---

### Task 1: Add exact niacin-equivalent regression tests

**Files:**
- Modify: `src/domains/nutrition/data/sources/__tests__/usda-fdc-adapter.test.mjs`
- Read: `src/domains/nutrition/data/sources/usda-fdc-adapter.ts`

**Interfaces:**
- Consumes: existing `parseUsdaFdcFoods`, `registerUsdaFdcFoods`.
- Produces: no production API change before RED.

- [x] Add fixtures for 409 direct; 406 + 407; and 406 + 501.
- [x] Assert `5 mg + 0.6 g tryptophan` returns `15 mg NE/100 g`, the correct conversion method, and raw component evidence.
- [x] Assert direct 409 is preferred, carries source identity evidence, and 406 + 407 is not double-counted with 501.
- [x] Assert niacin-only and tryptophan-only records produce no quantified B3 and are quarantined semantically.
- [x] Add wrong-ID, wrong-number, wrong-name, wrong-unit, invalid amount, overflow arithmetic, and conflicting duplicate cases (including permanent-ID mismatch for direct 409 and bypass with a generic conversion method).
- [x] Add a regression proving overflow in priority path 406+407 cannot be hidden by fallback to 406+501 (observed RED, then GREEN).
- [x] Run the adapter test and verify RED before implementation; the direct-409 evidence assertion failed because source identity was absent.

### Task 2: Implement source-auditable B3 derivation

**Files:**
- Modify: `src/domains/nutrition/domain/entities/nutrient.ts`
- Modify: `src/domains/nutrition/data/sources/usda-fdc-adapter.ts`
- Modify: `src/domains/nutrition/data/sources/__tests__/usda-fdc-adapter.test.mjs`

**Interfaces:**
- Add `FoodNutrientDerivationEvidence` with method `niacin_equivalent_1_to_60`, formula, reference URL and exact source components (`nutrientId`, nutrient number, name, amount, unit).
- Add optional derivation evidence to `FoodNutrientRecord` and its `FoodSourceItem.micronutrients` projection.
- Add conversion method `niacin_equivalent_from_components`.
- Internal helper reads exact FDC 406/407/409/501 rows and applies priority 409 > 406+407 > 406+501.

- [x] Implement only the minimal code needed to make Task 1 tests pass.
- [x] Keep B3 absent if required components cannot be established; quarantine component rows instead of manufacturing `0`.
- [x] Ensure 407 and 501 are alternatives, never additive.
- [x] Extend `isValidRegisteredUsdaFood` to validate derivation arithmetic and direct-409 source identity; reject malformed/forged evidence, generic `mg NE` conversions and non-finite outputs before registry mutation.
- [x] Re-run the targeted adapter test; full hardening is included in the final verification gate.

### Task 3: Stratify coverage by TBCA food type

**Files:**
- Modify: `src/domains/nutrition/domain/rules/nutrition-data-coverage.ts`
- Modify: `src/domains/nutrition/domain/rules/__tests__/nutrition-data-coverage.test.mjs`
- Inspect/modify if needed: `scripts/lib/nutrition-coverage-catalog.mjs`
- Modify: `scripts/audit-nutrition-data-coverage.mjs`

**Interfaces:**
- Extend `NutritionDataCoverageEntry` with TBCA-only `byTbcaFoodType` summaries: `ALIMENTO`, `PREPARACAO_COMPOSTA`, `UNKNOWN`.
- Input accepts optional `food_type`.
- Records from OFF, USDA or TITAN_LEGACY do not increment TBCA `UNKNOWN`.

- [x] Add tests proving TBCA types reconcile to TBCA totals, and non-TBCA records are excluded from the TBCA breakdown.
- [x] Add test for TBCA missing/unknown type grouped under `UNKNOWN`.
- [x] Run the coverage test RED before implementation.
- [x] Implement the breakdown while leaving existing overall and by-source percentages unchanged.
- [x] Update the generated coverage JSON and summary audit with recipe-eligible vs composite counts.

### Task 4: Research, documentation, and release metadata

**Files:**
- Create: `CHANGELOG_V11_35.md`
- Create: `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_35.md`
- Create: `docs/quality/NUTRITION_ENGINE_V11_35_REMAINING_GAPS.md`
- Create: `docs/quality/NUTRITION_ENGINE_V11_35_VERIFICATION.md`
- Modify: `README.md`
- Modify: `package.json`
- Modify: `docs/research/NUTRIENT_COVERAGE_ALL_SOURCES_V11_35.json` via audit script

**Interfaces:**
- Version: `11.35.0`.
- Research report includes exact star counts/licences, links and relevance; star counts are dated 2026-11-26.
- Verification distinguishes passing checks from commands blocked by missing toolchain/data.

- [x] Document scientific formula/limits and the source dictionaries.
- [x] Record current TBCA 7.2 local version and the external 7.3 licensing/permission boundary.
- [x] Document no real USDA corpus was imported in this environment; synthetic tests prove parser behavior only.
- [x] Update package version and README.

### Task 5: Final adversarial review and verification

**Files:**
- Review: all changes from Tasks 1–4.

- [x] Inspect nutrient conversion references, serializer/validator call sites and runtime evidence gates; add regression for generic conversion bypass and arithmetic overflow.
- [x] Run `npm run test:review` after final code changes (final release gate will be rerun).
- [x] Run `npm run test:nutrition-hardening` after final code changes (final release gate will be rerun).
- [x] Run `npm run test:nutrition-data-quality` after final code changes (final release gate will be rerun).
- [x] Run `npm run typecheck:calculations` after final code changes (final release gate will be rerun).
- [x] Run TBCA ingredient and recipe catalog audits; final release gate will be rerun.
- [x] Run `npm run audit:nutrition-coverage`; final release gate will be rerun after the research update.
- [x] Run USDA archive/import synthetic tests; final release gate will be rerun.
- [x] Attempt `npm run lint`, `npm run build` and `npm test`; record their dependency/toolchain blocks (not green).
- [x] Confirm V11.34 ingredient policy/tests remain intact and all six invalid composite recipe models remain blocked.
- [x] Commit the branch, archive the exact committed tree, run `unzip -t`, extract the ZIP into an empty smoke directory and repeat the critical tests there.
