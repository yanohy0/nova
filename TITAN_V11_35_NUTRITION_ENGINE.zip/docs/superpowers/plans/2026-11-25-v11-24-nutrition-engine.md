# V11.24 — Plano de execução do motor nutricional

## Objetivo

Fechar lacunas concretas da V11.23 sem introduzir nova infraestrutura. Prioridades: distribuição de kcal por refeição e escala proporcional de ingredientes; integridade dos dados nutricionais; elegibilidade de RMR; gates do otimizador; atualização adaptativa de TDEE.

## Decisões

- Manter Vite/React/TypeScript/Zustand e o HiGHS atual.
- Separar escala proporcional de otimização QP/MILP. O primeiro aplica um fator comum; o segundo pode mudar quantidades de ingredientes individualmente.
- Não auto-aplicar mudanças quando uma meta muda; a ação é explícita e reversível.
- Alimentos travados são invariantes. Dados ausentes não são inventados. Alimentos com composição incompleta tornam o resultado aproximado.
- Manter as 23 entradas de micronutrientes, com status por nutriente e valores nulos quando não quantificados.
- Não inferir jejum de ausência de registro.
- Não adicionar código ou dependências dos repositórios pesquisados; observar licenças GPL/AGPL e NOASSERTION.

## Tarefas

1. Testar RED e implementar escala proporcional de dia/slot por alvo de kcal.
2. Integrar a operação ao composer e ao snapshot de desfazer; estabelecer a composição atual como base proporcional para mudanças futuras de rendimento.
3. Testar ingredientes travados, limites de rendimento, massa, alimentos não resolvidos e alocação incompleta.
4. Expandir a agregação do composer para os 23 micronutrientes e status de dados.
5. Impedir certificação ótima quando composição/quantidade estiver incompleta ou baixa confiança.
6. Ignorar metas P/C/G por refeição até cada distribuição fechar 100%.
7. Centralizar seleção automática de RMR e preservar escolhas manuais/legadas.
8. Separar AI de 1.500 mg e CDRR de 2.300 mg para sódio; não tratar AI como UL ou diagnóstico.
9. Agregar fibra, gordura saturada e colesterol quando a fonte disponibilizar os campos.
10. Remover dependência do modal de metas para calcular TDEE adaptativo.
11. Atualizar changelog, pesquisa, testes, versão e ledger Superpowers.


## Gates

- Todos os fatores de escala de ingredientes desbloqueados dentro da mesma refeição devem ser iguais antes do arredondamento de 0,5 g.
- Ingredientes travados devem manter quantidade idêntica.
- A soma das metas por refeição deve fechar 100% antes da aplicação.
- Dados ausentes não podem se tornar zero nem gerar certificação `optimal`.
- Distribuições parciais de P/C/G não podem criar metas de refeição conflitantes.
- RMR manual deve continuar funcionando; automático deve recalcular quando não houver método manual persistido.
- AI de sódio não pode ser tratada como UL; o CDRR deve permanecer separado e não pode ser codificado em `upperLimit`.
- Valores de fibra, gordura saturada e colesterol permanecem nulos quando não há dados da fonte.
- Nenhuma dependência de runtime nova.
