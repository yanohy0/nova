# TITAN V11.22 Rendering Closure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Improve pressure convergence, temporal arc stability and skin diffusion in the existing V11.21 renderer, while documenting asset/physical/GPU gaps honestly.

**Architecture:** Retain the current Three.js/WebGL2 architecture. Replace the pressure Jacobi iteration with incomplete-Cholesky zero-fill preconditioned conjugate gradient (IC(0)-PCG) using caller-owned typed-array buffers, anchor lightning branch IDs to spatial cells, and extend the compositor to a bounded three-radius depth-aware diffusion kernel.

**Tech Stack:** TypeScript, Node native type stripping, GLSL ES 3.00, existing Three.js/WebGL2.

**Spec:** `docs/superpowers/specs/2026-11-25-v11-22-rendering-closure-design.md`

## Global Constraints

- No new runtime dependencies.
- Preserve current public app/domain contracts and dual-body renderer.
- Keep pressure workspace arrays instance-owned; zero per-step allocations.
- Keep branch identity deterministic and independent of frame time.
- Keep skin diffusion bounded, depth-gated and alpha preserving.
- Preserve a single diffuse backdrop halo and no floor lighting.

## Review Focus

- Zero velocity and near-zero residual must not divide by zero in PCG.
- Boundary face pressure correction must match the forward-divergence/backward-gradient operator.
- PCG must stop on bounded iterations and never emit non-finite values.
- Branch topology must not move when time advances; only branch activity/curvature may animate.
- Skin diffusion must not bleed across depth discontinuities or contaminate holographic/non-skin contours.

---

### Task 1: PCG pressure projection

**Files:**
- Modify: `src/shared/graphics/fluid-pressure-projection.ts`
- Modify: `src/shared/graphics/hydration-fluid-solver.ts`
- Test: `src/shared/graphics/__tests__/fluid-pressure-projection.test.mjs`

- [x] Strengthen the existing deterministic test to require at least 90% divergence reduction and no more than 32 iterations; add zero-flow, finite-output, and boundary-face cases.
- [x] Run test and confirm it fails against V11.21 Jacobi implementation.
- [x] Implement IC(0)-preconditioned conjugate gradient for `A=-Laplacian`, with `pressureResidual`, `pressurePreconditioned`, `pressureDirection` and `pressureProduct` typed arrays in the existing `FluidVorticityGrid` instance.
- [x] Correct pressure gradient on every face used by interior divergence, including the right and bottom boundary faces.
- [x] Run focused pressure and V11.21 physics regressions.

### Task 2: Stable plasma branch identity

**Files:**
- Modify: `src/shared/graphics/fluid-shader-engine.ts`
- Create: `scripts/check-lightning-branch-stability-v11-22.mjs`
- Modify: `package.json`

- [x] Add a source-contract test proving `nodeId` is spatial-only and branch pulse is time-varying but node-seeded.
- [x] Run test and confirm failure on V11.21 time-dependent `nodePhase`.
- [x] Change branch identity to `floor(pos3D.x * density)` and keep a stable local coordinate; use time only in the independent node cycle and smooth micro-bend.
- [x] Run source-contract and existing lightning waveform tests.

### Task 3: Three-radius depth-aware skin diffusion

**Files:**
- Modify: `src/domains/anatomy/engine/renderer/dual-body-compositor.ts`
- Modify: `scripts/check-skin-diffusion-v11-19.mjs`
- Modify: `package.json`

- [x] Update static shader contract to require center + near/mid/far lobes, four fixed directions, depth gate, channel ordering and bounded loops.
- [x] Run contract and confirm failure against the two-radius V11.21 shader.
- [x] Implement normalized three-radius weights at 0.9, 2.6 and 5.8 pixels with 4 cardinal directions; keep the hue gate and depth rejection.
- [x] Run the shader source contract and rendering-realism suite.

### Task 4: Research, gates, review and packaging

**Files:**
- Create: `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_22.md`
- Create: `docs/superpowers/specs/ASSET_AND_GPU_VALIDATION_GATES_V11_22.md`
- Create: `CHANGELOG_V11_22.md`
- Modify: `package.json`
- Create: `.superpowers/sdd/2026-11-25-v11-22-rendering-closure/progress.md`

- [x] Research five high-relevance GitHub repositories per remaining technical area; inspect source/README/license where possible, do not use Firecrawl, and do not copy unlicensed code/assets.
- [x] Inspect anatomy topology map and lighting rig; record only claims supported by current mesh and code.
- [x] Update package version to `11.22.0` and add focused scripts.
- [x] Run pressure, lightning, skin, V11.21 physics, rendering-realism, review and calculation typecheck tests.
- [x] Attempt full `npm test`, lint, build and GPU shader compilation; record exact blocker.
- [x] Perform a separate self-review (no subagent tool is available), create ZIP, verify CRC and SHA-256.
