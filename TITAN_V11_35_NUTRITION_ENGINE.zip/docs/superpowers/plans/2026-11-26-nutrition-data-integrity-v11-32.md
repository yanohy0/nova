# TITAN Nutrition Engine V11.32 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement the plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Harden the nutritional solver, daily supplement exposure, USDA import boundary, and training energy bridge without replacing existing engines.

**Architecture:** Add narrow domain/application adapters and preserve the existing TypeScript, Zustand, activity reconciliation and HiGHS components. Separate quantified observations from estimates and unknown data.

**Tech Stack:** TypeScript, Node 22 native test runner, existing Zustand/HiGHS/Zod dependencies; no new dependencies.

**Spec:** `docs/superpowers/specs/2026-11-26-nutrition-data-integrity-v11-32.md`

## Global Constraints
- No new runtime dependency.
- No values fabricated to fill missing nutrient data.
- No automatic session kcal estimate without a source-versioned MET selection.
- No source-specific UL applied to incompatible source totals.
- Do not claim real USDA coverage from synthetic fixtures.

## Review Focus
- Solver vectors with missing keys, malformed objects, NaN/Infinity and fractional binaries.
- Duplicate, invalid date, invalid units, chemical-form mismatch and unquantified supplement entries.
- A supplement-only or preformed-only UL shown against a food-only sum.
- A workout session with missing start, negative/too-long duration or no MET provenance.
- USDA rows containing a permanent-ID/legacy-number mismatch, unexpected name/unit, unknown nutrient, duplicate nutrient or missing food identity.

---

### Task 1: Solver primal validation
**Files:** Create `src/domains/nutrition/application/highs-solution-validation.ts`; modify `highs-nutrition-solver.ts`; create tests.
- [x] Write failing tests for complete QP extraction and binary one-hot selections.
- [x] Run tests and confirm missing/malformed primal values are the failure.
- [x] Implement strict extraction and fallback integration.
- [x] Run solver tests and existing composer solver tests.
- [x] Commit.

### Task 2: UL source-scope correctness and supplement ledger
**Files:** Create `src/domains/nutrition/domain/rules/supplement-intake.ts`; modify nutrition entity, persistence, store, nutrition calculator and tests.
- [x] Write failing tests for g/mg/µg conversion, forbidden equivalency, validation, scope-safe UL display and migration.
- [x] Run tests and confirm expected failures.
- [x] Implement immutable supplement event records and aggregation.
- [x] Persist and validate records in Zustand state; preserve backup storage key.
- [x] Keep food-only totals separate; suppress incompatible UL comparisons.
- [x] Run tests and commit.

### Task 3: USDA FoodData Central import boundary
**Files:** Create `src/domains/nutrition/data/sources/usda-fdc-adapter.ts` and tests; modify source id/lookup/coverage only as needed.
- [x] Write synthetic fixture tests for Foundation/SR Legacy/FNDDS record envelopes, exact mappings and quarantine.
- [x] Run tests and confirm expected failure.
- [x] Implement strict mapper with source datatype/version/fdcId and unmapped audit.
- [x] Map supported optional composition fields (fiber, saturated fat, cholesterol and sodium) only with exact permanent ID + legacy number + name + unit contracts.
- [x] Reject all records that share a duplicated FDC food ID; never select one copy by array order.
- [x] Do not bundle or fabricate source data; generate a content-addressed audit manifest and document archive download/activation requirements.
- [x] Run data-quality and provenance tests; commit after final release verification.

### Task 4: Training session to activity-energy bridge
**Files:** Create `src/domains/training/application/workout-activity-energy.ts` and tests; extend activity origin if needed.
- [x] Write failing tests for required source/versioned MET entry, explicit weight, session interval and estimate quality.
- [x] Run tests and confirm failures.
- [x] Implement bridge using the existing `estimateActivityEnergy` and `reconcileActivityEnergyRecords` contract.
- [x] Ensure estimate remains an estimated active-energy record and is not added to daily TDEE without user action.
- [x] Run training/activity tests and commit after final release verification.

### Task 5: Technical research, docs, release verification
**Files:** Research brief, changelog, README, package version.
- [x] Record repository stars/license/purpose and technical choices.
- [x] Audit DRI age-profile overrides so a reference update cannot accidentally erase an inherited UL, scope, unit or source.
- [x] Run full `npm run test:review`, `npm run typecheck:calculations`, targeted tests, syntax checks; verify ZIP integrity after packaging.
- [x] Attempt build/lint and `npm test`; report dependency blockers.
- [x] Inspect final diff for type, licensing, provenance and scope regressions.
- [x] Commit release and create ZIP from committed tree; integrity, extraction and post-extraction tests verified.


## Evidence and intentionally open work

- [x] CLI audit sidecar is content-addressed and referenced by generated manifest; the catalog is the final publication pointer.
- [x] Duplicate nutrient rows are order-independent: exact duplicates collapse, conflicting values are quarantined, duplicate macro conflicts reject the food.
- [x] New USDA food registrations invalidate/rebuild the shared lookup index and notify subscribed UI consumers.
- [ ] Real October 2026 Foundation archive import and data-wide validation: blocked because the archive was not available locally during this run; synthetic fixtures are not substitutes.
- [ ] Full Vite build/lint/browser verification and live WASM test: blocked by missing install (`vite`, `vite/client`, `tsx`, and `highs` package/runtime).
