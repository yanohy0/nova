# TITAN V.MAX V11.3 — repository review and engineering decisions

Research snapshot: 22 November 2026. GitHub star counts are approximate snapshots; they change over time.

## Decisions applied in this release

### Exercise catalog and training-to-anatomy mapping

- **[yuhonas/free-exercise-db](https://github.com/yuhonas/free-exercise-db)** — approximately 2.1k stars; Unlicense. Seven exercise records were added using the repository's text-only records: Barbell Curl, Barbell Rear Delt Row, Barbell Shrug, Barbell Hip Thrust, Lying Leg Curls, Single-Leg Leg Extension, and Barbell Seated Calf Raise. The source record URL and Git blob SHA are stored with every imported item. The app does not bundle the repository's images or GIFs.
- The imported exercise groups are normalized to the existing 14 TITAN training IDs. A source label is not forced into a misleading muscle ID: the rear-delt row is identified as posterior deltoid because its exercise name and instruction explicitly name the rear delts; unrepresented generic "middle back" is not fabricated as a TITAN muscle.
- Workout seeds now resolve exercise name, equipment and muscle highlights from one canonical catalog. Set IDs, weights, reps, completion flags, plan status, and rest targets are retained.
- Search now folds Portuguese accents and finds movement pattern, equipment, cue, name/slug, and primary or secondary muscle labels.

## Candidates compared for the body and mobile renderer

| Repository | Approx. stars | License | Decision |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k+ | MIT | Keep. It is already the renderer; replacing it would add migration risk without improving the current model automatically. |
| [zeux/meshoptimizer](https://github.com/zeux/meshoptimizer) | 8.9k | MIT | Best future offline glTF optimization candidate. Not added as a runtime dependency because V11.3 ships procedural geometry, not a GLB asset. |
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | 4.6k | MIT code; BodyParts3D geometry CC BY 4.0 | Best inspected anatomy reference/candidate for future muscle mesh import. Not bundled: the published viewer is an adult male reference with roughly 2.29m triangles / ~33 MB compressed geometry and requires CC BY attribution. The current package does not contain the geometry payload or per-structure assets required for a safe, tested selective import. |
| [gkjohnson/three-mesh-bvh](https://github.com/gkjohnson/three-mesh-bvh) | 3.6k | MIT | Defer. Current picking is based on one merged muscle batch with semantic attributes; no measured picking bottleneck justifies BVH maintenance, especially for any future deforming geometry. |
| [yuhonas/free-exercise-db](https://github.com/yuhonas/free-exercise-db) | ~2.1k | Unlicense | Adopt text metadata only, excluding images/media. |
| [donmccurdy/glTF-Transform](https://github.com/donmccurdy/glTF-Transform) | ~2.1k | MIT | Future GLB build pipeline candidate, not applicable to the current procedural mesh without an asset export stage. |
| [FarazzShaikh/THREE-CustomShaderMaterial](https://github.com/FarazzShaikh/THREE-CustomShaderMaterial) | ~1.3k | MIT | Reference only. Existing material patching already uses explicit, fail-fast Three.js shader chunks; another abstraction would duplicate the current path. |
| [NVlabs/SOMA-X](https://github.com/NVLabs/SOMA-X) | ~900 | Apache-2.0 source code; model files have a separate asset audit | Best future parametric full-body skin pipeline candidate. It is a Python/PyTorch/Warp toolchain, not a mobile renderer, and its skin surface does not provide the app's separate fitness muscle groups. Not integrated into the runtime. |
| [facebookresearch/MHR](https://github.com/facebookresearch/MHR) | ~900 | Apache-2.0 source code; model assets need separate review | Useful comparator for body identity and GLB export. Export omits its pose-corrective network, so it is not a drop-in high-fidelity animated asset pipeline. Not integrated. |
| [ektogamat/threejs-holographic-material](https://github.com/ektogamat/threejs-holographic-material) | ~250 | MIT | Shader reference only. Keep TITAN's one-pass Fresnel/scanline/sweep implementation rather than add an overlapping runtime material dependency. |

## V11.3 scope and explicit limits

- The complete head and body silhouette remain intact.
- The application continues to expose exactly 14 stable exercise muscle groups; it does not become a catalog of organs or every anatomical muscle.
- Hologram remains a single-pass material effect. Selective bloom/DOF is not added because it would introduce extra render targets and unvalidated mobile GPU cost.
- The pseudo `morphFactor` displacement (a global 1.5 mm normal offset) was removed. It was not a genuine body-shape or hypertrophy model and had no meaningful user-facing control.
- The body surface remains the existing procedural model. This release does not claim photorealistic anatomical meshes, actual hypertrophy simulation, or device-verified 60 FPS.
- No new runtime dependency or external geometry asset is added in this release.

## Validation boundary

The pure Node/TypeScript-stripping contract and geometry scripts are run by `npm run test:anatomy`. A full Vite build, full TypeScript project check, browser shader compilation, and physical iOS/Android GPU/thermal profiling require installed dependencies and target devices; these are not inferred from static checks.
