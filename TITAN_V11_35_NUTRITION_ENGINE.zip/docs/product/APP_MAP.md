# Mapa de Telas e Rotas — TITAN

## Navegação Principal (5 destinos)
1. **Cockpit** (`cockpit`) — Visão central do dia com Corpo 3D protagonista.
2. **Cardápio** (`cardapio`) — Plano diário de refeições, calorias e macros.
3. **Ação** (`ActionSheet`) — Menu contextual rápido (água, treino ativo, biblioteca, medidas).
4. **Treino** (`treino`) — Divisões, seleção de programa e histórico de séries.
5. **Evol.** (`evolucao`) — Registros diretos de peso e medidas corporais.

## Subtelas Internas
- `active-workout` — Execução de sessão com editor de séries e cronômetro de descanso em tempo real.
- `exercise-library` — Pesquisa de exercícios com destaque muscular primário e secundário no 3D.
