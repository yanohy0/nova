# V11.14 — implementação e backlog do motor de cálculos

## Implementado nesta revisão

- Testes de regressão cobrem os oito ramos adultos NASEM 2023 (quatro categorias × duas equações de sexo).
- A referência de magnésio agora diferencia adultos de 19–30 e 31–50 anos; os IDs legados continuam hidratando.
- O TDEE adaptativo usa média aritmética dos dias completos e únicos; duplicatas do mesmo dia são deduplicadas por mediana; resultados implausíveis são rejeitados, não truncados.
- RFM, já existente na base, passou a respeitar a faixa adulta quando a idade está disponível; valores antropométricos históricos inválidos não derrubam a tela Evolução.
- O registro de treino passou a aceitar RIR 0–5, gravar no estado e no histórico imutável, restaurar por persistência e limpar o RIR ao iniciar um novo ciclo.
- O 1RM distingue esforço informado de presunção de falha; sem RIR, a saída continua disponível por compatibilidade, mas é explicitamente marcada como esforço não verificado.
- A calculadora de hidratação por taxa de suor já existia na base V11.12; foi auditada e mantida com seus testes, sem alegar que foi criada nesta revisão.
- Testes documentam equações, persistência, valores ausentes e limites.

## Próximas prioridades

| Ordem | Trabalho | Critério de aceite |
|---:|---|---|
| 1 | Modelo dinâmico Hall/NIDDK para projeção de peso | Reproduzir curvas publicadas/casos de referência; documentar população e adaptação; comparar previsão com série observada sem substituir o motor atual antes da validação |
| 2 | Perfil de atividade e medição de energia | Equação selecionada por atividade observável ou PAL medido; importar calorimetria/DLW com origem e data; evitar dupla contagem de exercício |
| 3 | Validação por subgrupo e incerteza | Relatório de erro/viés por sexo, idade, IMC, nível de atividade e experiência de treino; métricas MAE, RMSE, MAPE e cobertura |
| 4 | Macronutrientes por composição corporal e treinamento | FFM apenas quando proveniente de método identificado; distinguir população geral, atleta magro e contexto de déficit energético |
| 5 | Micronutrientes e qualidade alimentar | Metas por ciclo de vida validadas; ampliar dados K/B5/B7 com licenças e unidades; manter nulos quando não analisados |
| 6 | Velocidade de barra e carga autorregulada | Telemetria por dispositivo/exercício, perfil velocidade-carga, erro absoluto e acordo contra testes observados |

## Testes

O projeto inclui execução de teste unitário/contrato e checagens estáticas. Build, lint completo e E2E no navegador devem ser executados no ambiente com dependências instaladas; uma execução local apenas com testes de domínio não substitui essas verificações.
