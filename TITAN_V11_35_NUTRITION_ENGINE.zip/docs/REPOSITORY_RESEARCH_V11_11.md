# Repository research — V11.11

Snapshot checked 2026-11-23. GitHub stars are adoption signals, not quality guarantees; counts fluctuate. License and integration fit remain part of selection.

| Purpose | Leading candidates | Approx. stars | Decision |
|---|---|---:|---|
| Browser E2E | [microsoft/playwright](https://github.com/microsoft/playwright) | 100k | Preferred E2E framework; cross-browser, isolated contexts. |
| React component tests | [testing-library/react-testing-library](https://github.com/testing-library/react-testing-library) | 19.7k | Preferred component behavior tests; tests user-visible behavior. |
| Test runner | [vitest-dev/vitest](https://github.com/vitest-dev/vitest) | 17.4k | Preferred runner because the app uses Vite. |
| Network mocking | [mswjs/msw](https://github.com/mswjs/msw) | 18.4k | Preferred when remote API consumers are introduced. |
| Accessibility engine | [dequelabs/axe-core](https://github.com/dequelabs/axe-core) | 7.9k | Add to browser/component tests; automated checks do not replace manual review. MPL-2.0 requires license review. |
| Routing | [remix-run/react-router](https://github.com/remix-run/react-router) | 56.5k | Preferred migration target; no router dependency added without lockfile regeneration. |
| Alternative routing | [TanStack/router](https://github.com/TanStack/router) | 15.3k | Strong type-safe option, but no reason to introduce two routers. |
| Server-state cache | [TanStack/query](https://github.com/TanStack/query) | 50.6k | Preferred only after a real authenticated API exists. |
| Large forms | [react-hook-form/react-hook-form](https://github.com/react-hook-form/react-hook-form) | 44.9k | Appropriate for complex profile/nutrition forms; current custom meal editor remains small enough for controlled state. |
| Validation | [colinhacks/zod](https://github.com/colinhacks/zod) | 44.1k | Already present in the project; keep one validation system. |
| IndexedDB | [dexie/Dexie.js](https://github.com/dexie/Dexie.js) | 14.7k | Not adopted now: persistence volume is bounded and backup is synchronous. Revisit with measured quota/latency or offline query requirements. |
| Performance audit | [GoogleChrome/lighthouse](https://github.com/GoogleChrome/lighthouse) | 31k | Preferred repeatable lab audit after build/runtime is available. |

## Selection rules

- Do not install equivalent overlapping state libraries. Zustand remains client/UI state.
- TanStack Query is not a replacement for local Zustand state; it is for remote server state.
- Do not introduce Dexie solely because it is popular. It changes the persistence and backup model and must be migrated transactionally.
- Playwright and Vitest/RTL/MSW/axe-core complement each other; none replaces the existing domain regression suite.
- React Hook Form is reserved for large, high-field-count editors; the current meal form is intentionally small and local.
- Stars are approximate and should be refreshed before a future dependency decision.
