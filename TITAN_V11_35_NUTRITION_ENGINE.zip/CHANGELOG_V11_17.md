# TITAN V.MAX — V11.17.0

## Renderização óptica, plasma temporal e iluminação anatômica

### Implementado

- Dither espacial estável por interleaved-gradient hash (não blue-noise) nos shaders de fluido e energia para evitar deslocamento/crawl do grão entre quadros.
- Macros metálicos deixam de manter RAF por causa de um preenchimento estático; valor e tilt do ponteiro são animados somente durante transições reais.
- Inclinação do metal agora usa alvo separado e amortecimento exponencial curto, e o agendador encerra quando a interação estabiliza.
- Plasma usa envelope suave de ataque/release com energia zero no início/fim do ciclo.
- Caminhos irregulares dos raios usam interpolação cúbica suave entre segmentos espaciais.
- Ramificações preservam identidade espacial e recebem somente pequena curvatura temporal contínua.
- Faíscas usam uma grade espacial fixa, seeds persistentes, drift suave e envelope de vida.
- Normal de anatomia usa transformação inversa-transposta do modelo.
- Back-scattering da pele usa normal, fonte traseira e visão no mesmo espaço mundial.
- Termo de backscatter usa paleta biológica quente fora do modo holográfico, preservando cores do holograma.
- Rig de luz do corpo foi simplificado para key/fill/rim discretos e softboxes; removido kicker extra.
- Mantido o único halo difuso atrás do corpo. Não há plano/plinto ou iluminação projetada no chão.
- Adicionado `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_17.md`, com pesquisa GitHub Top 5 por domínio, tecnologias, licenças e itens que continuam abertos.
- Adicionado o gate estático `scripts/check-rendering-realism-v11-17.mjs` à cadeia de testes e ao comando `npm run test:rendering-realism`.

### Deliberadamente não feito

- Sem novas dependências runtime.
- Sem solver SPH/FFT de oceano, sem partículas massivas e sem novo motor de renderização.
- Sem importação de atlas/modelos anatômicos até completar verificação de licenças dos dados/ativos, topologia e mapeamento para os IDs do TITAN.
- Sem afirmar SSS fisiologicamente completo: o termo atual é uma aproximação direcional de backscatter.
- Sem afirmar que a tabela de condutores atual usa medições espectrais reais de prata/ouro/cromo; ainda é uma aproximação derivada das cores do material.

### Integridade do pacote

- O ZIP enviado preservou seis arquivos exclusivos desta atualização. Foram restaurados 133 arquivos da base V11.16.0 anterior que estavam ausentes do upload, sem sobrescrever qualquer arquivo do ZIP atual.

### Validação

- Passaram: `node scripts/check-fluid-shaders.mjs`, `node scripts/check-cockpit-visual-semantics.mjs` e `node scripts/check-rendering-realism-v11-17.mjs`.
- Build/typecheck completos não foram executados porque o pacote não inclui `node_modules` nem `package-lock.json`; `npm install` excedeu o limite de execução disponível.
- `scripts/check-dual-body-anatomy.mjs` não avançou porque o ambiente não possui a dependência externa `three` instalada.
- Compilação de shader na GPU e revisão de FPS/screenshot em dispositivos físicos permanecem pendentes.
